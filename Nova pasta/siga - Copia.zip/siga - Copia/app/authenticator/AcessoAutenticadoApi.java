package authenticator;

import infra.jwt.Token;
import play.mvc.Http.Context;
import play.mvc.Result;
import play.mvc.Security.Authenticator;

import java.util.Optional;

import static infra.jwt.Token.INFO_TOKEN;
import static infra.util.UtilException.getException;
import static infra.util.UtilString.isVazia;
import static java.lang.String.valueOf;

/**
 * Autenticação basica do Play.
 */
public class AcessoAutenticadoApi extends Authenticator {

    /**
     * Verifica token
     *
     * @param ctx   Contexto da requisição.
     *
     * @return null se falhou autenticação e o contrário se passou!!
     */
    @Override
    public String getUsername( final Context ctx ) {

        return getTokenFromHeader( ctx )
            .map( Token::decode )
            .filter( Optional::isPresent )
            .map( Optional::get )
            .map( infoToken -> {
                ctx.args.put( INFO_TOKEN, infoToken );
                return ( isVazia( infoToken.getMsgInconsistencia()) )
                        ? valueOf( infoToken.getIdUsuario() ) : null;
            })
            .orElse( null );
    }

    private Optional<String> getTokenFromHeader( final Context ctx ) {

        final Optional<String> possivelToken = getTokenBearer(ctx);
        if ( possivelToken.isPresent() )
            return possivelToken;

        // Acesso externo.
        return ctx.request().header("Application-Authorization" );
    }

    private Optional<String> getTokenBearer( final Context ctx ) {

        final String AuthorizationType = "Bearer";

        return ctx
            .request()
            .header("Authorization" )
            .filter( header -> header.startsWith( AuthorizationType ) )
            .map( header -> header.substring( AuthorizationType.length() + 1 ) );
    }

    /**
     * Retorno da falha de autenticação.
     *
     * @param ctx Contexto da requisição.
     *
     * @return Status request
     */
    @Override
    public Result onUnauthorized( final Context ctx ) {

        return unauthorized( getException(
            ctx.args.containsKey( INFO_TOKEN )
                ? ((Token.Value) ctx.args.get( INFO_TOKEN )).getMsgInconsistencia()
                : "Acesso não autorizado"
        ));
    }
}
