package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;

public class DiaSemanaDto implements Serializable {
    private final String diaSemana;
    private final LocalDateTime horarioRoteirizacao;

    public DiaSemanaDto(String diaSemana, LocalDateTime horarioRoteirizacao) {
        this.diaSemana = diaSemana;
        this.horarioRoteirizacao = horarioRoteirizacao;
    }

    public String getDiaSemana() {
        return diaSemana;
    }

    public LocalDateTime getHorarioRoteirizacao() {
        return horarioRoteirizacao;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DiaSemanaDto that = (DiaSemanaDto) o;
        return Objects.equals(diaSemana, that.diaSemana) &&
                Objects.equals(horarioRoteirizacao, that.horarioRoteirizacao);
    }

    @Override
    public int hashCode() {
        return Objects.hash(diaSemana, horarioRoteirizacao);
    }
}
