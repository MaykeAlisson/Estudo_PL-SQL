package models.commons.dtos;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import models.commons.constantes.TipoLiberacao;
import models.commons.constantes.TipoLiberacaoDeserializer;
import models.commons.constantes.TipoLiberacaoSerializer;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Objects;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe que representa informações...
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 09/04/2018
 *
 * <p>Manutenção: Andre Luiz Alves de Faria - 07/2018 </p>
 */
public class LiberacaoAntecipacaoDto implements Serializable {

    @JsonProperty( "balanca" )
    private final String balanca;

    @JsonProperty( "box" )
    private final String box;

    @JsonProperty( "tipoLiberacao" )
    @JsonSerialize( using = TipoLiberacaoSerializer.class )
    @JsonDeserialize( using = TipoLiberacaoDeserializer.class )
    private final TipoLiberacao tipoLiberacao;

    @JsonProperty( "qtdPendSeparacao" )
    private final Long qtdPendSeparacao;

    @JsonProperty( "qtdPendLiberacao" )
    private final Long qtdPendLiberacao;

    @JsonProperty( "sequenciaBaixa" )
    private final Long sequenciaBaixa;

    @JsonProperty( "qtdLiberacaoParcial" )
    private final Long qtdLiberacaoParcial;

    @JsonProperty( "idCarga" )
    private final Long idCarga;

    @JsonProperty( "boxCarregamento" )
    private final String boxCarregamento;

    @JsonProperty( "capaLiberacao" )
    private final String capaLiberacao;


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CONSTRUCTOR
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @JsonCreator
    public LiberacaoAntecipacaoDto(
        final String balanca,
        final String box,
        final Short tipoLiberacao,
        final Long qtdPendSeparacao,
        final Long qtdPendLiberacao,
        final Long sequenciaBaixa,
        final Long qtdLiberacaoParcial,
        final Long idCarga,
        final String boxCarregamento,
        final String capaLiberacao
    ) {

        this.balanca = balanca;
        this.box = box;
        this.tipoLiberacao = getEnum( TipoLiberacao.class, tipoLiberacao );
        this.qtdPendSeparacao = qtdPendSeparacao;
        this.qtdPendLiberacao = qtdPendLiberacao;
        this.sequenciaBaixa   = sequenciaBaixa;
        this.qtdLiberacaoParcial = qtdLiberacaoParcial;
        this.idCarga = idCarga;
        this.boxCarregamento = boxCarregamento;
        this.capaLiberacao = capaLiberacao;
    }

    public LiberacaoAntecipacaoDto(
        @NotNull final LiberacaoAntecipacaoDto dto,
        final Long qtdLiberacaoParcial
    ) {

        this(
            dto.getBalanca(),
            dto.getBox(),
            getValor( dto.getTipoLiberacao() ),
            dto.getQtdPendSeparacao(),
            dto.getQtdPendLiberacao(),
            dto.getSequenciaBaixa(),
            qtdLiberacaoParcial,
            dto.getIdCarga(),
            dto.getBoxCarregamento(),
            dto.getCapaLiberacao()
        );
    }

    public LiberacaoAntecipacaoDto (
        final String balanca,
        final String box,
        final Short tipoLiberacao,
        final Long idCarga,
        final String boxCarregamento,
        final Long qtdPendSeparacao,
        final Long qtdPendLiberacao,
        final Long sequenciaBaixa
    ) {

        this(
            balanca,
            box,
            tipoLiberacao,
            qtdPendSeparacao,
            qtdPendLiberacao,
            sequenciaBaixa,
            null,
            idCarga,
            boxCarregamento,
            null
        );
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // GETTERS
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public String getBalanca() {

        return balanca;
    }

    public String getBox() {

        return box;
    }

    public TipoLiberacao getTipoLiberacao() {

        return tipoLiberacao;
    }

    public Long getQtdPendSeparacao() {

        return qtdPendSeparacao;
    }

    public Long getQtdPendLiberacao() {

        return qtdPendLiberacao;
    }

    public Long getQtdLiberacaoParcial() {

        return qtdLiberacaoParcial;
    }

    public Long getIdCarga() {

        return idCarga;
    }

    public String getBoxCarregamento() {

        return boxCarregamento;
    }

    public String getCapaLiberacao() {

        return capaLiberacao;
    }

    public Long getSequenciaBaixa() {
        return sequenciaBaixa;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASCODE
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LiberacaoAntecipacaoDto that = (LiberacaoAntecipacaoDto) o;
        return Objects.equals(balanca, that.balanca) &&
                Objects.equals(box, that.box) &&
                tipoLiberacao == that.tipoLiberacao &&
                Objects.equals(qtdPendSeparacao, that.qtdPendSeparacao) &&
                Objects.equals(qtdPendLiberacao, that.qtdPendLiberacao) &&
                Objects.equals(sequenciaBaixa, that.sequenciaBaixa) &&
                Objects.equals(qtdLiberacaoParcial, that.qtdLiberacaoParcial) &&
                Objects.equals(idCarga, that.idCarga) &&
                Objects.equals(boxCarregamento, that.boxCarregamento) &&
                Objects.equals(capaLiberacao, that.capaLiberacao);
    }

    @Override
    public int hashCode() {
        return Objects.hash(balanca, box, tipoLiberacao, qtdPendSeparacao, qtdPendLiberacao, sequenciaBaixa,
                            qtdLiberacaoParcial, idCarga, boxCarregamento, capaLiberacao);
    }
}
