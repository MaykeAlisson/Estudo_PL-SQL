package models.commons.dtos;

import models.commons.constantes.Estado;

import java.io.Serializable;

import static java.lang.String.format;

/**
 * Classe que representa informações sobre cidades
 *
 * <p>Autor: GPortes</p>
 *
 * @since 23/11/2015
 */
public class CidadeDto implements Serializable {

    private final Short idCidade;
    private final Short idDistrito;
    private final String descricao;
    private final Estado estado;
    private final String codigo;
    private final String uf;
    private final String descricaoCompletaCidade;

    public CidadeDto( final Short idCidade,
                      final Short idDistrito,
                      final String descricao,
                      final Estado estado ) {

        this.idCidade = idCidade;
        this.idDistrito = idDistrito;
        this.descricao = descricao;
        this.estado = estado;

        this.codigo = format( "%s.%s", idCidade, idDistrito );
        this.uf = estado != null ? estado.getValor() : "";
        this.descricaoCompletaCidade = descricao + " (" + this.uf + ")";
    }

    public Short getIdCidade() {

        return idCidade;
    }

    public Short getIdDistrito( ) {

        return idDistrito;
    }

    public String getDescricao() {

        return descricao;
    }

    public Estado getEstado() {

        return estado;
    }

    public String getCodigo( ) {

        return codigo;
    }

    public String getUf( ) {

        return uf;
    }

    public String getDescricaoCompletaCidade() {

        return descricaoCompletaCidade;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object o ) {
        if ( this == o ) return true;
        if ( o == null || getClass() != o.getClass() ) return false;

        CidadeDto cidadeDto = (CidadeDto) o;

        return !( getIdCidade() != null ? !getIdCidade().equals( cidadeDto.getIdCidade() ) : cidadeDto.getIdCidade() != null );

    }

    @Override
    public int hashCode() {
        return getIdCidade() != null ? getIdCidade().hashCode() : 0;
    }

    @Override
    public String toString() {

        return "CidadeDto { idCidade=" + getIdCidade() + " }";
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}