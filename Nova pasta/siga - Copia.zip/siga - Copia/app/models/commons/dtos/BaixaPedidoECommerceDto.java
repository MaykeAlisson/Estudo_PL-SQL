package models.commons.dtos;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import models.commons.constantes.OperacaoBaixaECommerce;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe que representa informações...
 *
 * <p>Autor: Victor.serafim</p>
 *
 * @since 19/01/2019
 */
@JsonIgnoreProperties( ignoreUnknown = true )
public class BaixaPedidoECommerceDto implements Serializable {

    private final Long idBaixaECommerce;
    private final BigDecimal vlrBruto;
    private final BigDecimal vlrLiquido;
    private final BigDecimal vlrTaxa;
    private final OperacaoBaixaECommerce operacao;
    private final Long version;
    private final String idPedidoOrigem;
    private final BigDecimal vlrPedido;
    private final Long idCliente;
    private final String razaoSocial;
    private final String observacao;
    private final String nroTransacao;

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CONSTRUCTOR
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @JsonCreator
    public BaixaPedidoECommerceDto(
        @JsonProperty( "idBaixaECommerce" ) final Long idBaixaECommerce,
        @JsonProperty( "version" ) final Long version
    ) {

        this(
          idBaixaECommerce,
          null,
          null,
          null,
          null,
          version,
          null,
          null,
          null,
          null,
          null,
          null);
    }

    public BaixaPedidoECommerceDto(
            final Long idBaixaECommerce,
            final BigDecimal vlrBruto,
            final BigDecimal vlrLiquido,
            final BigDecimal vlrTaxa,
            final Short operacao,
            final Long version,
            final String idPedidoOrigem,
            final BigDecimal vlrPedido,
            final Long idCliente,
            final String razaoSocial,
            final String observacao,
            final String nroTransacao) {

        this.idBaixaECommerce = idBaixaECommerce;
        this.vlrBruto = vlrBruto;
        this.vlrLiquido = vlrLiquido;
        this.vlrTaxa = vlrTaxa;
        this.operacao = getEnum(OperacaoBaixaECommerce.class,operacao);
        this.version = version;
        this.idPedidoOrigem = idPedidoOrigem;
        this.vlrPedido = vlrPedido;
        this.idCliente = idCliente;
        this.razaoSocial = razaoSocial;
        this.observacao = observacao;
        this.nroTransacao = nroTransacao;
    }

    @JsonProperty( "idBaixaECommerce" )
    public Long getIdBaixaECommerce() {

        return this.idBaixaECommerce;
    }

    @JsonProperty( "vlrBruto" )
    public BigDecimal getVlrBruto() {

        return this.vlrBruto;
    }

    @JsonProperty( "vlrLiquido" )
    public BigDecimal getVlrLiquido() {

        return this.vlrLiquido;
    }

    @JsonProperty( "vlrTaxa" )
    public BigDecimal getVlrTaxa() {

        return this.vlrTaxa;
    }

    @JsonProperty( "operacao" )
    public OperacaoBaixaECommerce getOperacao() {

        return operacao;
    }

    @JsonProperty( "version" )
    public Long getVersion() {

        return version;
    }

    @JsonProperty( "idPedidoOrigem" )
    public String getIdPedidoOrigem() {

        return idPedidoOrigem;
    }

    @JsonProperty( "vlrPedido" )
    public BigDecimal getVlrPedido() {

        return this.vlrPedido;
    }

    @JsonProperty( "idCliente" )
    public Long getIdCliente() {

        return this.idCliente;
    }

    @JsonProperty( "razaoSocial" )
    public String getRazaoSocial() {

        return this.razaoSocial;
    }

    @JsonProperty( "observacao" )
    public String getObservacao() {

        return observacao;
    }

    @JsonProperty( "nro_transacao" )
    public String getNroTransacao() {

        return nroTransacao;
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BaixaPedidoECommerceDto that = (BaixaPedidoECommerceDto) o;
        return Objects.equals(idBaixaECommerce, that.idBaixaECommerce);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idBaixaECommerce);
    }
}




