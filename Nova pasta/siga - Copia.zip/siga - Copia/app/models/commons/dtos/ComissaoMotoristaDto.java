package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

/**
 * Classe que representa informações de volume transportado por viagem e cda
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 31/05/2016
 */
public class ComissaoMotoristaDto implements Serializable {

    private Short idEmpresa;
    private Long idFuncionario;
    private Long idViagem;
    private Short idCda;
    private BigDecimal valorComissao;
    private BigDecimal fator;

    public ComissaoMotoristaDto(Short idEmpresa, Long idFuncionario, Long idViagem, Short idCda, BigDecimal valorComissao, BigDecimal fator) {
        this.idEmpresa = idEmpresa;
        this.idFuncionario = idFuncionario;
        this.idViagem = idViagem;
        this.idCda = idCda;
        this.valorComissao = valorComissao;
        this.fator = fator;
    }

    public Short getIdEmpresa() {
        return idEmpresa;
    }

    public void setIdEmpresa(Short idEmpresa) {
        this.idEmpresa = idEmpresa;
    }

    public Long getIdFuncionario() {
        return idFuncionario;
    }

    public void setIdFuncionario(Long idFuncionario) {
        this.idFuncionario = idFuncionario;
    }

    public Short getIdCda() {
        return idCda;
    }

    public void setIdCda(Short idCda) {
        this.idCda = idCda;
    }

    public BigDecimal getValorComissao() {
        return valorComissao;
    }

    public void setValorComissao(BigDecimal valorComissao) {
        this.valorComissao = valorComissao;
    }

    public BigDecimal getFator() {
        return fator;
    }

    public void setFator(BigDecimal fator) {
        this.fator = fator;
    }

    public Long getIdViagem() {
        return idViagem;
    }

    public void setIdViagem(Long idViagem) {
        this.idViagem = idViagem;
    }

    @Override
    public String toString() {
        return "ComissaoMotoristaDto{" +
                "idEmpresa=" + idEmpresa +
                ", idFuncionario=" + idFuncionario +
                ", idViagem=" + idViagem +
                ", idCda=" + idCda +
                ", valorComissao=" + valorComissao +
                ", fator=" + fator +
                '}';
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ComissaoMotoristaDto)) return false;
        ComissaoMotoristaDto that = (ComissaoMotoristaDto) o;
        return Objects.equals(getIdEmpresa(), that.getIdEmpresa()) &&
                Objects.equals(getIdFuncionario(), that.getIdFuncionario()) &&
                Objects.equals(getIdViagem(), that.getIdViagem()) &&
                Objects.equals(getIdCda(), that.getIdCda());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdEmpresa(), getIdFuncionario(), getIdViagem(), getIdCda());
    }
}


