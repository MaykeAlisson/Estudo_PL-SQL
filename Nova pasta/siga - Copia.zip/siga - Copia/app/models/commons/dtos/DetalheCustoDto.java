package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Classe que representa informações...
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 23/11/2016
 */
public class DetalheCustoDto implements Serializable {

    private final Long id;
    private final Short idEmpresa;
    private final Short idCda;
    private final Short idCdaConsolidado;
    private final BigDecimal valor;
    private final String idAtividade;
    private final String idSubGrupo;
    private final String idTipoAlocacao;
    private final Long idControleCusto;
    private final BigDecimal cpfFuncionario;
    private final BigDecimal cnpjCliente;
    private final BigDecimal cnpjFornecedor;
    private final BigDecimal cpfCnpjRepresentante;
    private final Short idVeiculo;
    private final String chave1;
    private final String identificador1;
    private final String chave2;
    private final String identificador2;
    private final String chave3;
    private final String identificador3;
    private final String chave4;
    private final String identificador4;
    private final String chave5;
    private final String identificador5;
    private final String chave6;
    private final String identificador6;
    private final String chave7;
    private final String identificador7;
    private final String chave8;
    private final String identificador8;
    private final String chave9;
    private final String identificador9;
    private final String chave10;
    private final String identifiador10;
    private final String chave11;
    private final String identificador11;
    private final String chave12;
    private final String identificador12;
    private final Long controleCstCliente;
    private final String descricaoRateio;
    private final String criterioRateio;

    public DetalheCustoDto( final Long id,
                            final Short idEmpresa,
                            final Short idCda,
                            final Short idCdaConsolidado,
                            final BigDecimal valor,
                            final String idAtividade,
                            final String idSubGrupo,
                            final String idTipoAlocacao,
                            final Long idControleCusto,
                            final BigDecimal cpfFuncionario,
                            final BigDecimal cnpjCliente,
                            final BigDecimal cnpjFornecedor,
                            final BigDecimal cpfCnpjRepresentante,
                            final Short idVeiculo,
                            final String chave1,
                            final String identificador1,
                            final String chave2,
                            final String identificador2,
                            final String chave3,
                            final String identificador3,
                            final String chave4,
                            final String identificador4,
                            final String chave5,
                            final String identificador5,
                            final String chave6,
                            final String identificador6,
                            final String chave7,
                            final String identificador7,
                            final String chave8,
                            final String identificador8,
                            final String chave9,
                            final String identificador9,
                            final String chave10,
                            final String identifiador10,
                            final String chave11,
                            final String identificador11,
                            final String chave12,
                            final String identificador12,
                            final Long controleCstCliente,
                            final String descricaoRateio,
                            final String criterioRateio ) {

        this.id = id;
        this.idEmpresa = idEmpresa;
        this.idCda = idCda;
        this.idCdaConsolidado = idCdaConsolidado;
        this.valor = valor;
        this.idAtividade = idAtividade;
        this.idSubGrupo = idSubGrupo;
        this.idTipoAlocacao = idTipoAlocacao;
        this.idControleCusto = idControleCusto;
        this.cpfFuncionario = cpfFuncionario;
        this.cnpjCliente = cnpjCliente;
        this.cnpjFornecedor = cnpjFornecedor;
        this.cpfCnpjRepresentante = cpfCnpjRepresentante;
        this.idVeiculo = idVeiculo;
        this.chave1 = chave1;
        this.identificador1 = identificador1;
        this.chave2 = chave2;
        this.identificador2 = identificador2;
        this.chave3 = chave3;
        this.identificador3 = identificador3;
        this.chave4 = chave4;
        this.identificador4 = identificador4;
        this.chave5 = chave5;
        this.identificador5 = identificador5;
        this.chave6 = chave6;
        this.identificador6 = identificador6;
        this.chave7 = chave7;
        this.identificador7 = identificador7;
        this.chave8 = chave8;
        this.identificador8 = identificador8;
        this.chave9 = chave9;
        this.identificador9 = identificador9;
        this.chave10 = chave10;
        this.identifiador10 = identifiador10;
        this.chave11 = chave11;
        this.identificador11 = identificador11;
        this.chave12 = chave12;
        this.identificador12 = identificador12;
        this.controleCstCliente = controleCstCliente;
        this.descricaoRateio = descricaoRateio;
        this.criterioRateio = criterioRateio;
    }

    public Long getId() {

        return id;
    }

    public Short getIdEmpresa() {

        return idEmpresa;
    }

    public Short getIdCda() {

        return idCda;
    }

    public Short getIdCdaConsolidado() {

        return idCdaConsolidado;
    }

    public BigDecimal getValor() {

        return valor;
    }

    public String getIdAtividade() {

        return idAtividade;
    }

    public String getIdSubGrupo() {

        return idSubGrupo;
    }

    public String getIdTipoAlocacao() {

        return idTipoAlocacao;
    }

    public Long getIdControleCusto() {

        return idControleCusto;
    }

    public BigDecimal getCpfFuncionario() {

        return cpfFuncionario;
    }

    public BigDecimal getCnpjCliente() {

        return cnpjCliente;
    }

    public BigDecimal getCnpjFornecedor() {

        return cnpjFornecedor;
    }

    public BigDecimal getCpfCnpjRepresentante() {

        return cpfCnpjRepresentante;
    }

    public Short getIdVeiculo() {

        return idVeiculo;
    }

    public String getChave1() {

        return chave1;
    }

    public String getIdentificador1() {

        return identificador1;
    }

    public String getChave2() {

        return chave2;
    }

    public String getIdentificador2() {

        return identificador2;
    }

    public String getChave3() {

        return chave3;
    }

    public String getIdentificador3() {

        return identificador3;
    }

    public String getChave4() {

        return chave4;
    }

    public String getIdentificador4() {

        return identificador4;
    }

    public String getChave5() {

        return chave5;
    }

    public String getIdentificador5() {

        return identificador5;
    }

    public String getChave6() {

        return chave6;
    }

    public String getIdentificador6() {

        return identificador6;
    }

    public String getChave7() {

        return chave7;
    }

    public String getIdentificador7() {

        return identificador7;
    }

    public String getChave8() {

        return chave8;
    }

    public String getIdentificador8() {

        return identificador8;
    }

    public String getChave9() {

        return chave9;
    }

    public String getIdentificador9() {

        return identificador9;
    }

    public String getChave10() {

        return chave10;
    }

    public String getIdentifiador10() {

        return identifiador10;
    }

    public String getChave11() {

        return chave11;
    }

    public String getIdentificador11() {

        return identificador11;
    }

    public String getChave12() {

        return chave12;
    }

    public String getIdentificador12() {

        return identificador12;
    }

    public Long getControleCstCliente() {

        return controleCstCliente;
    }

    public String getDescricaoRateio() {

        return descricaoRateio;
    }

    public String getCriterioRateio() {

        return criterioRateio;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object obj ) {

        if ( this == obj ) return true;
        if ( obj == null || getClass() != obj.getClass() ) return false;
        DetalheCustoDto that  = (DetalheCustoDto) obj;
        if ( getId() != null ? !getId().equals( that.getId() ) : that.getId() != null ) return false;
        return true;
    }

    @Override
    public int hashCode() {

        return ( getId() != null ? getId().hashCode() : 0 );
    }

    @Override
    public String toString() {

        return "DetalheCustoDto { id = " + id + " }";
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}


