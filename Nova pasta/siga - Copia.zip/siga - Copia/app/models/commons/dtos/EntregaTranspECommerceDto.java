package models.commons.dtos;

import models.ws.total.TotalEncomenda;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;

import static infra.util.UtilDate.toLocalDateTime;
import static infra.util.UtilString.isVazia;

/**
 * Classe que representa informações...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 09/05/2019
 */
public class EntregaTranspECommerceDto implements Serializable, TotalEncomenda {

    private final Long idPedidoEcommerce;
    private final Long nfSaida;
    private final String serieNf;
    private final LocalDateTime dataEmissaoNf;
    private final BigDecimal valor;
    private final String chaveAcessoNfe;
    private final Short cfopPredominante;
    private final Long qtdVolumes;
    private final String nomeDestinatarioEntrega;
    private final Long nroInscricao;
    private final String endereco;
    private final String nroEndereco;
    private final String complementoEndereco;
    private final String enderecoReferencia;
    private final String bairro;
    private final String descricaoCidade;
    private final String estado;
    private final Long cep;


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CONSTRUCTOR
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public EntregaTranspECommerceDto(
        final Long idPedidoEcommerce,
        final Long nfSaida,
        final String serieNf,
        final java.util.Date dataEmissaoNf,
        final BigDecimal valor,
        final String chaveAcessoNfe,
        final Short cfopPredominante,
        final Long qtdVolumes,
        final String nomeDestinatarioEntrega,
        final Long nroInscricao,
        final String logradouro,
        final String endereco,
        final String nroEndereco,
        final String complementoEndereco,
        final String enderecoReferencia,
        final String bairro,
        final String descricaoCidade,
        final String estado,
        final Long cep
    ) {

        this.idPedidoEcommerce = idPedidoEcommerce;
        this.nfSaida = nfSaida;
        this.serieNf = serieNf;
        this.dataEmissaoNf = toLocalDateTime( dataEmissaoNf );
        this.valor = valor;
        this.chaveAcessoNfe = chaveAcessoNfe;
        this.cfopPredominante = cfopPredominante;
        this.qtdVolumes = qtdVolumes;
        this.nomeDestinatarioEntrega = nomeDestinatarioEntrega;
        this.nroInscricao = nroInscricao;
        this.endereco = isVazia(logradouro) ? endereco : logradouro.concat(" ").concat(endereco);
        this.nroEndereco = nroEndereco;
        this.complementoEndereco = complementoEndereco;
        this.enderecoReferencia = enderecoReferencia;
        this.bairro = bairro;
        this.estado = estado;
        this.descricaoCidade = descricaoCidade;
        this.cep = cep;
    }

    public EntregaTranspECommerceDto(
        final Long idPedidoEcommerce,
        final Long nfSaida,
        final String serieNf,
        final java.util.Date dataEmissaoNf,
        final BigDecimal valor,
        final String chaveAcessoNfe,
        final Long qtdVolumes,
        final String nomeDestinatarioEntrega,
        final Long nroInscricao,
        final String logradouro,
        final String endereco,
        final String nroEndereco,
        final String complementoEndereco,
        final String enderecoReferencia,
        final String bairro,
        final String descricaoCidade,
        final String estado,
        final Long cep
    ) {

        this.idPedidoEcommerce = idPedidoEcommerce;
        this.nfSaida = nfSaida;
        this.serieNf = serieNf;
        this.dataEmissaoNf = toLocalDateTime( dataEmissaoNf );
        this.valor = valor;
        this.chaveAcessoNfe = chaveAcessoNfe;
        this.cfopPredominante = null;
        this.qtdVolumes = qtdVolumes;
        this.nomeDestinatarioEntrega = nomeDestinatarioEntrega;
        this.nroInscricao = nroInscricao;
        this.endereco = isVazia(logradouro) ? endereco : logradouro.concat(" ").concat(endereco);
        this.nroEndereco = nroEndereco;
        this.complementoEndereco = complementoEndereco;
        this.enderecoReferencia = enderecoReferencia;
        this.bairro = bairro;
        this.estado = estado;
        this.descricaoCidade = descricaoCidade;
        this.cep = cep;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // GETTERS
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public Long getIdPedido() {

        return this.idPedidoEcommerce;
    }

    @Override
    public String getNomeDestinatario() {

        return this.nomeDestinatarioEntrega;
    }

    @Override
    public Long getNroInscricao() {

        return this.nroInscricao;
    }

    @Override
    public String getEndereco() {

        return this.endereco;
    }

    @Override
    public String getNroEndereco() {

        return this.nroEndereco;
    }


    @Override
    public String getComplemento() {

        return this.complementoEndereco;
    }

    @Override
    public String getPontoReferencia() {

        return this.enderecoReferencia;
    }

    @Override
    public String getBairro() {

        return this.bairro;
    }

    @Override
    public String getCidade() {

        return this.descricaoCidade;
    }

    @Override
    public String getEstado() {

        return this.estado;
    }

    public Long getCep() {

        return this.cep;
    }

    @Override
    public Long getIdNf() {

        return this.nfSaida;
    }

    @Override
    public String getSerieNf() {

        return this.serieNf;
    }

    @Override
    public LocalDateTime getDataEmissaoNf() {

        return this.dataEmissaoNf;
    }

    @Override
    public BigDecimal getValorNf() {

        return this.valor;
    }

    @Override
    public String getChaveAcessoNf() {

        return this.chaveAcessoNfe;
    }

    @Override
    public Short getCfopPredominante() {

        return this.cfopPredominante;
    }

    @Override
    public Long getQtdVolumesNf() {

        return this.qtdVolumes;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object o ) {

        if ( this == o ) return true;
        if ( !(o instanceof EntregaTranspECommerceDto) ) return false;
        EntregaTranspECommerceDto that = (EntregaTranspECommerceDto) o;
        return  Objects.equals(idPedidoEcommerce, that.idPedidoEcommerce) &&
            Objects.equals(chaveAcessoNfe, that.chaveAcessoNfe);
    }

    @Override
    public int hashCode() {

        return Objects.hash(idPedidoEcommerce, chaveAcessoNfe);
    }
}