package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Objects;

import static infra.util.UtilDate.toLocalDate;
import static infra.util.UtilDate.toLocalDateTime;

/**
 * DTO que representa informações da procedure fisco.dbo.up_esocial_cat
 *
 * <p>Autor: Silas Andrade</p>
 *
 * @since 13/05/2019
 */
public class ComunicadoAcidenteTrabalhoDto implements Serializable {

    private final Long idCatSia;
    private final Short idEmpresa;
    private final Short tipoPessoa;
    private final BigDecimal cnpj;
    private final Long matricula;
    private final BigDecimal cpfTrab;
    private final BigDecimal pisPasep;
    private final Short categoriaTrabalhador;
    private final LocalDate dataAcidente;
    private final String tipoAcidente;
    private final String horaAcidente;
    private final String  horasTrabAntesAcidente;
    private final Short tipoCat;
    private final String indCatObito;
    private final LocalDate dataObito;
    private final String indComunPolicia;
    private final String codSitGeradora;
    private final String iniciativaCat;
    private final String obsCat;
    private final String tipoLocalAcidente;
    private final String descLocalAcidente;
    private final String codAmbienteAcidente;
    private final String tipoLogradouroAcidente;
    private final String descLogradouroAcidente;
    private final String nroLogradouroAcidente;
    private final String complLogradouroAcidente;
    private final String bairroAcidente;
    private final Long cepAcidente;
    private final Long municipioAcidente;
    private final String ufAcidente;
    private final Short paisAcidente;
    private final String codPostal;
    private final String tipoPessoaLocalAcidente;
    private final BigDecimal cnpjLocalAcidente;
    private final String codCnesAtestado;
    private final LocalDateTime dataAtendimentoAtestado;
    private final String horaAtendimentoAtestado;
    private final String indInternacao;
    private final Long diasDuracaoTratamento;
    private final String indAfastamento;
    private final String descLesao;
    private final String descComplLesao;
    private final String diagnosticoProvavel;
    private final String codCid;
    private final String obsAtestado;
    private final String nomeEmitenteAtestado;
    private final Short idOrgaoClasse;
    private final BigDecimal inscricaoOrgaoClasse;
    private final String ufOrgaoClasse;
    private final String reciboCatOrigem;
    private final String temVinculo;


    public ComunicadoAcidenteTrabalhoDto(
            final Long idCatSia,
            final Short idEmpresa,
            final Short tipoPessoa,
            final BigDecimal cnpj,
            final Long matricula,
            final BigDecimal cpfTrab,
            final BigDecimal pisPasep,
            final Short categoriaTrabalhador,
            final Date dataAcidente,
            final String tipoAcidente,
            final String horaAcidente,
            final String horasTrabAntesAcidente,
            final Short tipoCat,
            final String indCatObito,
            final Date dataObito,
            final String indComunPolicia,
            final String codSitGeradora,
            final String iniciativaCat,
            final String obsCat,
            final String tipoLocalAcidente,
            final String descLocalAcidente,
            final String codAmbienteAcidente,
            final String tipoLogradouroAcidente,
            final String descLogradouroAcidente,
            final String nroLogradouroAcidente,
            final String complLogradouroAcidente,
            final String bairroAcidente,
            final Long cepAcidente,
            final Long municipioAcidente,
            final String ufAcidente,
            final Short paisAcidente,
            final String codPostal,
            final String tipoPessoaLocalAcidente,
            final BigDecimal cnpjLocalAcidente,
            final String codCnesAtestado,
            final Date dataAtendimentoAtestado,
            final String horaAtendimentoAtestado,
            final String indInternacao,
            final Long diasDuracaoTratamento,
            final String indAfastamento,
            final String descLesao,
            final String descComplLesao,
            final String diagnosticoProvavel,
            final String codCid,
            final String obsAtestado,
            final String nomeEmitenteAtestado,
            final Short idOrgaoClasse,
            final BigDecimal inscricaoOrgaoClasse,
            final String ufOrgaoClasse,
            final String reciboCatOrigem,
            final String temVinculo) {

        this.idCatSia = idCatSia;
        this.idEmpresa = idEmpresa;
        this.tipoPessoa = tipoPessoa;
        this.cnpj = cnpj;
        this.matricula = matricula;
        this.cpfTrab = cpfTrab;
        this.pisPasep = pisPasep;
        this.categoriaTrabalhador = categoriaTrabalhador;
        this.dataAcidente = toLocalDate( dataAcidente );
        this.tipoAcidente = tipoAcidente;
        this.horaAcidente = horaAcidente;
        this.horasTrabAntesAcidente =  horasTrabAntesAcidente;
        this.tipoCat = tipoCat;
        this.indCatObito = indCatObito;
        this.dataObito = toLocalDate(dataObito);
        this.indComunPolicia = indComunPolicia;
        this.codSitGeradora = codSitGeradora;
        this.iniciativaCat = iniciativaCat;
        this.obsCat = obsCat;
        this.tipoLocalAcidente = tipoLocalAcidente;
        this.descLocalAcidente = descLocalAcidente;
        this.codAmbienteAcidente = codAmbienteAcidente;
        this.tipoLogradouroAcidente = tipoLogradouroAcidente;
        this.descLogradouroAcidente = descLogradouroAcidente;
        this.nroLogradouroAcidente = nroLogradouroAcidente;
        this.complLogradouroAcidente = complLogradouroAcidente;
        this.bairroAcidente = bairroAcidente;
        this.cepAcidente = cepAcidente;
        this.municipioAcidente = municipioAcidente;
        this.ufAcidente = ufAcidente;
        this.paisAcidente = paisAcidente;
        this.codPostal = codPostal;
        this.tipoPessoaLocalAcidente = tipoPessoaLocalAcidente;
        this.cnpjLocalAcidente = cnpjLocalAcidente;
        this.codCnesAtestado = codCnesAtestado;
        this.dataAtendimentoAtestado = toLocalDateTime(dataAtendimentoAtestado);
        this.horaAtendimentoAtestado = horaAtendimentoAtestado;
        this.indInternacao = indInternacao;
        this.diasDuracaoTratamento = diasDuracaoTratamento;
        this.indAfastamento = indAfastamento;
        this.descLesao = descLesao;
        this.descComplLesao = descComplLesao;
        this.diagnosticoProvavel = diagnosticoProvavel;
        this.codCid = codCid;
        this.obsAtestado = obsAtestado;
        this.nomeEmitenteAtestado = nomeEmitenteAtestado;
        this.idOrgaoClasse = idOrgaoClasse;
        this.inscricaoOrgaoClasse = inscricaoOrgaoClasse;
        this.ufOrgaoClasse = ufOrgaoClasse;
        this.reciboCatOrigem = reciboCatOrigem;
        this.temVinculo = temVinculo;
    }

    public Long getIdCatSia() {
        return idCatSia;
    }

    public Short getIdEmpresa() {
        return idEmpresa;
    }

    public Short getTipoPessoa() {
        return tipoPessoa;
    }

    public BigDecimal getCnpj() {
        return cnpj;
    }

    public Long getMatricula() {
        return matricula;
    }

    public BigDecimal getCpfTrab() {
        return cpfTrab;
    }

    public BigDecimal getPisPasep() {
        return pisPasep;
    }

    public Short getCategoriaTrabalhador() {
        return categoriaTrabalhador;
    }

    public LocalDate getDataAcidente() {
        return dataAcidente;
    }

    public String getTipoAcidente() {
        return tipoAcidente;
    }

    public String getHoraAcidente() {
        return horaAcidente;
    }

    public String getHorasTrabAntesAcidente() {
        return horasTrabAntesAcidente;
    }

    public Short getTipoCat() {
        return tipoCat;
    }

    public String getIndCatObito() {
        return indCatObito;
    }

    public LocalDate getDataObito() {
        return dataObito;
    }

    public String getIndComunPolicia() {
        return indComunPolicia;
    }

    public String getCodSitGeradora() {
        return codSitGeradora;
    }

    public String getIniciativaCat() {
        return iniciativaCat;
    }

    public String getObsCat() {
        return obsCat;
    }

    public String getTipoLocalAcidente() {
        return tipoLocalAcidente;
    }

    public String getDescLocalAcidente() {
        return descLocalAcidente;
    }

    public String getCodAmbienteAcidente() {
        return codAmbienteAcidente;
    }

    public String getTipoLogradouroAcidente() {
        return tipoLogradouroAcidente;
    }

    public String getDescLogradouroAcidente() {
        return descLogradouroAcidente;
    }

    public String getNroLogradouroAcidente() {
        return nroLogradouroAcidente;
    }

    public String getComplLogradouroAcidente() {
        return complLogradouroAcidente;
    }

    public String getBairroAcidente() {
        return bairroAcidente;
    }

    public Long getCepAcidente() {
        return cepAcidente;
    }

    public Long getMunicipioAcidente() {
        return municipioAcidente;
    }

    public String getUfAcidente() {
        return ufAcidente;
    }

    public Short getPaisAcidente() {
        return paisAcidente;
    }

    public String getCodPostal() {
        return codPostal;
    }

    public String getTipoPessoaLocalAcidente() {
        return tipoPessoaLocalAcidente;
    }

    public BigDecimal getCnpjLocalAcidente() {
        return cnpjLocalAcidente;
    }

    public String getCodCnesAtestado() {
        return codCnesAtestado;
    }

    public LocalDateTime getDataAtendimentoAtestado() {
        return dataAtendimentoAtestado;
    }

    public String getHoraAtendimentoAtestado() {
        return horaAtendimentoAtestado;
    }

    public String getIndInternacao() {
        return indInternacao;
    }

    public Long getDiasDuracaoTratamento() {
        return diasDuracaoTratamento;
    }

    public String getIndAfastamento() {
        return indAfastamento;
    }

    public String getDescLesao() {
        return descLesao;
    }

    public String getDescComplLesao() {
        return descComplLesao;
    }

    public String getDiagnosticoProvavel() {
        return diagnosticoProvavel;
    }

    public String getCodCid() {
        return codCid;
    }

    public String getObsAtestado() {
        return obsAtestado;
    }

    public String getNomeEmitenteAtestado() {
        return nomeEmitenteAtestado;
    }

    public Short getIdOrgaoClasse() {
        return idOrgaoClasse;
    }

    public BigDecimal getInscricaoOrgaoClasse() {
        return inscricaoOrgaoClasse;
    }

    public String getUfOrgaoClasse() {
        return ufOrgaoClasse;
    }

    public String getReciboCatOrigem() {
        return reciboCatOrigem;
    }

    public String getTemVinculo() {
        return temVinculo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ComunicadoAcidenteTrabalhoDto that = (ComunicadoAcidenteTrabalhoDto) o;
        return Objects.equals(idCatSia, that.idCatSia) &&
                Objects.equals(idEmpresa, that.idEmpresa) &&
                Objects.equals(tipoPessoa, that.tipoPessoa) &&
                Objects.equals(cnpj, that.cnpj);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCatSia, idEmpresa, tipoPessoa, cnpj);
    }
}
