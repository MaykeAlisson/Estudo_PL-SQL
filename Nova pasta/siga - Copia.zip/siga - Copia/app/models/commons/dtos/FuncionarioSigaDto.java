package models.commons.dtos;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Objects;

import static infra.util.UtilDate.toLocalDate;
import static infra.util.UtilDate.toLocalDateTime;

public class FuncionarioSigaDto implements Serializable {

    private Short idEmpresa;
    private String nome;
    private Long cpf;
    private Long pisPasep;
    private Long matricula;
    private Short categoria;
    private Long funcao;
    private String externo;
    private Long idade;
    private String sexo;
    private String funcaoDescricao;
    private LocalDateTime nascimento;

    public Short getIdEmpresa() {
        return idEmpresa;
    }

    public String getNome() {
        return nome;
    }

    public Long getCpf() {
        return cpf;
    }

    public Long getPisPasep() {
        return pisPasep;
    }

    public Long getMatricula() {
        return matricula;
    }

    public Short getCategoria() {
        return categoria;
    }

    public Long getFuncao() {
        return funcao;
    }

    public String getExterno() {
        return externo;
    }

    public Long getIdade() {
        return idade;
    }

    public String getSexo() {
        return sexo;
    }

    public String getFuncaoDescricao() {
        return funcaoDescricao;
    }

    public LocalDateTime getNascimento() {
        return nascimento;
    }

    public FuncionarioSigaDto(Short idEmpresa, String nome, Long cpf, Long pisPasep, Long matricula, Short categoria, Long funcao, String externo, Long idade, String sexo, String funcaoDescricao, Date nascimento) {
        this.idEmpresa = idEmpresa;
        this.nome = nome;
        this.cpf = cpf;
        this.pisPasep = pisPasep;
        this.matricula = matricula;
        this.categoria = categoria;
        this.funcao = funcao;
        this.externo = externo;
        this.idade = idade;
        this.sexo = sexo;
        this.funcaoDescricao = funcaoDescricao;
        this.nascimento = toLocalDateTime(nascimento);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof FuncionarioSigaDto)) return false;
        FuncionarioSigaDto that = (FuncionarioSigaDto) o;
        return Objects.equals(getIdEmpresa(), that.getIdEmpresa()) &&
                Objects.equals(getCpf(), that.getCpf()) &&
                Objects.equals(getFuncao(), that.getFuncao()) &&
                Objects.equals(getExterno(), that.getExterno());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdEmpresa(), getCpf(), getFuncao(), getExterno());
    }
}