package models.commons.dtos;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import infra.jsonDeserializer.LocalDateTimeSerializer;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

import static infra.util.UtilDate.toLocalDateTime;

/**
 * Classe que representa informações...
 *
 * <p>Autor: Mayke.furtado</p>
 *
 * @since 24/05/2019
 */
public class DescargasAbertoDto implements Serializable {

    private final Short numeroPagerChamada;
    private final String nomeMotorista;
    private final LocalDateTime dataMovto;
    private final Long transportadora;
    private final Short empresa;
    private final Short filial;
    private final String razaoSocial;


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CONSTRUCTOR
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public DescargasAbertoDto(
        final Short numeroPagerChamada,
        final String nomeMotorista,
        final java.util.Date dataMovto,
        final Long transportadora,
        final Short empresa,
        final Short filial,
        final String razaoSocial
    ) {

        this.numeroPagerChamada = numeroPagerChamada;
        this.nomeMotorista = nomeMotorista;
        this.dataMovto = toLocalDateTime(dataMovto);
        this.transportadora = transportadora;
        this.empresa = empresa;
        this.filial = filial;
        this.razaoSocial = razaoSocial;
    }

    @JsonProperty( "numeroPagerChamada" )
    public Short getNumeroPagerChamada() {

        return this.numeroPagerChamada;
    }

    @JsonProperty( "nomeMotorista" )
    public String getNomeMotorista() {

        return this.nomeMotorista;
    }

    @JsonProperty( "dataMovto" )
    @JsonSerialize( using = LocalDateTimeSerializer.class )
    public LocalDateTime getDataMovto() {

        return this.dataMovto;
    }

    @JsonProperty( "transportadora" )
    public Long getTransportadora() {

        return this.transportadora;
    }

    @JsonProperty( "empresa" )
    public Short getEmpresa() {

        return this.empresa;
    }

    @JsonProperty( "filial" )
    public Short getFilial() {

        return this.filial;
    }

    @JsonProperty( "razaoSocial" )
    public String getRazaoSocial() {

        return this.razaoSocial;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals(Object o) {

        if (this == o) return true;
        if (!(o instanceof DescargasAbertoDto)) return false;
        DescargasAbertoDto that = (DescargasAbertoDto) o;
        return Objects.equals(getNumeroPagerChamada(), that.getNumeroPagerChamada());
    }

    @Override
    public int hashCode() {

        return Objects.hash(getNumeroPagerChamada());
    }
}


