package models.commons.dtos;

import services.logistica.builder.ItemPedidoAntecipacaoAux;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class DestinatarioRoteirizacaoAntecipacaoDto implements Serializable {

    private Long destinatario;
    private String tipoDestinatario;
    private Long idZonaRoteirizacaoOriginal;
    private BigDecimal latitude;
    private BigDecimal longitude;
    private BigDecimal peso;
    private BigDecimal volume;
    private BigDecimal volumeTotal;
    private BigDecimal pesoTotal;
    private Integer cidade;
    private Integer distrito;
    private Short cda;
    private Long idZonaRoteirizacao;
    private String grupoCidade;
    private String zoneId;
    private List<ItemPedidoRoteirizacaoDto> itens;

    public DestinatarioRoteirizacaoAntecipacaoDto(){
    }

    public DestinatarioRoteirizacaoAntecipacaoDto(Long destinatario, String tipoDestinatario, Long idZonaRoteirizacaoOriginal, BigDecimal latitude, BigDecimal longitude, BigDecimal peso, BigDecimal volume, BigDecimal volumeTotal, BigDecimal pesoTotal, Integer cidade, Integer distrito, Short cda, Long idZonaRoteirizacao, String grupoCidade, String zoneId, List<ItemPedidoRoteirizacaoDto> itens) {
        this.destinatario = destinatario;
        this.tipoDestinatario = tipoDestinatario;
        this.idZonaRoteirizacaoOriginal = idZonaRoteirizacaoOriginal;
        this.latitude = latitude;
        this.longitude = longitude;
        this.peso = peso;
        this.volume = volume;
        this.volumeTotal = volumeTotal;
        this.pesoTotal = pesoTotal;
        this.cidade = cidade;
        this.distrito = distrito;
        this.cda = cda;
        this.idZonaRoteirizacao = idZonaRoteirizacao;
        this.grupoCidade = grupoCidade;
        this.zoneId = zoneId;
        this.itens = itens;
    }

    public Long getDestinatario() {
        return destinatario;
    }

    public String getTipoDestinatario() {
        return tipoDestinatario;
    }

    public Long getIdZonaRoteirizacao() {
        return idZonaRoteirizacao;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public BigDecimal getPeso() {
        return peso;
    }

    public BigDecimal getVolume() {
        return volume;
    }

    public BigDecimal getVolumeTotal() {
        return volumeTotal;
    }

    public BigDecimal getPesoTotal() {
        return pesoTotal;
    }

    public Long getIdZonaRoteirizacaoOriginal() {
        return idZonaRoteirizacaoOriginal;
    }

    public Integer getCidade() {
        return cidade;
    }

    public Integer getDistrito() {
        return distrito;
    }

    public Short getCda() {
        return cda;
    }

    public List<ItemPedidoRoteirizacaoDto> getItens() {
        return itens;
    }

    public String getGrupoCidade() {
        return grupoCidade;
    }

    public String getZoneId() {
        return zoneId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DestinatarioRoteirizacaoAntecipacaoDto that = (DestinatarioRoteirizacaoAntecipacaoDto) o;
        return Objects.equals(destinatario, that.destinatario);
    }

    @Override
    public int hashCode() {

        return Objects.hash(destinatario);
    }

    public static DestinatarioRoteirizacaoAntecipacaoDto create(List<ItemPedidoAntecipacaoAux> itensItemPedidoAntecipacao, BigDecimal volumeTotalPedidos, BigDecimal pesoTotalPedidos) {
        ItemPedidoAntecipacaoAux itemPedido = itensItemPedidoAntecipacao.stream().findFirst().get();
        List<ItemPedidoRoteirizacaoDto> itens = itensItemPedidoAntecipacao.stream()
                .map(ip -> new ItemPedidoRoteirizacaoDto(ip.getPedido(), ip.getSequencia(), ip.getDestinatario(), ip.getMercadoria(), ip.getPesoItem(), ip.getVolumeItem(), ip.getQuantidadeVendidaCalculada().intValue()))
                .collect(Collectors.toList());

        BigDecimal volume = itens.stream()
                .map(emp -> (emp.getVolumeItem().multiply(new BigDecimal(emp.getQuantidadeVendida()))))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal peso = itens.stream()
                .map(emp -> (emp.getPesoItem().multiply(new BigDecimal(emp.getQuantidadeVendida()))))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        DestinatarioRoteirizacaoAntecipacaoDto dest = new DestinatarioRoteirizacaoAntecipacaoDto(itemPedido.getDestinatario(), itemPedido.getTipoDestinatario(), itemPedido.getIdZonaRoteirizacao(),
                itemPedido.getLatitude(), itemPedido.getLongitude(), peso, volume, volumeTotalPedidos, pesoTotalPedidos, itemPedido.getCidade(), itemPedido.getDistrito(), itemPedido.getCda(), itemPedido.getIdZonaRoteirizacao(),
                itemPedido.getGrupoCidade(),itemPedido.getZoneId(), itens);
        return dest;
    }

}
