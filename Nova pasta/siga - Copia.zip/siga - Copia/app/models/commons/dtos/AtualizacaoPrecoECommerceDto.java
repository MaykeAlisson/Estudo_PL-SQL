package models.commons.dtos;

import com.fasterxml.jackson.annotation.JsonProperty;
import models.commons.constantes.OrigemPedidoECommerce;
import models.commons.constantes.TipoAtualizacaoPreco;
import services.ws.PrincipiaMercadoriaValue;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

import static infra.util.UtilEnum.getEnum;
import static models.commons.constantes.OrigemPedidoECommerce.getOrigemMercadoria;

/**
 * Classe que representa informações de atualizações de mercadorias do e-commerce
 *
 * <p>Autor: GPortes</p>
 *
 * @since 24/01/2019
 */
public class AtualizacaoPrecoECommerceDto implements Serializable, PrincipiaMercadoriaValue {

    private final Long idAtuPrecoMercadoria;
    private final Long idMercadoria;
    private final TipoAtualizacaoPreco tipoAtualizacao;
    private final BigDecimal precoVenda;
    private final Long version;
    private final OrigemPedidoECommerce segmentoMercadoria;


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CONSTRUCTOR
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public AtualizacaoPrecoECommerceDto(
        final Long idAtuPrecoMercadoria,
        final Long idMercadoria,
        final String tipoAtualizacao,
        final BigDecimal precoVenda,
        final Long version,
        final String divisao
    ) {

        this.idAtuPrecoMercadoria = idAtuPrecoMercadoria;
        this.idMercadoria = idMercadoria;
        this.tipoAtualizacao = getEnum( TipoAtualizacaoPreco.class, tipoAtualizacao );
        this.precoVenda = precoVenda;
        this.version = version;
        this.segmentoMercadoria = getOrigemMercadoria( divisao ).orElse( null );
    }

    @JsonProperty( "idAtuPrecoMercadoria" )
    public Long getIdAtuPrecoMercadoria() {

        return idAtuPrecoMercadoria;
    }

    @JsonProperty( "idMercadoria" )
    public Long getIdMercadoria() {

        return this.idMercadoria;
    }

    @Override
    @JsonProperty( "segmentoMercadoria" )
    public OrigemPedidoECommerce getSegmentoMercadoria() {

        return this.segmentoMercadoria;
    }


    @JsonProperty( "tipoAtualizacao" )
    public TipoAtualizacaoPreco getTipoAtualizacao() {

        return this.tipoAtualizacao;
    }

    @Override
    @JsonProperty( "precoVenda" )
    public BigDecimal getPrecoVenda() {

        return precoVenda;
    }

    @JsonProperty( "version" )
    public Long getVersion() {

        return this.version;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object o ) {

        if ( this == o ) return true;
        if ( !(o instanceof AtualizacaoPrecoECommerceDto) ) return false;
        AtualizacaoPrecoECommerceDto that = (AtualizacaoPrecoECommerceDto) o;
        return Objects.equals(getIdAtuPrecoMercadoria(), that.getIdAtuPrecoMercadoria());
    }

    @Override
    public int hashCode() {

        return Objects.hash(getIdAtuPrecoMercadoria());
    }
}
