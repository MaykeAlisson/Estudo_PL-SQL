package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Classe que representa informações...
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 10/05/2019
 */
public class CleberProjecaoFaturamentoDto implements Serializable {


    private  Long diaSemanaPedido;
    private  Long qtdDiasFaturamento;
    private  BigDecimal valor;


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CONSTRUCTOR
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public CleberProjecaoFaturamentoDto(
            final Long diaSemanaPedido,
            final Long qtdDiasFaturamento,
            final BigDecimal valor
    ) {

        this.diaSemanaPedido = diaSemanaPedido;
        this.qtdDiasFaturamento = qtdDiasFaturamento;
        this.valor = valor;
    }

    @JsonProperty( "diaSemanaPedido" )
    public Long getDiaSemanaPedido() {

        if (this.diaSemanaPedido == 1)  return 7l;
        return this.diaSemanaPedido -1;
    }

    @JsonProperty( "qtdDiasFaturamento" )
    public Long getQtdDiasFaturamento() {

        return this.qtdDiasFaturamento;
    }

    @JsonProperty( "valor" )
    public BigDecimal getValor() {

        return this.valor;
    }


}
