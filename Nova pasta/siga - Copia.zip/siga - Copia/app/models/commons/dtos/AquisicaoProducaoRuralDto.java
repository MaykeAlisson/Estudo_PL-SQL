package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

/**
 * Classe que representa informaþ§es...
 *
 * <p>Autor: Tiagopti</p>
 *
 * @since 25/02/2019
 */
public class AquisicaoProducaoRuralDto implements Serializable {


    private Short tipoPessoa;
    private BigDecimal cnpjCpf;
    private String serie;
    private Long numDocto;
    private Date dtEmissaoNF;
    private BigDecimal vlrBruto;
    private BigDecimal vlrPrevidencia;
    private BigDecimal vlrRat;
    private BigDecimal vlrSenar;
    private Short indOpcCP;


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CONSTRUCTOR
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public Short getTipoPessoa() {
        return tipoPessoa;
    }

    public BigDecimal getCnpjCpf() {
        return cnpjCpf;
    }

    public String getSerie() {
        return serie;
    }

    public Long getNumDocto() {
        return numDocto;
    }

    public Date getDtEmissaoNF() {
        return dtEmissaoNF;
    }

    public BigDecimal getVlrBruto() {
        return vlrBruto;
    }

    public BigDecimal getVlrPrevidencia() {
        return vlrPrevidencia;
    }

    public BigDecimal getVlrRat() {
        return vlrRat;
    }

    public BigDecimal getVlrSenar() {
        return vlrSenar;
    }

    public Short getIndOpcCP() {
        return indOpcCP;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AquisicaoProducaoRuralDto)) return false;
        AquisicaoProducaoRuralDto that = (AquisicaoProducaoRuralDto) o;
        return Objects.equals(getTipoPessoa(), that.getTipoPessoa()) &&
                Objects.equals(getCnpjCpf(), that.getCnpjCpf());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getTipoPessoa(), getCnpjCpf());
    }
}

