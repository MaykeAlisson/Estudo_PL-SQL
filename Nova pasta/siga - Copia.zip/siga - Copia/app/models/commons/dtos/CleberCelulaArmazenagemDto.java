package models.commons.dtos;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.beans.Transient;
import java.io.Serializable;
import java.util.List;
import java.util.Objects;

import static infra.util.UtilCollections.isVazia;
import static java.util.Comparator.comparing;

/**
 * Classe que representa informações...
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 20/12/2018
 */
public class CleberCelulaArmazenagemDto implements Serializable {


    private final String modulo;
    private final Short rua;
    private final Long predio;
    private final Short nivel;
    private final Short capacidade;
    private Short capacidadeOcupada;
    private Long mercadoria;


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CONSTRUCTOR
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public CleberCelulaArmazenagemDto(
            final String modulo,
            final Short rua,
            final Long predio,
            final Short nivel,
            final Short capacidade
    ) {

        this.modulo = modulo;
        this.rua = rua;
        this.predio = predio;
        this.nivel = nivel;
        this.capacidade = capacidade;
    }

    @JsonProperty( "modulo" )
    public String getModulo() {

        return this.modulo;
    }

    @JsonProperty( "rua" )
    public Short getRua() {

        return this.rua;
    }

    @JsonProperty( "predio" )
    public Long getPredio() {

        return this.predio;
    }

    @JsonProperty( "nivel" )
    public Short getNivel() {

        return this.nivel;
    }

    @JsonProperty( "capacidade" )
    public Short getCapacidade() {

        return this.capacidade;
    }

    @JsonProperty("capacidadeOcupada")
    public Short getCapacidadeOcupada() {
        return capacidadeOcupada == null ? 0 : capacidadeOcupada;
    }

    public void setCapacidadeOcupada(Short capacidadeOcupada) {
        this.capacidadeOcupada = capacidadeOcupada;
    }

    @JsonProperty("mercadoria")
    public Long getMercadoria() {
        return mercadoria == null ?  0L : mercadoria;
    }

    public void setMercadoria(Long mercadoria) {
        this.mercadoria = mercadoria;
    }

    @Transient
    public boolean isCelulaOcupada() {
        return this.getMercadoria() > 0;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CleberCelulaArmazenagemDto)) return false;
        CleberCelulaArmazenagemDto that = (CleberCelulaArmazenagemDto) o;
        return getModulo().equals(that.getModulo()) &&
                getRua().equals(that.getRua()) &&
                getPredio().equals(that.getPredio()) &&
                getNivel().equals(that.getNivel()) &&
                getCapacidade().equals(that.getCapacidade()) &&
                Objects.equals(getCapacidadeOcupada(), that.getCapacidadeOcupada()) &&
                Objects.equals(getMercadoria(), that.getMercadoria());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getModulo(), getRua(), getPredio(), getNivel(), getCapacidade(), getCapacidadeOcupada(), getMercadoria());
    }

    @Override
    public String toString() {
        return "CleberCelulaArmazenagemDto{" +
                "modulo='" + modulo + '\'' +
                ", rua=" + rua +
                ", predio=" + predio +
                ", nivel=" + nivel +
                ", capacidade=" + capacidade +
                ", capacidadeOcupada=" + capacidadeOcupada +
                ", mercadoria=" + mercadoria +
                '}';
    }



    public static void sortPorCapacidadeDesc(List<CleberCelulaArmazenagemDto> cleberCelulaArmazenagemDtos) {

        if ( !isVazia(cleberCelulaArmazenagemDtos) )
            cleberCelulaArmazenagemDtos.sort(
                    comparing( CleberCelulaArmazenagemDto::getCapacidade ).reversed()
            );
    }

}
