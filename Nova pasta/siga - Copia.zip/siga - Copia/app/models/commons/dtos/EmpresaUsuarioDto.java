package models.commons.dtos;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import models.commons.constantes.SimNao;

import java.io.Serializable;
import java.util.Objects;

import static models.commons.constantes.SimNao.SIM;

/**
 * Representa Empresas do Usuario
 *
 * <p>GPortes</p>
 *
 * @since 03/09/2014.
 */
public class EmpresaUsuarioDto implements Serializable {

    @JsonProperty( value = "idEmpresa" )
    private final Short idEmpresa;

    @JsonProperty( value = "descricao" )
    private final String descricao;

    @JsonIgnore
    private final SimNao principal;

    @JsonProperty( value = "principal" )
    private final Boolean isPrincipal;

    /**
     * Construtor utilizado na query  [ Empresa.xml / Empresa.buscarEmpresaPrincipalDoUsuario ]
     *
     * @param idEmpresa
     * @param descricao
     * @param principal
     */
    public EmpresaUsuarioDto( final Short idEmpresa,
                              final String descricao,
                              final SimNao principal ) {

        this.idEmpresa = idEmpresa;
        this.descricao = descricao;
        this.principal = principal;
        this.isPrincipal = Objects.equals( principal, SIM );
    }

    public Short getIdEmpresa() {

        return idEmpresa;
    }

    public String getDescricao() {

        return descricao;
    }

    public SimNao getPrincipal() {

        return principal;
    }

    public Boolean isPrincipal() {

        return isPrincipal;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof EmpresaUsuarioDto)) return false;

        EmpresaUsuarioDto dto = (EmpresaUsuarioDto) o;

        if (getIdEmpresa() != null ? !getIdEmpresa().equals(dto.getIdEmpresa()) : dto.getIdEmpresa() != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return getIdEmpresa() != null ? getIdEmpresa().hashCode() : 0;
    }

    @Override
    public String toString() {
        return "EmpresaUsuarioDto{ idEmpresa=" + getIdEmpresa() + "}";
    }

}
