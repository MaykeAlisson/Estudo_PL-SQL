package models.commons.dtos;

import models.commons.constantes.Estado;

import java.io.Serializable;

/**
 * Classe que representa informações do Cliente
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 20/11/2015
 */
public class ClientePesquisaDto implements Serializable {

    private final Short idEmpresa;
    private final Long idCliente;
    private final String razaoSocial;
    private final Long cnpj;
    private final Short idCidade;
    private final Short idDistrito;
    private final String descricaoCidade;
    private final Estado estado;
    private final String descricaoCompletaCidade;

    public ClientePesquisaDto( final Short idEmpresa,
                               final Long idCliente,
                               final String razaoSocial,
                               final Long cnpj,
                               final Short idCidade,
                               final Short idDistrito,
                               final String descricaoCidade,
                               final Estado estado ) {

        this.idEmpresa = idEmpresa;
        this.idCliente = idCliente;
        this.razaoSocial = razaoSocial;
        this.cnpj = cnpj;
        this.idCidade = idCidade;
        this.idDistrito = idDistrito;
        this.descricaoCidade = descricaoCidade;
        this.estado = estado;
        this.descricaoCompletaCidade = descricaoCidade + " (" + estado.getValor() + ")";
    }

    public Short getIdEmpresa() {

        return idEmpresa;
    }

    public Long getIdCliente() {

        return idCliente;
    }

    public String getRazaoSocial() {

        return razaoSocial;
    }

    public Long getCnpj() {

        return cnpj;
    }

    public Short getIdCidade() {

        return idCidade;
    }

    public Short getIdDistrito() {

        return idDistrito;
    }

    public String getDescricaoCidade() {

        return descricaoCidade;
    }

    public String getDescricaoCompletaCidade() {

        return descricaoCompletaCidade;
    }

    public Estado getEstado( ) {

        return estado;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object o ) {

        if ( this == o ) return true;
        if ( o == null || getClass() != o.getClass() ) return false;

        ClientePesquisaDto that = (ClientePesquisaDto) o;

        if ( getIdEmpresa() != null ? !getIdEmpresa().equals( that.getIdEmpresa() ) : that.getIdEmpresa() != null )
            return false;
        return !( getIdCliente() != null ? !getIdCliente().equals( that.getIdCliente() ) : that.getIdCliente() != null );

    }

    @Override
    public int hashCode() {

        int result = getIdEmpresa() != null ? getIdEmpresa().hashCode() : 0;
        result = 31 * result + ( getIdCliente() != null ? getIdCliente().hashCode() : 0 );
        return result;
    }

    @Override
    public String toString() {

        return "ClientePesquisaDto { " +
                "idEmpresa = " + idEmpresa +
                ", idCliente = " + idCliente + " }";
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}