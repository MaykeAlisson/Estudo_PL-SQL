package models.commons.dtos;

import java.io.Serializable;
import java.util.Objects;

public class ExamesFuncaoDto implements Serializable {

    private Long exame;

    public Long getExame() {
        return exame;
    }

    public ExamesFuncaoDto(Long exame) {
        this.exame = exame;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ExamesFuncaoDto)) return false;
        ExamesFuncaoDto that = (ExamesFuncaoDto) o;
        return Objects.equals(getExame(), that.getExame());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getExame());
    }
}