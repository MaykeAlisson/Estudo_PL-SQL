package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilNumero.isNullZero;

public class DestinatarioRoteirizacaoCargaDto implements Serializable {

    private Long idDestinatario;
    private String tipoDestinatario;
    private Short idCidade;
    private Short idDistrito;
    private String estado;
    private BigDecimal peso;
    private BigDecimal valor;
    private BigDecimal volume;
    private BigDecimal volumeAlimenticio;
    private Short idCda;
    private String rotNaSemana;
    private String idGrupoCidade;
    private String rotZoneId;
    private String rotProfileId;
    private String rotZoneDomainId;
    private String bloqueioRotZoneId;
    private Long idZonaRoteirizacao;
    private Long idZonaRoteirizacaoOriginal;
    private BigDecimal latitude;
    private BigDecimal longitude;
    private Date dataEntradaPedido;
    private Long idCarga;
    private boolean selecionado;
    private String destinatarioFiltro;
    private String bairro;
    private String descricaoCidade;
    private String cep;
    private Long setor;
    private String logradouro;
    private String nomeLogradouro;
    private String numeroEndereco;
    private String ramoAtividade;
    private String usarCoordDistritRoteirizar;
    private BigDecimal latitudeCidade;
    private BigDecimal longitudeCidade;
    private String razaoSocial;
    private Long idCargaAntecPesado;
    private Short tipoDocumento;
    private String tipoAgente;
    private Date dataVencimento;
    private String boleto;
    private String idGrupoCidadeAgrupado;
    private Boolean bloqueadoQuinzenal;

    private List<Long> pedidos;

    public static List<DestinatarioRoteirizacaoCargaDto> create(List<LotePedidoRoteirizacaoDto> lotePedidosRoteirizacao) {
        if( isVazia(lotePedidosRoteirizacao) ) {
           return new ArrayList<>(0);
        }
        List<DestinatarioRoteirizacaoCargaDto> destinatariosRoteirizacao = new ArrayList<>();
        Map<Long, List<LotePedidoRoteirizacaoDto>> mapDestinatarioXLotePedidos = lotePedidosRoteirizacao.stream()
                .collect(Collectors.groupingBy(LotePedidoRoteirizacaoDto::getIdDestinatario));
        mapDestinatarioXLotePedidos.forEach((destinatario, pedidosRoteirizacao) -> {
            LotePedidoRoteirizacaoDto lotePedido = pedidosRoteirizacao.stream().findFirst().get();
            Optional<LotePedidoRoteirizacaoDto> loteCargaPesado = pedidosRoteirizacao.stream().filter(pr -> isNullZero(pr.getIdCargaAntecPesado()) > 0L).findFirst();
            if( loteCargaPesado.isPresent() ) {
                lotePedido = loteCargaPesado.get();
            }

            DestinatarioRoteirizacaoCargaDto dest = new DestinatarioRoteirizacaoCargaDto();
            dest.setIdDestinatario(lotePedido.getIdDestinatario());
            dest.setTipoDestinatario(lotePedido.getTipoDestinatario());
            dest.setIdCidade(lotePedido.getIdCidade());
            dest.setIdDistrito(lotePedido.getIdDistrito());
            dest.setIdGrupoCidade(lotePedido.getIdGrupoCidade());
            dest.setIdGrupoCidadeAgrupado(lotePedido.getIdGrupoCidadeAgrupado());
            dest.setIdZonaRoteirizacao(lotePedido.getIdZonaRoteirizacao());
            dest.setIdZonaRoteirizacaoOriginal(lotePedido.getIdZonaRoteirizacao());
            dest.setIdCarga(lotePedido.getIdCarga());
            dest.setIdCda(lotePedido.getIdCda());
            dest.setRotZoneId(lotePedido.getRotZoneId());
            dest.setRotZoneDomainId(lotePedido.getRotZoneDomainId());
            dest.setRotProfileId(lotePedido.getRotProfileId());
            dest.setBloqueioRotZoneId(lotePedido.getBloqueioRotZoneId());
            dest.setRotNaSemana(lotePedido.getRotNaSemana());
            dest.setLatitude(lotePedido.getLatitude());
            dest.setLongitude(lotePedido.getLongitude());
            dest.setEstado(lotePedido.getEstado());
            dest.setBairro(lotePedido.getBairro());
            dest.setDescricaoCidade(lotePedido.getDescricaoCidade());
            dest.setCep(lotePedido.getCep());
            dest.setLogradouro(lotePedido.getLogradouro());
            dest.setNomeLogradouro(lotePedido.getNomeLogradouro());
            dest.setNumeroEndereco(lotePedido.getNumeroEndereco());
            dest.setSetor(lotePedido.getSetor());
            dest.setDestinatarioFiltro(lotePedido.getTipoDestinatario()+lotePedido.getIdDestinatario());
            dest.setUsarCoordDistritRoteirizar(lotePedido.getUsarCoordDistritRoteirizar());
            dest.setLatitudeCidade(lotePedido.getLatitudeCidade());
            dest.setLongitudeCidade(lotePedido.getLongitudeCidade());
            dest.setIdCargaAntecPesado(lotePedido.getIdCargaAntecPesado());
            dest.setRamoAtividade(lotePedido.getRamoAtividade());
            dest.setRazaoSocial(lotePedido.getRazaoSocial());
            dest.setTipoDocumento(lotePedido.getTipoDocumento());
            dest.setTipoAgente(lotePedido.getTipoAgente());
            dest.setBoleto(lotePedido.getBoleto());
            dest.setDataVencimento(lotePedido.getDataVencimento());
            dest.setBloqueadoQuinzenal(false);

            BigDecimal volume = pedidosRoteirizacao.stream()
                    .map(emp -> (emp.getVolume()))
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
            BigDecimal peso = pedidosRoteirizacao.stream()
                    .map(emp -> (emp.getPeso()))
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
            BigDecimal volumeAlimenticio = pedidosRoteirizacao.stream()
                    .map(emp -> (emp.getVolumeAlimenticio()))
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
            BigDecimal valor = pedidosRoteirizacao.stream()
                    .map(emp -> (emp.getValor()))
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
            dest.setPeso(peso);
            dest.setValor(valor);
            dest.setVolume(volume);
            dest.setVolumeAlimenticio(volumeAlimenticio);

            dest.setSelecionado(true);
            dest.setPedidos(pedidosRoteirizacao.stream().map(LotePedidoRoteirizacaoDto::getIdPedido).collect(Collectors.toList()));

            destinatariosRoteirizacao.add(dest);
        });
        return destinatariosRoteirizacao;
    }

    public Long getIdDestinatario() {
        return idDestinatario;
    }

    public void setIdDestinatario(Long idDestinatario) {
        this.idDestinatario = idDestinatario;
    }

    public String getTipoDestinatario() {
        return tipoDestinatario;
    }

    public void setTipoDestinatario(String tipoDestinatario) {
        this.tipoDestinatario = tipoDestinatario;
    }

    public Short getIdCidade() {
        return idCidade;
    }

    public void setIdCidade(Short idCidade) {
        this.idCidade = idCidade;
    }

    public Short getIdDistrito() {
        return idDistrito;
    }

    public void setIdDistrito(Short idDistrito) {
        this.idDistrito = idDistrito;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public BigDecimal getPeso() {
        return peso;
    }

    public void setPeso(BigDecimal peso) {
        this.peso = peso;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }

    public BigDecimal getVolume() {
        return volume;
    }

    public void setVolume(BigDecimal volume) {
        this.volume = volume;
    }

    public BigDecimal getVolumeAlimenticio() {
        return volumeAlimenticio;
    }

    public void setVolumeAlimenticio(BigDecimal volumeAlimenticio) {
        this.volumeAlimenticio = volumeAlimenticio;
    }

    public Short getIdCda() {
        return idCda;
    }

    public void setIdCda(Short idCda) {
        this.idCda = idCda;
    }

    public String getRotNaSemana() {
        return rotNaSemana;
    }

    public void setRotNaSemana(String rotNaSemana) {
        this.rotNaSemana = rotNaSemana;
    }

    public String getIdGrupoCidade() {
        return idGrupoCidade;
    }

    public void setIdGrupoCidade(String idGrupoCidade) {
        this.idGrupoCidade = idGrupoCidade;
    }

    public String getRotZoneId() {
        return rotZoneId;
    }

    public void setRotZoneId(String rotZoneId) {
        this.rotZoneId = rotZoneId;
    }

    public String getRotProfileId() {
        return rotProfileId;
    }

    public void setRotProfileId(String rotProfileId) {
        this.rotProfileId = rotProfileId;
    }

    public String getRotZoneDomainId() {
        return rotZoneDomainId;
    }

    public void setRotZoneDomainId(String rotZoneDomainId) {
        this.rotZoneDomainId = rotZoneDomainId;
    }

    public String getBloqueioRotZoneId() {
        return bloqueioRotZoneId;
    }

    public void setBloqueioRotZoneId(String bloqueioRotZoneId) {
        this.bloqueioRotZoneId = bloqueioRotZoneId;
    }

    public Long getIdZonaRoteirizacao() {
        return idZonaRoteirizacao;
    }

    public void setIdZonaRoteirizacao(Long idZonaRoteirizacao) {
        this.idZonaRoteirizacao = idZonaRoteirizacao;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }

    public Date getDataEntradaPedido() {
        return dataEntradaPedido;
    }

    public void setDataEntradaPedido(Date dataEntradaPedido) {
        this.dataEntradaPedido = dataEntradaPedido;
    }

    public Long getIdCarga() {
        return idCarga;
    }

    public void setIdCarga(Long idCarga) {
        this.idCarga = idCarga;
    }

    public List<Long> getPedidos() {
        return pedidos;
    }

    public void setPedidos(List<Long> pedidos) {
        this.pedidos = pedidos;
    }

    public boolean isSelecionado() {
        return selecionado;
    }

    public void setSelecionado(boolean selecionado) {
        this.selecionado = selecionado;
    }

    public String getDestinatarioFiltro() {
        return destinatarioFiltro;
    }

    public void setDestinatarioFiltro(String destinatarioFiltro) {
        this.destinatarioFiltro = destinatarioFiltro;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getDescricaoCidade() {
        return descricaoCidade;
    }

    public void setDescricaoCidade(String descricaoCidade) {
        this.descricaoCidade = descricaoCidade;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public Long getSetor() {
        return setor;
    }

    public void setSetor(Long setor) {
        this.setor = setor;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public String getNomeLogradouro() {
        return nomeLogradouro;
    }

    public void setNomeLogradouro(String nomeLogradouro) {
        this.nomeLogradouro = nomeLogradouro;
    }

    public String getNumeroEndereco() {
        return numeroEndereco;
    }

    public void setNumeroEndereco(String numeroEndereco) {
        this.numeroEndereco = numeroEndereco;
    }

    public String getRamoAtividade() {
        return ramoAtividade;
    }

    public void setRamoAtividade(String ramoAtividade) {
        this.ramoAtividade = ramoAtividade;
    }

    public String getUsarCoordDistritRoteirizar() {
        return usarCoordDistritRoteirizar;
    }

    public void setUsarCoordDistritRoteirizar(String usarCoordDistritRoteirizar) {
        this.usarCoordDistritRoteirizar = usarCoordDistritRoteirizar;
    }

    public BigDecimal getLatitudeCidade() {
        return latitudeCidade;
    }

    public void setLatitudeCidade(BigDecimal latitudeCidade) {
        this.latitudeCidade = latitudeCidade;
    }

    public BigDecimal getLongitudeCidade() {
        return longitudeCidade;
    }

    public void setLongitudeCidade(BigDecimal longitudeCidade) {
        this.longitudeCidade = longitudeCidade;
    }

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }

    public Long getIdCargaAntecPesado() {
        return idCargaAntecPesado;
    }

    public void setIdCargaAntecPesado(Long idCargaAntecPesado) {
        this.idCargaAntecPesado = idCargaAntecPesado;
    }

    public Short getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(Short tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getTipoAgente() {
        return tipoAgente;
    }

    public void setTipoAgente(String tipoAgente) {
        this.tipoAgente = tipoAgente;
    }

    public Date getDataVencimento() {
        return dataVencimento;
    }

    public void setDataVencimento(Date dataVencimento) {
        this.dataVencimento = dataVencimento;
    }

    public String getBoleto() {
        return boleto;
    }

    public void setBoleto(String boleto) {
        this.boleto = boleto;
    }

    public Long getIdZonaRoteirizacaoOriginal() {
        return idZonaRoteirizacaoOriginal;
    }

    public void setIdZonaRoteirizacaoOriginal(Long idZonaRoteirizacaoOriginal) {
        this.idZonaRoteirizacaoOriginal = idZonaRoteirizacaoOriginal;
    }

    public String getIdGrupoCidadeAgrupado() {
        return idGrupoCidadeAgrupado;
    }

    public void setIdGrupoCidadeAgrupado(String idGrupoCidadeAgrupado) {
        this.idGrupoCidadeAgrupado = idGrupoCidadeAgrupado;
    }

    public Boolean getBloqueadoQuinzenal() {
        return bloqueadoQuinzenal;
    }

    public void setBloqueadoQuinzenal(Boolean bloqueadoQuinzenal) {
        this.bloqueadoQuinzenal = bloqueadoQuinzenal;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DestinatarioRoteirizacaoCargaDto that = (DestinatarioRoteirizacaoCargaDto) o;
        return Objects.equals(idDestinatario, that.idDestinatario) &&
                Objects.equals(tipoDestinatario, that.tipoDestinatario);
    }

    @Override
    public int hashCode() {

        return Objects.hash(idDestinatario, tipoDestinatario);
    }
}
