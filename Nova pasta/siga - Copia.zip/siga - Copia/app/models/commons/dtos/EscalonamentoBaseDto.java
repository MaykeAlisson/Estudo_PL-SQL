package models.commons.dtos;

import java.io.Serializable;
import java.util.Objects;

/**
 * Classe que representa informações base para criar um escalonamento.
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 20/04/2018
 */
public class EscalonamentoBaseDto implements Serializable {

    private final String titulo;
    private final String classeDeServico;
    private final Short prioridade;

    public EscalonamentoBaseDto( final String titulo,
                                 final String classeDeServico,
                                 final Short prioridade ) {

        this.titulo = titulo;
        this.classeDeServico = classeDeServico;
        this.prioridade = prioridade;
    }

    public String getTitulo() {

        return titulo;
    }

    public String getClasseDeServico() {

        return classeDeServico;
    }

    public Short getPrioridade() {

        return prioridade;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object o ) {

        if ( this == o ) return true;
        if ( !(o instanceof EscalonamentoBaseDto) ) return false;
        EscalonamentoBaseDto that = (EscalonamentoBaseDto) o;
        return Objects.equals(getTitulo(), that.getTitulo()) &&
                Objects.equals(getClasseDeServico(), that.getClasseDeServico()) &&
                Objects.equals(getPrioridade(), that.getPrioridade());
    }

    @Override
    public int hashCode() {

        return Objects.hash(getTitulo(), getClasseDeServico(), getPrioridade());
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}


