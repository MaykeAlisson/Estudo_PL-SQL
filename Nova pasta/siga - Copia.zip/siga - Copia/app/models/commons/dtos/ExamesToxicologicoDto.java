package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;
import java.util.Objects;

import static infra.util.UtilDate.toLocalDate;

/**
 * DTO que representa informações da procedure up_esocial_exames_toxicologico
 *
 * <p>Autor: Silas Andrade</p>
 *
 * @since 27/05/2019
 */
public class ExamesToxicologicoDto implements Serializable {

    private final Short idEmpresa;
    private final Short tipoPessoa;
    private final BigDecimal cnpj;
    private final Long matricula;
    private final BigDecimal cpfTrab;
    private final BigDecimal pisPasep;
    private final Short categoriaTrabalhador;
    private final LocalDate dataExame;
    private final BigDecimal cnpjLaboratorio;
    private final String codigoExame;
    private final String nomeMedico;
    private final BigDecimal nroCrm;
    private final String ufCrm;
    private final String indRecusa;
    private final String temVinculo;


    public ExamesToxicologicoDto(
                                final Short idEmpresa,
                                final Short tipoPessoa,
                                final BigDecimal cnpj,
                                final Long matricula,
                                final BigDecimal cpfTrab,
                                final BigDecimal pisPasep,
                                final Short categoriaTrabalhador,
                                final Date dataExame,
                                final BigDecimal cnpjLaboratorio,
                                final String codigoExame,
                                final String nomeMedico,
                                final BigDecimal nroCrm,
                                final String ufCrm,
                                final String indRecusa,
                                final String temVinculo) {
        this.idEmpresa = idEmpresa;
        this.tipoPessoa = tipoPessoa;
        this.cnpj = cnpj;
        this.matricula = matricula;
        this.cpfTrab = cpfTrab;
        this.pisPasep = pisPasep;
        this.categoriaTrabalhador = categoriaTrabalhador;
        this.dataExame = toLocalDate(dataExame);
        this.cnpjLaboratorio = cnpjLaboratorio;
        this.codigoExame = codigoExame;
        this.nomeMedico = nomeMedico;
        this.nroCrm = nroCrm;
        this.ufCrm = ufCrm;
        this.indRecusa = indRecusa;
        this.temVinculo = temVinculo;
    }

    public Short getIdEmpresa() {
        return idEmpresa;
    }

    public Short getTipoPessoa() {
        return tipoPessoa;
    }

    public BigDecimal getCnpj() {
        return cnpj;
    }

    public Long getMatricula() {
        return matricula;
    }

    public BigDecimal getCpfTrab() {
        return cpfTrab;
    }

    public BigDecimal getPisPasep() {
        return pisPasep;
    }

    public Short getCategoriaTrabalhador() {
        return categoriaTrabalhador;
    }

    public LocalDate getDataExame() {
        return dataExame;
    }

    public BigDecimal getCnpjLaboratorio() {
        return cnpjLaboratorio;
    }

    public String getCodigoExame() {
        return codigoExame;
    }

    public String getNomeMedico() {
        return nomeMedico;
    }

    public BigDecimal getNroCrm() {
        return nroCrm;
    }

    public String getUfCrm() {
        return ufCrm;
    }

    public String getIndRecusa() {
        return indRecusa;
    }

    public String getTemVinculo() {
        return temVinculo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ExamesToxicologicoDto that = (ExamesToxicologicoDto) o;
        return  Objects.equals(matricula, that.matricula) &&
                Objects.equals(cpfTrab, that.cpfTrab) &&
                Objects.equals(pisPasep, that.pisPasep);
    }

    @Override
    public int hashCode() {
        return Objects.hash(matricula, cpfTrab, pisPasep);
    }
}
