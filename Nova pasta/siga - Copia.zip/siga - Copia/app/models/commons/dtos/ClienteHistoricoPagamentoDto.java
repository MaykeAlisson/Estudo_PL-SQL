package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.*;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilDate.getData;
import static infra.util.UtilDate.getOrElse;
import static infra.util.UtilNumero.somar;
import static java.util.Collections.emptyList;
import static java.util.Collections.sort;

/**
 * Classe ref. informações do historico de pagamento do cliente
 *
 * <p>Autor: GPortes</p>
 *
 * @since  22/08/2014.
 */
public class ClienteHistoricoPagamentoDto implements Serializable {

    private static final long serialVersionUID = 211512159498382352L;

    private final Short idEmpresa;
    private final Long idCliente;
    private final Date periodo;
    private final BigDecimal vlrPagamentoLiquido;

    public ClienteHistoricoPagamentoDto( final Short idEmpresa,
                                         final Long idCliente,
                                         final Date periodo,
                                         final BigDecimal vlrPagamentoLiquido) {
        this.idEmpresa = idEmpresa;
        this.idCliente = idCliente;
        this.periodo = periodo;
        this.vlrPagamentoLiquido = vlrPagamentoLiquido;
    }

    public Short getIdEmpresa() {
        return idEmpresa;
    }

    public Long getIdCliente() {
        return idCliente;
    }

    public Date getPeriodo() {
        return periodo;
    }

    public BigDecimal getVlrPagamentoLiquido() {
        return vlrPagamentoLiquido;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ClienteHistoricoPagamentoDto)) return false;

        ClienteHistoricoPagamentoDto that = (ClienteHistoricoPagamentoDto) o;

        if (idCliente != null ? !idCliente.equals(that.idCliente) : that.idCliente != null) return false;
        if (idEmpresa != null ? !idEmpresa.equals(that.idEmpresa) : that.idEmpresa != null) return false;
        if (periodo != null ? !periodo.equals(that.periodo) : that.periodo != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = idEmpresa != null ? idEmpresa.hashCode() : 0;
        result = 31 * result + (idCliente != null ? idCliente.hashCode() : 0);
        result = 31 * result + (periodo != null ? periodo.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ClienteHistoricoPagamentoDto{" +
                "idEmpresa=" + idEmpresa +
                ", idCliente=" + idCliente +
                ", periodo=" + periodo +
                ", vlrPagamentoLiquido=" + vlrPagamentoLiquido +
                '}';
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    /**
     * Ordena lista de ClienteHistoricoPagamentoDto pela coluna período.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dtos  Lista de ClienteHistoricoPagamentoDto.
     *
     */
    public static void orderByPeriodo( List<ClienteHistoricoPagamentoDto> dtos ) {

        if ( isVazia(dtos) )
            return;

        sort( dtos, new Comparator<ClienteHistoricoPagamentoDto>() {
            @Override
            public int compare( final ClienteHistoricoPagamentoDto dtoA,
                                final ClienteHistoricoPagamentoDto dtoB ) {

                return getOrElse( dtoA.getPeriodo(), getData( 1, 1, 1900 ) )
                        .compareTo( getOrElse( dtoB.getPeriodo(), getData( 1, 1, 1900 ) ) );
            }
        } );

    }


    /**
     * Sumariza varios em apenas um cliente.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dtos      Lista de ClienteHistoricoPagamentoDto.
     * @param idCliente Código do cliente.
     *
     * @return  Lista de histórico de pagamentos.
     */
    public static List<ClienteHistoricoPagamentoDto> sumarizarPorCliente(List<ClienteHistoricoPagamentoDto> dtos,
                                                                         final long idCliente ) {

        if ( isVazia( dtos ))
            return emptyList();

        orderByPeriodo( dtos );

        Map<Date, BigDecimal> acumulador = new HashMap<Date, BigDecimal>( );
        Date key = null;

        for ( ClienteHistoricoPagamentoDto dto : dtos ) {
            key = dto.getPeriodo();
            acumulador.put( key, acumulador.containsKey( key ) ? somar( acumulador.get( key ), dto.getVlrPagamentoLiquido() ) : dto.getVlrPagamentoLiquido() );
        }

        final short idEmpresa = dtos.get( 0 ).getIdEmpresa();
        List<ClienteHistoricoPagamentoDto> newDtos = new ArrayList<ClienteHistoricoPagamentoDto>( acumulador.size() );

        for ( Date periodo : acumulador.keySet() )
            newDtos.add( new ClienteHistoricoPagamentoDto( idEmpresa, idCliente, periodo, acumulador.get( periodo ) ) );

        return newDtos;
    }


}
