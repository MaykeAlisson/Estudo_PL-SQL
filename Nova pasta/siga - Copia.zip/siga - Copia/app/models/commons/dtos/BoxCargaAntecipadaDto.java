package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;

public class BoxCargaAntecipadaDto implements Serializable {

    private final Long idBoxCargaAntecipada;
    private final String box;
    private final BigDecimal volumeBox;
    private final BigDecimal volumeAlocado;

    public BoxCargaAntecipadaDto(Long idBoxCargaAntecipada, String box, BigDecimal volumeBox, BigDecimal volumeAlocado) {
        this.idBoxCargaAntecipada = idBoxCargaAntecipada;
        this.box = box;
        this.volumeBox = volumeBox;
        this.volumeAlocado = volumeAlocado;
    }

    public Long getIdBoxCargaAntecipada() {
        return idBoxCargaAntecipada;
    }

    public String getBox() {
        return box;
    }

    public BigDecimal getVolumeBox() {
        return volumeBox;
    }

    public BigDecimal getVolumeAlocado() {
        return volumeAlocado;
    }
}
