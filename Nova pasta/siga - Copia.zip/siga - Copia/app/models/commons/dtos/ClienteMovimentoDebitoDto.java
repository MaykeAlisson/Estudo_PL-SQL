package models.commons.dtos;

import java.io.Serializable;
import java.util.Date;

import static infra.util.UtilDate.*;
import static infra.util.UtilString.isVazia;

/**
 * Classe ref. informações de pagamento do cliente.
 *
 * <p>Autor: GPortes/Cleber</p>
 *
 * @since  22/08/2014.
 */
public class ClienteMovimentoDebitoDto implements Serializable {

    private static final long serialVersionUID = 7704524065710553494L;

    private final Short idEmpresa;
    private final Long seqDebito;
    private final Short idLanctoDebito;
    private final Date dataBaixa;
    private final Long idCliente;
    private final Long diasAtraso;


    public ClienteMovimentoDebitoDto( final Short idEmpresa,
                                      final Long seqDebito,
                                      final Short idLanctoDebito,
                                      final Date dataBaixa,
                                      final Long idCliente,
                                      final Date dataVencimento,
                                      final Date dataPagamento,
                                      final String tempErro ) {

        this.idEmpresa = idEmpresa;
        this.seqDebito = seqDebito;
        this.idLanctoDebito = idLanctoDebito;
        this.dataBaixa = dataBaixa;
        this.idCliente = idCliente;

        final Date dtPagto = ( isVazia( tempErro ) ? dataPagamento :  adicionarNDias( -1, dataPagamento ) );
        this.diasAtraso = ehMenor( dtPagto, dataVencimento ) ? 0 : diferencaEmDias( dataVencimento, dtPagto );
    }

    public ClienteMovimentoDebitoDto( final Short idEmpresa,
                                      final Long seqDebito,
                                      final Short idLanctoDebito,
                                      final Date dataBaixa,
                                      final Long idCliente,
                                      final Date dataVencimento,
                                      final Date dataPagamento ) {

        this( idEmpresa, seqDebito, idLanctoDebito, dataBaixa, idCliente, dataVencimento, dataPagamento, "" );
    }

    public Short getIdEmpresa() {

        return idEmpresa;
    }

    public Long getSeqDebito() {

        return seqDebito;
    }

    public Short getIdLanctoDebito() {

        return idLanctoDebito;
    }

    public Date getDataBaixa() {

        return dataBaixa;
    }

    public Long getIdCliente() {

        return idCliente;
    }

    public Long getDiasAtraso() {

        return diasAtraso;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object o ) {
        if ( this == o ) return true;
        if ( o == null || getClass() != o.getClass() ) return false;

        ClienteMovimentoDebitoDto that = (ClienteMovimentoDebitoDto) o;

        if ( getIdEmpresa() != null ? !getIdEmpresa().equals( that.getIdEmpresa() ) : that.getIdEmpresa() != null )
            return false;
        if ( getSeqDebito() != null ? !getSeqDebito().equals( that.getSeqDebito() ) : that.getSeqDebito() != null )
            return false;
        if ( getIdLanctoDebito() != null ? !getIdLanctoDebito().equals( that.getIdLanctoDebito() ) : that.getIdLanctoDebito() != null )
            return false;
        return !( getDataBaixa() != null ? !getDataBaixa().equals( that.getDataBaixa() ) : that.getDataBaixa() != null );

    }

    @Override
    public int hashCode() {
        int result = getIdEmpresa() != null ? getIdEmpresa().hashCode() : 0;
        result = 31 * result + ( getSeqDebito() != null ? getSeqDebito().hashCode() : 0 );
        result = 31 * result + ( getIdLanctoDebito() != null ? getIdLanctoDebito().hashCode() : 0 );
        result = 31 * result + ( getDataBaixa() != null ? getDataBaixa().hashCode() : 0 );
        return result;
    }

    @Override
    public String toString() {
        return "ClienteMovimentoDebitoDto{" +
                "idEmpresa=" + idEmpresa +
                ", seqDebito=" + seqDebito +
                '}';
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}
