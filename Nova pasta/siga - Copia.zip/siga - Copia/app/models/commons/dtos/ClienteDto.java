package models.commons.dtos;

import models.commons.constantes.SimNao;
import models.commons.constantes.SituacaoPedido;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

import static infra.util.UtilDate.toLocalDate;
import static infra.util.UtilDate.zerarHoras;
import static infra.util.UtilString.isVazia;
import static models.domains.vendas.OcorCliente.IdOcorCliente.ATIVO;

/**
 * Representa informações simplificadas do Cliente
 *
 * <p>Autor: GPortes</p>
 *
 * @since 08/05/2014
 *
 */
public class ClienteDto implements Serializable {

    private final Long idCliente;
    private final Short idEmpresa;
    private final String razaoSocial;
    private final Date dataImplantacao;
    private final LocalDateTime dataAbertura;
    private final BigDecimal vlrLimiteManualLoja;
    private final LocalDate validadeLimiteManualLoja;
    private final SimNao antecipado;
    private final SimNao analiseCredito;
    private final SimNao analiseCreditoDiferenciada;
    private final String endereco;
    private final String nroEndereco;
    private final Short idCidade;
    private final Short idDistrito;
    private final Short idRamoAtividade;
    private final Date dataReativacao;
    private final Date dataLimiteReativacao;
    private final String descricaoOcorCadastro;
    private final SituacaoPedido situacaoPedidoOcorCadastro;
    private final Short idOcorrenciaCredito;
    private final String descricaoOcorCredito;
    private final SituacaoPedido situacaoPedidoOcorCredito;
    private final SituacaoPedido situacaoPedidoRamoAtividade;
    private final Short percAcrescLimiteCreditoCidade;
    private final Short percAcrescLimiteCreditoToleranciaCidade;

    /**
     * Construtor utilizado na query  [ Cliente.xml / Cliente.buscarClienteDto ]
     *
     * @param idCliente
     * @param idEmpresa
     * @param razaoSocial
     * @param dataImplantacao
     * @param vlrLimiteManualLoja
     * @param validadeLimiteCred
     * @param analiseCredito
     * @param analiseCreditoDiferenciada
     * @param endereco
     * @param nroEndereco
     * @param idCidade
     * @param idDistrito
     * @param idRamoAtividade
     * @param dataReativacao
     * @param dataLimiteReativacao
     * @param dataAbertura
     * @param descricaoOcorCadastro
     * @param situacaoPedidoOcorCadastro
     * @param idOcorrenciaCredito
     * @param descricaoOcorCredito
     * @param situacaoPedidoOcorCredito
     * @param idClienteAntecipado
     * @param situacaoPedidoRamoAtividade
     * @param percAcrescLimiteCreditoCidade
     * @param percAcrescLimiteCreditoToleranciaCidade
     */
    public ClienteDto(
        final Long idCliente,
        final Short idEmpresa,
        final String razaoSocial,
        final Date dataImplantacao,
        final BigDecimal vlrLimiteManualLoja,
        final LocalDateTime validadeLimiteCred,
        final SimNao analiseCredito,
        final SimNao analiseCreditoDiferenciada,
        final String endereco,
        final String nroEndereco,
        final Short idCidade,
        final Short idDistrito,
        final Short idRamoAtividade,
        final Date dataReativacao,
        final Date dataLimiteReativacao,
        final LocalDateTime dataAbertura,
        final String descricaoOcorCadastro,
        final SituacaoPedido situacaoPedidoOcorCadastro,
        final Short idOcorrenciaCredito,
        final String descricaoOcorCredito,
        final SituacaoPedido situacaoPedidoOcorCredito,
        final Long idClienteAntecipado,
        final SituacaoPedido situacaoPedidoRamoAtividade,
        final Short percAcrescLimiteCreditoCidade,
        final Short percAcrescLimiteCreditoToleranciaCidade
    ) {

        this.idCliente = idCliente;
        this.idEmpresa = idEmpresa;
        this.razaoSocial = razaoSocial;
        this.dataImplantacao = zerarHoras( dataImplantacao );
        this.dataAbertura = zerarHoras( dataAbertura );
        this.vlrLimiteManualLoja = vlrLimiteManualLoja;
        this.validadeLimiteManualLoja = toLocalDate( validadeLimiteCred );
        this.analiseCredito = analiseCredito;
        this.analiseCreditoDiferenciada = analiseCreditoDiferenciada;
        this.endereco = endereco;
        this.nroEndereco = nroEndereco;
        this.idCidade = idCidade;
        this.idDistrito = idDistrito;
        this.idRamoAtividade = idRamoAtividade;
        this.dataReativacao = zerarHoras( dataReativacao );
        this.dataLimiteReativacao = zerarHoras( dataLimiteReativacao );
        this.descricaoOcorCadastro = descricaoOcorCadastro;
        this.situacaoPedidoOcorCadastro = situacaoPedidoOcorCadastro;
        this.idOcorrenciaCredito = idOcorrenciaCredito;
        this.descricaoOcorCredito = descricaoOcorCredito;
        this.situacaoPedidoOcorCredito = situacaoPedidoOcorCredito;
        this.antecipado = idClienteAntecipado != null ? SimNao.SIM : SimNao.NAO;
        this.situacaoPedidoRamoAtividade = situacaoPedidoRamoAtividade;
        this.percAcrescLimiteCreditoCidade = percAcrescLimiteCreditoCidade;
        this.percAcrescLimiteCreditoToleranciaCidade = percAcrescLimiteCreditoToleranciaCidade;
    }

    public Long getIdCliente() {

        return idCliente;
    }

    public Short getIdEmpresa() {

        return idEmpresa;
    }

    public String getRazaoSocial() {

        return razaoSocial;
    }

    public Date getDataImplantacao() {

        return dataImplantacao;
    }

    public LocalDateTime getDataAbertura() {

        return dataAbertura;
    }

    public BigDecimal getVlrLimiteManualLoja() {

        return vlrLimiteManualLoja;
    }

    public LocalDate getValidadeLimiteManualLoja() {

        return validadeLimiteManualLoja;
    }

    public SimNao getAnaliseCredito() {

        return analiseCredito;
    }

    public SimNao getAnaliseCreditoDiferenciada() {

        return analiseCreditoDiferenciada;
    }

    public String getEndereco() {

        return endereco;
    }

    public String getNroEndereco() {

        return nroEndereco;
    }

    public Short getIdCidade() {

        return idCidade;
    }

    public Short getIdDistrito() {

        return idDistrito;
    }

    public Short getIdRamoAtividade() {

        return idRamoAtividade;
    }

    public Date getDataReativacao() {

        return dataReativacao;
    }

    public Date getDataLimiteReativacao() {

        return dataLimiteReativacao;
    }

    public String getDescricaoOcorCadastro() {

        return isVazia( descricaoOcorCadastro ) ? ATIVO.getDescricao() : descricaoOcorCadastro;
    }

    public SituacaoPedido getSituacaoPedidoOcorCadastro() {

        return situacaoPedidoOcorCadastro;
    }

    public Short getIdOcorrenciaCredito() {

        return idOcorrenciaCredito;
    }

    public String getDescricaoOcorCredito() {

        return descricaoOcorCredito;
    }

    public SituacaoPedido getSituacaoPedidoOcorCredito() {

        return situacaoPedidoOcorCredito;
    }

    public ClienteEnderecoDto getClienteEnderecoDto() {

        return new ClienteEnderecoDto( idEmpresa, idCliente, endereco, nroEndereco, idCidade );
    }

    public SimNao getAntecipado() {

        return antecipado;
    }

    public SituacaoPedido getSituacaoPedidoRamoAtividade() {

        return situacaoPedidoRamoAtividade;
    }

    public Short getPercAcrescLimiteCreditoCidade() {

        return percAcrescLimiteCreditoCidade;
    }

    public Short getPercAcrescLimiteCreditoToleranciaCidade() {

        return percAcrescLimiteCreditoToleranciaCidade;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ClienteDto)) return false;

        ClienteDto that = (ClienteDto) o;

        if (idCliente != null ? !idCliente.equals(that.idCliente) : that.idCliente != null) return false;
        if (idEmpresa != null ? !idEmpresa.equals(that.idEmpresa) : that.idEmpresa != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = idCliente != null ? idCliente.hashCode() : 0;
        result = 31 * result + (idEmpresa != null ? idEmpresa.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ClienteDto{ idCliente=" + idCliente + ", idEmpresa=" + idEmpresa + '}';
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}
