package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;


/**
 * Classe que representa informaþ§es...
 *
 * <p>Autor: Tiagopti</p>
 *
 * @since 31/07/2018
 */
public class IncidInssDto implements Serializable {

    private final Long id;
    private final BigDecimal cpf;
    private final Short categoria;
    private final String matricula;
    private final Long idIncid;
    private final String decimoTerceiro;
    private final Short tipoIncid;
    private final BigDecimal valorIncid;

    public IncidInssDto(
        final Long id,
        final BigDecimal cpf,
        final Short categoria,
        final String matricula,
        final Long idIncid,
        final String decimoTerceiro,
        final Short tipoIncid,
        final BigDecimal valorIncid
    ) {
        this.id = id;
        this.cpf = cpf;
        this.categoria = categoria;
        this.matricula = matricula;
        this.idIncid = idIncid;
        this.decimoTerceiro = decimoTerceiro;
        this.tipoIncid = tipoIncid;
        this.valorIncid = valorIncid;
    }

    public Long getId() {
        return id;
    }

    public BigDecimal getCpf() {
        return cpf;
    }

    public Short getCategoria() {
        return categoria;
    }

    public String getMatricula() {
        return matricula;
    }

    public Long getIdIncid() {
        return idIncid;
    }

    public String getDecimoTerceiro() {
        return decimoTerceiro;
    }

    public Short getTipoIncid() {
        return tipoIncid;
    }

    public BigDecimal getValorIncid() {
        return valorIncid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof IncidInssDto)) return false;
        IncidInssDto that = (IncidInssDto) o;
        return Objects.equals(getId(), that.getId()) &&
                Objects.equals(getCpf(), that.getCpf()) &&
                Objects.equals(getCategoria(), that.getCategoria()) &&
                Objects.equals(getMatricula(), that.getMatricula()) &&
                Objects.equals(getIdIncid(), that.getIdIncid()) &&
                Objects.equals(getDecimoTerceiro(), that.getDecimoTerceiro()) &&
                Objects.equals(getTipoIncid(), that.getTipoIncid()) &&
                Objects.equals(getValorIncid(), that.getValorIncid());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getCpf(), getCategoria(), getMatricula(), getIdIncid(), getDecimoTerceiro(), getTipoIncid(), getValorIncid());
    }
}

