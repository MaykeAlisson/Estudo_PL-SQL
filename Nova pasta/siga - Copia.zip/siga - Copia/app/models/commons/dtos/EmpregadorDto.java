package models.commons.dtos;

import infra.model.Model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

/**
 * Classe que representa informaþ§es...
 *
 * <p>Autor: Fernandopti</p>
 *
 * @since 18/10/2017
 */
public class EmpregadorDto extends Model {

    private Short idEmpresa;
    private Short tipoPessoa;
    private BigDecimal cnpj;
    private String razaoSocial;
    private Short classifricacaoTributaria;
    private Short naturezaJuridica;
    private Long indCooperativa;
    private Long indConstrutora;
    private Short indDesoneracao;
    private Long indRegEletronicoFunc;
    private String indEntidadeEducativa;
    private String indEmpresaTrabTemporario;
    private String respDpNome;
    private BigDecimal respDpCpf;
    private String respDpTelefone;
    private String respDpEmail;
    private BigDecimal softwareCnpj;
    private String softwareRazao;
    private String softwateNomeContato;
    private String softwateFoneContato;
    private String softwareEmailContato;
    private Short situacaoEspecial;
    private String respContabilNome;
    private BigDecimal respContabilCpf;
    private String respContabilTelefone;
    private String respContabilEmail;

    public Short getIdEmpresa() {

        return this.idEmpresa;
    }

    public void setIdEmpresa( final Short idEmpresa ) {

        this.idEmpresa = idEmpresa;
    }

    public Short getTipoPessoa() {

        return this.tipoPessoa;
    }

    public void setTipoPessoa( final Short tipoPessoa ) {

        this.tipoPessoa = tipoPessoa;
    }

    public BigDecimal getCnpj() {

        return this.cnpj;
    }

    public void setCnpj( final BigDecimal cnpj ) {

        this.cnpj = cnpj;
    }

    public String getRazaoSocial() {

        return this.razaoSocial;
    }

    public void setRazaoSocial( final String razaoSocial ) {

        this.razaoSocial = razaoSocial;
    }

    public Short getClassifricacaoTributaria() {

        return this.classifricacaoTributaria;
    }

    public void setClassifricacaoTributaria( final Short classifricacaoTributaria ) {

        this.classifricacaoTributaria = classifricacaoTributaria;
    }

    public Short getNaturezaJuridica() {

        return this.naturezaJuridica;
    }

    public void setNaturezaJuridica( final Short naturezaJuridica ) {

        this.naturezaJuridica = naturezaJuridica;
    }

    public Long getIndCooperativa() {

        return this.indCooperativa;
    }

    public void setIndCooperativa( final Long indCooperativa ) {

        this.indCooperativa = indCooperativa;
    }

    public Long getIndConstrutora() {

        return this.indConstrutora;
    }

    public void setIndConstrutora( final Long indConstrutora ) {

        this.indConstrutora = indConstrutora;
    }

    public Short getIndDesoneracao() {

        return this.indDesoneracao;
    }

    public void setIndDesoneracao( final Short indDesoneracao ) {

        this.indDesoneracao = indDesoneracao;
    }

    public Long getIndRegEletronicoFunc() {

        return this.indRegEletronicoFunc;
    }

    public void setIndRegEletronicoFunc( final Long indRegEletronicoFunc ) {

        this.indRegEletronicoFunc = indRegEletronicoFunc;
    }

    public String getIndEntidadeEducativa() {

        return this.indEntidadeEducativa;
    }

    public void setIndEntidadeEducativa( final String indEntidadeEducativa ) {

        this.indEntidadeEducativa = indEntidadeEducativa;
    }

    public String getIndEmpresaTrabTemporario() {

        return this.indEmpresaTrabTemporario;
    }

    public void setIndEmpresaTrabTemporario( final String indEmpresaTrabTemporario ) {

        this.indEmpresaTrabTemporario = indEmpresaTrabTemporario;
    }

    public String getRespDpNome() {

        return this.respDpNome;
    }

    public void setRespDpNome( final String respDpNome ) {

        this.respDpNome = respDpNome;
    }

    public BigDecimal getRespDpCpf() {

        return this.respDpCpf;
    }

    public void setRespDpCpf( final BigDecimal respDpCpf ) {

        this.respDpCpf = respDpCpf;
    }

    public String getRespDpTelefone() {

        return this.respDpTelefone;
    }

    public void setRespDpTelefone( final String respDpTelefone ) {

        this.respDpTelefone = respDpTelefone;
    }

    public String getRespDpEmail() {

        return this.respDpEmail;
    }

    public void setRespDpEmail( final String respDpEmail ) {

        this.respDpEmail = respDpEmail;
    }

    public BigDecimal getSoftwareCnpj() {

        return this.softwareCnpj;
    }

    public void setSoftwareCnpj( final BigDecimal softwareCnpj ) {

        this.softwareCnpj = softwareCnpj;
    }

    public String getSoftwareRazao() {

        return this.softwareRazao;
    }

    public void setSoftwareRazao( final String softwareRazao ) {

        this.softwareRazao = softwareRazao;
    }

    public String getSoftwateNomeContato() {

        return this.softwateNomeContato;
    }

    public void setSoftwateNomeContato( final String softwateNomeContato ) {

        this.softwateNomeContato = softwateNomeContato;
    }

    public String getSoftwateFoneContato() {

        return this.softwateFoneContato;
    }

    public void setSoftwateFoneContato( final String softwateFoneContato ) {

        this.softwateFoneContato = softwateFoneContato;
    }

    public String getSoftwareEmailContato() {

        return this.softwareEmailContato;
    }

    public void setSoftwareEmailContato( final String softwareEmailContato ) {

        this.softwareEmailContato = softwareEmailContato;
    }

    public Short getSituacaoEspecial() {

        return this.situacaoEspecial;
    }

    public void setSituacaoEspecial( final Short situacaoEspecial ) {

        this.situacaoEspecial = situacaoEspecial;
    }

    public String getRespContabilNome() {
        return respContabilNome;
    }

    public void setRespContabilNome(String respContabilNome) {
        this.respContabilNome = respContabilNome;
    }

    public BigDecimal getRespContabilCpf() {
        return respContabilCpf;
    }

    public void setRespContabilCpf(BigDecimal respContabilCpf) {
        this.respContabilCpf = respContabilCpf;
    }

    public String getRespContabilTelefone() {
        return respContabilTelefone;
    }

    public void setRespContabilTelefone(String respContabilTelefone) {
        this.respContabilTelefone = respContabilTelefone;
    }

    public String getRespContabilEmail() {
        return respContabilEmail;
    }

    public void setRespContabilEmail(String respContabilEmail) {
        this.respContabilEmail = respContabilEmail;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof EmpregadorDto)) return false;
        EmpregadorDto that = (EmpregadorDto) o;
        return Objects.equals(getIdEmpresa(), that.getIdEmpresa()) &&
                Objects.equals(getTipoPessoa(), that.getTipoPessoa()) &&
                Objects.equals(getCnpj(), that.getCnpj()) &&
                Objects.equals(getRazaoSocial(), that.getRazaoSocial()) &&
                Objects.equals(getClassifricacaoTributaria(), that.getClassifricacaoTributaria()) &&
                Objects.equals(getNaturezaJuridica(), that.getNaturezaJuridica()) &&
                Objects.equals(getIndCooperativa(), that.getIndCooperativa()) &&
                Objects.equals(getIndConstrutora(), that.getIndConstrutora()) &&
                Objects.equals(getIndDesoneracao(), that.getIndDesoneracao()) &&
                Objects.equals(getIndRegEletronicoFunc(), that.getIndRegEletronicoFunc()) &&
                Objects.equals(getIndEntidadeEducativa(), that.getIndEntidadeEducativa()) &&
                Objects.equals(getIndEmpresaTrabTemporario(), that.getIndEmpresaTrabTemporario()) &&
                Objects.equals(getRespDpNome(), that.getRespDpNome()) &&
                Objects.equals(getRespDpCpf(), that.getRespDpCpf()) &&
                Objects.equals(getRespDpTelefone(), that.getRespDpTelefone()) &&
                Objects.equals(getRespDpEmail(), that.getRespDpEmail()) &&
                Objects.equals(getSoftwareCnpj(), that.getSoftwareCnpj()) &&
                Objects.equals(getSoftwareRazao(), that.getSoftwareRazao()) &&
                Objects.equals(getSoftwateNomeContato(), that.getSoftwateNomeContato()) &&
                Objects.equals(getSoftwateFoneContato(), that.getSoftwateFoneContato()) &&
                Objects.equals(getSoftwareEmailContato(), that.getSoftwareEmailContato()) &&
                Objects.equals(getSituacaoEspecial(), that.getSituacaoEspecial()) &&
                Objects.equals(getRespContabilNome(), that.getRespContabilNome()) &&
                Objects.equals(getRespContabilCpf(), that.getRespContabilCpf()) &&
                Objects.equals(getRespContabilTelefone(), that.getRespContabilTelefone()) &&
                Objects.equals(getRespContabilEmail(), that.getRespContabilEmail());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdEmpresa(), getTipoPessoa(), getCnpj(), getRazaoSocial(), getClassifricacaoTributaria(), getNaturezaJuridica(), getIndCooperativa(), getIndConstrutora(), getIndDesoneracao(), getIndRegEletronicoFunc(), getIndEntidadeEducativa(), getIndEmpresaTrabTemporario(), getRespDpNome(), getRespDpCpf(), getRespDpTelefone(), getRespDpEmail(), getSoftwareCnpj(), getSoftwareRazao(), getSoftwateNomeContato(), getSoftwateFoneContato(), getSoftwareEmailContato(), getSituacaoEspecial(), getRespContabilNome(), getRespContabilCpf(), getRespContabilTelefone(), getRespContabilEmail());
    }
}
