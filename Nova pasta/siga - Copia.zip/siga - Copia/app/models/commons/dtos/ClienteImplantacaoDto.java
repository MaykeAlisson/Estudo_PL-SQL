package models.commons.dtos;

import java.io.Serializable;
import java.util.Date;

/**
 * Classe ref. a informação de implantação do cliente na analise de credito.
 *
 * <p>Autor: GPortes</p>
 *
 * @since  22/08/2014.
 */
public class ClienteImplantacaoDto implements Serializable {

    private static final long serialVersionUID = 1342824542221013323L;

    private final Date data;
    private final boolean implantacao;
    private final String motivo;


    /**
     * Construtor para cliente implantação
     *
     * <p>Autor:GPortes </p>
     *
     * @param data      Data da implantação.
     * @param motivo    Motivo da implantação.
     */
    public ClienteImplantacaoDto( final Date data,
                                  final String motivo ) {

        this.data = data;
        this.motivo = motivo;
        this.implantacao = true;
    }

    /**
     * Construtor para cliente implantação ou reimplantação
     *
     * @param data          Data da implantação ou reimplantação.
     * @param implantacao   True: Implantação - False: o contrário (reimplantação)
     * @param motivo        Motivo da implantação ou reimplantação.
     */
    public ClienteImplantacaoDto( final Date data,
                                  final boolean implantacao,
                                  final String motivo ) {

        this.data = data;
        this.implantacao = implantacao;
        this.motivo = motivo;
    }

    public Date getData() {
        return data;
    }

    public boolean ehImplantacao() {
        return this.implantacao;
    }

    public String getMotivo() {
        return motivo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ClienteImplantacaoDto)) return false;

        ClienteImplantacaoDto that = (ClienteImplantacaoDto) o;

        if (implantacao != that.implantacao) return false;
        if (data != null ? !data.equals(that.data) : that.data != null) return false;
        if (motivo != null ? !motivo.equals(that.motivo) : that.motivo != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = data != null ? data.hashCode() : 0;
        result = 31 * result + (implantacao ? 1 : 0);
        result = 31 * result + (motivo != null ? motivo.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ClienteImplantacao{" +
                "data=" + data +
                ", implantacao=" + implantacao +
                ", motivo='" + motivo + '\'' +
                '}';
    }
}
