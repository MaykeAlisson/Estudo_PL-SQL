package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

public class DependentesESocialDto implements Serializable {

    private Short idEmpresa;
    private Long idFuncionario;
    private Short sequencia;
    private String tipoDependente;
    private String nomeDependente;
    private Date nascimentoDependente;
    private BigDecimal cpfDependente;
    private String depIrrf;
    private String depSf;
    private String depConvenio;
    private String incapacidadeFisica;

    public Short getIdEmpresa() {

        return this.idEmpresa;
    }

    public void setIdEmpresa( final Short idEmpresa ) {

        this.idEmpresa = idEmpresa;
    }

    public Long getIdFuncionario() {

        return this.idFuncionario;
    }

    public void setIdFuncionario( final Long idFuncionario ) {

        this.idFuncionario = idFuncionario;
    }

    public Short getSequencia() {

        return this.sequencia;
    }

    public void setSequencia( final Short sequencia ) {

        this.sequencia = sequencia;
    }

    public String getTipoDependente() {

        return this.tipoDependente;
    }

    public void setTipoDependente( final String tipoDependente ) {

        this.tipoDependente = tipoDependente;
    }

    public String getNomeDependente() {

        return this.nomeDependente;
    }

    public void setNomeDependente( final String nomeDependente ) {

        this.nomeDependente = nomeDependente;
    }

    public Date getNascimentoDependente() {

        return this.nascimentoDependente;
    }

    public void setNascimentoDependente( final Date nascimentoDependente ) {

        this.nascimentoDependente = nascimentoDependente;
    }

    public BigDecimal getCpfDependente() {

        return this.cpfDependente;
    }

    public void setCpfDependente( final BigDecimal cpfDependente ) {

        this.cpfDependente = cpfDependente;
    }

    public String getDepIrrf() {

        return this.depIrrf;
    }

    public void setDepIrrf( final String depIrrf ) {

        this.depIrrf = depIrrf;
    }

    public String getDepSf() {

        return this.depSf;
    }

    public void setDepSf( final String depSf ) {

        this.depSf = depSf;
    }

    public String getDepConvenio() {

        return this.depConvenio;
    }

    public void setDepConvenio( final String depConvenio ) {

        this.depConvenio = depConvenio;
    }

    public String getIncapacidadeFisica() {

        return this.incapacidadeFisica;
    }

    public void setIncapacidadeFisica( final String incapacidadeFisica ) {

        this.incapacidadeFisica = incapacidadeFisica;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DependentesESocialDto that = (DependentesESocialDto) o;

        if (idEmpresa != null ? !idEmpresa.equals(that.idEmpresa) : that.idEmpresa != null) return false;
        if (idFuncionario != null ? !idFuncionario.equals(that.idFuncionario) : that.idFuncionario != null)
            return false;
        if (sequencia != null ? !sequencia.equals(that.sequencia) : that.sequencia != null) return false;
        if (tipoDependente != null ? !tipoDependente.equals(that.tipoDependente) : that.tipoDependente != null)
            return false;
        if (nomeDependente != null ? !nomeDependente.equals(that.nomeDependente) : that.nomeDependente != null)
            return false;
        if (nascimentoDependente != null ? !nascimentoDependente.equals(that.nascimentoDependente) : that.nascimentoDependente != null)
            return false;
        if (cpfDependente != null ? !cpfDependente.equals(that.cpfDependente) : that.cpfDependente != null)
            return false;
        if (depIrrf != null ? !depIrrf.equals(that.depIrrf) : that.depIrrf != null) return false;
        if (depSf != null ? !depSf.equals(that.depSf) : that.depSf != null) return false;
        if (depConvenio != null ? !depConvenio.equals(that.depConvenio) : that.depConvenio != null) return false;
        return incapacidadeFisica != null ? incapacidadeFisica.equals(that.incapacidadeFisica) : that.incapacidadeFisica == null;
    }

    @Override
    public int hashCode() {
        int result = idEmpresa != null ? idEmpresa.hashCode() : 0;
        result = 31 * result + (idFuncionario != null ? idFuncionario.hashCode() : 0);
        result = 31 * result + (sequencia != null ? sequencia.hashCode() : 0);
        result = 31 * result + (tipoDependente != null ? tipoDependente.hashCode() : 0);
        result = 31 * result + (nomeDependente != null ? nomeDependente.hashCode() : 0);
        result = 31 * result + (nascimentoDependente != null ? nascimentoDependente.hashCode() : 0);
        result = 31 * result + (cpfDependente != null ? cpfDependente.hashCode() : 0);
        result = 31 * result + (depIrrf != null ? depIrrf.hashCode() : 0);
        result = 31 * result + (depSf != null ? depSf.hashCode() : 0);
        result = 31 * result + (depConvenio != null ? depConvenio.hashCode() : 0);
        result = 31 * result + (incapacidadeFisica != null ? incapacidadeFisica.hashCode() : 0);
        return result;
    }
}