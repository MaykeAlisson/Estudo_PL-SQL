package models.commons.dtos;

import java.io.Serializable;
import java.util.Objects;

public class GeradoraCatDto implements Serializable {

    private String codigo;
    private String descricao;

    public String getCodigo() {
        return codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public GeradoraCatDto(String codigo, String descricao) {
        this.codigo = codigo;
        this.descricao = descricao;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof GeradoraCatDto)) return false;
        GeradoraCatDto that = (GeradoraCatDto) o;
        return Objects.equals(getCodigo(), that.getCodigo()) &&
                Objects.equals(getDescricao(), that.getDescricao());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getCodigo(), getDescricao());
    }
}