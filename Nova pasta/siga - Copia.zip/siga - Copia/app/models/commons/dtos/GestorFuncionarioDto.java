package models.commons.dtos;

import java.io.Serializable;
import java.util.Objects;

import static infra.util.UtilString.getOrElse;
import static infra.util.UtilString.trim;
import static java.lang.String.format;

/**
 * Classe que representa informações do gestor do funcionario.
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 14/02/2018
 */
public class GestorFuncionarioDto implements Serializable {

    private final Short idDepartamento;
    private final String descricaoDepartamento;
    private final Short idEmpresa;
    private final Long idDiretor;
    private final String nomeDiretor;
    private final String emailDiretor;
    private final Long idGestor;
    private final String nomeGestor;
    private final String emailGestor;
    private final Long idFuncionario;
    private final String nomeFuncionario;
    private final String emailFuncionario;

    public GestorFuncionarioDto(
        final Short idDepartamento,
        final String descricaoDepartamento,
        final Short idEmpresa,
        final Long idDiretor,
        final String nomeDiretor,
        final String emailDiretor,
        final Long idGestor,
        final String nomeGestor,
        final String emailGestor,
        final Long idFuncionario,
        final String nomeFuncionario,
        final String emailFuncionario
    ) {

        this.idDepartamento = idDepartamento;
        this.descricaoDepartamento = descricaoDepartamento;
        this.idEmpresa = idEmpresa;
        this.idDiretor = idDiretor;
        this.nomeDiretor = nomeDiretor;
        this.emailDiretor = emailDiretor;
        this.idGestor = idGestor;
        this.nomeGestor = nomeGestor;
        this.emailGestor = emailGestor;
        this.idFuncionario = idFuncionario;
        this.nomeFuncionario = nomeFuncionario;
        this.emailFuncionario = emailFuncionario;
    }

    public Short getIdDepartamento() {

        return idDepartamento;
    }

    public String getDescricaoDepartamento() {

        return descricaoDepartamento;
    }

    public Short getIdEmpresa() {

        return idEmpresa;
    }

    public Long getIdDiretor() {

        return idDiretor;
    }

    public String getNomeDiretor() {

        return nomeDiretor;
    }

    public String getEmailDiretor() {

        return emailDiretor;
    }

    public Long getIdGestor() {

        return idGestor;
    }

    public String getNomeGestor() {

        return nomeGestor;
    }

    public String getEmailGestor() {

        return emailGestor;
    }

    public Long getIdFuncionario() {

        return idFuncionario;
    }

    public String getNomeFuncionario() {

        return nomeFuncionario;
    }

    public String getEmailFuncionario() {

        return emailFuncionario;
    }

    public String getInfoTelecom() {

        return format( "%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s",
            getIdEmpresa(),
            trim( getDescricaoDepartamento() ),
            getIdDiretor(),
            getNomeDiretor(),
            getEmailDiretor(),
            getIdGestor(),
            trim( getNomeGestor() ),
            getOrElse( trim( getEmailGestor() ), "NAO_CADASTRADO" ),
            getIdFuncionario(),
            trim( getNomeFuncionario() ),
            getOrElse( trim( getEmailFuncionario() ), "NAO_CADASTRADO" )
        );
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object o ) {

        if ( this == o ) return true;
        if ( !(o instanceof GestorFuncionarioDto) ) return false;
        GestorFuncionarioDto that = (GestorFuncionarioDto) o;
        return Objects.equals(getIdDepartamento(), that.getIdDepartamento()) &&
                Objects.equals(getIdEmpresa(), that.getIdEmpresa()) &&
                Objects.equals(getIdGestor(), that.getIdGestor()) &&
                Objects.equals(getIdFuncionario(), that.getIdFuncionario());
    }

    @Override
    public int hashCode() {

        return Objects.hash(getIdDepartamento(), getIdEmpresa(), getIdGestor(), getIdFuncionario());
    }

    @Override
    public String toString() {

        return "GestorDoFuncionarioDto { idDepartamento = " + idDepartamento + ", idEmpresa = " + idEmpresa + ", idGestor = " + idGestor + ", idFuncionario = " + idFuncionario + " }";
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}


