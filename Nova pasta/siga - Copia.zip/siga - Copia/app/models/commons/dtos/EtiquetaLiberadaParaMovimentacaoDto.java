package models.commons.dtos;

import java.io.Serializable;
import java.util.Objects;


/**
 * Classe que representa informações da busca pela cargas liberadas para
 * movimentação entre boxes. Boxes de liberaçao ou origemEtiqueta de carregamento.
 *
 * <p>Autor: Andre Luiz Alves de Faria</p>
 *
 * @since 28/08/2018
 */
public class EtiquetaLiberadaParaMovimentacaoDto implements Serializable {

    private final Long idCarga;
    private final String boxDestino;
    private final Long qtdMovimentada;
    private final Short digitoBoxDestino;
    private final String filtroOrigemEtiqueta;
    private final String origemEtiqueta;
    private final Short statusLiberacao;
    private final String modulo;

    public EtiquetaLiberadaParaMovimentacaoDto(
            Long idCarga,
            String boxDestino,
            Long qtdMovimentada,
            Short digitoBoxDestino,
            String filtroOrigemEtiqueta,
            String origemEtiqueta,
            Short statusLiberacao,
            String modulo ) {

        this.idCarga = idCarga;
        this.boxDestino = boxDestino;
        this.qtdMovimentada = qtdMovimentada;
        this.digitoBoxDestino = digitoBoxDestino;
        this.filtroOrigemEtiqueta = filtroOrigemEtiqueta;
        this.origemEtiqueta = origemEtiqueta;
        this.statusLiberacao = statusLiberacao;
        this.modulo = modulo;
    }


    public Long getIdCarga() {
        return idCarga;
    }

    public String getBoxDestino() {
        return boxDestino;
    }

    public Long getQtdMovimentada() {
        return qtdMovimentada;
    }

    public Short getDigitoBoxDestino() {
        return digitoBoxDestino;
    }

    public String getFiltroOrigemEtiqueta() { return filtroOrigemEtiqueta; }

    public String getOrigemEtiqueta() {
        return origemEtiqueta;
    }

    public Short getStatusLiberacao() { return statusLiberacao; }

    public String getmodulo() { return modulo; }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EtiquetaLiberadaParaMovimentacaoDto that = (EtiquetaLiberadaParaMovimentacaoDto) o;
        return Objects.equals(idCarga, that.idCarga) &&
                Objects.equals(boxDestino, that.boxDestino) &&
                Objects.equals(qtdMovimentada, that.qtdMovimentada) &&
                Objects.equals(digitoBoxDestino, that.digitoBoxDestino) &&
                Objects.equals(filtroOrigemEtiqueta, that.filtroOrigemEtiqueta) &&
                Objects.equals(origemEtiqueta, that.origemEtiqueta) &&
                Objects.equals(statusLiberacao, that.statusLiberacao) &&
                Objects.equals(modulo, that.modulo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCarga, boxDestino, qtdMovimentada, digitoBoxDestino, filtroOrigemEtiqueta,
                            origemEtiqueta, statusLiberacao, modulo);
    }

    @Override
    public String toString() {
        return "BuscarEtiquetaLiberadaParaMovimentacaoDto{" +
                "idCarga=" + idCarga +
                ", boxDestino='" + boxDestino + '\'' +
                ", qtdMovimentada=" + qtdMovimentada +
                ", digitoBoxDestino=" + digitoBoxDestino +
                ", filtroOrigemEtiqueta='" + filtroOrigemEtiqueta + '\'' +
                ", origemEtiqueta='" + origemEtiqueta + '\'' +
                ", statusLiberacao=" + statusLiberacao +
                ", modulo='" + modulo + '\'' +
                '}';
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}


