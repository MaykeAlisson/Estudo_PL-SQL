package models.commons.dtos;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Representa o periodo de reativação do cliente.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 11/06/2015
 */
public class ClienteReativacaoDto implements Serializable {

    private final Long idCliente;
    private final Date reativacao;
    private final Date limiteReativacao;
    private final List<Long> idClientesParticipaRede;

    public ClienteReativacaoDto( final Long idCliente,
                                 final Date reativacao,
                                 final Date limiteReativacao,
                                 final List<Long> idClientesParticipaRede ) {

        this.idCliente = idCliente;
        this.reativacao = reativacao;
        this.limiteReativacao = limiteReativacao;
        this.idClientesParticipaRede = idClientesParticipaRede;
    }

    public Long getIdCliente() {
        return idCliente;
    }

    public Date getReativacao() {
        return reativacao;
    }

    public Date getLimiteReativacao() {
        return limiteReativacao;
    }

    public List<Long> getIdClientesParticipaRede() {
        return idClientesParticipaRede;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object o ) {
        if ( this == o ) return true;
        if ( !( o instanceof ClienteReativacaoDto) ) return false;

        ClienteReativacaoDto that = (ClienteReativacaoDto) o;

        if ( idCliente != null ? !idCliente.equals( that.idCliente ) : that.idCliente != null ) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return idCliente != null ? idCliente.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "ClienteReativacaoDto { " +
                "idCliente = " + idCliente + " }";
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}