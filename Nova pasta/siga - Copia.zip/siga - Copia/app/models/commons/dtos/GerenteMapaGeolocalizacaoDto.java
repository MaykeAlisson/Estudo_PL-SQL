package models.commons.dtos;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

/**
 * Classe que representa informações de mapas de geolocalização de veiculos pertencentes a um Gerente de Transporte.
 *
 * <p>Autor: GPortes</p>
 */
public class GerenteMapaGeolocalizacaoDto implements Serializable {

    private final Short idGerente;
    private final List<String> mapa;

    public GerenteMapaGeolocalizacaoDto( final Short idGerente,
                                         final List<String> mapa ) {

        this.idGerente = idGerente;
        this.mapa = mapa;
    }

    public Short getIdGerente() {

        return idGerente;
    }

    public List<String> getMapa() {

        return mapa;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object o ) {
        if ( this == o ) return true;
        if ( o == null || getClass() != o.getClass() ) return false;
        GerenteMapaGeolocalizacaoDto that = (GerenteMapaGeolocalizacaoDto) o;
        return Objects.equals(idGerente, that.idGerente);
    }

    @Override
    public int hashCode() {

        return Objects.hash(idGerente);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}
