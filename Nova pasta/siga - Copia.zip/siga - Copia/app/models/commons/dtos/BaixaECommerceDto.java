package models.commons.dtos;

import models.commons.constantes.BandeiraCartao;
import models.commons.constantes.OperacaoBaixaECommerce;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;

import static infra.util.UtilDate.toLocalDate;
import static infra.util.UtilNumero.ehZero;
import static infra.util.UtilNumero.toLong;
import static infra.util.UtilNumero.toShort;
import static infra.util.UtilString.isVazia;
import static java.math.BigDecimal.ZERO;
import static models.commons.constantes.BandeiraCartao.AMEX;
import static models.commons.constantes.BandeiraCartao.ELO;
import static models.commons.constantes.BandeiraCartao.HIPERCARD;
import static models.commons.constantes.BandeiraCartao.MASTERCARD;
import static models.commons.constantes.BandeiraCartao.VISA;
import static models.commons.constantes.OperacaoBaixaECommerce.PAGTO;
import static models.commons.constantes.OperacaoBaixaECommerce.REEMBOLSO;
import static models.domains.seguranca.Usuario.USUARIO_SISTEMA;
import static models.domains.vendas.FormaPagamento.IdFormaPagamento;
import static models.domains.admin.Empresa.IdEmpresa;

/**
 * Classe que representa informações do Mercado Pago
 *
 * <p>Autor: Victor.serafim</p>
 *
 * @since 19/01/2019
 */
public class BaixaECommerceDto implements Serializable {

    private final String nroTransacao;
    private final LocalDate dataPagamento;
    private final String pedidoOrigem;
    private final OperacaoBaixaECommerce operacao;
    private final BigDecimal vlrLiquido;
    private final BigDecimal vlrBruto;
    private final BigDecimal vlrTaxa;
    private final IdEmpresa idEmpresaFormaPgto;
    private final IdFormaPagamento idFormaPagamento;
    private final BandeiraCartao bandeiraCartao;
    private final Long idUsuarioImportacao;
    private final String nomeArquivo;
    private final LocalDateTime dataImportacao;

    public BaixaECommerceDto( final Builder builder ) {

        this.nroTransacao = builder.nroTransacao;
        this.dataPagamento = builder.dataPagamento;
        this.pedidoOrigem = builder.pedidoOrigem;
        this.operacao = builder.operacao;
        this.vlrLiquido = builder.vlrLiquido;
        this.vlrBruto = builder.vlrBruto;
        this.vlrTaxa = builder.vlrTaxa;
        this.idEmpresaFormaPgto = builder.idEmpresaFormaPgto;
        this.idFormaPagamento = builder.idFormaPagamento;
        this.bandeiraCartao = builder.bandeiraCartao;
        this.idUsuarioImportacao = builder.idUsuarioImportacao;
        this.nomeArquivo = builder.nomeArquivo;
        this.dataImportacao = builder.dataImportacao;
    }

    public String getNroTransacao() {

        return nroTransacao;
    }

    public LocalDate getDataPagamento() {

        return dataPagamento;
    }

    public String getPedidoOrigem() {

        return pedidoOrigem;
    }

    public OperacaoBaixaECommerce getOperacao() {

        return operacao;
    }

    public BigDecimal getVlrLiquido() {

        return vlrLiquido;
    }

    public BigDecimal getVlrBruto() {

        return vlrBruto;
    }

    public BigDecimal getVlrTaxa() {

        return vlrTaxa;
    }

    public IdEmpresa getIdEmpresaFormaPgto() {

        return idEmpresaFormaPgto;
    }

    public IdFormaPagamento getIdFormaPagamento() {

        return idFormaPagamento;
    }

    public BandeiraCartao getBandeiraCartao() {

        return bandeiraCartao;
    }

    public Long getIdUsuarioImportacao() {

        return idUsuarioImportacao;
    }

    public String getNomeArquivo() {

        return nomeArquivo;
    }

    public LocalDateTime getDataImportacao() {

        return dataImportacao;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // BUILDER
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public static class Builder {

        private String nroTransacao;
        private LocalDate dataPagamento;
        private String pedidoOrigem;
        private OperacaoBaixaECommerce operacao;
        private BigDecimal vlrLiquido;
        private BigDecimal vlrBruto;
        private BigDecimal vlrTaxa;
        private IdEmpresa idEmpresaFormaPgto;
        private IdFormaPagamento idFormaPagamento;
        private BandeiraCartao bandeiraCartao;
        private Long idUsuarioImportacao;
        private String nomeArquivo;
        private LocalDateTime dataImportacao;

        public Builder( final String nroTransacao ) {

            this.nroTransacao = nroTransacao;
            this.dataPagamento = null;
            this.pedidoOrigem = null;
            this.operacao = PAGTO;
            this.vlrLiquido = ZERO;
            this.vlrBruto = ZERO;
            this.vlrTaxa = ZERO;
            this.idEmpresaFormaPgto = IdEmpresa.ARCOM;
            this.idFormaPagamento = null;
            this.bandeiraCartao = null;
            this.idUsuarioImportacao = USUARIO_SISTEMA;
            this.nomeArquivo = null;
            this.dataImportacao = null;
        }

        public Builder comDataPagamento( final String dataPagamento ) {

            this.dataPagamento = ( isVazia(dataPagamento) )
                                 ? null
                                 : toLocalDate( dataPagamento.substring(0,10), "yyyy-MM-dd" );
            return this;
        }

        public Builder comPedidoOrigem( final String pedidoOrigem ) {

            this.pedidoOrigem = pedidoOrigem;
            return this;
        }

        public Builder comTipoPagamento( final String tipoPagamento ) {

            if ( isVazia(tipoPagamento) ) return this;

            switch ( tipoPagamento ) {
                case "payment":
                    this.operacao = PAGTO;
                    break;
                case "refund":
                    this.operacao = REEMBOLSO;
                    break;
            }
            return this;
        }

        public Builder comVlrLiquido(final String vlrLiquido){

            this.vlrLiquido =  isVazia( vlrLiquido ) ? ZERO : new BigDecimal(vlrLiquido).abs();
            return this;
        }

        public Builder comVlrBruto(final String vlrBruto){

            this.vlrBruto = isVazia( vlrBruto ) ? ZERO : new BigDecimal(vlrBruto).abs();
            return this;
        }
        public Builder comVlrTaxa(final String vlrTaxa){

            this.vlrTaxa = isVazia( vlrTaxa ) ? ZERO : new BigDecimal(vlrTaxa).abs();
            return this;
        }
        public Builder comIdEmpresaFormaPgto(final IdEmpresa idEmpresaFormaPgto ){

            this.idEmpresaFormaPgto = idEmpresaFormaPgto;
            return this;
        }

        public Builder comIdFormaPagamento( final String idFormaPagamento ){

            if ( isVazia(idFormaPagamento) ) return this;

            switch ( idFormaPagamento ) {
                case "visa":
                    this.idFormaPagamento = IdFormaPagamento.CARTAO_CREDITO;
                    break;
                case "bolbradesco":
                    this.idFormaPagamento = IdFormaPagamento.BOLETO;
                    break;
                case "master":
                    this.idFormaPagamento = IdFormaPagamento.CARTAO_CREDITO;
                    break;
                case "amex":
                    this.idFormaPagamento = IdFormaPagamento.CARTAO_CREDITO;
                    break;
                case "hipercard":
                    this.idFormaPagamento = IdFormaPagamento.CARTAO_CREDITO;
                    break;
                case "elo":
                    this.idFormaPagamento = IdFormaPagamento.CARTAO_CREDITO;
                    break;
            }

            return this;
        }

        public Builder comBandeiraCartao( final String bandeiraCartao ) {

            if ( isVazia(bandeiraCartao) ) return this;

            switch ( bandeiraCartao ) {
                case "visa":
                    this.bandeiraCartao =VISA ;
                    return this;
                case "master":
                    this.bandeiraCartao = MASTERCARD;
                    return this;
                case "amex":
                    this.bandeiraCartao = AMEX;
                    return this;
                case "hipercard":
                    this.bandeiraCartao = HIPERCARD;
                    return this;
                case "elo":
                    this.bandeiraCartao = ELO;
                    return this;

            }
            return this;
        }

        public Builder comIdUsuarioImportacao(final String idUsuarioImportacao){

            this.idUsuarioImportacao=new Long(idUsuarioImportacao);
            return this;
        }


        public Builder comNomeArquivo( final String nomeArquivo ) {

            this.nomeArquivo = nomeArquivo;
            return this;
        }

        public Builder comDataImportacao( final LocalDateTime dataImportacao ) {

            this.dataImportacao = dataImportacao;
            return this;
        }

        public BaixaECommerceDto build() {

            return new BaixaECommerceDto(this );
        }

    }



    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BaixaECommerceDto that = (BaixaECommerceDto) o;
        return Objects.equals(nroTransacao, that.nroTransacao) &&
                operacao == that.operacao;
    }

    @Override
    public int hashCode() {
        return Objects.hash(nroTransacao, operacao);
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}


