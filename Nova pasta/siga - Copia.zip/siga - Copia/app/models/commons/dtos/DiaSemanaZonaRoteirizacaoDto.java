package models.commons.dtos;

import java.io.Serializable;

public class DiaSemanaZonaRoteirizacaoDto implements Serializable {
    private final String descricaoDiaSemana;
    private final Short diaSemana;
    private final String horario;

    public DiaSemanaZonaRoteirizacaoDto(String descricaoDiaSemana, Short diaSemana, String horario) {
        this.descricaoDiaSemana = descricaoDiaSemana;
        this.diaSemana = diaSemana;
        this.horario = horario;
    }

    public String getDescricaoDiaSemana() {
        return descricaoDiaSemana;
    }

    public Short getDiaSemana() {
        return diaSemana;
    }

    public String getHorario() {
        return horario;
    }
}
