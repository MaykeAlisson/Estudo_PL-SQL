package models.commons.dtos;

import java.io.Serializable;
import java.util.Objects;

public class ExamesLocaisDto implements Serializable {

    private Long codigo;
    private String descricao;
    private String obs1;
    private String obs2;
    private String obs3;
    private String obsAd;

    public ExamesLocaisDto(Long codigo,String descricao, String obs1, String obs2, String obs3, String obsAd) {
        this.codigo = codigo;
        this.descricao = descricao;
        this.obs1 = obs1;
        this.obs2 = obs2;
        this.obs3 = obs3;
        this.obsAd = obsAd;
    }

    public Long getCodigo() {
        return codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public String getObs1() {
        return obs1;
    }

    public String getObs2() {
        return obs2;
    }

    public String getObs3() {
        return obs3;
    }

    public String getObsAd() {
        return obsAd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ExamesLocaisDto)) return false;
        ExamesLocaisDto that = (ExamesLocaisDto) o;
        return Objects.equals(getCodigo(), that.getCodigo());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getCodigo());
    }
}