package models.commons.dtos;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

public class CleberProjecaoVendaDto {

    private LocalDate dataSemana;
    private BigDecimal valorVendaSemana;
    private LocalDate dataPedido;
    private BigDecimal valorVendaDia;
    private LocalDate dataFaturamento;
    private BigDecimal valorFaturadoDia;

    public LocalDate getDataSemana() {
        return dataSemana;
    }

    public void setDataSemana(LocalDate dataSemana) {
        this.dataSemana = dataSemana;
    }

    public BigDecimal getValorVendaSemana() {
        return valorVendaSemana;
    }

    public void setValorVendaSemana(BigDecimal valorVendaSemana) {
        this.valorVendaSemana = valorVendaSemana;
    }

    public LocalDate getDataPedido() {
        return dataPedido;
    }

    public void setDataPedido(LocalDate dataPedido) {
        this.dataPedido = dataPedido;
    }

    public BigDecimal getValorVendaDia() {
        return valorVendaDia;
    }

    public void setValorVendaDia(BigDecimal valorVendaDia) {
        this.valorVendaDia = valorVendaDia;
    }

    public LocalDate getDataFaturamento() {
        return dataFaturamento;
    }

    public void setDataFaturamento(LocalDate dataFaturamento) {
        this.dataFaturamento = dataFaturamento;
    }

    public BigDecimal getValorFaturadoDia() {
        return valorFaturadoDia;
    }

    public void setValorFaturadoDia(BigDecimal valorFaturadoDia) {
        this.valorFaturadoDia = valorFaturadoDia;
    }


    public CleberProjecaoVendaDto(LocalDate dataSemana, BigDecimal valorVendaSemana, LocalDate dataPedido, BigDecimal valorVendaDia, LocalDate dataFaturamento, BigDecimal valorFaturadoDia) {
        this.dataSemana = dataSemana;
        this.valorVendaSemana = valorVendaSemana;
        this.dataPedido = dataPedido;
        this.valorVendaDia = valorVendaDia;
        this.dataFaturamento = dataFaturamento;
        this.valorFaturadoDia = valorFaturadoDia;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CleberProjecaoVendaDto)) return false;
        CleberProjecaoVendaDto that = (CleberProjecaoVendaDto) o;
        return Objects.equals(getDataSemana(), that.getDataSemana()) &&
                Objects.equals(getValorVendaSemana(), that.getValorVendaSemana()) &&
                Objects.equals(getDataPedido(), that.getDataPedido()) &&
                Objects.equals(getValorVendaDia(), that.getValorVendaDia()) &&
                Objects.equals(getDataFaturamento(), that.getDataFaturamento()) &&
                Objects.equals(getValorFaturadoDia(), that.getValorFaturadoDia());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getDataSemana(), getValorVendaSemana(), getDataPedido(), getValorVendaDia(), getDataFaturamento(), getValorFaturadoDia());
    }

    @Override
    public String toString() {
        return "CleberProjecaoVendaDto{" +
                "dataSemana=" + dataSemana +
                ", valorVendaSemana=" + valorVendaSemana +
                ", dataPedido=" + dataPedido +
                ", valorVendaDia=" + valorVendaDia +
                ", dataFaturamento=" + dataFaturamento +
                ", valorFaturadoDia=" + valorFaturadoDia +
                '}';
    }
}


