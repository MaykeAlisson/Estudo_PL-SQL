package models.commons.dtos;

import infra.model.Constante;
import models.commons.constantes.SimNao;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilString.isVazia;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Collections.emptySet;
import static java.util.Optional.ofNullable;
import static models.commons.constantes.SimNao.NAO;
import static models.commons.constantes.SimNao.SIM;

/**
 * Evelope para envio de emails.
 *
 * <p>Autor: GPortes</p>
 */
public class EnvelopeDto {

    private Optional<String> assunto;
    private List<String> destinatarios;
    private long qtdeDestinatarios;
    private Optional<String> mensagem;
    private Optional<Short> sequencia;
    private Optional<String> objeto;
    private List<String> arquivos;
    private Optional<String> arquivoLinhaUnica;
    private Optional<SimNao> exclusao;

    public static class Builder {

        // Requerido:
        private String assunto;

        // Opcional:
        private Set<String> destinatarios;
        private String mensagem;
        private String objeto;
        private Short sequencia;
        private Set<String> arquivos;
        private SimNao exclusao;

        public Builder( final String assunto ) {

            if ( isVazia( assunto) )
                throw new IllegalArgumentException( "FALTOU DEFINIR ASSUNTO DO ENVELOPE !" );

            this.assunto = assunto;
            this.destinatarios = emptySet();
            this.mensagem = null;
            this.objeto = null;
            this.sequencia = null;
            this.exclusao = NAO;
            this.arquivos = emptySet();
        }

        public Builder comDestinatarios( final String... destinatarios ) {

            if ( isVazia( destinatarios ) )
                return this;

            if ( isVazia( this.destinatarios ) )
                this.destinatarios = new LinkedHashSet<>(  );

            this.destinatarios.addAll( asList( destinatarios ) );
            return this;
        }

        public Builder comMensagem( final String mensagem ) {

            this.mensagem = mensagem;
            return this;
        }

        public Builder comSequencia( final Short sequencia ) {

            this.sequencia = sequencia;
            return this;
        }

        public Builder comSequencia( final Sequencia sequencia ) {

            this.sequencia = sequencia != null ? sequencia.getValor() : null;
            return this;
        }

        public Builder comObjetoDestino( final String objeto ) {

            this.objeto = objeto;
            return this;
        }

        public Builder comArquivos( final String... arquivos ) {

            if ( isVazia( arquivos ) )
                return this;

            if ( isVazia( this.arquivos ) )
                this.arquivos = new LinkedHashSet<>(  );

            this.arquivos.addAll( asList( arquivos ) );
            return this;
        }

        public Builder comArquivos( final Set<String> arquivos ) {

            if ( isVazia( arquivos ) )
                return this;

            this.arquivos = arquivos;
            return this;
        }

        public Builder comExclusao() {
            this.exclusao = SIM;
            return this;
        }

        public EnvelopeDto build() {

            return new EnvelopeDto( this );
        }

    }

    private EnvelopeDto( models.commons.dtos.EnvelopeDto.Builder builder ) {

        assunto = ofNullable( builder.assunto );
        mensagem = ofNullable( builder.mensagem );
        sequencia = ofNullable( builder.sequencia );
        objeto = ofNullable( builder.objeto );
        exclusao = ofNullable(builder.exclusao);
        destinatarios = isVazia( builder.destinatarios ) ? emptyList() : new ArrayList<>( builder.destinatarios );
        qtdeDestinatarios = destinatarios.size();
        arquivos = isVazia( builder.arquivos ) ? emptyList() : new ArrayList<>( builder.arquivos );
        arquivoLinhaUnica = builder.arquivos
                            .stream()
                            .reduce( ( a, b ) -> a + "," + b );
    }

    public Optional<String> getAssunto( ) {

        return assunto;
    }

    public List<String> getDestinatarios( ) {

        return destinatarios;
    }
    
    public long getQtdeDestinatarios() {
        
        return qtdeDestinatarios;
    }

    public Optional<String> getMensagem( ) {

        return mensagem;
    }

    public Optional<Short> getSequencia( ) {

        return sequencia;
    }

    public Optional<String> getObjeto( ) {

        return objeto;
    }

    public Optional<SimNao> getExclusao() {
        return exclusao;
    }

    public List<String> getArquivos( ) {

        return arquivos;
    }

    public Optional<String> getArquivo() {

        return arquivoLinhaUnica;
    }

    public enum Sequencia implements Constante<Short> {

        UM( "UM", (short) 1 ),
        DOIS( "DOIS", (short) 2 ),
        TRES( "TRES", (short) 3 ),
        QUATRO( "QUATRO", (short) 4 ),
        CINCO( "CINCO", (short) 5 ),
        SEIS( "SEIS", (short) 6 ),
        SETE( "SETE", (short) 7 ),
        OITO( "OITO", (short) 8 ),
        NOVO( "NOVO", (short) 9 ),
        DEZ( "DEZ", (short) 10 ),
        ;

        final private String descricao;
        final private Short valor;

        Sequencia( final String descricao,
                   final Short valor ) {

            this.descricao = descricao;
            this.valor = valor;
        }

        @Override
        public String getDescricao() {

            return this.descricao;
        }

        @Override
        public Short getValor() {

            return this.valor;
        }
    }

}
