package models.commons.dtos;

import java.io.Serializable;

public class HorariosESocialDto implements Serializable {

    private Short empresa;
    private Long funcionario;
    private Long dia;
    private String codHorario;

    public Short getEmpresa() {

        return this.empresa;
    }

    public void setEmpresa( final Short empresa ) {

        this.empresa = empresa;
    }

    public Long getFuncionario() {

        return this.funcionario;
    }

    public void setFuncionario( final Long funcionario ) {

        this.funcionario = funcionario;
    }

    public Long getDia() {

        return this.dia;
    }

    public void setDia( final Long dia ) {

        this.dia = dia;
    }

    public String getCodHorario() {
        return codHorario;
    }

    public void setCodHorario(String codHorario) {
        this.codHorario = codHorario;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        HorariosESocialDto that = (HorariosESocialDto) o;

        if (empresa != null ? !empresa.equals(that.empresa) : that.empresa != null) return false;
        if (funcionario != null ? !funcionario.equals(that.funcionario) : that.funcionario != null) return false;
        if (dia != null ? !dia.equals(that.dia) : that.dia != null) return false;
        return codHorario != null ? codHorario.equals(that.codHorario) : that.codHorario == null;
    }

    @Override
    public int hashCode() {
        int result = empresa != null ? empresa.hashCode() : 0;
        result = 31 * result + (funcionario != null ? funcionario.hashCode() : 0);
        result = 31 * result + (dia != null ? dia.hashCode() : 0);
        result = 31 * result + (codHorario != null ? codHorario.hashCode() : 0);
        return result;
    }
}