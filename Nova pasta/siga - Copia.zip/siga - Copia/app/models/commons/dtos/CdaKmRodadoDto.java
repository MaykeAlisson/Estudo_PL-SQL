package models.commons.dtos;

import models.commons.constantes.TipoViagem;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Classe que representa informações sobre cidades
 *
 * <p>Autor:Cleber</p>
 *
 * @since 29/08/2016
 */
public class CdaKmRodadoDto implements Serializable {

    private Short idCda;
    private TipoViagem tipoViagem;
    private BigDecimal kmRodado;
    private BigDecimal fator;


    public CdaKmRodadoDto(
        final Short idCda,
        final TipoViagem tipoViagem,
        final BigDecimal kmRodado,
        final BigDecimal fator
    ) {

        this.idCda = idCda;
        this.tipoViagem = tipoViagem;
        this.kmRodado = kmRodado;
        this.fator = fator;
    }

    public Short getIdCda() {
        return idCda;
    }

    public TipoViagem getTipoViagem() {
        return tipoViagem;
    }

    public BigDecimal getKmRodado() {
        return kmRodado;
    }

    public BigDecimal getFator() {
        return fator;
    }

    public void setIdCda(Short idCda) {
        this.idCda = idCda;
    }

    public void setTipoViagem(TipoViagem tipoViagem) {
        this.tipoViagem = tipoViagem;
    }

    public void setKmRodado(BigDecimal kmRodado) {
        this.kmRodado = kmRodado;
    }

    public void setFator(BigDecimal fator) {
        this.fator = fator;
    }

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CdaKmRodadoDto that = (CdaKmRodadoDto) o;

        if (idCda != null ? !idCda.equals(that.idCda) : that.idCda != null) return false;
        if (tipoViagem != that.tipoViagem) return false;
        if (kmRodado != null ? !kmRodado.equals(that.kmRodado) : that.kmRodado != null) return false;
        return fator != null ? fator.equals(that.fator) : that.fator == null;

    }

    @Override
    public int hashCode() {
        int result = idCda != null ? idCda.hashCode() : 0;
        result = 31 * result + (tipoViagem != null ? tipoViagem.hashCode() : 0);
        result = 31 * result + (kmRodado != null ? kmRodado.hashCode() : 0);
        result = 31 * result + (fator != null ? fator.hashCode() : 0);
        return result;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////


}