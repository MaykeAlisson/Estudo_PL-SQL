package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class FuncionarioESocialDto implements Serializable {

    private Short idEmpresa;
    private Short tipoPessoa;
    private BigDecimal cnpj;
    private Long matricula;
    private BigDecimal cpf;
    private BigDecimal pisPasep;
    private String nome;
    private String sexo;
    private Long racaCor;
    private Long estadoCivil;
    private String grauInstrucao;
    private String primeiroEmprego;
    private Date nascimento;
    private Long municipioNascimento;
    private String ufNascimento;
    private Short paisNascimento;
    private Short paisNacionalidade;
    private String mae;
    private String pai;
    private Long ctps;
    private Long serieCtps;
    private String ufEmissorCtps;
    private BigDecimal ricNumero;
    private String ricOrgaoEmissor;
    private Date ricDtExpedicao;
    private String identidade;
    private String orgaoIdentidade;
    private Date emissaoIdentidade;
    private String rneNumero;
    private String rneOrgaoEmissor;
    private Date rneDtExpedicao;
    private String ocNumero;
    private String ocOrgaoEmissor;
    private Date ocDtExpedicao;
    private Date ocDtValidade;
    private BigDecimal cnhNroRegistro;
    private Date cnhDataExpedicao;
    private String cnhUf;
    private Date cnhDataVencto;
    private String cnhCategoria;
    private String tipoLogradouro;
    private String endereco;
    private String NroEndereco;
    private String complemento;
    private String bairro;
    private Long cep;
    private Long municipioMoradia;
    private String ufMoradia;
    private Short exteriorPaisResidencia;
    private String exteriorDescLogradouro;
    private String exteriorNrLogradouro;
    private String exteriorComplemento;
    private String exteriorBairro;
    private String exteriorNomeCidade;
    private String exteriorCodPostal;
    private Date estrangeiroDtChegada;
    private Short estrangeiroClassifIngresso;
    private String estrangeiroCasadoBr;
    private String estrangeiroFilhosBr;
    private String deficienciaFisica;
    private String deficienciaVisual;
    private String deficienciaAuditiva;
    private String deficienciaMental;
    private String deficienciaIntelectual;
    private String deficienciaReabilitado;
    private String preencheCota;
    private String aposentado;
    private Long tipoRegimeTrabalhista;
    private Long tipoRegimePrevidenciario;
    private Long nroReciboPreCadastro;
    private String cadastroInicial;
    private Date dataAdmissao;
    private Long tipoAdmissao;
    private Long indicativoAdmissao;
    private Short regimeJornada;
    private Long naturezaAtividade;
    private Short mesBaseCategoria;
    private BigDecimal cnpjSindicatoCategoria;
    private Long opcaoFgts;
    private Date dataOpcaoFgts;
    private Long cargo;
    private Short categoriaTrabalhador;
    private BigDecimal salarioBase;
    private Long unidadePagtoSalFixo;
    private String descSalarioVariavel;
    private Long tipoDuracaoContrato;
    private Date dataTerminoContrato;
    private String clausulaAssegurRescisao;
    private Long tipoInscrLocalTrab;
    private Long cnpjLocalTrab;
    private Long qtdHorasSemana;
    private Long tipoJornada;
    private String descTipoJornada;
    private String regimeTempoParcial;
    private BigDecimal cnpjSindicatoFiliado;
    private BigDecimal cnpjEmpresaAnt;
    private Long matricEmpresaAnt;
    private Date dataInicioVinculo;
    private Date dataDesligamento;
    private String estagiario;
    private String codExameToxAdm;
    private Date dataExameToxAdm;
    private BigDecimal cnpjLabExameToxAdm;
    private BigDecimal crmExameToxAdm;
    private String ufCrmExameToxAdm;
    private String codExameToxDem;
    private Date dataExameToxDem;
    private BigDecimal cnpjLabExameToxDem;
    private BigDecimal crmExameToxDem;
    private String ufCrmExameToxDem;
    private Date dataInicioAfastamento;
    private Short motivoESocial;
    private Long tipoReintegracao;
    private Long nroProcessoReintegracao;
    private Long nroLeiReintegracao;
    private Date dataReintegracaoEfetiva;
    private Date dataReintegracaoFinanceira;
    private String indReintegracaoPagtoJuizo;


    public Short getIdEmpresa() {
        return idEmpresa;
    }

    public void setIdEmpresa(Short idEmpresa) {
        this.idEmpresa = idEmpresa;
    }

    public Short getTipoPessoa() {
        return tipoPessoa;
    }

    public void setTipoPessoa(Short tipoPessoa) {
        this.tipoPessoa = tipoPessoa;
    }

    public BigDecimal getCnpj() {
        return cnpj;
    }

    public void setCnpj(BigDecimal cnpj) {
        this.cnpj = cnpj;
    }

    public Long getMatricula() {
        return matricula;
    }

    public void setMatricula(Long matricula) {
        this.matricula = matricula;
    }

    public String getCpf() {
        return cpf.toString();
    }

    public void setCpf(BigDecimal cpf) {
        this.cpf = cpf;
    }

    public BigDecimal getPisPasep() {
        return pisPasep;
    }

    public void setPisPasep(BigDecimal pisPasep) {
        this.pisPasep = pisPasep;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public Long getRacaCor() {
        return racaCor;
    }

    public void setRacaCor(Long racaCor) {
        this.racaCor = racaCor;
    }

    public Long getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(Long estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    public String getGrauInstrucao() {
        return grauInstrucao;
    }

    public void setGrauInstrucao(String grauInstrucao) {
        this.grauInstrucao = grauInstrucao;
    }

    public String getPrimeiroEmprego() {
        return primeiroEmprego;
    }

    public void setPrimeiroEmprego(String primeiroEmprego) {
        this.primeiroEmprego = primeiroEmprego;
    }

    public Date getNascimento() {
        return nascimento;
    }

    public void setNascimento(Date nascimento) {
        this.nascimento = nascimento;
    }

    public Long getMunicipioNascimento() {
        return municipioNascimento;
    }

    public void setMunicipioNascimento(Long municipioNascimento) {
        this.municipioNascimento = municipioNascimento;
    }

    public String getUfNascimento() {
        return ufNascimento;
    }

    public void setUfNascimento(String ufNascimento) {
        this.ufNascimento = ufNascimento;
    }

    public Short getPaisNascimento() {
        return paisNascimento;
    }

    public void setPaisNascimento(Short paisNascimento) {
        this.paisNascimento = paisNascimento;
    }

    public Short getPaisNacionalidade() {
        return paisNacionalidade;
    }

    public void setPaisNacionalidade(Short paisNacionalidade) {
        this.paisNacionalidade = paisNacionalidade;
    }

    public String getMae() {
        return mae;
    }

    public void setMae(String mae) {
        this.mae = mae;
    }

    public String getPai() {
        return pai;
    }

    public void setPai(String pai) {
        this.pai = pai;
    }

    public Long getCtps() {
        return ctps;
    }

    public void setCtps(Long ctps) {
        this.ctps = ctps;
    }

    public Long getSerieCtps() {
        return serieCtps;
    }

    public void setSerieCtps(Long serieCtps) {
        this.serieCtps = serieCtps;
    }

    public String getUfEmissorCtps() {
        return ufEmissorCtps;
    }

    public void setUfEmissorCtps(String ufEmissorCtps) {
        this.ufEmissorCtps = ufEmissorCtps;
    }

    public BigDecimal getRicNumero() {
        return ricNumero;
    }

    public void setRicNumero(BigDecimal ricNumero) {
        this.ricNumero = ricNumero;
    }

    public String getRicOrgaoEmissor() {
        return ricOrgaoEmissor;
    }

    public void setRicOrgaoEmissor(String ricOrgaoEmissor) {
        this.ricOrgaoEmissor = ricOrgaoEmissor;
    }

    public Date getRicDtExpedicao() {
        return ricDtExpedicao;
    }

    public void setRicDtExpedicao(Date ricDtExpedicao) {
        this.ricDtExpedicao = ricDtExpedicao;
    }

    public String getIdentidade() {
        return identidade;
    }

    public void setIdentidade(String identidade) {
        this.identidade = identidade;
    }

    public String getOrgaoIdentidade() {
        return orgaoIdentidade;
    }

    public void setOrgaoIdentidade(String orgaoIdentidade) {
        this.orgaoIdentidade = orgaoIdentidade;
    }

    public Date getEmissaoIdentidade() {
        return emissaoIdentidade;
    }

    public void setEmissaoIdentidade(Date emissaoIdentidade) {
        this.emissaoIdentidade = emissaoIdentidade;
    }

    public String getRneNumero() {
        return rneNumero;
    }

    public void setRneNumero(String rneNumero) {
        this.rneNumero = rneNumero;
    }

    public String getRneOrgaoEmissor() {
        return rneOrgaoEmissor;
    }

    public void setRneOrgaoEmissor(String rneOrgaoEmissor) {
        this.rneOrgaoEmissor = rneOrgaoEmissor;
    }

    public Date getRneDtExpedicao() {
        return rneDtExpedicao;
    }

    public void setRneDtExpedicao(Date rneDtExpedicao) {
        this.rneDtExpedicao = rneDtExpedicao;
    }

    public String getOcNumero() {
        return ocNumero;
    }

    public void setOcNumero(String ocNumero) {
        this.ocNumero = ocNumero;
    }

    public String getOcOrgaoEmissor() {
        return ocOrgaoEmissor;
    }

    public void setOcOrgaoEmissor(String ocOrgaoEmissor) {
        this.ocOrgaoEmissor = ocOrgaoEmissor;
    }

    public Date getOcDtExpedicao() {
        return ocDtExpedicao;
    }

    public void setOcDtExpedicao(Date ocDtExpedicao) {
        this.ocDtExpedicao = ocDtExpedicao;
    }

    public Date getOcDtValidade() {
        return ocDtValidade;
    }

    public void setOcDtValidade(Date ocDtValidade) {
        this.ocDtValidade = ocDtValidade;
    }

    public BigDecimal getCnhNroRegistro() {
        return cnhNroRegistro;
    }

    public void setCnhNroRegistro(BigDecimal cnhNroRegistro) {
        this.cnhNroRegistro = cnhNroRegistro;
    }

    public Date getCnhDataExpedicao() {
        return cnhDataExpedicao;
    }

    public void setCnhDataExpedicao(Date cnhDataExpedicao) {
        this.cnhDataExpedicao = cnhDataExpedicao;
    }

    public String getCnhUf() {
        return cnhUf;
    }

    public void setCnhUf(String cnhUf) {
        this.cnhUf = cnhUf;
    }

    public Date getCnhDataVencto() {
        return cnhDataVencto;
    }

    public void setCnhDataVencto(Date cnhDataVencto) {
        this.cnhDataVencto = cnhDataVencto;
    }

    public String getCnhCategoria() {
        return cnhCategoria;
    }

    public void setCnhCategoria(String cnhCategoria) {
        this.cnhCategoria = cnhCategoria;
    }

    public String getTipoLogradouro() {
        return tipoLogradouro;
    }

    public void setTipoLogradouro(String tipoLogradouro) {
        this.tipoLogradouro = tipoLogradouro;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getNroEndereco() {
        return NroEndereco;
    }

    public void setNroEndereco(String nroEndereco) {
        NroEndereco = nroEndereco;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public Long getCep() {
        return cep;
    }

    public void setCep(Long cep) {
        this.cep = cep;
    }

    public Long getMunicipioMoradia() {
        return municipioMoradia;
    }

    public void setMunicipioMoradia(Long municipioMoradia) {
        this.municipioMoradia = municipioMoradia;
    }

    public String getUfMoradia() {
        return ufMoradia;
    }

    public void setUfMoradia(String ufMoradia) {
        this.ufMoradia = ufMoradia;
    }

    public Short getExteriorPaisResidencia() {
        return exteriorPaisResidencia;
    }

    public void setExteriorPaisResidencia(Short exteriorPaisResidencia) {
        this.exteriorPaisResidencia = exteriorPaisResidencia;
    }

    public String getExteriorDescLogradouro() {
        return exteriorDescLogradouro;
    }

    public void setExteriorDescLogradouro(String exteriorDescLogradouro) {
        this.exteriorDescLogradouro = exteriorDescLogradouro;
    }

    public String getExteriorNrLogradouro() {
        return exteriorNrLogradouro;
    }

    public void setExteriorNrLogradouro(String exteriorNrLogradouro) {
        this.exteriorNrLogradouro = exteriorNrLogradouro;
    }

    public String getExteriorComplemento() {
        return exteriorComplemento;
    }

    public void setExteriorComplemento(String exteriorComplemento) {
        this.exteriorComplemento = exteriorComplemento;
    }

    public String getExteriorBairro() {
        return exteriorBairro;
    }

    public void setExteriorBairro(String exteriorBairro) {
        this.exteriorBairro = exteriorBairro;
    }

    public String getExteriorNomeCidade() {
        return exteriorNomeCidade;
    }

    public void setExteriorNomeCidade(String exteriorNomeCidade) {
        this.exteriorNomeCidade = exteriorNomeCidade;
    }

    public String getExteriorCodPostal() {
        return exteriorCodPostal;
    }

    public void setExteriorCodPostal(String exteriorCodPostal) {
        this.exteriorCodPostal = exteriorCodPostal;
    }

    public Date getEstrangeiroDtChegada() {
        return estrangeiroDtChegada;
    }

    public void setEstrangeiroDtChegada(Date estrangeiroDtChegada) {
        this.estrangeiroDtChegada = estrangeiroDtChegada;
    }

    public Short getEstrangeiroClassifIngresso() {
        return estrangeiroClassifIngresso;
    }

    public void setEstrangeiroClassifIngresso(Short estrangeiroClassifIngresso) {
        this.estrangeiroClassifIngresso = estrangeiroClassifIngresso;
    }

    public String getEstrangeiroCasadoBr() {
        return estrangeiroCasadoBr;
    }

    public void setEstrangeiroCasadoBr(String estrangeiroCasadoBr) {
        this.estrangeiroCasadoBr = estrangeiroCasadoBr;
    }

    public String getEstrangeiroFilhosBr() {
        return estrangeiroFilhosBr;
    }

    public void setEstrangeiroFilhosBr(String estrangeiroFilhosBr) {
        this.estrangeiroFilhosBr = estrangeiroFilhosBr;
    }

    public String getDeficienciaFisica() {
        return deficienciaFisica;
    }

    public void setDeficienciaFisica(String deficienciaFisica) {
        this.deficienciaFisica = deficienciaFisica;
    }

    public String getDeficienciaVisual() {
        return deficienciaVisual;
    }

    public void setDeficienciaVisual(String deficienciaVisual) {
        this.deficienciaVisual = deficienciaVisual;
    }

    public String getDeficienciaAuditiva() {
        return deficienciaAuditiva;
    }

    public void setDeficienciaAuditiva(String deficienciaAuditiva) {
        this.deficienciaAuditiva = deficienciaAuditiva;
    }

    public String getDeficienciaMental() {
        return deficienciaMental;
    }

    public void setDeficienciaMental(String deficienciaMental) {
        this.deficienciaMental = deficienciaMental;
    }

    public String getDeficienciaIntelectual() {
        return deficienciaIntelectual;
    }

    public void setDeficienciaIntelectual(String deficienciaIntelectual) {
        this.deficienciaIntelectual = deficienciaIntelectual;
    }

    public String getDeficienciaReabilitado() {
        return deficienciaReabilitado;
    }

    public void setDeficienciaReabilitado(String deficienciaReabilitado) {
        this.deficienciaReabilitado = deficienciaReabilitado;
    }

    public String getPreencheCota() {
        return preencheCota;
    }

    public void setPreencheCota(String preencheCota) {
        this.preencheCota = preencheCota;
    }

    public String getAposentado() {
        return aposentado;
    }

    public void setAposentado(String aposentado) {
        this.aposentado = aposentado;
    }

    public Long getTipoRegimeTrabalhista() {
        return tipoRegimeTrabalhista;
    }

    public void setTipoRegimeTrabalhista(Long tipoRegimeTrabalhista) {
        this.tipoRegimeTrabalhista = tipoRegimeTrabalhista;
    }

    public Long getTipoRegimePrevidenciario() {
        return tipoRegimePrevidenciario;
    }

    public void setTipoRegimePrevidenciario(Long tipoRegimePrevidenciario) {
        this.tipoRegimePrevidenciario = tipoRegimePrevidenciario;
    }

    public Long getNroReciboPreCadastro() {
        return nroReciboPreCadastro;
    }

    public void setNroReciboPreCadastro(Long nroReciboPreCadastro) {
        this.nroReciboPreCadastro = nroReciboPreCadastro;
    }

    public String getCadastroInicial() {
        return cadastroInicial;
    }

    public void setCadastroInicial(String cadastroInicial) {
        this.cadastroInicial = cadastroInicial;
    }

    public Date getDataAdmissao() {
        return dataAdmissao;
    }

    public void setDataAdmissao(Date dataAdmissao) {
        this.dataAdmissao = dataAdmissao;
    }

    public Long getTipoAdmissao() {
        return tipoAdmissao;
    }

    public void setTipoAdmissao(Long tipoAdmissao) {
        this.tipoAdmissao = tipoAdmissao;
    }

    public Long getIndicativoAdmissao() {
        return indicativoAdmissao;
    }

    public void setIndicativoAdmissao(Long indicativoAdmissao) {
        this.indicativoAdmissao = indicativoAdmissao;
    }

    public Short getRegimeJornada() {
        return regimeJornada;
    }

    public void setRegimeJornada(Short regimeJornada) {
        this.regimeJornada = regimeJornada;
    }

    public Long getNaturezaAtividade() {
        return naturezaAtividade;
    }

    public void setNaturezaAtividade(Long naturezaAtividade) {
        this.naturezaAtividade = naturezaAtividade;
    }

    public Short getMesBaseCategoria() {
        return mesBaseCategoria;
    }

    public void setMesBaseCategoria(Short mesBaseCategoria) {
        this.mesBaseCategoria = mesBaseCategoria;
    }

    public BigDecimal getCnpjSindicatoCategoria() {
        return cnpjSindicatoCategoria;
    }

    public void setCnpjSindicatoCategoria(BigDecimal cnpjSindicatoCategoria) {
        this.cnpjSindicatoCategoria = cnpjSindicatoCategoria;
    }

    public Long getOpcaoFgts() {
        return opcaoFgts;
    }

    public void setOpcaoFgts(Long opcaoFgts) {
        this.opcaoFgts = opcaoFgts;
    }

    public Date getDataOpcaoFgts() {
        return dataOpcaoFgts;
    }

    public void setDataOpcaoFgts(Date dataOpcaoFgts) {
        this.dataOpcaoFgts = dataOpcaoFgts;
    }

    public Long getCargo() {
        return cargo;
    }

    public void setCargo(Long cargo) {
        this.cargo = cargo;
    }

    public Short getCategoriaTrabalhador() {
        return categoriaTrabalhador;
    }

    public void setCategoriaTrabalhador(Short categoriaTrabalhador) {
        this.categoriaTrabalhador = categoriaTrabalhador;
    }

    public BigDecimal getSalarioBase() {
        return salarioBase;
    }

    public void setSalarioBase(BigDecimal salarioBase) {
        this.salarioBase = salarioBase;
    }

    public Long getUnidadePagtoSalFixo() {
        return unidadePagtoSalFixo;
    }

    public void setUnidadePagtoSalFixo(Long unidadePagtoSalFixo) {
        this.unidadePagtoSalFixo = unidadePagtoSalFixo;
    }

    public String getDescSalarioVariavel() {
        return descSalarioVariavel;
    }

    public void setDescSalarioVariavel(String descSalarioVariavel) {
        this.descSalarioVariavel = descSalarioVariavel;
    }

    public Long getTipoDuracaoContrato() {
        return tipoDuracaoContrato;
    }

    public void setTipoDuracaoContrato(Long tipoDuracaoContrato) {
        this.tipoDuracaoContrato = tipoDuracaoContrato;
    }

    public Date getDataTerminoContrato() {
        return dataTerminoContrato;
    }

    public void setDataTerminoContrato(Date dataTerminoContrato) {
        this.dataTerminoContrato = dataTerminoContrato;
    }

    public String getClausulaAssegurRescisao() {
        return clausulaAssegurRescisao;
    }

    public void setClausulaAssegurRescisao(String clausulaAssegurRescisao) {
        this.clausulaAssegurRescisao = clausulaAssegurRescisao;
    }

    public Long getTipoInscrLocalTrab() {
        return tipoInscrLocalTrab;
    }

    public void setTipoInscrLocalTrab(Long tipoInscrLocalTrab) {
        this.tipoInscrLocalTrab = tipoInscrLocalTrab;
    }

    public Long getCnpjLocalTrab() {
        return cnpjLocalTrab;
    }

    public void setCnpjLocalTrab(Long cnpjLocalTrab) {
        this.cnpjLocalTrab = cnpjLocalTrab;
    }

    public Long getQtdHorasSemana() {
        return qtdHorasSemana;
    }

    public void setQtdHorasSemana(Long qtdHorasSemana) {
        this.qtdHorasSemana = qtdHorasSemana;
    }

    public Long getTipoJornada() {
        return tipoJornada;
    }

    public void setTipoJornada(Long tipoJornada) {
        this.tipoJornada = tipoJornada;
    }

    public String getDescTipoJornada() {
        return descTipoJornada;
    }

    public void setDescTipoJornada(String descTipoJornada) {
        this.descTipoJornada = descTipoJornada;
    }

    public String getRegimeTempoParcial() {
        return regimeTempoParcial;
    }

    public void setRegimeTempoParcial(String regimeTempoParcial) {
        this.regimeTempoParcial = regimeTempoParcial;
    }

    public BigDecimal getCnpjSindicatoFiliado() {
        return cnpjSindicatoFiliado;
    }

    public void setCnpjSindicatoFiliado(BigDecimal cnpjSindicatoFiliado) {
        this.cnpjSindicatoFiliado = cnpjSindicatoFiliado;
    }

    public BigDecimal getCnpjEmpresaAnt() {
        return cnpjEmpresaAnt;
    }

    public void setCnpjEmpresaAnt(BigDecimal cnpjEmpresaAnt) {
        this.cnpjEmpresaAnt = cnpjEmpresaAnt;
    }

    public Long getMatricEmpresaAnt() {
        return matricEmpresaAnt;
    }

    public void setMatricEmpresaAnt(Long matricEmpresaAnt) {
        this.matricEmpresaAnt = matricEmpresaAnt;
    }

    public Date getDataInicioVinculo() {
        return dataInicioVinculo;
    }

    public void setDataInicioVinculo(Date dataInicioVinculo) {
        this.dataInicioVinculo = dataInicioVinculo;
    }

    public Date getDataDesligamento() {
        return dataDesligamento;
    }

    public void setDataDesligamento(Date dataDesligamento) {
        this.dataDesligamento = dataDesligamento;
    }

    public String getEstagiario() {
        return estagiario;
    }

    public void setEstagiario(String estagiario) {
        this.estagiario = estagiario;
    }

    public String getCodExameToxAdm() {
        return codExameToxAdm;
    }

    public void setCodExameToxAdm(String codExameToxAdm) {
        this.codExameToxAdm = codExameToxAdm;
    }

    public Date getDataExameToxAdm() {
        return dataExameToxAdm;
    }

    public void setDataExameToxAdm(Date dataExameToxAdm) {
        this.dataExameToxAdm = dataExameToxAdm;
    }

    public BigDecimal getCnpjLabExameToxAdm() {
        return cnpjLabExameToxAdm;
    }

    public void setCnpjLabExameToxAdm(BigDecimal cnpjLabExameToxAdm) {
        this.cnpjLabExameToxAdm = cnpjLabExameToxAdm;
    }

    public BigDecimal getCrmExameToxAdm() {
        return crmExameToxAdm;
    }

    public void setCrmExameToxAdm(BigDecimal crmExameToxAdm) {
        this.crmExameToxAdm = crmExameToxAdm;
    }

    public String getUfCrmExameToxAdm() {
        return ufCrmExameToxAdm;
    }

    public void setUfCrmExameToxAdm(String ufCrmExameToxAdm) {
        this.ufCrmExameToxAdm = ufCrmExameToxAdm;
    }

    public String getCodExameToxDem() {
        return codExameToxDem;
    }

    public void setCodExameToxDem(String codExameToxDem) {
        this.codExameToxDem = codExameToxDem;
    }

    public Date getDataExameToxDem() {
        return dataExameToxDem;
    }

    public void setDataExameToxDem(Date dataExameToxDem) {
        this.dataExameToxDem = dataExameToxDem;
    }

    public BigDecimal getCnpjLabExameToxDem() {
        return cnpjLabExameToxDem;
    }

    public void setCnpjLabExameToxDem(BigDecimal cnpjLabExameToxDem) {
        this.cnpjLabExameToxDem = cnpjLabExameToxDem;
    }

    public BigDecimal getCrmExameToxDem() {
        return crmExameToxDem;
    }

    public void setCrmExameToxDem(BigDecimal crmExameToxDem) {
        this.crmExameToxDem = crmExameToxDem;
    }

    public String getUfCrmExameToxDem() {
        return ufCrmExameToxDem;
    }

    public void setUfCrmExameToxDem(String ufCrmExameToxDem) {
        this.ufCrmExameToxDem = ufCrmExameToxDem;
    }

    public Date getDataInicioAfastamento() {
        return dataInicioAfastamento;
    }

    public void setDataInicioAfastamento(Date dataInicioAfastamento) {
        this.dataInicioAfastamento = dataInicioAfastamento;
    }

    public Short getMotivoESocial() {
        return motivoESocial;
    }

    public void setMotivoESocial(Short motivoESocial) {
        this.motivoESocial = motivoESocial;
    }

    public Long getTipoReintegracao() {
        return tipoReintegracao;
    }

    public Long getNroProcessoReintegracao() {
        return nroProcessoReintegracao;
    }

    public Long getNroLeiReintegracao() {
        return nroLeiReintegracao;
    }

    public Date getDataReintegracaoEfetiva() {
        return dataReintegracaoEfetiva;
    }

    public Date getDataReintegracaoFinanceira() {
        return dataReintegracaoFinanceira;
    }

    public String getIndReintegracaoPagtoJuizo() {
        return indReintegracaoPagtoJuizo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        FuncionarioESocialDto that = (FuncionarioESocialDto) o;

        if (idEmpresa != null ? !idEmpresa.equals(that.idEmpresa) : that.idEmpresa != null) return false;
        if (tipoPessoa != null ? !tipoPessoa.equals(that.tipoPessoa) : that.tipoPessoa != null) return false;
        if (cnpj != null ? !cnpj.equals(that.cnpj) : that.cnpj != null) return false;
        if (matricula != null ? !matricula.equals(that.matricula) : that.matricula != null) return false;
        if (cpf != null ? !cpf.equals(that.cpf) : that.cpf != null) return false;
        if (pisPasep != null ? !pisPasep.equals(that.pisPasep) : that.pisPasep != null) return false;
        if (nome != null ? !nome.equals(that.nome) : that.nome != null) return false;
        if (sexo != null ? !sexo.equals(that.sexo) : that.sexo != null) return false;
        if (racaCor != null ? !racaCor.equals(that.racaCor) : that.racaCor != null) return false;
        if (estadoCivil != null ? !estadoCivil.equals(that.estadoCivil) : that.estadoCivil != null) return false;
        if (grauInstrucao != null ? !grauInstrucao.equals(that.grauInstrucao) : that.grauInstrucao != null)
            return false;
        if (primeiroEmprego != null ? !primeiroEmprego.equals(that.primeiroEmprego) : that.primeiroEmprego != null)
            return false;
        if (nascimento != null ? !nascimento.equals(that.nascimento) : that.nascimento != null) return false;
        if (municipioNascimento != null ? !municipioNascimento.equals(that.municipioNascimento) : that.municipioNascimento != null)
            return false;
        if (ufNascimento != null ? !ufNascimento.equals(that.ufNascimento) : that.ufNascimento != null) return false;
        if (paisNascimento != null ? !paisNascimento.equals(that.paisNascimento) : that.paisNascimento != null)
            return false;
        if (paisNacionalidade != null ? !paisNacionalidade.equals(that.paisNacionalidade) : that.paisNacionalidade != null)
            return false;
        if (mae != null ? !mae.equals(that.mae) : that.mae != null) return false;
        if (pai != null ? !pai.equals(that.pai) : that.pai != null) return false;
        if (ctps != null ? !ctps.equals(that.ctps) : that.ctps != null) return false;
        if (serieCtps != null ? !serieCtps.equals(that.serieCtps) : that.serieCtps != null) return false;
        if (ufEmissorCtps != null ? !ufEmissorCtps.equals(that.ufEmissorCtps) : that.ufEmissorCtps != null)
            return false;
        if (ricNumero != null ? !ricNumero.equals(that.ricNumero) : that.ricNumero != null) return false;
        if (ricOrgaoEmissor != null ? !ricOrgaoEmissor.equals(that.ricOrgaoEmissor) : that.ricOrgaoEmissor != null)
            return false;
        if (ricDtExpedicao != null ? !ricDtExpedicao.equals(that.ricDtExpedicao) : that.ricDtExpedicao != null)
            return false;
        if (identidade != null ? !identidade.equals(that.identidade) : that.identidade != null) return false;
        if (orgaoIdentidade != null ? !orgaoIdentidade.equals(that.orgaoIdentidade) : that.orgaoIdentidade != null)
            return false;
        if (emissaoIdentidade != null ? !emissaoIdentidade.equals(that.emissaoIdentidade) : that.emissaoIdentidade != null)
            return false;
        if (rneNumero != null ? !rneNumero.equals(that.rneNumero) : that.rneNumero != null) return false;
        if (rneOrgaoEmissor != null ? !rneOrgaoEmissor.equals(that.rneOrgaoEmissor) : that.rneOrgaoEmissor != null)
            return false;
        if (rneDtExpedicao != null ? !rneDtExpedicao.equals(that.rneDtExpedicao) : that.rneDtExpedicao != null)
            return false;
        if (ocNumero != null ? !ocNumero.equals(that.ocNumero) : that.ocNumero != null) return false;
        if (ocOrgaoEmissor != null ? !ocOrgaoEmissor.equals(that.ocOrgaoEmissor) : that.ocOrgaoEmissor != null)
            return false;
        if (ocDtExpedicao != null ? !ocDtExpedicao.equals(that.ocDtExpedicao) : that.ocDtExpedicao != null)
            return false;
        if (ocDtValidade != null ? !ocDtValidade.equals(that.ocDtValidade) : that.ocDtValidade != null) return false;
        if (cnhNroRegistro != null ? !cnhNroRegistro.equals(that.cnhNroRegistro) : that.cnhNroRegistro != null)
            return false;
        if (cnhDataExpedicao != null ? !cnhDataExpedicao.equals(that.cnhDataExpedicao) : that.cnhDataExpedicao != null)
            return false;
        if (cnhUf != null ? !cnhUf.equals(that.cnhUf) : that.cnhUf != null) return false;
        if (cnhDataVencto != null ? !cnhDataVencto.equals(that.cnhDataVencto) : that.cnhDataVencto != null)
            return false;
        if (cnhCategoria != null ? !cnhCategoria.equals(that.cnhCategoria) : that.cnhCategoria != null) return false;
        if (tipoLogradouro != null ? !tipoLogradouro.equals(that.tipoLogradouro) : that.tipoLogradouro != null)
            return false;
        if (endereco != null ? !endereco.equals(that.endereco) : that.endereco != null) return false;
        if (NroEndereco != null ? !NroEndereco.equals(that.NroEndereco) : that.NroEndereco != null) return false;
        if (complemento != null ? !complemento.equals(that.complemento) : that.complemento != null) return false;
        if (bairro != null ? !bairro.equals(that.bairro) : that.bairro != null) return false;
        if (cep != null ? !cep.equals(that.cep) : that.cep != null) return false;
        if (municipioMoradia != null ? !municipioMoradia.equals(that.municipioMoradia) : that.municipioMoradia != null)
            return false;
        if (ufMoradia != null ? !ufMoradia.equals(that.ufMoradia) : that.ufMoradia != null) return false;
        if (exteriorPaisResidencia != null ? !exteriorPaisResidencia.equals(that.exteriorPaisResidencia) : that.exteriorPaisResidencia != null)
            return false;
        if (exteriorDescLogradouro != null ? !exteriorDescLogradouro.equals(that.exteriorDescLogradouro) : that.exteriorDescLogradouro != null)
            return false;
        if (exteriorNrLogradouro != null ? !exteriorNrLogradouro.equals(that.exteriorNrLogradouro) : that.exteriorNrLogradouro != null)
            return false;
        if (exteriorComplemento != null ? !exteriorComplemento.equals(that.exteriorComplemento) : that.exteriorComplemento != null)
            return false;
        if (exteriorBairro != null ? !exteriorBairro.equals(that.exteriorBairro) : that.exteriorBairro != null)
            return false;
        if (exteriorNomeCidade != null ? !exteriorNomeCidade.equals(that.exteriorNomeCidade) : that.exteriorNomeCidade != null)
            return false;
        if (exteriorCodPostal != null ? !exteriorCodPostal.equals(that.exteriorCodPostal) : that.exteriorCodPostal != null)
            return false;
        if (estrangeiroDtChegada != null ? !estrangeiroDtChegada.equals(that.estrangeiroDtChegada) : that.estrangeiroDtChegada != null)
            return false;
        if (estrangeiroClassifIngresso != null ? !estrangeiroClassifIngresso.equals(that.estrangeiroClassifIngresso) : that.estrangeiroClassifIngresso != null)
            return false;
        if (estrangeiroCasadoBr != null ? !estrangeiroCasadoBr.equals(that.estrangeiroCasadoBr) : that.estrangeiroCasadoBr != null)
            return false;
        if (estrangeiroFilhosBr != null ? !estrangeiroFilhosBr.equals(that.estrangeiroFilhosBr) : that.estrangeiroFilhosBr != null)
            return false;
        if (deficienciaFisica != null ? !deficienciaFisica.equals(that.deficienciaFisica) : that.deficienciaFisica != null)
            return false;
        if (deficienciaVisual != null ? !deficienciaVisual.equals(that.deficienciaVisual) : that.deficienciaVisual != null)
            return false;
        if (deficienciaAuditiva != null ? !deficienciaAuditiva.equals(that.deficienciaAuditiva) : that.deficienciaAuditiva != null)
            return false;
        if (deficienciaMental != null ? !deficienciaMental.equals(that.deficienciaMental) : that.deficienciaMental != null)
            return false;
        if (deficienciaIntelectual != null ? !deficienciaIntelectual.equals(that.deficienciaIntelectual) : that.deficienciaIntelectual != null)
            return false;
        if (deficienciaReabilitado != null ? !deficienciaReabilitado.equals(that.deficienciaReabilitado) : that.deficienciaReabilitado != null)
            return false;
        if (preencheCota != null ? !preencheCota.equals(that.preencheCota) : that.preencheCota != null) return false;
        if (aposentado != null ? !aposentado.equals(that.aposentado) : that.aposentado != null) return false;
        if (tipoRegimeTrabalhista != null ? !tipoRegimeTrabalhista.equals(that.tipoRegimeTrabalhista) : that.tipoRegimeTrabalhista != null)
            return false;
        if (tipoRegimePrevidenciario != null ? !tipoRegimePrevidenciario.equals(that.tipoRegimePrevidenciario) : that.tipoRegimePrevidenciario != null)
            return false;
        if (nroReciboPreCadastro != null ? !nroReciboPreCadastro.equals(that.nroReciboPreCadastro) : that.nroReciboPreCadastro != null)
            return false;
        if (cadastroInicial != null ? !cadastroInicial.equals(that.cadastroInicial) : that.cadastroInicial != null)
            return false;
        if (dataAdmissao != null ? !dataAdmissao.equals(that.dataAdmissao) : that.dataAdmissao != null) return false;
        if (tipoAdmissao != null ? !tipoAdmissao.equals(that.tipoAdmissao) : that.tipoAdmissao != null) return false;
        if (indicativoAdmissao != null ? !indicativoAdmissao.equals(that.indicativoAdmissao) : that.indicativoAdmissao != null)
            return false;
        if (regimeJornada != null ? !regimeJornada.equals(that.regimeJornada) : that.regimeJornada != null)
            return false;
        if (naturezaAtividade != null ? !naturezaAtividade.equals(that.naturezaAtividade) : that.naturezaAtividade != null)
            return false;
        if (mesBaseCategoria != null ? !mesBaseCategoria.equals(that.mesBaseCategoria) : that.mesBaseCategoria != null)
            return false;
        if (cnpjSindicatoCategoria != null ? !cnpjSindicatoCategoria.equals(that.cnpjSindicatoCategoria) : that.cnpjSindicatoCategoria != null)
            return false;
        if (opcaoFgts != null ? !opcaoFgts.equals(that.opcaoFgts) : that.opcaoFgts != null) return false;
        if (dataOpcaoFgts != null ? !dataOpcaoFgts.equals(that.dataOpcaoFgts) : that.dataOpcaoFgts != null)
            return false;
        if (cargo != null ? !cargo.equals(that.cargo) : that.cargo != null) return false;
        if (categoriaTrabalhador != null ? !categoriaTrabalhador.equals(that.categoriaTrabalhador) : that.categoriaTrabalhador != null)
            return false;
        if (salarioBase != null ? !salarioBase.equals(that.salarioBase) : that.salarioBase != null) return false;
        if (unidadePagtoSalFixo != null ? !unidadePagtoSalFixo.equals(that.unidadePagtoSalFixo) : that.unidadePagtoSalFixo != null)
            return false;
        if (descSalarioVariavel != null ? !descSalarioVariavel.equals(that.descSalarioVariavel) : that.descSalarioVariavel != null)
            return false;
        if (tipoDuracaoContrato != null ? !tipoDuracaoContrato.equals(that.tipoDuracaoContrato) : that.tipoDuracaoContrato != null)
            return false;
        if (dataTerminoContrato != null ? !dataTerminoContrato.equals(that.dataTerminoContrato) : that.dataTerminoContrato != null)
            return false;
        if (clausulaAssegurRescisao != null ? !clausulaAssegurRescisao.equals(that.clausulaAssegurRescisao) : that.clausulaAssegurRescisao != null)
            return false;
        if (tipoInscrLocalTrab != null ? !tipoInscrLocalTrab.equals(that.tipoInscrLocalTrab) : that.tipoInscrLocalTrab != null)
            return false;
        if (cnpjLocalTrab != null ? !cnpjLocalTrab.equals(that.cnpjLocalTrab) : that.cnpjLocalTrab != null)
            return false;
        if (qtdHorasSemana != null ? !qtdHorasSemana.equals(that.qtdHorasSemana) : that.qtdHorasSemana != null)
            return false;
        if (tipoJornada != null ? !tipoJornada.equals(that.tipoJornada) : that.tipoJornada != null) return false;
        if (descTipoJornada != null ? !descTipoJornada.equals(that.descTipoJornada) : that.descTipoJornada != null)
            return false;
        if (regimeTempoParcial != null ? !regimeTempoParcial.equals(that.regimeTempoParcial) : that.regimeTempoParcial != null)
            return false;
        if (cnpjSindicatoFiliado != null ? !cnpjSindicatoFiliado.equals(that.cnpjSindicatoFiliado) : that.cnpjSindicatoFiliado != null)
            return false;
        if (cnpjEmpresaAnt != null ? !cnpjEmpresaAnt.equals(that.cnpjEmpresaAnt) : that.cnpjEmpresaAnt != null)
            return false;
        if (matricEmpresaAnt != null ? !matricEmpresaAnt.equals(that.matricEmpresaAnt) : that.matricEmpresaAnt != null)
            return false;
        if (dataInicioVinculo != null ? !dataInicioVinculo.equals(that.dataInicioVinculo) : that.dataInicioVinculo != null)
            return false;
        if (dataDesligamento != null ? !dataDesligamento.equals(that.dataDesligamento) : that.dataDesligamento != null)
            return false;
        if (estagiario != null ? !estagiario.equals(that.estagiario) : that.estagiario != null) return false;
        if (codExameToxAdm != null ? !codExameToxAdm.equals(that.codExameToxAdm) : that.codExameToxAdm != null)
            return false;
        if (dataExameToxAdm != null ? !dataExameToxAdm.equals(that.dataExameToxAdm) : that.dataExameToxAdm != null)
            return false;
        if (cnpjLabExameToxAdm != null ? !cnpjLabExameToxAdm.equals(that.cnpjLabExameToxAdm) : that.cnpjLabExameToxAdm != null)
            return false;
        if (crmExameToxAdm != null ? !crmExameToxAdm.equals(that.crmExameToxAdm) : that.crmExameToxAdm != null)
            return false;
        if (ufCrmExameToxAdm != null ? !ufCrmExameToxAdm.equals(that.ufCrmExameToxAdm) : that.ufCrmExameToxAdm != null)
            return false;
        if (codExameToxDem != null ? !codExameToxDem.equals(that.codExameToxDem) : that.codExameToxDem != null)
            return false;
        if (dataExameToxDem != null ? !dataExameToxDem.equals(that.dataExameToxDem) : that.dataExameToxDem != null)
            return false;
        if (cnpjLabExameToxDem != null ? !cnpjLabExameToxDem.equals(that.cnpjLabExameToxDem) : that.cnpjLabExameToxDem != null)
            return false;
        if (crmExameToxDem != null ? !crmExameToxDem.equals(that.crmExameToxDem) : that.crmExameToxDem != null)
            return false;
        if (ufCrmExameToxDem != null ? !ufCrmExameToxDem.equals(that.ufCrmExameToxDem) : that.ufCrmExameToxDem != null)
            return false;
        if (dataInicioAfastamento != null ? !dataInicioAfastamento.equals(that.dataInicioAfastamento) : that.dataInicioAfastamento != null)
            return false;
        return motivoESocial != null ? motivoESocial.equals(that.motivoESocial) : that.motivoESocial == null;
    }

    @Override
    public int hashCode() {
        int result = idEmpresa != null ? idEmpresa.hashCode() : 0;
        result = 31 * result + (tipoPessoa != null ? tipoPessoa.hashCode() : 0);
        result = 31 * result + (cnpj != null ? cnpj.hashCode() : 0);
        result = 31 * result + (matricula != null ? matricula.hashCode() : 0);
        result = 31 * result + (cpf != null ? cpf.hashCode() : 0);
        result = 31 * result + (pisPasep != null ? pisPasep.hashCode() : 0);
        result = 31 * result + (nome != null ? nome.hashCode() : 0);
        result = 31 * result + (sexo != null ? sexo.hashCode() : 0);
        result = 31 * result + (racaCor != null ? racaCor.hashCode() : 0);
        result = 31 * result + (estadoCivil != null ? estadoCivil.hashCode() : 0);
        result = 31 * result + (grauInstrucao != null ? grauInstrucao.hashCode() : 0);
        result = 31 * result + (primeiroEmprego != null ? primeiroEmprego.hashCode() : 0);
        result = 31 * result + (nascimento != null ? nascimento.hashCode() : 0);
        result = 31 * result + (municipioNascimento != null ? municipioNascimento.hashCode() : 0);
        result = 31 * result + (ufNascimento != null ? ufNascimento.hashCode() : 0);
        result = 31 * result + (paisNascimento != null ? paisNascimento.hashCode() : 0);
        result = 31 * result + (paisNacionalidade != null ? paisNacionalidade.hashCode() : 0);
        result = 31 * result + (mae != null ? mae.hashCode() : 0);
        result = 31 * result + (pai != null ? pai.hashCode() : 0);
        result = 31 * result + (ctps != null ? ctps.hashCode() : 0);
        result = 31 * result + (serieCtps != null ? serieCtps.hashCode() : 0);
        result = 31 * result + (ufEmissorCtps != null ? ufEmissorCtps.hashCode() : 0);
        result = 31 * result + (ricNumero != null ? ricNumero.hashCode() : 0);
        result = 31 * result + (ricOrgaoEmissor != null ? ricOrgaoEmissor.hashCode() : 0);
        result = 31 * result + (ricDtExpedicao != null ? ricDtExpedicao.hashCode() : 0);
        result = 31 * result + (identidade != null ? identidade.hashCode() : 0);
        result = 31 * result + (orgaoIdentidade != null ? orgaoIdentidade.hashCode() : 0);
        result = 31 * result + (emissaoIdentidade != null ? emissaoIdentidade.hashCode() : 0);
        result = 31 * result + (rneNumero != null ? rneNumero.hashCode() : 0);
        result = 31 * result + (rneOrgaoEmissor != null ? rneOrgaoEmissor.hashCode() : 0);
        result = 31 * result + (rneDtExpedicao != null ? rneDtExpedicao.hashCode() : 0);
        result = 31 * result + (ocNumero != null ? ocNumero.hashCode() : 0);
        result = 31 * result + (ocOrgaoEmissor != null ? ocOrgaoEmissor.hashCode() : 0);
        result = 31 * result + (ocDtExpedicao != null ? ocDtExpedicao.hashCode() : 0);
        result = 31 * result + (ocDtValidade != null ? ocDtValidade.hashCode() : 0);
        result = 31 * result + (cnhNroRegistro != null ? cnhNroRegistro.hashCode() : 0);
        result = 31 * result + (cnhDataExpedicao != null ? cnhDataExpedicao.hashCode() : 0);
        result = 31 * result + (cnhUf != null ? cnhUf.hashCode() : 0);
        result = 31 * result + (cnhDataVencto != null ? cnhDataVencto.hashCode() : 0);
        result = 31 * result + (cnhCategoria != null ? cnhCategoria.hashCode() : 0);
        result = 31 * result + (tipoLogradouro != null ? tipoLogradouro.hashCode() : 0);
        result = 31 * result + (endereco != null ? endereco.hashCode() : 0);
        result = 31 * result + (NroEndereco != null ? NroEndereco.hashCode() : 0);
        result = 31 * result + (complemento != null ? complemento.hashCode() : 0);
        result = 31 * result + (bairro != null ? bairro.hashCode() : 0);
        result = 31 * result + (cep != null ? cep.hashCode() : 0);
        result = 31 * result + (municipioMoradia != null ? municipioMoradia.hashCode() : 0);
        result = 31 * result + (ufMoradia != null ? ufMoradia.hashCode() : 0);
        result = 31 * result + (exteriorPaisResidencia != null ? exteriorPaisResidencia.hashCode() : 0);
        result = 31 * result + (exteriorDescLogradouro != null ? exteriorDescLogradouro.hashCode() : 0);
        result = 31 * result + (exteriorNrLogradouro != null ? exteriorNrLogradouro.hashCode() : 0);
        result = 31 * result + (exteriorComplemento != null ? exteriorComplemento.hashCode() : 0);
        result = 31 * result + (exteriorBairro != null ? exteriorBairro.hashCode() : 0);
        result = 31 * result + (exteriorNomeCidade != null ? exteriorNomeCidade.hashCode() : 0);
        result = 31 * result + (exteriorCodPostal != null ? exteriorCodPostal.hashCode() : 0);
        result = 31 * result + (estrangeiroDtChegada != null ? estrangeiroDtChegada.hashCode() : 0);
        result = 31 * result + (estrangeiroClassifIngresso != null ? estrangeiroClassifIngresso.hashCode() : 0);
        result = 31 * result + (estrangeiroCasadoBr != null ? estrangeiroCasadoBr.hashCode() : 0);
        result = 31 * result + (estrangeiroFilhosBr != null ? estrangeiroFilhosBr.hashCode() : 0);
        result = 31 * result + (deficienciaFisica != null ? deficienciaFisica.hashCode() : 0);
        result = 31 * result + (deficienciaVisual != null ? deficienciaVisual.hashCode() : 0);
        result = 31 * result + (deficienciaAuditiva != null ? deficienciaAuditiva.hashCode() : 0);
        result = 31 * result + (deficienciaMental != null ? deficienciaMental.hashCode() : 0);
        result = 31 * result + (deficienciaIntelectual != null ? deficienciaIntelectual.hashCode() : 0);
        result = 31 * result + (deficienciaReabilitado != null ? deficienciaReabilitado.hashCode() : 0);
        result = 31 * result + (preencheCota != null ? preencheCota.hashCode() : 0);
        result = 31 * result + (aposentado != null ? aposentado.hashCode() : 0);
        result = 31 * result + (tipoRegimeTrabalhista != null ? tipoRegimeTrabalhista.hashCode() : 0);
        result = 31 * result + (tipoRegimePrevidenciario != null ? tipoRegimePrevidenciario.hashCode() : 0);
        result = 31 * result + (nroReciboPreCadastro != null ? nroReciboPreCadastro.hashCode() : 0);
        result = 31 * result + (cadastroInicial != null ? cadastroInicial.hashCode() : 0);
        result = 31 * result + (dataAdmissao != null ? dataAdmissao.hashCode() : 0);
        result = 31 * result + (tipoAdmissao != null ? tipoAdmissao.hashCode() : 0);
        result = 31 * result + (indicativoAdmissao != null ? indicativoAdmissao.hashCode() : 0);
        result = 31 * result + (regimeJornada != null ? regimeJornada.hashCode() : 0);
        result = 31 * result + (naturezaAtividade != null ? naturezaAtividade.hashCode() : 0);
        result = 31 * result + (mesBaseCategoria != null ? mesBaseCategoria.hashCode() : 0);
        result = 31 * result + (cnpjSindicatoCategoria != null ? cnpjSindicatoCategoria.hashCode() : 0);
        result = 31 * result + (opcaoFgts != null ? opcaoFgts.hashCode() : 0);
        result = 31 * result + (dataOpcaoFgts != null ? dataOpcaoFgts.hashCode() : 0);
        result = 31 * result + (cargo != null ? cargo.hashCode() : 0);
        result = 31 * result + (categoriaTrabalhador != null ? categoriaTrabalhador.hashCode() : 0);
        result = 31 * result + (salarioBase != null ? salarioBase.hashCode() : 0);
        result = 31 * result + (unidadePagtoSalFixo != null ? unidadePagtoSalFixo.hashCode() : 0);
        result = 31 * result + (descSalarioVariavel != null ? descSalarioVariavel.hashCode() : 0);
        result = 31 * result + (tipoDuracaoContrato != null ? tipoDuracaoContrato.hashCode() : 0);
        result = 31 * result + (dataTerminoContrato != null ? dataTerminoContrato.hashCode() : 0);
        result = 31 * result + (clausulaAssegurRescisao != null ? clausulaAssegurRescisao.hashCode() : 0);
        result = 31 * result + (tipoInscrLocalTrab != null ? tipoInscrLocalTrab.hashCode() : 0);
        result = 31 * result + (cnpjLocalTrab != null ? cnpjLocalTrab.hashCode() : 0);
        result = 31 * result + (qtdHorasSemana != null ? qtdHorasSemana.hashCode() : 0);
        result = 31 * result + (tipoJornada != null ? tipoJornada.hashCode() : 0);
        result = 31 * result + (descTipoJornada != null ? descTipoJornada.hashCode() : 0);
        result = 31 * result + (regimeTempoParcial != null ? regimeTempoParcial.hashCode() : 0);
        result = 31 * result + (cnpjSindicatoFiliado != null ? cnpjSindicatoFiliado.hashCode() : 0);
        result = 31 * result + (cnpjEmpresaAnt != null ? cnpjEmpresaAnt.hashCode() : 0);
        result = 31 * result + (matricEmpresaAnt != null ? matricEmpresaAnt.hashCode() : 0);
        result = 31 * result + (dataInicioVinculo != null ? dataInicioVinculo.hashCode() : 0);
        result = 31 * result + (dataDesligamento != null ? dataDesligamento.hashCode() : 0);
        result = 31 * result + (estagiario != null ? estagiario.hashCode() : 0);
        result = 31 * result + (codExameToxAdm != null ? codExameToxAdm.hashCode() : 0);
        result = 31 * result + (dataExameToxAdm != null ? dataExameToxAdm.hashCode() : 0);
        result = 31 * result + (cnpjLabExameToxAdm != null ? cnpjLabExameToxAdm.hashCode() : 0);
        result = 31 * result + (crmExameToxAdm != null ? crmExameToxAdm.hashCode() : 0);
        result = 31 * result + (ufCrmExameToxAdm != null ? ufCrmExameToxAdm.hashCode() : 0);
        result = 31 * result + (codExameToxDem != null ? codExameToxDem.hashCode() : 0);
        result = 31 * result + (dataExameToxDem != null ? dataExameToxDem.hashCode() : 0);
        result = 31 * result + (cnpjLabExameToxDem != null ? cnpjLabExameToxDem.hashCode() : 0);
        result = 31 * result + (crmExameToxDem != null ? crmExameToxDem.hashCode() : 0);
        result = 31 * result + (ufCrmExameToxDem != null ? ufCrmExameToxDem.hashCode() : 0);
        result = 31 * result + (dataInicioAfastamento != null ? dataInicioAfastamento.hashCode() : 0);
        result = 31 * result + (motivoESocial != null ? motivoESocial.hashCode() : 0);
        return result;
    }

}