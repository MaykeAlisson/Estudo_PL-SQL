package models.commons.dtos;

import java.io.Serializable;
import java.util.Date;

/**
 * Classe que representa informaþ§es...
 *
 * <p>Autor: Fernandopti</p>
 *
 * @since 20/03/2018
 */
public class DataAlteracaoFuncDto implements Serializable {

    private Short empresa;
    private Long funcionario;
    private Date dataAlteracao;

    public Short getEmpresa() {

        return this.empresa;
    }

    public void setEmpresa( final Short empresa ) {

        this.empresa = empresa;
    }

    public Long getFuncionario() {

        return this.funcionario;
    }

    public void setFuncionario( final Long funcionario ) {

        this.funcionario = funcionario;
    }

    public Date getDataAlteracao() {
        return dataAlteracao;
    }

    public void setDataAlteracao(Date dataAlteracao) {
        this.dataAlteracao = dataAlteracao;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DataAlteracaoFuncDto that = (DataAlteracaoFuncDto) o;

        if (empresa != null ? !empresa.equals(that.empresa) : that.empresa != null) return false;
        if (funcionario != null ? !funcionario.equals(that.funcionario) : that.funcionario != null) return false;
        return dataAlteracao != null ? dataAlteracao.equals(that.dataAlteracao) : that.dataAlteracao == null;
    }

    @Override
    public int hashCode() {
        int result = empresa != null ? empresa.hashCode() : 0;
        result = 31 * result + (funcionario != null ? funcionario.hashCode() : 0);
        result = 31 * result + (dataAlteracao != null ? dataAlteracao.hashCode() : 0);
        return result;
    }
}
