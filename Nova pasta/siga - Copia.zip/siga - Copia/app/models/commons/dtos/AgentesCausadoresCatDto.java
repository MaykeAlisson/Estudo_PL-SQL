package models.commons.dtos;

import java.io.Serializable;
import java.util.Objects;

/**
 * DTO que representa informações da procedure fisco.dbo.up_esocial_cat_agente_causador
 *
 * <p>Autor: Silas Andrade</p>
 *
 * @since 21/05/2019
 */
public class AgentesCausadoresCatDto implements Serializable {

    private final String codAgenteCausador;
    private final String descAgenteCausador;


    public AgentesCausadoresCatDto(
            String codAgenteCausador,
            String descAgenteCausador) {
        this.codAgenteCausador = codAgenteCausador;
        this.descAgenteCausador = descAgenteCausador;
    }

    public String getCodAgenteCausador() {
        return codAgenteCausador;
    }

    public String getDescAgenteCausador() {
        return descAgenteCausador;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AgentesCausadoresCatDto that = (AgentesCausadoresCatDto) o;
        return Objects.equals(codAgenteCausador, that.codAgenteCausador) &&
                Objects.equals(descAgenteCausador, that.descAgenteCausador);
    }

    @Override
    public int hashCode() {
        return Objects.hash(codAgenteCausador, descAgenteCausador);
    }
}
