package models.commons.dtos;

import java.io.Serializable;
import java.util.Date;

/**
 * Classe que representa informaþ§es...
 *
 * <p>Autor: Fernandopti</p>
 *
 * @since 06/12/2017
 */
public class EmpregadoresESocialDto implements Serializable {

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // !!!!!!   FAVOR GERAR EQUALS E HASCODE  !!!!!!!!
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private Long parametro;
    private Short empresa;
    private Long numero;
    private Date data;
    private Date ultimaAtualizacao;
    private String caminho;
    private Long cnpj;

    public Long getParametro() {
        return parametro;
    }

    public void setParametro(Long parametro) {
        this.parametro = parametro;
    }

    public Short getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Short empresa) {
        this.empresa = empresa;
    }

    public Long getNumero() {
        return numero;
    }

    public void setNumero(Long numero) {
        this.numero = numero;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public Date getUltimaAtualizacao() {
        return ultimaAtualizacao;
    }

    public void setUltimaAtualizacao(Date ultimaAtualizacao) {
        this.ultimaAtualizacao = ultimaAtualizacao;
    }

    public String getCaminho() {
        return caminho;
    }

    public void setCaminho(String caminho) {
        this.caminho = caminho;
    }

    public Long getCnpj() {
        return cnpj;
    }

    public void setCnpj(Long cnpj) {
        this.cnpj = cnpj;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        EmpregadoresESocialDto that = (EmpregadoresESocialDto) o;

        if (parametro != null ? !parametro.equals(that.parametro) : that.parametro != null) return false;
        if (empresa != null ? !empresa.equals(that.empresa) : that.empresa != null) return false;
        if (numero != null ? !numero.equals(that.numero) : that.numero != null) return false;
        if (data != null ? !data.equals(that.data) : that.data != null) return false;
        if (ultimaAtualizacao != null ? !ultimaAtualizacao.equals(that.ultimaAtualizacao) : that.ultimaAtualizacao != null)
            return false;
        if (caminho != null ? !caminho.equals(that.caminho) : that.caminho != null) return false;
        return cnpj != null ? cnpj.equals(that.cnpj) : that.cnpj == null;
    }

    @Override
    public int hashCode() {
        int result = parametro != null ? parametro.hashCode() : 0;
        result = 31 * result + (empresa != null ? empresa.hashCode() : 0);
        result = 31 * result + (numero != null ? numero.hashCode() : 0);
        result = 31 * result + (data != null ? data.hashCode() : 0);
        result = 31 * result + (ultimaAtualizacao != null ? ultimaAtualizacao.hashCode() : 0);
        result = 31 * result + (caminho != null ? caminho.hashCode() : 0);
        result = 31 * result + (cnpj != null ? cnpj.hashCode() : 0);
        return result;
    }
}
