package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

/**
 * Classe que representa informações...
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 04/01/2018
 */
public class EbitdaCmvImpostoDto implements Serializable {

    private Long cnpjCliente;
    private Long idsetor;
    private Short idcidade;
    private Short iddistrito;
    private Short idcda;
    private BigDecimal vlrCmv;
    private BigDecimal vlrImpostos;

    public Long getCnpjCliente() {

        return this.cnpjCliente;
    }

    public void setCnpjCliente( final Long cnpjCliente ) {

        this.cnpjCliente = cnpjCliente;
    }

    public Long getIdsetor() {

        return this.idsetor;
    }

    public void setIdsetor( final Long idsetor ) {

        this.idsetor = idsetor;
    }

    public Short getIdcidade() {

        return this.idcidade;
    }

    public void setIdcidade( final Short idcidade ) {

        this.idcidade = idcidade;
    }

    public Short getIddistrito() {

        return this.iddistrito;
    }

    public void setIddistrito( final Short iddistrito ) {

        this.iddistrito = iddistrito;
    }

    public Short getIdcda() {

        return this.idcda;
    }

    public void setIdcda( final Short idcda ) {

        this.idcda = idcda;
    }

    public BigDecimal getVlrCmv() {

        return this.vlrCmv;
    }

    public void setVlrCmv( final BigDecimal vlrCmv ) {

        this.vlrCmv = vlrCmv;
    }

    public BigDecimal getVlrImpostos() {

        return this.vlrImpostos;
    }

    public void setVlrImpostos( final BigDecimal vlrImpostos ) {

        this.vlrImpostos = vlrImpostos;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof EbitdaCmvImpostoDto)) return false;
        EbitdaCmvImpostoDto that = (EbitdaCmvImpostoDto) o;
        return Objects.equals(getCnpjCliente(), that.getCnpjCliente()) &&
                Objects.equals(getIdsetor(), that.getIdsetor()) &&
                Objects.equals(getIdcidade(), that.getIdcidade()) &&
                Objects.equals(getIddistrito(), that.getIddistrito()) &&
                Objects.equals(getIdcda(), that.getIdcda());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getCnpjCliente(), getIdsetor(), getIdcidade(), getIddistrito(), getIdcda());
    }
}
