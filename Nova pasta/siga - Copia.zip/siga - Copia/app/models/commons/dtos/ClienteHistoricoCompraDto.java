package models.commons.dtos;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilDate.getData;
import static infra.util.UtilDate.getOrElse;
import static java.util.Collections.emptyList;
import static java.util.Collections.sort;

/**
 * Classe que representa informações o sobre periodo de compra da rede.
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 11/06/2015
 */
public class ClienteHistoricoCompraDto implements Serializable {

    private static final long serialVersionUID = 4525467282477653427L;

    private final Short idEmpresa;
    private final Long idCliente;
    private final Date periodo;

    public ClienteHistoricoCompraDto( final Short idEmpresa,
                                      final Long idCliente,
                                      final Date periodo ) {
        this.idEmpresa = idEmpresa;
        this.idCliente = idCliente;
        this.periodo = periodo;
    }

    public Short getIdEmpresa() {
        return idEmpresa;
    }

    public Long getIdCliente() {
        return idCliente;
    }

    public Date getPeriodo() {
        return periodo;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object o ) {
        if ( this == o ) return true;
        if ( !( o instanceof ClienteHistoricoCompraDto) ) return false;

        ClienteHistoricoCompraDto that = (ClienteHistoricoCompraDto) o;

        if ( idCliente != null ? !idCliente.equals( that.idCliente ) : that.idCliente != null ) return false;
        if ( idEmpresa != null ? !idEmpresa.equals( that.idEmpresa ) : that.idEmpresa != null ) return false;
        if ( periodo != null ? !periodo.equals( that.periodo ) : that.periodo != null ) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = idEmpresa != null ? idEmpresa.hashCode() : 0;
        result = 31 * result + ( idCliente != null ? idCliente.hashCode() : 0 );
        result = 31 * result + ( periodo != null ? periodo.hashCode() : 0 );
        return result;
    }

    @Override
    public String toString() {
        return "ClienteHistoricoCompraDto { " +
                "idEmpresa = " + idEmpresa +
                ", idCliente = " + idCliente + " }";
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    /**
     * Ordena lista de ClienteHistoricoCompraDto pela coluna período.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dtos  Lista de ClienteHistoricoCompraDto.
     *
     */
    public static void orderByPeriodo( List<ClienteHistoricoCompraDto> dtos ) {

        if ( isVazia(dtos) )
            return;

        sort( dtos, new Comparator<ClienteHistoricoCompraDto>() {
            @Override
            public int compare( final ClienteHistoricoCompraDto dtoA,
                                final ClienteHistoricoCompraDto dtoB ) {

                return getOrElse( dtoA.getPeriodo(), getData( 1, 1, 1900 ) )
                        .compareTo( getOrElse( dtoB.getPeriodo(), getData( 1, 1, 1900 ) ) );
            }
        } );

    }


    /**
     * Retorna os períodos (sem repetição) de uma lista de histórico de compras;
     *
     * <p>Autor: GPortes</p>
     *
     * @param dtos  Lista de ClienteHistoricoCompraDto.
     *
     * @return Lista de períodos.
     *
     */
    public static List<Date> getPeriodos( List<ClienteHistoricoCompraDto> dtos ) {

        if ( isVazia( dtos ))
            return emptyList();

        orderByPeriodo( dtos );

        List<Date> periodos = new ArrayList<Date>( dtos.size() );

        for ( ClienteHistoricoCompraDto dto : dtos )
            if ( !periodos.contains( dto.getPeriodo() ) )
                periodos.add( dto.getPeriodo() );

        return periodos;
    }


}