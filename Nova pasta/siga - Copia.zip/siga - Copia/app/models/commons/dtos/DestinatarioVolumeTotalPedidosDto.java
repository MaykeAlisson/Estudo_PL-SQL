package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;

public class DestinatarioVolumeTotalPedidosDto implements Serializable {

    private final Long idDestinatario;
    private final BigDecimal volumeTotalPedidos;
    private final BigDecimal pesoTotalPedidos;

    public DestinatarioVolumeTotalPedidosDto(Long idDestinatario, BigDecimal volumeTotalPedidos, BigDecimal pesoTotalPedidos) {
        this.idDestinatario = idDestinatario;
        this.volumeTotalPedidos = volumeTotalPedidos;
        this.pesoTotalPedidos = pesoTotalPedidos;
    }

    public Long getIdDestinatario() {
        return idDestinatario;
    }

    public BigDecimal getVolumeTotalPedidos() {
        return volumeTotalPedidos;
    }

    public BigDecimal getPesoTotalPedidos() {
        return pesoTotalPedidos;
    }
}
