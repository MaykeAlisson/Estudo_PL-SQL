package models.commons.dtos;

import com.fasterxml.jackson.annotation.JsonProperty;
import models.commons.constantes.Estado;
import models.commons.constantes.SimNao;
import models.commons.constantes.SituacaoPedidoECommerce;
import models.commons.constantes.TipoServicoCorreio;
import services.ws.CorreioDestinatario;

import java.io.Serializable;
import java.nio.file.Path;
import java.util.Objects;

import static infra.util.UtilBR.formatarCep;
import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilString.isEmptyGet;
import static java.lang.String.format;
import static models.commons.constantes.SimNao.NAO;

/**
 * Classe que representa o destinatario de um pedido e-commerce.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 07/02/2019
 */
public class DestinatarioPedidoECommerceDto implements Serializable, CorreioDestinatario {

    private final Long idPedidoECommerce;
    private final SituacaoPedidoECommerce situacao;
    private final String nomePessoa;
    private final String logradouro;
    private final String endereco;
    private final String nroEndereco;
    private final String complementoEndereco;
    private final Long cep;
    private final Estado estado;
    private final TipoServicoCorreio tipoServico;
    private final String codigoRastreamento;
    private final SimNao gerarEtiqueta;
    private final String arquivoEtiqueta;
    private final Long idCliente;


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CONSTRUCTOR
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public DestinatarioPedidoECommerceDto(
        final Long idPedidoECommerce,
        final Short situacao,
        final String nomePessoa,
        final String logradouro,
        final String endereco,
        final String nroEndereco,
        final String complementoEndereco,
        final Long cep,
        final String estado,
        final String tipoServico,
        final String codigoRastreamento,
        final String gerarEtiqueta,
        final String arquivoEtiqueta,
        final Long idCliente
    ) {

        this.idPedidoECommerce = idPedidoECommerce;
        this.situacao = getEnum(SituacaoPedidoECommerce.class,situacao);
        this.nomePessoa = nomePessoa;
        this.logradouro = logradouro;
        this.endereco = endereco;
        this.nroEndereco = nroEndereco;
        this.complementoEndereco = complementoEndereco;
        this.cep = cep;
        this.estado = getEnum( Estado.class, estado );
        this.tipoServico = getEnum( TipoServicoCorreio.class, tipoServico );
        this.codigoRastreamento = codigoRastreamento;
        this.gerarEtiqueta = gerarEtiqueta != null ? getEnum( SimNao.class, gerarEtiqueta ) : NAO;
        this.arquivoEtiqueta = arquivoEtiqueta;
        this.idCliente = idCliente;
    }

    @JsonProperty( "idPedidoECommerce" )
    @Override
    public Long getIdPedidoECommerce() {

        return this.idPedidoECommerce;
    }

    @JsonProperty( "situacao" )
    public SituacaoPedidoECommerce getSituacao() {

        return this.situacao;
    }

    @JsonProperty( "nomePessoa" )
    @Override
    public String getNomePessoa() {

        return this.nomePessoa;
    }

    @JsonProperty( "logradouro" )
    @Override
    public String getLogradouro() {

        return this.logradouro;
    }

    @JsonProperty( "endereco" )
    @Override
    public String getEndereco() {

        return this.endereco;
    }

    @JsonProperty( "nroEndereco" )
    @Override
    public String getNroEndereco() {

        return this.nroEndereco;
    }

    @JsonProperty( "complementoEndereco" )
    @Override
    public String getComplementoEndereco() {

        return complementoEndereco;
    }

    @JsonProperty( "cep" )
    public Long getCep() {

        return this.cep;
    }

    @JsonProperty( "estado" )
    public Estado getEstado() {

        return estado;
    }

    @JsonProperty( "tipoServico" )
    public TipoServicoCorreio getTipoServico() {

        return this.tipoServico;
    }

    @JsonProperty( "codigoRastreamento" )
    public String getCodigoRastreamento() {

        return codigoRastreamento;
    }

    @JsonProperty( "gerarEtiqueta" )
    public SimNao getGerarEtiqueta() {

        return this.gerarEtiqueta;
    }

    @JsonProperty( "arquivoEtiqueta" )
    public String getArquivoEtiqueta() {

        return this.arquivoEtiqueta;
    }

    @JsonProperty( "idCliente" )
    public Long getIdCliente() {

        return idCliente;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object o ) {

        if ( this == o ) return true;
        if ( !(o instanceof DestinatarioPedidoECommerceDto) ) return false;
        DestinatarioPedidoECommerceDto that = (DestinatarioPedidoECommerceDto) o;
        return Objects.equals(getIdPedidoECommerce(), that.getIdPedidoECommerce());
    }

    @Override
    public int hashCode() {

        return Objects.hash(getIdPedidoECommerce());
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODO AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Retorna endereço para gravar obervação do pedido e-commerce.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dto Destinatario.
     *
     * @return Endereço.
     */
    public static String getEnderecoObsPedido( final DestinatarioPedidoECommerceDto dto ) {

        if ( dto == null ) return "";

        final String endereco = format( "End.: %s %s, %s",
            dto.getLogradouro(),
            dto.getEndereco(),
            isEmptyGet( dto.getNroEndereco(), "S/N" )
        );

        return format( "CEP: %s ( %s )\n%s", formatarCep(dto.getCep()), dto.getEstado(), endereco );
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // BUILDER
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public static class Builder {

        private DestinatarioPedidoECommerceDto dto;
        private String codigoRastreamento;
        private String arquivoEtiqueta;

        public Builder( final DestinatarioPedidoECommerceDto dto ) {

            this.dto = dto;
            this.codigoRastreamento = "";
            this.arquivoEtiqueta = "";
        }

        public Builder comCodigoRastreamento( final String codigoRastreamento ) {

            this.codigoRastreamento = codigoRastreamento;
            return this;
        }

        public Builder comArquivoEtiqueta( final String arquivoEtiqueta ) {

            this.arquivoEtiqueta = arquivoEtiqueta;
            return this;
        }

        public Builder comArquivoEtiqueta( final Path arquivoEtiqueta ) {

            this.arquivoEtiqueta = arquivoEtiqueta == null ? null : arquivoEtiqueta.getFileName().toString();
            return this;
        }

        public DestinatarioPedidoECommerceDto builder() {

            return new DestinatarioPedidoECommerceDto(
                this.dto.getIdPedidoECommerce(),
                getValor(this.dto.getSituacao()),
                this.dto.getNomePessoa(),
                this.dto.getLogradouro(),
                this.dto.getEndereco(),
                this.dto.getNroEndereco(),
                this.dto.getComplementoEndereco(),
                this.dto.getCep(),
                getValor(this.dto.getEstado()),
                getValor(this.dto.getTipoServico()),
                this.codigoRastreamento,
                getValor(this.dto.getGerarEtiqueta()),
                this.arquivoEtiqueta,
                this.dto.getIdCliente()
            );
        }
    }

}
