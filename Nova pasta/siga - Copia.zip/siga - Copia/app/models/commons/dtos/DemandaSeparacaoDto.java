package models.commons.dtos;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import static infra.util.UtilCollections.isVazia;
import static java.util.Comparator.comparing;

/**
 * Classe que representa informações...
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 13/07/2017
 */
public class DemandaSeparacaoDto implements Serializable {

    private  String idTipoDestinatario;
    private  Long idDestinatario;
    private  Long idPedido;
    private  String idZone;
    private  Date dataEntrada;
    private  Short idSequencia;
    private  Long idMercadoria;
    private  Short idModoMapa;
    private  Long qtdCaixa;
    private  String idLocalSeparacao;
    private  BigDecimal quantidade;
    private  BigDecimal peso;
    private  BigDecimal volume;
    private Long idMicroregiao;
    private Short idCda;
    private String idGrupoCidade;

    public DemandaSeparacaoDto(
        final String idTipoDestinatario,
        final Long idDestinatario,
        final Long idPedido,
        final String idZone,
        final Date dataEntrada,
        final Short idSequencia,
        final Long idMercadoria,
        final Short idModoMapa,
        final Long qtdCaixa,
        final String idLocalSeparacao,
        final BigDecimal quantidade,
        final BigDecimal peso,
        final BigDecimal volume,
        final Long idMicroregiao,
        final Short idCda,
        final String idGrupoCidade
    ) {

        this.idTipoDestinatario = idTipoDestinatario;
        this.idDestinatario = idDestinatario;
        this.idPedido = idPedido;
        this.idZone = idZone;
        this.dataEntrada = dataEntrada;
        this.idSequencia = idSequencia;
        this.idMercadoria = idMercadoria;
        this.idModoMapa = idModoMapa;
        this.qtdCaixa = qtdCaixa;
        this.idLocalSeparacao = idLocalSeparacao;
        this.quantidade = quantidade;
        this.peso = peso;
        this.volume = volume;
        this.idMicroregiao = idMicroregiao;
        this.idCda = idCda;
        this.idGrupoCidade = idGrupoCidade;
    }

    public String getIdTipoDestinatario() {

        return idTipoDestinatario;
    }

    public Long getIdDestinatario() {

        return idDestinatario;
    }

    public Long getIdPedido() {

        return idPedido;
    }

    public String getIdZone() {

        return idZone;
    }

    public Date getDataEntrada() {

        return dataEntrada;
    }

    public Short getIdSequencia() {

        return idSequencia;
    }

    public Long getIdMercadoria() {

        return idMercadoria;
    }

    public String getIdLocalSeparacao() {

        return idLocalSeparacao;
    }

    public BigDecimal getQuantidade() {

        return quantidade;
    }

    public BigDecimal getPeso() {

        return peso;
    }

    public BigDecimal getVolume() {

        return volume;
    }

    public Long getQtdCaixa() {

        return qtdCaixa;
    }

    public Short getIdModoMapa() {

        return idModoMapa;
    }

    public void setQuantidade(BigDecimal quantidade) {

        this.quantidade = quantidade;
    }

    public void setPeso(BigDecimal peso) {

        this.peso = peso;
    }

    public void setVolume(BigDecimal volume) {

        this.volume = volume;
    }

    public Long getIdMicroregiao() {

        return idMicroregiao;
    }

    public Short getIdCda() {

        return idCda;
    }

    public String getIdGrupoCidade() {

        return idGrupoCidade;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals(Object o) {

        if (this == o) return true;
        if (!(o instanceof DemandaSeparacaoDto)) return false;

        DemandaSeparacaoDto that = (DemandaSeparacaoDto) o;

        if (!idTipoDestinatario.equals(that.idTipoDestinatario)) return false;
        if (!idDestinatario.equals(that.idDestinatario)) return false;
        if (!idPedido.equals(that.idPedido)) return false;
        if (!idZone.equals(that.idZone)) return false;
        if (!dataEntrada.equals(that.dataEntrada)) return false;
        if (!idSequencia.equals(that.idSequencia)) return false;
        if (!idMercadoria.equals(that.idMercadoria)) return false;
        if (!idLocalSeparacao.equals(that.idLocalSeparacao)) return false;
        if (!quantidade.equals(that.quantidade)) return false;
        if (!peso.equals(that.peso)) return false;
        return volume.equals(that.volume);
    }

    @Override
    public int hashCode() {
        int result = idTipoDestinatario.hashCode();
        result = 31 * result + idDestinatario.hashCode();
        result = 31 * result + idPedido.hashCode();
        result = 31 * result + idZone.hashCode();
        result = 31 * result + dataEntrada.hashCode();
        result = 31 * result + idSequencia.hashCode();
        result = 31 * result + idMercadoria.hashCode();
        result = 31 * result + idLocalSeparacao.hashCode();
        result = 31 * result + quantidade.hashCode();
        result = 31 * result + peso.hashCode();
        result = 31 * result + volume.hashCode();
        return result;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public static void orderByDestinatarioEDataEntrada( List<DemandaSeparacaoDto> lista ) {

        if ( isVazia(lista) )
            return;

        lista.sort(
            comparing( DemandaSeparacaoDto::getIdTipoDestinatario )
            .thenComparing( DemandaSeparacaoDto::getIdDestinatario )
            .thenComparing( DemandaSeparacaoDto::getDataEntrada )
        );
    }

    public static void orderByZoneEMercadoria( List<DemandaSeparacaoDto> lista ) {

        if ( isVazia(lista) )
            return;

        lista.sort(
            comparing( DemandaSeparacaoDto::getIdZone )
            .thenComparing( DemandaSeparacaoDto::getIdMercadoria )
        );
    }

}


