package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilNumero.getOrElseZero;
import static infra.util.UtilResult.R;
import static infra.util.UtilString.getOrElse;


/**
 * Classe que representa informações sobre o limite construído do cliente.
 *
 * <p>Autor: GPortes</p>
 */
public class LimiteConstruidoDto implements Serializable {

    private final Short idEmpresa;
    private final Long idCliente;
    private final String situacao;
    private final String motivoAtraso;
    private final Integer percAcrescimoPagto;
    private final String motivoAcrescimoPagto;
    private final Short percAcrescimoCidade;
    private final String motivoAcrescimoCidade;
    private final String motivoRedutor;
    private final BigDecimal vlrConstruido;
    private final String motivoVlrConstruido;

    private LimiteConstruidoDto( models.commons.dtos.LimiteConstruidoDto.Builder builder ) {

        this.idEmpresa = builder.idEmpresa;
        this.idCliente = builder.idCliente;
        this.situacao = builder.situacao;
        this.vlrConstruido = getOrElseZero( builder.vlrConstruido );
        this.motivoVlrConstruido = getOrElse( builder.motivoVlrConstruido, "" );
        this.percAcrescimoPagto = getOrElseZero( builder.percAcrescimoPagto, Integer.class );
        this.motivoAcrescimoPagto = getOrElse( builder.motivoAcrescimoPagto, "" );
        this.percAcrescimoCidade = getOrElseZero( builder.percAcrescimoCidade, Short.class );
        this.motivoAcrescimoCidade = getOrElse( builder.motivoAcrescimoCidade, "" );
        this.motivoRedutor = getOrElse( builder.motivoRedutor, "" );
        this.motivoAtraso = getOrElse( builder.motivoAtraso, "" );
    }

    public static class Builder {

        private Short idEmpresa;
        private Long idCliente;
        private String situacao;
        private String motivoAtraso;
        private Integer percAcrescimoPagto;
        private String motivoAcrescimoPagto;
        private Short percAcrescimoCidade;
        private String motivoAcrescimoCidade;
        private String motivoRedutor;
        private BigDecimal vlrConstruido;
        private String motivoVlrConstruido;

        public Builder ( final Short idEmpresa,
                         final Long idCliente ) {

            this.idEmpresa = idEmpresa;
            this.idCliente = idCliente;
        }

        public Builder comSituacao( final String situacao ) {

            this.situacao = situacao;
            return this;
        }

        public Builder comMotivoAtraso( final String motivoAtraso ) {

            this.motivoAtraso = motivoAtraso;
            return this;
        }

        public Builder comAcrescimoPagto( final R<Integer> acrescimo ) {

            this.percAcrescimoPagto = acrescimo.getValor();
            this.motivoAcrescimoPagto =  acrescimo.getMotivo();
            return this;
        }

        public Builder comAcrescimoCidade( final R<List<Short>> acrescimo ) {

            final List<Short> acresc = acrescimo.getValor();
            this.percAcrescimoCidade =  ( isVazia( acresc ) ? 0 : acresc.get( 0 ) );
            this.motivoAcrescimoCidade = acrescimo.getMotivo();
            return this;
        }

        public Builder comRedutor( final String motivo ) {

            this.motivoRedutor = motivo;
            return this;
        }

        public Builder comConstruido( final R<BigDecimal> valorConstruido ) {

            this.vlrConstruido = valorConstruido.getValor();
            this.motivoVlrConstruido = valorConstruido.getMotivo();
            return this;
        }

        public LimiteConstruidoDto builder() {

            return new LimiteConstruidoDto( this );
        }

    }

    public Short getIdEmpresa( ) {
        return idEmpresa;
    }

    public Long getIdCliente( ) {
        return idCliente;
    }

    public String getSituacao( ) {
        return situacao;
    }

    public String getMotivoAtraso( ) {
        return motivoAtraso;
    }

    public Integer getPercAcrescimoPagto( ) {
        return percAcrescimoPagto;
    }

    public String getMotivoAcrescimoPagto( ) {
        return motivoAcrescimoPagto;
    }

    public Short getPercAcrescimoCidade( ) {
        return percAcrescimoCidade;
    }

    public String getMotivoAcrescimoCidade( ) {
        return motivoAcrescimoCidade;
    }

    public String getMotivoRedutor( ) {
        return motivoRedutor;
    }

    public BigDecimal getVlrConstruido( ) {
        return vlrConstruido;
    }

    public String getMotivoVlrConstruido( ) {
        return motivoVlrConstruido;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object o ) {
        if ( this == o ) return true;
        if ( o == null || getClass( ) != o.getClass( ) ) return false;

        LimiteConstruidoDto that = (LimiteConstruidoDto) o;

        if ( idEmpresa != null ? !idEmpresa.equals( that.idEmpresa ) : that.idEmpresa != null ) return false;
        return idCliente != null ? idCliente.equals( that.idCliente ) : that.idCliente == null;

    }

    @Override
    public int hashCode( ) {
        int result = idEmpresa != null ? idEmpresa.hashCode( ) : 0;
        result = 31 * result + ( idCliente != null ? idCliente.hashCode( ) : 0 );
        return result;
    }
}
