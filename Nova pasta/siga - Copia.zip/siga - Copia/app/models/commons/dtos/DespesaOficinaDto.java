package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Classe que representa informações sobre cidades
 *
 * <p>Autor: Cléber</p>
 *
 * @since 26/05/16
 */

public class DespesaOficinaDto implements Serializable {

    private  String tipoAlocacao;
    private  Long idOrdemServico;
    private  Date dataAbertura;
    private  Date dataFechamento;
    private  Short idVeiculo;
    private  BigDecimal valorServico;
    private  BigDecimal valorPecaTerceiros;
    private  BigDecimal valorPecaArcom;
    private  String observacao;

    public DespesaOficinaDto(   final String tipoAlocacao,
                                final Long idOrdemServico,
                                final Date dataAbertura,
                                final Date dataFechamento,
                                final Short idVeiculo,
                                final BigDecimal valorServico,
                                final BigDecimal valorPecaTerceiros,
                                final BigDecimal valorPecaArcom,
                                final String observacao) {

        this.tipoAlocacao = tipoAlocacao;
        this.idOrdemServico = idOrdemServico;
        this.dataAbertura = dataAbertura;
        this.dataFechamento = dataFechamento;
        this.idVeiculo = idVeiculo;
        this.valorServico = valorServico;
        this.valorPecaTerceiros = valorPecaTerceiros;
        this.valorPecaArcom = valorPecaArcom;
        this.observacao = observacao;
    }

    public String getTipoAlocacao() {
        return tipoAlocacao;
    }

    public Long getIdOrdemServico() {
        return idOrdemServico;
    }

    public Date getDataAbertura() {
        return dataAbertura;
    }

    public Date getDataFechamento() {
        return dataFechamento;
    }

    public Short getIdVeiculo() {
        return idVeiculo;
    }

    public BigDecimal getValorServico() {
        return valorServico == null ? BigDecimal.ZERO : valorServico;
    }

    public BigDecimal getValorPecaTerceiros() {
        return valorPecaTerceiros == null ? BigDecimal.ZERO: valorPecaTerceiros;
    }

    public BigDecimal getValorPecaArcom() {
        return valorPecaArcom == null ? BigDecimal.ZERO : valorPecaArcom;
    }

    public String getObservacao() {
        return observacao;
    }

    @Override
    public String toString() {
        return "DespesaOficinaDto{" +
                "tipoAlocacao='" + tipoAlocacao + '\'' +
                ", idOrdemServico=" + idOrdemServico +
                ", dataAbertura=" + dataAbertura +
                ", dataFechamento=" + dataFechamento +
                ", idVeiculo=" + idVeiculo +
                ", valorServico=" + valorServico +
                ", valorPecaTerceiros=" + valorPecaTerceiros +
                ", valorPecaArcom=" + valorPecaArcom +
                ", observacao='" + observacao + '\'' +
                '}';
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DespesaOficinaDto that = (DespesaOficinaDto) o;

        if (!tipoAlocacao.equals(that.tipoAlocacao)) return false;
        if (!idOrdemServico.equals(that.idOrdemServico)) return false;
        if (!dataAbertura.equals(that.dataAbertura)) return false;
        if (!dataFechamento.equals(that.dataFechamento)) return false;
        if (!idVeiculo.equals(that.idVeiculo)) return false;
        if (!valorServico.equals(that.valorServico)) return false;
        if (!valorPecaTerceiros.equals(that.valorPecaTerceiros)) return false;
        if (!valorPecaArcom.equals(that.valorPecaArcom)) return false;
        return observacao.equals(that.observacao);

    }

    @Override
    public int hashCode() {
        int result = tipoAlocacao.hashCode();
        result = 31 * result + idOrdemServico.hashCode();
        result = 31 * result + dataAbertura.hashCode();
        result = 31 * result + dataFechamento.hashCode();
        result = 31 * result + idVeiculo.hashCode();
        result = 31 * result + valorServico.hashCode();
        result = 31 * result + valorPecaTerceiros.hashCode();
        result = 31 * result + valorPecaArcom.hashCode();
        result = 31 * result + observacao.hashCode();
        return result;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}