package models.commons.dtos;

import models.commons.constantes.ESocialConstantes;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import static infra.util.UtilDate.getDataComoString;


/**
 * Classe que representa informaþ§es...
 *
 * <p>Autor: Fernandopti</p>
 *
 * @since 23/10/2017
 */


public class EventoDetalheDto implements Serializable {

    private Date dataEnvio;
    private Date dataRetorno;
    private String protocoloEnvio;
    private String chave;
    private String reciboEvento;
    private Long idEventoCatalogo;
    private String versaoProcessamento;
    private String idEvento;
    private String nomeEvento;
    private Short idEmpresa;
    private String descricao;


    public String getDataEnvio() {

        return getDataComoString( this.dataEnvio, ESocialConstantes.DD_MM_YYYY_HHMMSS);
    }

    public void setDataEnvio( final Date dataEnvio ) {

        this.dataEnvio = dataEnvio;
    }

    public String getDataRetorno() {
        return new SimpleDateFormat(ESocialConstantes.DD_MM_YYYY_HHMMSS).format(this.dataRetorno);

    }

    public void setDataRetorno( final Date dataRetorno ) {

        this.dataRetorno = dataRetorno;
    }

    public String getProtocoloEnvio() {

        return this.protocoloEnvio;
    }

    public void setProtocoloEnvio( final String protocoloEnvio ) {

        this.protocoloEnvio = protocoloEnvio;
    }

    public String getChave() {
        return chave;
    }

    public void setChave(String chave) {
        this.chave = chave;
    }

    public String getReciboEvento() {
        return reciboEvento;
    }

    public void setReciboEvento(final String reciboEvento ) {

        this.reciboEvento = reciboEvento;
    }

    public Long getIdEventoCatalogo() {

        return this.idEventoCatalogo;
    }

    public void setIdEventoCatalogo( final Long idEventoCatalogo ) {

        this.idEventoCatalogo = idEventoCatalogo;
    }

    public String getVersaoProcessamento() {

        return this.versaoProcessamento;
    }

    public void setVersaoProcessamento( final String versaoProcessamento ) {

        this.versaoProcessamento = versaoProcessamento;
    }

    public String getIdEvento() {

        return this.idEvento;
    }

    public void setIdEvento( final String idEvento ) {

        this.idEvento = idEvento;
    }

    public String getNomeEvento() {
        return nomeEvento;
    }

    public void setNomeEvento(String nomeEvento) {
        this.nomeEvento = nomeEvento;
    }

    public Short getIdEmpresa() {
        return idEmpresa;
    }

    public void setIdEmpresa(Short idEmpresa) {
        this.idEmpresa = idEmpresa;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof EventoDetalheDto)) return false;

        EventoDetalheDto that = (EventoDetalheDto) o;

        if (getDataEnvio() != null ? !getDataEnvio().equals(that.getDataEnvio()) : that.getDataEnvio() != null)
            return false;
        if (getDataRetorno() != null ? !getDataRetorno().equals(that.getDataRetorno()) : that.getDataRetorno() != null)
            return false;
        if (getProtocoloEnvio() != null ? !getProtocoloEnvio().equals(that.getProtocoloEnvio()) : that.getProtocoloEnvio() != null)
            return false;
        if (getChave() != null ? !getChave().equals(that.getChave()) : that.getChave() != null) return false;
        if (getReciboEvento() != null ? !getReciboEvento().equals(that.getReciboEvento()) : that.getReciboEvento() != null)
            return false;
        if (getIdEventoCatalogo() != null ? !getIdEventoCatalogo().equals(that.getIdEventoCatalogo()) : that.getIdEventoCatalogo() != null)
            return false;
        if (getVersaoProcessamento() != null ? !getVersaoProcessamento().equals(that.getVersaoProcessamento()) : that.getVersaoProcessamento() != null)
            return false;
        if (getIdEvento() != null ? !getIdEvento().equals(that.getIdEvento()) : that.getIdEvento() != null)
            return false;
        if (getNomeEvento() != null ? !getNomeEvento().equals(that.getNomeEvento()) : that.getNomeEvento() != null)
            return false;
        if (getIdEmpresa() != null ? !getIdEmpresa().equals(that.getIdEmpresa()) : that.getIdEmpresa() != null)
            return false;
        if (getDescricao() != null ? !getDescricao().equals(that.getDescricao()) : that.getDescricao() != null)
            return false;
        return true;
    }

    @Override
    public int hashCode() {
        int result = getDataEnvio() != null ? getDataEnvio().hashCode() : 0;
        result = 31 * result + (getDataRetorno() != null ? getDataRetorno().hashCode() : 0);
        result = 31 * result + (getProtocoloEnvio() != null ? getProtocoloEnvio().hashCode() : 0);
        result = 31 * result + (getChave() != null ? getChave().hashCode() : 0);
        result = 31 * result + (getReciboEvento() != null ? getReciboEvento().hashCode() : 0);
        result = 31 * result + (getIdEventoCatalogo() != null ? getIdEventoCatalogo().hashCode() : 0);
        result = 31 * result + (getVersaoProcessamento() != null ? getVersaoProcessamento().hashCode() : 0);
        result = 31 * result + (getIdEvento() != null ? getIdEvento().hashCode() : 0);
        result = 31 * result + (getNomeEvento() != null ? getNomeEvento().hashCode() : 0);
        result = 31 * result + (getIdEmpresa() != null ? getIdEmpresa().hashCode() : 0);
        result = 31 * result + (getDescricao() != null ? getDescricao().hashCode() : 0);
        return result;
    }
}
