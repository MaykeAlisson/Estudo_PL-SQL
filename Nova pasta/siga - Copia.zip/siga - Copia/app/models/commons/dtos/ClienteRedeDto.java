package models.commons.dtos;


import models.commons.constantes.SimNao;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilDate.ehMenor;
import static infra.util.UtilDate.isValida;
import static infra.util.UtilNumero.getOrElseZero;
import static infra.util.UtilNumero.somar;
import static java.math.BigDecimal.ZERO;
import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.toList;
import static models.commons.constantes.SimNao.SIM;

/**
 * Classe que representa informações...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 15/06/2015
 */
public class ClienteRedeDto implements Serializable {

    private static final long serialVersionUID = 4054737166418210441L;
    private final Long idRede;
    private final Long idCliente;
    private final SimNao agrupaAnaliseCredito;
    private final Date implantacao;
    private final LocalDateTime dataUltimoPedido;
    private final LocalDateTime dataUltimoPedidoExclusivo;
    private final LocalDateTime dataUltimoPedidoTelevenda;
    private final Date dataReativacao;
    private final Date dataLimiteReativacao;
    private final BigDecimal vlrLimiteManualLoja;
    private final Short idCidade;
    private final Short idDistrito;
    private final Short percentualAcrescimoLimiteCredito;
    private final Short percentualAcrescimoLimiteCreditoTolerancia;

    public ClienteRedeDto(
        final Long idRede,
        final Long idCliente,
        final SimNao agrupaAnaliseCredito,
        final Date implantacao,
        final LocalDateTime dataUltimoPedido,
        final LocalDateTime dataUltimoPedidoExclusivo,
        final LocalDateTime dataUltimoPedidoTelevenda,
        final BigDecimal vlrLimiteManualLoja,
        final Date dataReativacao,
        final Date dataLimiteReativacao,
        final Short idCidade,
        final Short idDistrito,
        final Short percentualAcrescimoLimiteCredito,
        final Short percentualAcrescimoLimiteCreditoTolerancia
    ) {

        this.idRede = idRede;
        this.idCliente = idCliente;
        this.agrupaAnaliseCredito = agrupaAnaliseCredito;
        this.implantacao = implantacao;
        this.dataUltimoPedido = dataUltimoPedido;
        this.dataUltimoPedidoExclusivo = dataUltimoPedidoExclusivo;
        this.dataUltimoPedidoTelevenda = dataUltimoPedidoTelevenda;
        this.vlrLimiteManualLoja = vlrLimiteManualLoja;
        this.dataReativacao = dataReativacao;
        this.dataLimiteReativacao = dataLimiteReativacao;
        this.idCidade = idCidade;
        this.idDistrito = idDistrito;
        this.percentualAcrescimoLimiteCredito = getOrElseZero( percentualAcrescimoLimiteCredito, Short.class );
        this.percentualAcrescimoLimiteCreditoTolerancia = getOrElseZero( percentualAcrescimoLimiteCreditoTolerancia, Short.class );
    }

    public Long getIdRede() {

        return idRede;
    }

    public Long getIdCliente() {

        return idCliente;
    }

    public SimNao getAgrupaAnaliseCredito() {

        return agrupaAnaliseCredito;
    }

    public Date getImplantacao() {

        return implantacao;
    }

    public BigDecimal getVlrLimiteManualLoja() {

        return vlrLimiteManualLoja;
    }

    public LocalDateTime getDataUltimoPedido() {

        return dataUltimoPedido;
    }

    public LocalDateTime getDataUltimoPedidoExclusivo() {

        return dataUltimoPedidoExclusivo;
    }

    public LocalDateTime getDataUltimoPedidoTelevenda() {

        return dataUltimoPedidoTelevenda;
    }

    public Short getIdCidade() {

        return idCidade;
    }

    public Short getIdDistrito() {

        return idDistrito;
    }

    public Short getPercentualAcrescimoLimiteCredito() {

        return percentualAcrescimoLimiteCredito;
    }

    public Short getPercentualAcrescimoLimiteCreditoTolerancia() {

        return percentualAcrescimoLimiteCreditoTolerancia;
    }

    public Date getDataReativacao() {

        return dataReativacao;
    }

    public Date getDataLimiteReativacao() {

        return dataLimiteReativacao;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object o ) {
        if ( this == o ) return true;
        if ( !( o instanceof ClienteRedeDto) ) return false;

        ClienteRedeDto that = (ClienteRedeDto) o;

        if ( idCliente != null ? !idCliente.equals( that.idCliente ) : that.idCliente != null ) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return idCliente != null ? idCliente.hashCode() : 0;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Retorna informações comuns de uma rede agrupada.
     *
     * <p>Autor: GPortes</p>
     *
     * <pre>{@code
     *
     *      // Exemplo:
     *      List<ClienteRedeDto> dtos = ...;
     *
     *      ClienteRedeDto.InfoRedeAgrupada res = ClienteRedeDto.buscarResumo( dtos );
     *
     *      res.getQtdeLojas();
     *      res.getDataImplantacao();
     *
     * }</pre>
     *
     * @param clientes Listas de clientes rede.
     *
     * @return Resumo
     */
    public static InfoRedeAgrupada buscarInfoRedeAgrupada( final List<ClienteRedeDto> clientes ) {

        final List<ClienteRedeDto> clientesAgrupados = clientes
                    .stream()
                    .filter(dto -> Objects.equals(dto.getAgrupaAnaliseCredito(), SIM))
                    .collect(toList());

        final int qtdeLojasDaRede = isVazia( clientesAgrupados ) ? 0 : clientesAgrupados.size();
        List<Long> idClientesDeTodaRede = emptyList();
        Date menorDataImplantacao = null;
        Date menorDataReativacao = null;
        Date dataLimiteReativacao = null;
        BigDecimal vlrSomatoriaLimiteManual = ZERO;
        boolean existeAcrescimoCidade = true;
        Short maiorAcrecimoCidade = 0;
        Short acrescimoCidadeTolerancia = 0;

        if ( qtdeLojasDaRede > 0 )
            idClientesDeTodaRede = new ArrayList<>( qtdeLojasDaRede );

        for ( final ClienteRedeDto dto : clientesAgrupados ) {

            // Clientes da rede.
            idClientesDeTodaRede.add( dto.getIdCliente() );

            // Buscamos a data + antiga de implantação da rede.
            if ( ( menorDataImplantacao == null )
                 || ( isValida( dto.getImplantacao() ) && ehMenor( dto.getImplantacao(), menorDataImplantacao ) ) )
                menorDataImplantacao = dto.getImplantacao();

            // Buscamos a data + antiga da reativação da rede.
            if ( ( menorDataReativacao == null )
                    || ( isValida( dto.getDataReativacao() ) && ehMenor( dto.getDataReativacao(), menorDataReativacao ) ) ) {
                menorDataReativacao = dto.getDataReativacao( );
                dataLimiteReativacao = dto.getDataLimiteReativacao();
            }

            // Somamos todos os limites da rede.
            vlrSomatoriaLimiteManual = somar( vlrSomatoriaLimiteManual, dto.getVlrLimiteManualLoja() );

            // Se um dos clientes da rede esta localizado em cidade sem acrescimo, então sinalizamos a rede para não ter acrescimo.
            if ( dto.getPercentualAcrescimoLimiteCredito() == 0 )
                existeAcrescimoCidade = false;

            // Buscamos o maior acrescimo da rede.
            if ( maiorAcrecimoCidade < dto.getPercentualAcrescimoLimiteCredito() ) {
                maiorAcrecimoCidade = dto.getPercentualAcrescimoLimiteCredito();
                acrescimoCidadeTolerancia = dto.getPercentualAcrescimoLimiteCreditoTolerancia();
            }
        }

        return InfoRedeAgrupada.newInstance(
                    idClientesDeTodaRede,
                    qtdeLojasDaRede,
                    menorDataImplantacao,
                    menorDataReativacao,
                    dataLimiteReativacao,
                    vlrSomatoriaLimiteManual,
                    existeAcrescimoCidade,
                    maiorAcrecimoCidade,
                    acrescimoCidadeTolerancia
        );
    }

    public interface InfoRedeAgrupada {

        List<Long> getIdsCliente();
        Integer getQtdeLojas();
        Date getDataImplantacao();
        Date getDataReativacao();
        Date getDataLimiteReativacao();
        BigDecimal getVlrLimiteManual();
        Boolean isPermiteAcrescimoCidade();
        Short getPercAcrescLimiteCreditoCidade();
        Short getPercAcrescLimiteCreditoCidadeTolerancia();

        static InfoRedeAgrupada newInstance( final List<Long> idClientes,
                                             final Integer qtdeLojas,
                                             final Date dataImplantacao,
                                             final Date dataReativacao,
                                             final Date dataLimiteReativacao,
                                             final BigDecimal vlrLimiteManual,
                                             final Boolean existeAcrescimoCidade,
                                             final Short percentualAcrescimoLimiteCredito,
                                             final Short percentualAcrescimoLimiteCreditoTolerancia ) {
            return new InfoRedeAgrupada() {

                @Override
                public List<Long> getIdsCliente() { return idClientes; }

                @Override
                public Integer getQtdeLojas() { return qtdeLojas; }

                @Override
                public Date getDataImplantacao() { return dataImplantacao; }

                @Override
                public Date getDataReativacao( ) { return dataReativacao; }

                @Override
                public Date getDataLimiteReativacao( ) { return dataLimiteReativacao; }

                @Override
                public BigDecimal getVlrLimiteManual() { return vlrLimiteManual; }

                @Override
                public Boolean isPermiteAcrescimoCidade() { return existeAcrescimoCidade; }

                @Override
                public Short getPercAcrescLimiteCreditoCidade() { return percentualAcrescimoLimiteCredito; }

                @Override
                public Short getPercAcrescLimiteCreditoCidadeTolerancia() { return percentualAcrescimoLimiteCreditoTolerancia; }
            };
        }

    }
}