package models.commons.dtos;



import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import infra.jsonDeserializer.LocalDateTimeSerializer;
import infra.util.UtilDate;

/**
 * Classe que representa informações...
 *
 * <p>Autor: Alysson Myller</p>
 *
 * @since 17/05/2019
 */
public class ClienteAtivoSetorDto implements Serializable {


    private final Long cliente;
    private final String razaoSocial;
    private final Long cgc;
    private final String logradouro;
    private final String endereco;
    private final String nroEndereco;
    private final String bairro;
    private final String complemento;
    private final BigDecimal latitude;
    private final BigDecimal longitude;
    private final LocalDateTime dataUltimoPedido;
    private final BigDecimal valorTresMeses;


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CONSTRUCTOR
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public ClienteAtivoSetorDto(
            final Long cliente,
            final String razaoSocial,
            final Long cgc,
            final String logradouro,
            final String endereco,
            final String nroEndereco,
            final String bairro,
            final String complemento,
            final BigDecimal latitude,
            final BigDecimal longitude,
            final java.util.Date dataUltimoPedido,
            final BigDecimal valorTresMeses
    ) {

        this.cliente = cliente;
        this.razaoSocial = razaoSocial;
        this.cgc = cgc;
        this.logradouro = logradouro;
        this.endereco = endereco;
        this.nroEndereco = nroEndereco;
        this.bairro = bairro;
        this.complemento = complemento;
        this.latitude = latitude;
        this.longitude = longitude;
        this.dataUltimoPedido = UtilDate.toLocalDateTime(dataUltimoPedido);
        this.valorTresMeses = valorTresMeses;
    }

    @JsonProperty( "cliente" )
    public Long getCliente() {

        return this.cliente;
    }

    @JsonProperty( "razaoSocial" )
    public String getRazaoSocial() {

        return this.razaoSocial;
    }

    @JsonProperty( "cgc" )
    public Long getCgc() {

        return this.cgc;
    }

    @JsonProperty( "logradouro" )
    public String getLogradouro() {

        return this.logradouro;
    }

    @JsonProperty( "endereco" )
    public String getEndereco() {

        return this.endereco;
    }

    @JsonProperty( "nroEndereco" )
    public String getNroEndereco() {

        return this.nroEndereco;
    }

    @JsonProperty( "bairro" )
    public String getBairro() {

        return this.bairro;
    }

    @JsonProperty( "complemento" )
    public String getComplemento() {

        return this.complemento;
    }

    @JsonProperty( "latitude" )
    public BigDecimal getLatitude() {

        return this.latitude;
    }

    @JsonProperty( "longitude" )
    public BigDecimal getLongitude() {

        return this.longitude;
    }

    @JsonProperty( "valorTresMeses" )
    public BigDecimal getValorTresMeses() {

        return this.valorTresMeses;
    }

    @JsonProperty( "dataUltimoPedido" )
    @JsonSerialize( using = LocalDateTimeSerializer.class )
    public LocalDateTime getDataUltimoPedido() {

        return this.dataUltimoPedido;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ClienteAtivoSetorDto that = (ClienteAtivoSetorDto) o;
        return Objects.equals(getCgc(), that.getCgc());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getCgc());
    }
}


