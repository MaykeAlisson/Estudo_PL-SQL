package models.commons.dtos;

import infra.util.UtilDate;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

/**
 * Alysson Myller
 * 25/06/2018
 */
public class ComboioVeiculoDto implements Serializable {

    private Long comboio;
    private Integer veiculo;
    private Short empresa;
    private Date dataInsercao;
    private BigDecimal latitude;
    private BigDecimal longitude;
    private Date dataUltimaCoordenada;
    private String ignorar;
    private Long usuarioAlteracao;
    private Short cdaDestino;
    private Long distanciaMetros;
    private String situacaoVeiculo;
    private String descricaoCda;
    private String dataUltimaCoordenadaFormatada;


    public ComboioVeiculoDto(
            Long comboio,
            Integer veiculo,
            Short empresa,
            Date dataInsercao,
            BigDecimal latitude,
            BigDecimal longitude,
            Date dataUltimaCoordenada,
            String ignorar,
            Long usuarioAlteracao,
            Short cdaDestino,
            Long distanciaMetros,
            String situacaoVeiculo,
            String descricaoCda
    ) {

        this.comboio = comboio;
        this.veiculo = veiculo;
        this.empresa = empresa;
        this.dataInsercao = dataInsercao;
        this.latitude = latitude;
        this.longitude = longitude;
        this.dataUltimaCoordenada = dataUltimaCoordenada;
        this.ignorar = ignorar;
        this.usuarioAlteracao = usuarioAlteracao;
        this.cdaDestino = cdaDestino;
        this.distanciaMetros = distanciaMetros;
        this.situacaoVeiculo = situacaoVeiculo;
        this.descricaoCda = descricaoCda;
    }

    public Long getComboio() {
        return comboio;
    }

    public void setComboio(Long comboio) {
        this.comboio = comboio;
    }

    public Integer getVeiculo() {
        return veiculo;
    }

    public void setVeiculo(Integer veiculo) {
        this.veiculo = veiculo;
    }

    public Short getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Short empresa) {
        this.empresa = empresa;
    }

    public Date getDataInsercao() {
        return dataInsercao;
    }

    public void setDataInsercao(Date dataInsercao) {
        this.dataInsercao = dataInsercao;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }

    public Date getDataUltimaCoordenada() {
        return dataUltimaCoordenada;
    }

    public void setDataUltimaCoordenada(Date dataUltimaCoordenada) {
        this.dataUltimaCoordenada = dataUltimaCoordenada;
    }

    public String getIgnorar() {
        return ignorar;
    }

    public void setIgnorar(String ignorar) {
        this.ignorar = ignorar;
    }

    public Long getUsuarioAlteracao() {
        return usuarioAlteracao;
    }

    public void setUsuarioAlteracao(Long usuarioAlteracao) {
        this.usuarioAlteracao = usuarioAlteracao;
    }

    public Short getCdaDestino() {
        return cdaDestino;
    }

    public void setCdaDestino(Short cdaDestino) {
        this.cdaDestino = cdaDestino;
    }

    public Long getDistanciaMetros() {
        return distanciaMetros;
    }

    public void setDistanciaMetros(Long distanciaMetros) {
        this.distanciaMetros = distanciaMetros;
    }

    public String getSituacaoVeiculo() {
        return situacaoVeiculo;
    }

    public void setSituacaoVeiculo(String situacaoVeiculo) {
        this.situacaoVeiculo = situacaoVeiculo;
    }

    public String getDescricaoCda() {
        return descricaoCda;
    }

    public void setDescricaoCda(String descricaoCda) {
        this.descricaoCda = descricaoCda;
    }

    public String getDataUltimaCoordenadaFormatada() {
        return UtilDate.getDataComoString(getDataUltimaCoordenada(), "dd/MM/yyyy HH:mm:ss");
    }

    public void setDataUltimaCoordenadaFormatada(String dataUltimaCoordenadaFormatada) {
        this.dataUltimaCoordenadaFormatada = dataUltimaCoordenadaFormatada;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASCODE
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object o ) {

        if ( this == o ) return true;
        if ( !(o instanceof ComboioVeiculoDto) ) return false;
        ComboioVeiculoDto that = (ComboioVeiculoDto) o;
        return Objects.equals(getComboio(), that.getComboio()) &&
                Objects.equals(getVeiculo(), that.getVeiculo()) &&
                Objects.equals(getEmpresa(), that.getEmpresa());
    }

    @Override
    public int hashCode() {

        return Objects.hash(getComboio(), getVeiculo(), getEmpresa());
    }
}
