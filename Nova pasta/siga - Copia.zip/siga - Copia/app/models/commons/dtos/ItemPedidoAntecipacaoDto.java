package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

public class ItemPedidoAntecipacaoDto implements Serializable {

    private final Long pedido;
    private final Short sequencia;
    private final Long destinatario;
    private final String tipoDestinatario;
    private final String razaoSocial;
    private final Integer cidade;
    private final Integer distrito;
    private final String estado;
    private final String grupoCidade;
    private final Long idZonaRoteirizacao;
    private final String zoneId;
    private final String bloqueioRoteirizacao;
    private final String roteirizaNaSemana;
    private final Long mercadoria;
    private final Short areaSeparacaoCaixa;
    private final Short areaSeparacaoUnitario;
    private final String localSeparacaoCaixa;
    private final String localSeparacaoUnitario;
    private final Short tipoCelulaCaixa;
    private final Short tipoCelulaUnitario;
    private final Short categoriaSeparacao;
    private final Short areaSeparacaoCaixaCliente;
    private final String participaAntecCargaCaixa;
    private final String participaAntecCargaUnitario;
    private final String separaPorClienteCaixa;
    private final String separaPorClienteUnitario;
    private final Short tipoBoxAntecipacao;
    private final Integer quantidadeVendida;
    private final BigDecimal pesoItem;
    private final BigDecimal volumeItem;
    private final Short modoMapa;
    private final Integer quantidadeCaixa;
    private final Short limiteSeparacaoClienteCaixa;
    private final Short limiteSeparacaoClienteUnitario;
    private final Short limiteSeparaClientePesCaixa;
    private final Short limiteSeparaClientePesUnitario;
    private final Short areaLimiteAtingidoCaixa;
    private final Short areaLimiteAtingidoUnitario;
    private final Short areaLimiteNaoAtingidoCaixa;
    private final Short areaLimiteNaoAtingidoUnitario;
    private final Long quantidadePalete;
    private final Short limitePaleteIncompleto;
    private final Integer limitePaleteCompleto;
    private final Integer quantidadeEtiquetaEspecial;
    private final Short cda;
    private final BigDecimal latitude;
    private final BigDecimal longitude;
    private final String grupoCidadeZonaRoteirizacao;
    private final String bloqueioZonaRoteirizacao;

    public ItemPedidoAntecipacaoDto(Long pedido, Short sequencia, Long destinatario, String tipoDestinatario, String razaoSocial, Integer cidade, Integer distrito, String estado, String grupoCidade, Long idZonaRoteirizacao, String zoneId, String bloqueioRoteirizacao, String roteirizaNaSemana, Long mercadoria, Short areaSeparacaoCaixa, Short areaSeparacaoUnitario, String localSeparacaoCaixa, String localSeparacaoUnitario, Short tipoCelulaCaixa, Short tipoCelulaUnitario, Short categoriaSeparacao, Short areaSeparacaoCaixaCliente, String participaAntecCargaCaixa, String participaAntecCargaUnitario, String separaPorClienteCaixa, String separaPorClienteUnitario, Short tipoBoxAntecipacao, Integer quantidadeVendida, BigDecimal pesoItem, BigDecimal volumeItem, Short modoMapa, Integer quantidadeCaixa, Short limiteSeparacaoClienteCaixa, Short limiteSeparacaoClienteUnitario, Short limiteSeparaClientePesCaixa, Short limiteSeparaClientePesUnitario, Short areaLimiteAtingidoCaixa, Short areaLimiteAtingidoUnitario, Short areaLimiteNaoAtingidoCaixa, Short areaLimiteNaoAtingidoUnitario, Long quantidadePalete, Short limitePaleteIncompleto, Integer limitePaleteCompleto, Integer quantidadeEtiquetaEspecial, Short cda, BigDecimal latitude, BigDecimal longitude, String grupoCidadeZonaRoteirizacao, String bloqueioZonaRoteirizacao) {
        this.pedido = pedido;
        this.sequencia = sequencia;
        this.destinatario = destinatario;
        this.tipoDestinatario = tipoDestinatario;
        this.razaoSocial = razaoSocial;
        this.cidade = cidade;
        this.distrito = distrito;
        this.estado = estado;
        this.grupoCidade = grupoCidade;
        this.idZonaRoteirizacao = idZonaRoteirizacao;
        this.zoneId = zoneId;
        this.bloqueioRoteirizacao = bloqueioRoteirizacao;
        this.roteirizaNaSemana = roteirizaNaSemana;
        this.mercadoria = mercadoria;
        this.areaSeparacaoCaixa = areaSeparacaoCaixa;
        this.areaSeparacaoUnitario = areaSeparacaoUnitario;
        this.localSeparacaoCaixa = localSeparacaoCaixa;
        this.localSeparacaoUnitario = localSeparacaoUnitario;
        this.tipoCelulaCaixa = tipoCelulaCaixa;
        this.tipoCelulaUnitario = tipoCelulaUnitario;
        this.categoriaSeparacao = categoriaSeparacao;
        this.areaSeparacaoCaixaCliente = areaSeparacaoCaixaCliente;
        this.participaAntecCargaCaixa = participaAntecCargaCaixa;
        this.participaAntecCargaUnitario = participaAntecCargaUnitario;
        this.separaPorClienteCaixa = separaPorClienteCaixa;
        this.separaPorClienteUnitario = separaPorClienteUnitario;
        this.tipoBoxAntecipacao = tipoBoxAntecipacao;
        this.quantidadeVendida = quantidadeVendida;
        this.pesoItem = pesoItem;
        this.volumeItem = volumeItem;
        this.modoMapa = modoMapa;
        this.quantidadeCaixa = quantidadeCaixa;
        this.limiteSeparacaoClienteCaixa = limiteSeparacaoClienteCaixa;
        this.limiteSeparacaoClienteUnitario = limiteSeparacaoClienteUnitario;
        this.limiteSeparaClientePesCaixa = limiteSeparaClientePesCaixa;
        this.limiteSeparaClientePesUnitario = limiteSeparaClientePesUnitario;
        this.areaLimiteAtingidoCaixa = areaLimiteAtingidoCaixa;
        this.areaLimiteAtingidoUnitario = areaLimiteAtingidoUnitario;
        this.areaLimiteNaoAtingidoCaixa = areaLimiteNaoAtingidoCaixa;
        this.areaLimiteNaoAtingidoUnitario = areaLimiteNaoAtingidoUnitario;
        this.quantidadePalete = quantidadePalete;
        this.limitePaleteIncompleto = limitePaleteIncompleto;
        this.limitePaleteCompleto = limitePaleteCompleto;
        this.quantidadeEtiquetaEspecial = quantidadeEtiquetaEspecial;
        this.cda = cda;
        this.latitude = latitude;
        this.longitude = longitude;
        this.grupoCidadeZonaRoteirizacao = grupoCidadeZonaRoteirizacao;
        this.bloqueioZonaRoteirizacao = bloqueioZonaRoteirizacao;
    }

    public Long getPedido() {
        return pedido;
    }

    public Long getDestinatario() {
        return destinatario;
    }

    public String getTipoDestinatario() {
        return tipoDestinatario;
    }

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public Integer getCidade() {
        return cidade;
    }

    public Integer getDistrito() {
        return distrito;
    }

    public String getEstado() {
        return estado;
    }

    public String getGrupoCidade() {
        return grupoCidade;
    }

    public Long getIdZonaRoteirizacao() {
        return idZonaRoteirizacao;
    }

    public String getZoneId() {
        return zoneId;
    }

    public String getBloqueioRoteirizacao() {
        return bloqueioRoteirizacao;
    }

    public String getRoteirizaNaSemana() {
        return roteirizaNaSemana;
    }

    public Long getMercadoria() {
        return mercadoria;
    }

    public Short getSequencia() {
        return sequencia;
    }

    public Short getAreaSeparacaoCaixa() {
        return areaSeparacaoCaixa;
    }

    public Short getAreaSeparacaoUnitario() {
        return areaSeparacaoUnitario;
    }

    public String getLocalSeparacaoCaixa() {
        return localSeparacaoCaixa;
    }

    public String getLocalSeparacaoUnitario() {
        return localSeparacaoUnitario;
    }

    public Short getTipoCelulaCaixa() {
        return tipoCelulaCaixa;
    }

    public Short getTipoCelulaUnitario() {
        return tipoCelulaUnitario;
    }

    public Short getCategoriaSeparacao() {
        return categoriaSeparacao;
    }

    public Short getAreaSeparacaoCaixaCliente() {
        return areaSeparacaoCaixaCliente;
    }

    public String getParticipaAntecCargaCaixa() {
        return participaAntecCargaCaixa;
    }

    public String getParticipaAntecCargaUnitario() {
        return participaAntecCargaUnitario;
    }

    public String getSeparaPorClienteCaixa() {
        return separaPorClienteCaixa;
    }

    public String getSeparaPorClienteUnitario() {
        return separaPorClienteUnitario;
    }

    public Short getTipoBoxAntecipacao() {
        return tipoBoxAntecipacao;
    }

    public Integer getQuantidadeVendida() {
        return quantidadeVendida;
    }

    public BigDecimal getPesoItem() {
        return pesoItem;
    }

    public BigDecimal getVolumeItem() {
        return volumeItem;
    }

    public Short getModoMapa() {
        return modoMapa;
    }

    public Integer getQuantidadeCaixa() {
        return quantidadeCaixa;
    }

    public Short getLimiteSeparacaoClienteCaixa() {
        return limiteSeparacaoClienteCaixa;
    }

    public Short getLimiteSeparacaoClienteUnitario() {
        return limiteSeparacaoClienteUnitario;
    }

    public Short getLimiteSeparaClientePesCaixa() {
        return limiteSeparaClientePesCaixa;
    }

    public Short getLimiteSeparaClientePesUnitario() {
        return limiteSeparaClientePesUnitario;
    }

    public Short getAreaLimiteAtingidoCaixa() {
        return areaLimiteAtingidoCaixa;
    }

    public Short getAreaLimiteAtingidoUnitario() {
        return areaLimiteAtingidoUnitario;
    }

    public Short getAreaLimiteNaoAtingidoCaixa() {
        return areaLimiteNaoAtingidoCaixa;
    }

    public Short getAreaLimiteNaoAtingidoUnitario() {
        return areaLimiteNaoAtingidoUnitario;
    }

    public Long getQuantidadePalete() {
        return quantidadePalete;
    }

    public Short getLimitePaleteIncompleto() {
        return limitePaleteIncompleto;
    }

    public Integer getLimitePaleteCompleto() {
        return limitePaleteCompleto;
    }

    public Integer getQuantidadeEtiquetaEspecial() {
        return quantidadeEtiquetaEspecial;
    }

    public Short getCda() {
        return cda;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public String getGrupoCidadeZonaRoteirizacao() {
        return grupoCidadeZonaRoteirizacao;
    }

    public String getBloqueioZonaRoteirizacao() {
        return bloqueioZonaRoteirizacao;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ItemPedidoAntecipacaoDto that = (ItemPedidoAntecipacaoDto) o;
        return Objects.equals(pedido, that.pedido) &&
                Objects.equals(sequencia, that.sequencia);
    }

    @Override
    public int hashCode() {
        return Objects.hash(pedido, sequencia);
    }



}