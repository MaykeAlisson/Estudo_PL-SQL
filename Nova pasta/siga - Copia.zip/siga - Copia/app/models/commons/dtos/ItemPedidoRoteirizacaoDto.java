package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

public class ItemPedidoRoteirizacaoDto implements Serializable {

    private Long pedido;
    private Short sequencia;
    private Long destinatario;
    private Long mercadoria;
    private BigDecimal pesoItem;
    private BigDecimal volumeItem;
    private Integer quantidadeVendida;

    public ItemPedidoRoteirizacaoDto(){
    }

    public ItemPedidoRoteirizacaoDto(Long pedido, Short sequencia, Long destinatario, Long mercadoria, BigDecimal pesoItem, BigDecimal volumeItem, Integer quantidadeVendida) {
        this.pedido = pedido;
        this.sequencia = sequencia;
        this.destinatario = destinatario;
        this.mercadoria = mercadoria;
        this.pesoItem = pesoItem;
        this.volumeItem = volumeItem;
        this.quantidadeVendida = quantidadeVendida;
    }

    public Long getPedido() {
        return pedido;
    }

    public Short getSequencia() {
        return sequencia;
    }

    public Long getDestinatario() {
        return destinatario;
    }

    public BigDecimal getPesoItem() {
        return pesoItem;
    }

    public BigDecimal getVolumeItem() {
        return volumeItem;
    }

    public Integer getQuantidadeVendida() {
        return quantidadeVendida;
    }

    public Long getMercadoria() {
        return mercadoria;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ItemPedidoRoteirizacaoDto that = (ItemPedidoRoteirizacaoDto) o;
        return Objects.equals(pedido, that.pedido) &&
                Objects.equals(sequencia, that.sequencia);
    }

    @Override
    public int hashCode() {

        return Objects.hash(pedido, sequencia);
    }

    public BigDecimal calcularVolume() {
        return volumeItem.multiply(new BigDecimal(quantidadeVendida));
    }
}
