    package models.commons.dtos;



import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

    /**
     * Classe que representa informações...
     *
     * <p>Autor: Clebersilva</p>
     *
     * @since 10/06/2016
     */
    public class DiariaMotoristaDto implements Serializable {

        private Short idEmpresa;
        private long idFuncionario;
        private Date dataCompetencia;
        private BigDecimal valorDiaria;

        public DiariaMotoristaDto(Short idEmpresa, long idFuncionario, Date dataCompetencia, BigDecimal valorDiaria) {
            this.idEmpresa = idEmpresa;
            this.idFuncionario = idFuncionario;
            this.dataCompetencia = dataCompetencia;
            this.valorDiaria = valorDiaria;
        }

        public Short getIdEmpresa() {
            return idEmpresa;
        }

        public void setIdEmpresa(Short idEmpresa) {
            this.idEmpresa = idEmpresa;
        }

        public long getIdFuncionario() {
            return idFuncionario;
        }

        public void setIdFuncionario(long idFuncionario) {
            this.idFuncionario = idFuncionario;
        }

        public Date getDataCompetencia() {
            return dataCompetencia;
        }

        public void setDataCompetencia(Date dataCompetencia) {
            this.dataCompetencia = dataCompetencia;
        }

        public BigDecimal getValorDiaria() {
            return valorDiaria;
        }

        public void setValorDiaria(BigDecimal valorDiaria) {
            this.valorDiaria = valorDiaria;
        }
    }


