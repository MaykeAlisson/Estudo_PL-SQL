package models.commons.dtos;

import infra.model.Model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

/**
 * Alysson Myller
 * 27/04/2018
 */
public class DepartamentoFuncoesDto implements Serializable {

    private Long funcao;
    private String descFuncao;
    private Short idEmpresa;
    private Short filial;
    private Short departamento;
    private String descDepartamento;
    private Integer quantidadeFuncionario;

    public DepartamentoFuncoesDto(Long funcao, String descFuncao, Short idEmpresa, Short filial, Short departamento, String descDepartamento, Integer quantidadeFuncionario) {
        this.funcao = funcao;
        this.descFuncao = descFuncao;
        this.idEmpresa = idEmpresa;
        this.filial = filial;
        this.departamento = departamento;
        this.descDepartamento = descDepartamento;
        this.quantidadeFuncionario = quantidadeFuncionario;
    }

    public Long getFuncao() {
        return funcao;
    }

    public void setFuncao(Long funcao) {
        this.funcao = funcao;
    }

    public String getDescFuncao() {
        return descFuncao;
    }

    public void setDescFuncao(String descFuncao) {
        this.descFuncao = descFuncao;
    }

    public Short getIdEmpresa() {
        return idEmpresa;
    }

    public void setIdEmpresa(Short idEmpresa) {
        this.idEmpresa = idEmpresa;
    }

    public Short getFilial() {
        return filial;
    }

    public void setFilial(Short filial) {
        this.filial = filial;
    }

    public Short getDepartamento() {
        return departamento;
    }

    public void setDepartamento(Short departamento) {
        this.departamento = departamento;
    }

    public String getDescDepartamento() {
        return descDepartamento;
    }

    public void setDescDepartamento(String descDepartamento) {
        this.descDepartamento = descDepartamento;
    }

    public Integer getQuantidadeFuncionario() {
        return quantidadeFuncionario;
    }

    public void setQuantidadeFuncionario(Integer quantidadeFuncionario) {
        this.quantidadeFuncionario = quantidadeFuncionario;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DepartamentoFuncoesDto that = (DepartamentoFuncoesDto) o;
        return Objects.equals(funcao, that.funcao) &&
                Objects.equals(idEmpresa, that.idEmpresa) &&
                Objects.equals(filial, that.filial) &&
                Objects.equals(departamento, that.departamento);
    }

    @Override
    public int hashCode() {
        return Objects.hash(funcao, idEmpresa, filial, departamento);
    }

    @Override
    public String toString() {
        return "DepartamentoFuncoesDto{" +
                "funcao=" + funcao +
                ", descFuncao='" + descFuncao + '\'' +
                ", idEmpresa=" + idEmpresa +
                ", filial=" + filial +
                ", departamento=" + departamento +
                ", descDepartamento='" + descDepartamento + '\'' +
                ", quantidadeFuncionario=" + quantidadeFuncionario +
                '}';
    }
}
