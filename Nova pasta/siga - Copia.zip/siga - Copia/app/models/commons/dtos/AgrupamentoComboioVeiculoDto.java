package models.commons.dtos;

import java.io.Serializable;
import java.util.List;

/**
 * Alysson Myller
 * 26/07/2018
 */
public class AgrupamentoComboioVeiculoDto implements Serializable {

    private Long idComboio;
    private Long distanciaMetros;
    private String distanciaKm;
    private String situacaoComboioVeiculo;
    private List<ComboioVeiculoDto> veiculos;

    public Long getIdComboio() {
        return idComboio;
    }

    public void setIdComboio(Long idComboio) {
        this.idComboio = idComboio;
    }

    public String getDistanciaKm() {
        return distanciaKm;
    }

    public void setDistanciaKm(String distanciaKm) {
        this.distanciaKm = distanciaKm;
    }

    public List<ComboioVeiculoDto> getVeiculos() {
        return veiculos;
    }

    public void setVeiculos(List<ComboioVeiculoDto> veiculos) {
        this.veiculos = veiculos;
    }

    public String getSituacaoComboioVeiculo() {
        return situacaoComboioVeiculo;
    }

    public void setSituacaoComboioVeiculo(String situacaoComboioVeiculo) {
        this.situacaoComboioVeiculo = situacaoComboioVeiculo;
    }

    public Long getDistanciaMetros() {
        return distanciaMetros;
    }

    public void setDistanciaMetros(Long distanciaMetros) {
        this.distanciaMetros = distanciaMetros;
    }
}