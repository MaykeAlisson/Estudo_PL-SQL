package models.commons.dtos;

import infra.util.UtilNumero;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Classe que representa informações de volume transportado por viagem e cda
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 31/05/2016
 */
public class ComissaoRepresentanteDto implements Serializable {

    private Short idEmpresa;
    private BigDecimal cpfRepresentante;
    private BigDecimal valorComissao;
    private BigDecimal valorInss;

    public ComissaoRepresentanteDto(Short idEmpresa, BigDecimal cpfRepresentante,BigDecimal valorComissao,BigDecimal valorInss) {
        this.idEmpresa = idEmpresa;
        this.cpfRepresentante = cpfRepresentante;
        this.valorComissao = valorComissao;
        this.valorInss = valorInss;
    }

    public Short getIdEmpresa() {
        return idEmpresa;
    }

    public void setIdEmpresa(Short idEmpresa) {
        this.idEmpresa = idEmpresa;
    }

    public BigDecimal getCpfRepresentante() {
        return cpfRepresentante;
    }

    public void setCpfRepresentante(BigDecimal cpfRepresentante) {
        this.cpfRepresentante = cpfRepresentante;
    }

    public BigDecimal getValorComissao() {
        return UtilNumero.getOrElseZero(valorComissao);
    }

    public void setValorComissao(BigDecimal valorComissao) {
        this.valorComissao = valorComissao;
    }

    public BigDecimal getValorInss() {
        return UtilNumero.getOrElseZero(valorInss);
    }

    public void setValorInss(BigDecimal valorInss) {
        this.valorInss = valorInss;
    }

    public BigDecimal getValorTotalDespesa() { return UtilNumero.somar(this.getValorComissao(),this.getValorInss());}
}
