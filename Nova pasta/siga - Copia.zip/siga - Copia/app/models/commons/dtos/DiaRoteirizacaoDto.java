package models.commons.dtos;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

/**
 * Classe que representa informações sobre os dias de roteirizacao
 *
 * <p>Autor: Jander Dutra</p>
 *
 * @since 21/12/2018
 */
public class DiaRoteirizacaoDto implements Serializable {
    private final Short diaSemana;
    private final String fechaSemana;
    private final Date horaSemana;

    public DiaRoteirizacaoDto(Short diaSemana, String fechaSemana, Date horaSemana) {
        this.diaSemana = diaSemana;
        this.fechaSemana = fechaSemana;
        this.horaSemana = horaSemana;
    }

    public Short getDiaSemana() {
        return diaSemana;
    }

    public String getFechaSemana() {
        return fechaSemana;
    }

    public Date getHoraSemana() {
        return horaSemana;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DiaRoteirizacaoDto that = (DiaRoteirizacaoDto) o;
        return Objects.equals(diaSemana, that.diaSemana) &&
                Objects.equals(fechaSemana, that.fechaSemana) &&
                Objects.equals(horaSemana, that.horaSemana);
    }

    @Override
    public int hashCode() {
        return Objects.hash(diaSemana, fechaSemana, horaSemana);
    }
}
