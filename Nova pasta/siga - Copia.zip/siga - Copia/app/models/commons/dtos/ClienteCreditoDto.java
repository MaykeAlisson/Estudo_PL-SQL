package models.commons.dtos;

import models.commons.constantes.SimNao;
import models.commons.constantes.SituacaoPedido;
import models.domains.vendas.CidadeId;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static infra.util.UtilBoolean.getOrElseFalse;
import static infra.util.UtilDate.ehMaiorIgual;
import static infra.util.UtilNumero.getOrElseZero;
import static java.util.Optional.ofNullable;
import static models.domains.vendas.Cliente.DATA_INICIO_CONTA_PERDIDA;

/**
 * Representa informações do cliente p/ analise de crédito.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 29/02/2016.
 */
public class ClienteCreditoDto implements Serializable {

    private final Long idCliente;
    private final Short idEmpresa;
    private final String razaoSocial;
    private final String endereco;
    private final String nroEndereco;
    private final SimNao antecipado;
    private final Date dataImplantacao;
    private final LocalDateTime dataAbertura;
    private final BigDecimal limiteManual;
    private final LocalDate validadeLimiteManual;
    private final Short idOcorrenciaCredito;
    private final String descricaoOcorCredito;
    private final String descricaoOcorCadastro;
    private final SituacaoPedido situacaoPedidoOcorrencia;
    private final SituacaoPedido situacaoPedidoRamoAtividade;
    private final SimNao participaAnaliseCredito;
    private final SimNao analiseCreditoDiferenciada;
    private final Date dataReativacao;
    private final Date dataLimiteReativacao;
    private final CidadeId cidadeId;
    private final Short idCidade;
    private final Short idDistrito;
    private final Short percAcrescLimiteCreditoCidade;
    private final Short percAcrescLimiteCreditoToleranciaCidade;
    private final boolean permiteAcrescimoCidade;
    private final Optional<Long> idRede;
    private final Optional<SimNao> agrupaAnaliseCredito;
    private final Integer qtdeLojas;
    private final List<Long> idClientes;
    private final boolean checarContaPerdida;

    private ClienteCreditoDto( models.commons.dtos.ClienteCreditoDto.Builder builder ) {

        this.idCliente = builder.idCliente;
        this.idEmpresa = builder.idEmpresa;
        this.razaoSocial = builder.razaoSocial;
        this.endereco = builder.endereco;
        this.nroEndereco = builder.nroEndereco;
        this.antecipado = builder.antecipado;
        this.dataImplantacao = builder.dataImplantacao;
        this.dataAbertura = builder.dataAbertura;
        this.limiteManual = builder.limiteManual;
        this.validadeLimiteManual = builder.validadeLimiteManual;
        this.idOcorrenciaCredito = builder.idOcorrenciaCredito;
        this.descricaoOcorCredito = builder.descricaoOcorCredito;
        this.descricaoOcorCadastro = builder.descricaoOcorCadastro;
        this.situacaoPedidoOcorrencia = builder.situacaoPedidoOcorrencia;
        this.situacaoPedidoRamoAtividade = builder.situacaoPedidoRamoAtividade;
        this.participaAnaliseCredito = builder.participaAnaliseCredito;
        this.analiseCreditoDiferenciada = builder.analiseCreditoDiferenciada;
        this.dataReativacao = builder.dataReativacao;
        this.dataLimiteReativacao = builder.dataLimiteReativacao;
        this.cidadeId = builder.cidadeId;
        this.idCidade = builder.cidadeId != null ? builder.cidadeId.getIdCidade() : null;
        this.idDistrito = builder.cidadeId != null ? builder.cidadeId.getIdDistrito() : null;
        this.idRede = builder.idRede;
        this.agrupaAnaliseCredito = builder.agrupaAnaliseCredito;
        this.qtdeLojas = builder.qtdeLojas;
        this.idClientes = builder.idClientes;
        this.checarContaPerdida = ehMaiorIgual( this.dataImplantacao, DATA_INICIO_CONTA_PERDIDA );
        this.percAcrescLimiteCreditoCidade = getOrElseZero( builder.percAcrescLimiteCreditoCidade, Short.class );
        this.percAcrescLimiteCreditoToleranciaCidade = getOrElseZero( builder.percAcrescLimiteCreditoToleranciaCidade, Short.class );
        this.permiteAcrescimoCidade = getOrElseFalse( builder.permiteAcrescimoCidade );
    }

    public static class Builder {

        private Long idCliente;
        private Short idEmpresa;
        private String razaoSocial;
        private String endereco;
        private String nroEndereco;
        private SimNao antecipado;
        private Date dataImplantacao;
        private LocalDateTime dataAbertura;
        private BigDecimal limiteManual;
        private LocalDate validadeLimiteManual;
        private Short idOcorrenciaCredito;
        private String descricaoOcorCredito;
        private String descricaoOcorCadastro;
        private SituacaoPedido situacaoPedidoOcorrencia;
        private SituacaoPedido situacaoPedidoRamoAtividade;
        private SimNao participaAnaliseCredito;
        private SimNao analiseCreditoDiferenciada;
        private Date dataReativacao;
        private Date dataLimiteReativacao;
        private CidadeId cidadeId;
        private Short percAcrescLimiteCreditoCidade;
        private Short percAcrescLimiteCreditoToleranciaCidade;
        private boolean permiteAcrescimoCidade;
        private Optional<Long> idRede;
        private Optional<SimNao> agrupaAnaliseCredito;
        private Integer qtdeLojas;
        private List<Long> idClientes;


        public Builder( final Short idEmpresa,
                        final Long idCliente ) {

            this.idEmpresa = idEmpresa;
            this.idCliente = idCliente;
        }

        public Builder comRazaoSocial( final String razaoSocial ) {

            this.razaoSocial = razaoSocial;
            return this;
        }

        public Builder comEndereco( final String endereco ) {

            this.endereco = endereco;
            return this;
        }

        public Builder comNroEndereco( final String nroEndereco ) {

            this.nroEndereco = nroEndereco;
            return this;
        }

        public Builder comAntecipado( final SimNao antecipado ) {

            this.antecipado = antecipado;
            return this;
        }

        public Builder comDataImplantacao( final Date dataImplantacao ) {

            this.dataImplantacao = dataImplantacao;
            return this;
        }

        public Builder comDataAbertura( final LocalDateTime dataAbertura ) {

            this.dataAbertura = dataAbertura;
            return this;
        }

        public Builder comLimiteManual( final BigDecimal limiteManual ) {

            this.limiteManual = limiteManual;
            return this;
        }

        public Builder comValidadeLimiteManual( final LocalDate validadeLimiteManual ) {

            this.validadeLimiteManual = validadeLimiteManual;
            return this;
        }

        public Builder comIdOcorrenciaCredito( final Short idOcorrenciaCredito ) {

            this.idOcorrenciaCredito = idOcorrenciaCredito;
            return this;
        }

        public Builder comDescricaoOcorCredito( final String descricaoOcorCredito ) {

            this.descricaoOcorCredito = descricaoOcorCredito;
            return this;
        }

        public Builder comDescricaoOcorCadastro( final String descricaoOcorCadastro ) {

            this.descricaoOcorCadastro = descricaoOcorCadastro;
            return this;
        }

        public Builder comSituacaoPedidoOcorrencia( final SituacaoPedido situacaoPedidoOcorrencia ) {

            this.situacaoPedidoOcorrencia = situacaoPedidoOcorrencia;
            return this;
        }

        public Builder comSituacaoPedidoRamoAtividade( final SituacaoPedido situacaoPedidoRamoAtividade ) {

            this.situacaoPedidoRamoAtividade = situacaoPedidoRamoAtividade;
            return this;
        }

        public Builder comParticipaAnaliseCredito( final SimNao participaAnaliseCredito ) {

            this.participaAnaliseCredito = participaAnaliseCredito;
            return this;
        }

        public Builder comAnaliseCreditoDiferenciada( final SimNao analiseCreditoDiferenciada ) {

            this.analiseCreditoDiferenciada = analiseCreditoDiferenciada;
            return this;
        }

        public Builder comDataReativacao( final Date dataReativacao ) {

            this.dataReativacao = dataReativacao;
            return this;
        }

        public Builder comDataLimiteReativacao( final Date dataLimiteReativacao ) {

            this.dataLimiteReativacao = dataLimiteReativacao;
            return this;
        }

        public Builder comCidadeId( final CidadeId cidadeId ) {

            this.cidadeId = cidadeId;
            return this;
        }

        public Builder comPermiteAcrescimoCidade( final Boolean permiteAcrescimoCidade ) {

            this.permiteAcrescimoCidade = permiteAcrescimoCidade;
            return this;
        }

        public Builder comPercAcrescLimiteCreditoCidade( final Short percAcrescLimiteCreditoCidade ) {

            this.percAcrescLimiteCreditoCidade = percAcrescLimiteCreditoCidade;
            return this;
        }

        public Builder comPercAcrescLimiteCreditoToleranciaCidade( final Short percAcrescLimiteCreditoToleranciaCidade ) {

            this.percAcrescLimiteCreditoToleranciaCidade = percAcrescLimiteCreditoToleranciaCidade;
            return this;
        }

        public Builder comIdClientes( final List<Long> idClientes ) {

            this.idClientes = idClientes;
            this.qtdeLojas = idClientes.size();
            return this;
        }

        public Builder comIdRede( final Long idRede,
                                  final SimNao agrupaAnaliseCredito ) {

            this.idRede = ofNullable( idRede );
            this.agrupaAnaliseCredito = ofNullable( agrupaAnaliseCredito );
            return this;
        }


        public ClienteCreditoDto builder() {

            return new ClienteCreditoDto( this );
        }

    }

    public Long getIdCliente() {

        return idCliente;
    }

    public Short getIdEmpresa() {

        return idEmpresa;
    }

    public String getRazaoSocial() {

        return razaoSocial;
    }

    public String getEndereco() {

        return endereco;
    }

    public String getNroEndereco() {

        return nroEndereco;
    }

    public boolean isChecarContaPerdida() {

        return checarContaPerdida;
    }

    public SimNao getAntecipado() {

        return antecipado;
    }

    public Date getDataImplantacao() {

        return dataImplantacao;
    }

    public LocalDateTime getDataAbertura() {

        return dataAbertura;
    }

    public BigDecimal getLimiteManual() {

        return limiteManual;
    }

    public LocalDate getValidadeLimiteManual() {

        return validadeLimiteManual;
    }

    public Short getIdOcorrenciaCredito() {

        return idOcorrenciaCredito;
    }

    public String getDescricaoOcorCredito() {

        return descricaoOcorCredito;
    }

    public String getDescricaoOcorCadastro() {

        return descricaoOcorCadastro;
    }

    public SituacaoPedido getSituacaoPedidoOcorrencia() {

        return situacaoPedidoOcorrencia;
    }

    public SituacaoPedido getSituacaoPedidoRamoAtividade() {

        return situacaoPedidoRamoAtividade;
    }

    public SimNao getParticipaAnaliseCredito() {

        return participaAnaliseCredito;
    }

    public SimNao getAnaliseCreditoDiferenciada() {

        return analiseCreditoDiferenciada;
    }

    public Date getDataReativacao() {

        return dataReativacao;
    }

    public Date getDataLimiteReativacao() {

        return dataLimiteReativacao;
    }

    public CidadeId getCidadeId() {

        return cidadeId;
    }

    public Short getIdCidade() {

        return idCidade;
    }

    public Short getIdDistrito() {

        return idDistrito;
    }

    public Short getPercAcrescLimiteCreditoCidade() {

        return percAcrescLimiteCreditoCidade;
    }

    public Short getPercAcrescLimiteCreditoToleranciaCidade() {

        return percAcrescLimiteCreditoToleranciaCidade;
    }

    public boolean isPermiteAcrescimoCidade() {

        return permiteAcrescimoCidade;
    }

    public Integer getQtdeLojas() {

        return qtdeLojas;
    }

    public List<Long> getIdClientes() {

        return idClientes;
    }

    public Optional<Long> getIdRede() {

        return idRede;
    }

    public Optional<SimNao> getAgrupaAnaliseCredito() {

        return agrupaAnaliseCredito;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    @Override
    public boolean equals( Object o ) {

        if ( this == o ) return true;
        if ( !(o instanceof ClienteCreditoDto) ) return false;
        ClienteCreditoDto that = (ClienteCreditoDto) o;
        return Objects.equals(getIdCliente(), that.getIdCliente()) &&
                Objects.equals(getIdEmpresa(), that.getIdEmpresa());
    }

    @Override
    public int hashCode() {

        return Objects.hash(getIdCliente(), getIdEmpresa());
    }

    @Override
    public String toString() {

        return "ClienteCreditoDto{ idCliente=" + idCliente + ", idEmpresa=" + idEmpresa + '}';
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
