package models.commons.dtos;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

import static infra.util.UtilCollections.isVazia;
import static java.util.Comparator.comparing;

/**
 * Classe que representa informações...
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 02/04/2018
 */
public class CleberLinhaSeparadaTarefaDto implements Serializable {

    private Long idLoteEnvioTarefa;
    private Long idVocollectTarefa;
    private Long qtdRecipiente;
    private Long qtdLinha;
    private Long qtdPick00;
    private Long qtdPick01;
    private Long qtdPick02;
    private Long qtdPick03;
    private Long qtdPick04;
    private Long qtdPick05;
    private Long qtdPick06;
    private Long qtdPick07;
    private Long qtdPick08;
    private Long qtdPick09;
    private Long qtdPick10;
    private Long qtdPick11;
    private Long qtdPick12;
    private Long qtdPick13;
    private Long qtdPick14;
    private Long qtdPick15;

    public Long getIdLoteEnvioTarefa() {
        return idLoteEnvioTarefa;
    }

    public void setIdLoteEnvioTarefa(Long idLoteEnvioTarefa) {
        this.idLoteEnvioTarefa = idLoteEnvioTarefa;
    }

    public Long getIdVocollectTarefa() {

        return this.idVocollectTarefa;
    }

    public void setIdVocollectTarefa( final Long idVocollectTarefa ) {

        this.idVocollectTarefa = idVocollectTarefa;
    }

    public Long getQtdRecipiente() {

        return this.qtdRecipiente;
    }

    public void setQtdRecipiente( final Long qtdRecipiente ) {

        this.qtdRecipiente = qtdRecipiente;
    }

    public Long getQtdLinha() {

        return this.qtdLinha;
    }

    public void setQtdLinha( final Long qtdLinha ) {

        this.qtdLinha = qtdLinha;
    }

    public Long getQtdPick00() {

        return this.qtdPick00;
    }

    public void setQtdPick00( final Long qtdPick00 ) {

        this.qtdPick00 = qtdPick00;
    }

    public Long getQtdPick01() {

        return this.qtdPick01;
    }

    public void setQtdPick01( final Long qtdPick01 ) {

        this.qtdPick01 = qtdPick01;
    }

    public Long getQtdPick02() {

        return this.qtdPick02;
    }

    public void setQtdPick02( final Long qtdPick02 ) {

        this.qtdPick02 = qtdPick02;
    }

    public Long getQtdPick03() {

        return this.qtdPick03;
    }

    public void setQtdPick03( final Long qtdPick03 ) {

        this.qtdPick03 = qtdPick03;
    }

    public Long getQtdPick04() {

        return this.qtdPick04;
    }

    public void setQtdPick04( final Long qtdPick04 ) {

        this.qtdPick04 = qtdPick04;
    }

    public Long getQtdPick05() {

        return this.qtdPick05;
    }

    public void setQtdPick05( final Long qtdPick05 ) {

        this.qtdPick05 = qtdPick05;
    }

    public Long getQtdPick06() {

        return this.qtdPick06;
    }

    public void setQtdPick06( final Long qtdPick06 ) {

        this.qtdPick06 = qtdPick06;
    }

    public Long getQtdPick07() {

        return this.qtdPick07;
    }

    public void setQtdPick07( final Long qtdPick07 ) {

        this.qtdPick07 = qtdPick07;
    }

    public Long getQtdPick08() {

        return this.qtdPick08;
    }

    public void setQtdPick08( final Long qtdPick08 ) {

        this.qtdPick08 = qtdPick08;
    }

    public Long getQtdPick09() {

        return this.qtdPick09;
    }

    public void setQtdPick09( final Long qtdPick09 ) {

        this.qtdPick09 = qtdPick09;
    }

    public Long getQtdPick10() {

        return this.qtdPick10;
    }

    public void setQtdPick10( final Long qtdPick10 ) {

        this.qtdPick10 = qtdPick10;
    }

    public Long getQtdPick11() {

        return this.qtdPick11;
    }

    public void setQtdPick11( final Long qtdPick11 ) {

        this.qtdPick11 = qtdPick11;
    }

    public Long getQtdPick12() {

        return this.qtdPick12;
    }

    public void setQtdPick12( final Long qtdPick12 ) {

        this.qtdPick12 = qtdPick12;
    }

    public Long getQtdPick13() {

        return this.qtdPick13;
    }

    public void setQtdPick13( final Long qtdPick13 ) {

        this.qtdPick13 = qtdPick13;
    }

    public Long getQtdPick14() {

        return this.qtdPick14;
    }

    public void setQtdPick14( final Long qtdPick14 ) {

        this.qtdPick14 = qtdPick14;
    }

    public Long getQtdPick15() {

        return this.qtdPick15;
    }

    public void setQtdPick15( final Long qtdPick15 ) {

        this.qtdPick15 = qtdPick15;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASCODE
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CleberLinhaSeparadaTarefaDto)) return false;
        CleberLinhaSeparadaTarefaDto that = (CleberLinhaSeparadaTarefaDto) o;
        return Objects.equals(getIdLoteEnvioTarefa(), that.getIdLoteEnvioTarefa()) &&
                Objects.equals(getIdVocollectTarefa(), that.getIdVocollectTarefa());
    }

    @Override
    public int hashCode() {

        return Objects.hash(getIdVocollectTarefa(), getQtdRecipiente(), getQtdLinha(), getQtdPick00(), getQtdPick01(), getQtdPick02(), getQtdPick03(), getQtdPick04(), getQtdPick05(), getQtdPick06(), getQtdPick07(), getQtdPick08(), getQtdPick09(), getQtdPick10(), getQtdPick11(), getQtdPick12(), getQtdPick13(), getQtdPick14(), getQtdPick15());
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public static void sortPorLoteTarefa(List<CleberLinhaSeparadaTarefaDto> lista) {

        if (!isVazia(lista) )
            lista.sort( comparing( CleberLinhaSeparadaTarefaDto::getIdVocollectTarefa ) );
    }

}
