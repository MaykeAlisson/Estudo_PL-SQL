package models.commons.dtos;

import java.io.Serializable;
import java.util.Objects;

public class DestinatarioInconsistenteRoteirizacaoDto implements Serializable {

    private final Long destinatario;
    private final Short empresa;
    private final Long idZonaRoteirizacao;
    private final String grupoCidadeDestinatario;
    private final String grupoCidadeZonaRoteirizacao;

    public DestinatarioInconsistenteRoteirizacaoDto(Long destinatario, Short empresa, Long idZonaRoteirizacao, String grupoCidadeDestinatario, String grupoCidadeZonaRoteirizacao) {
        this.destinatario = destinatario;
        this.empresa = empresa;
        this.idZonaRoteirizacao = idZonaRoteirizacao;
        this.grupoCidadeDestinatario = grupoCidadeDestinatario;
        this.grupoCidadeZonaRoteirizacao = grupoCidadeZonaRoteirizacao;
    }

    public Long getDestinatario() {
        return destinatario;
    }

    public Short getEmpresa() {
        return empresa;
    }

    public Long getIdZonaRoteirizacao() {
        return idZonaRoteirizacao;
    }

    public String getGrupoCidadeDestinatario() {
        return grupoCidadeDestinatario;
    }

    public String getGrupoCidadeZonaRoteirizacao() {
        return grupoCidadeZonaRoteirizacao;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DestinatarioInconsistenteRoteirizacaoDto that = (DestinatarioInconsistenteRoteirizacaoDto) o;
        return Objects.equals(destinatario, that.destinatario) &&
                Objects.equals(empresa, that.empresa);
    }

    @Override
    public int hashCode() {

        return Objects.hash(destinatario, empresa);
    }
}
