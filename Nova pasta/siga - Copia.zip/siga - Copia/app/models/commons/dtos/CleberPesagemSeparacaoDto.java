package models.commons.dtos;

import java.io.Serializable;
import java.util.Objects;

public class CleberPesagemSeparacaoDto  implements Serializable{

    private String numeroVoco;
    private Long quantidadePesagem;
    private Long quantidadeBalanca;

    public CleberPesagemSeparacaoDto(String numeroVoco, Long quantidadePesagem, Long quantidadeBalanca) {
        this.numeroVoco = numeroVoco;
        this.quantidadePesagem = quantidadePesagem;
        this.quantidadeBalanca = quantidadeBalanca;
    }

    public String getNumeroVoco() {
        return numeroVoco;
    }

    public void setNumeroVoco(String numeroVoco) {
        this.numeroVoco = numeroVoco;
    }

    public Long getQuantidadePesagem() {
        return quantidadePesagem;
    }

    public void setQuantidadePesagem(Long quantidadePesagem) {
        this.quantidadePesagem = quantidadePesagem;
    }

    public Long getQuantidadeBalanca() {
        return quantidadeBalanca;
    }

    public void setQuantidadeBalanca(Long quantidadeBalanca) {
        this.quantidadeBalanca = quantidadeBalanca;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CleberPesagemSeparacaoDto)) return false;
        CleberPesagemSeparacaoDto that = (CleberPesagemSeparacaoDto) o;
        return Objects.equals(getNumeroVoco(), that.getNumeroVoco()) &&
                Objects.equals(getQuantidadePesagem(), that.getQuantidadePesagem()) &&
                Objects.equals(getQuantidadeBalanca(), that.getQuantidadeBalanca());
    }

    @Override
    public int hashCode() {

        return Objects.hash(getNumeroVoco(), getQuantidadePesagem(), getQuantidadeBalanca());
    }

    @Override
    public String toString() {
        return "CleberPesagemSeparacaoDto{" +
                "numeroVoco='" + numeroVoco + '\'' +
                ", quantidadePesagem=" + quantidadePesagem +
                ", quantidadeBalanca=" + quantidadeBalanca +
                '}';
    }
}
