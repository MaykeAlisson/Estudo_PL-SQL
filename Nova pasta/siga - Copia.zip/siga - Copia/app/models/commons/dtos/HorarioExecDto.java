package models.commons.dtos;

import models.commons.constantes.ESocialConstantes;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Classe que representa informaþ§es...
 *
 * <p>Autor: Tiagopti</p>
 *
 * @since 18/10/2017
 */
public class HorarioExecDto implements Serializable {

    private Date dataEvento;

    public String getDataEvento() {
        String retorno = new SimpleDateFormat(ESocialConstantes.DD_MM_YYYY_HHMMSS).format(dataEvento);
        return retorno;
    }

    public void setDataEvento(Date dataEvento) {
        this.dataEvento = dataEvento;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof HorarioExecDto)) return false;

        HorarioExecDto that = (HorarioExecDto) o;

        return getDataEvento() != null ? getDataEvento().equals(that.getDataEvento()) : that.getDataEvento() == null;
    }

    @Override
    public int hashCode() {
        return getDataEvento() != null ? getDataEvento().hashCode() : 0;
    }
}