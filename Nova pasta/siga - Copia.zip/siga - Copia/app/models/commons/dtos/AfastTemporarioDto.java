package models.commons.dtos;

import infra.model.Model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

/**
 * Classe que representa informaþ§es...
 *
 * <p>Autor: Tiagopti</p>
 *
 * @since 09/01/2017
 */
public class AfastTemporarioDto extends Model implements Serializable {

    private Short idEmpresa;
    private Long idFuncionario;
    private String comVinculo;
    private BigDecimal cpf;
    private BigDecimal pisPasep;
    private Short categoriaTrabalhador;
    private Date dataAfastInicio;
    private Date dataAfastFim;
    private Long qtdDiasAfast;
    private Short motivoESocial;
    private String motivoSIA;
    private String infoMesmoMotivo;
    private String codCID;
    private String nomeEmitenteAtestado;
    private Short ideOCEmitenteAtestado;
    private BigDecimal nroOCEmitenteAtestado;
    private String ufOCEmitenteAtestado;
    private String observacao;
    private Date dataTransferencia;

    public Short getIdEmpresa() {
        return idEmpresa;
    }

    public void setIdEmpresa(Short idEmpresa) {
        this.idEmpresa = idEmpresa;
    }

    public Long getIdFuncionario() {
        return idFuncionario;
    }

    public void setIdFuncionario(Long idFuncionario) {
        this.idFuncionario = idFuncionario;
    }

    public String getComVinculo() {
        return comVinculo;
    }

    public void setComVinculo(String comVinculo) {
        this.comVinculo = comVinculo;
    }

    public BigDecimal getCpf() {
        return cpf;
    }

    public void setCpf(BigDecimal cpf) {
        this.cpf = cpf;
    }

    public BigDecimal getPisPasep() {
        return pisPasep;
    }

    public void setPisPasep(BigDecimal pisPasep) {
        this.pisPasep = pisPasep;
    }

    public Short getCategoriaTrabalhador() {
        return categoriaTrabalhador;
    }

    public void setCategoriaTrabalhador(Short categoriaTrabalhador) {
        this.categoriaTrabalhador = categoriaTrabalhador;
    }

    public Date getDataAfastInicio() {
        return dataAfastInicio;
    }

    public void setDataAfastInicio(Date dataAfastInicio) {
        this.dataAfastInicio = dataAfastInicio;
    }

    public Date getDataAfastFim() {
        return dataAfastFim;
    }

    public void setDataAfastFim(Date dataAfastFim) {
        this.dataAfastFim = dataAfastFim;
    }

    public Long getQtdDiasAfast() {
        return qtdDiasAfast;
    }

    public void setQtdDiasAfast(Long qtdDiasAfast) {
        this.qtdDiasAfast = qtdDiasAfast;
    }

    public Short getMotivoESocial() {
        return motivoESocial;
    }

    public void setMotivoESocial(Short motivoESocial) {
        this.motivoESocial = motivoESocial;
    }

    public String getMotivoSIA() {
        return motivoSIA;
    }

    public void setMotivoSIA(String motivoSIA) {
        this.motivoSIA = motivoSIA;
    }

    public String getInfoMesmoMotivo() {
        return infoMesmoMotivo;
    }

    public void setInfoMesmoMotivo(String infoMesmoMotivo) {
        this.infoMesmoMotivo = infoMesmoMotivo;
    }

    public String getCodCID() {
        return codCID;
    }

    public void setCodCID(String codCID) {
        this.codCID = codCID;
    }

    public String getNomeEmitenteAtestado() {
        return nomeEmitenteAtestado;
    }

    public void setNomeEmitenteAtestado(String nomeEmitenteAtestado) {
        this.nomeEmitenteAtestado = nomeEmitenteAtestado;
    }

    public Short getIdeOCEmitenteAtestado() {
        return ideOCEmitenteAtestado;
    }

    public void setIdeOCEmitenteAtestado(Short ideOCEmitenteAtestado) {
        this.ideOCEmitenteAtestado = ideOCEmitenteAtestado;
    }

    public BigDecimal getNroOCEmitenteAtestado() {
        return nroOCEmitenteAtestado;
    }

    public void setNroOCEmitenteAtestado(BigDecimal nroOCEmitenteAtestado) {
        this.nroOCEmitenteAtestado = nroOCEmitenteAtestado;
    }

    public String getUfOCEmitenteAtestado() {
        return ufOCEmitenteAtestado;
    }

    public void setUfOCEmitenteAtestado(String ufOCEmitenteAtestado) {
        this.ufOCEmitenteAtestado = ufOCEmitenteAtestado;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public Date getDataTransferencia() {
        return dataTransferencia;
    }

    public void setDataTransferencia(Date dataTransferencia) {
        this.dataTransferencia = dataTransferencia;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASCODE
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AfastTemporarioDto)) return false;
        AfastTemporarioDto that = (AfastTemporarioDto) o;
        return Objects.equals(getIdEmpresa(), that.getIdEmpresa()) &&
                Objects.equals(getIdFuncionario(), that.getIdFuncionario()) &&
                Objects.equals(getComVinculo(), that.getComVinculo()) &&
                Objects.equals(getCpf(), that.getCpf()) &&
                Objects.equals(getPisPasep(), that.getPisPasep()) &&
                Objects.equals(getCategoriaTrabalhador(), that.getCategoriaTrabalhador()) &&
                Objects.equals(getDataAfastInicio(), that.getDataAfastInicio()) &&
                Objects.equals(getDataAfastFim(), that.getDataAfastFim()) &&
                Objects.equals(getQtdDiasAfast(), that.getQtdDiasAfast()) &&
                Objects.equals(getMotivoESocial(), that.getMotivoESocial()) &&
                Objects.equals(getMotivoSIA(), that.getMotivoSIA()) &&
                Objects.equals(getInfoMesmoMotivo(), that.getInfoMesmoMotivo()) &&
                Objects.equals(getCodCID(), that.getCodCID()) &&
                Objects.equals(getNomeEmitenteAtestado(), that.getNomeEmitenteAtestado()) &&
                Objects.equals(getIdeOCEmitenteAtestado(), that.getIdeOCEmitenteAtestado()) &&
                Objects.equals(getNroOCEmitenteAtestado(), that.getNroOCEmitenteAtestado()) &&
                Objects.equals(getUfOCEmitenteAtestado(), that.getUfOCEmitenteAtestado()) &&
                Objects.equals(getObservacao(), that.getObservacao()) &&
                Objects.equals(getDataTransferencia(), that.getDataTransferencia());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdEmpresa(), getIdFuncionario(), getComVinculo(), getCpf(), getPisPasep(), getCategoriaTrabalhador(), getDataAfastInicio(), getDataAfastFim(), getQtdDiasAfast(), getMotivoESocial(), getMotivoSIA(), getInfoMesmoMotivo(), getCodCID(), getNomeEmitenteAtestado(), getIdeOCEmitenteAtestado(), getNroOCEmitenteAtestado(), getUfOCEmitenteAtestado(), getObservacao(), getDataTransferencia());
    }
}