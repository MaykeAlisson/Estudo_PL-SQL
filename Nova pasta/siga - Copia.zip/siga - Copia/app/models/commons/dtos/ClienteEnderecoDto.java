package models.commons.dtos;

import infra.util.UtilNumero;
import models.domains.vendas.CidadeId;
import models.domains.vendas.Cliente;

import java.io.Serializable;

import static infra.util.UtilString.apenasNumero;
import static infra.util.UtilString.ehIgual;

/**
 * Classe que representa informações simples do endereço do cliente.
 *
 * <p>Autor: GPortes</p>
 *
 * @since  17/02/2015.
 */
public class ClienteEnderecoDto implements Serializable {

    private final Short idEmpresa;
    private final Long idCliente;
    private final String endereco;
    private final String nro;
    private final Short idCidade;

    public ClienteEnderecoDto( final Short idEmpresa,
                               final Long idCliente,
                               final String endereco,
                               final String nro,
                               final Short idCidade ) {

        this.idEmpresa = idEmpresa;
        this.idCliente = idCliente;
        this.endereco = endereco;
        this.nro = nro;
        this.idCidade = idCidade;
    }

    public ClienteEnderecoDto( final Short idEmpresa,
                               final Long idCliente,
                               final String endereco,
                               final String nro,
                               final CidadeId idCidade ) {

        this( idEmpresa, idCliente, endereco, nro, idCidade != null ? idCidade.getIdCidade() : null );
    }


    public Short getIdEmpresa() {
        return idEmpresa;
    }

    public Long getIdCliente() {
        return idCliente;
    }

    public String getEndereco() {
        return endereco;
    }

    public String getNro() {
        return nro;
    }

    public Short getIdCidade() {
        return idCidade;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ClienteEnderecoDto)) return false;

        ClienteEnderecoDto that = (ClienteEnderecoDto) o;

        if (idCliente != null ? !idCliente.equals(that.idCliente) : that.idCliente != null) return false;
        if (idEmpresa != null ? !idEmpresa.equals(that.idEmpresa) : that.idEmpresa != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = idEmpresa != null ? idEmpresa.hashCode() : 0;
        result = 31 * result + (idCliente != null ? idCliente.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ClienteEnderecoDto{" +
                "idEmpresa=" + idEmpresa +
                ", idCliente=" + idCliente +
                ", endereco='" + endereco + '\'' +
                ", nro='" + nro + '\'' +
                ", idCidade=" + idCidade +
                '}';
    }

    /**
     * Critério de comparação de endereços para clientes com <b>conta perdida</b>.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dto1 Endereço do cliente
     * @param dto2 Endereço do cliente
     *
     * @return boolean - true se são equivalentes e false o contrário.
     */
    public static boolean ehMesmoEndereco( final ClienteEnderecoDto dto1,
                                           final ClienteEnderecoDto dto2 ) {

        if ( ( dto1 == null && dto2 != null ) || ( dto1 != null && dto2 == null ) )
            return false;

        // 1. Cidade
        if ( ! UtilNumero.ehIgual( dto1.getIdCidade(), dto2.getIdCidade() ) )
            return false;

        // 2. Logradouro e endereço.
        if ( ! ehIgual( dto1.getEndereco(), dto2.getEndereco() ) )
            return false;

        // 3. Nro do endereço com margem de erro de 10 posições acima e abaixo.
        if ( apenasNumero( dto1.getNro()) && apenasNumero(dto2.getNro()) )
            return UtilNumero.ehIgual( Long.valueOf( dto1.getNro() ), Long.valueOf( dto2.getNro() ), Cliente.MARGEM_CONSIDERAR_NRO_ENDERECO_CONTA_PERDIDA );

        // 4. Nro do endereço é alfanumerico.
        return ehIgual( dto1.getNro(), dto2.getNro() );

    }

}
