package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Classe que representa informações...
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 22/05/2019
 */
public class LancamentoContabilTransportesDto implements Serializable {


    private final Short empresa;
    private final String lanctoContabil;
    private final BigDecimal vlrContabil;
    private final BigDecimal vlrDiversaAcerto;
    private final BigDecimal vlrDiversaCaixa;
    private final BigDecimal vlrNotaEntrada;


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CONSTRUCTOR
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public LancamentoContabilTransportesDto(
            final Short empresa,
            final String lanctoContabil,
            final BigDecimal vlrContabil,
            final BigDecimal vlrDiversaAcerto,
            final BigDecimal vlrDiversaCaixa,
            final BigDecimal vlrNotaEntrada
    ) {

        this.empresa = empresa;
        this.lanctoContabil = lanctoContabil;
        this.vlrContabil = vlrContabil;
        this.vlrDiversaAcerto = vlrDiversaAcerto;
        this.vlrDiversaCaixa = vlrDiversaCaixa;
        this.vlrNotaEntrada = vlrNotaEntrada;
    }

    @JsonProperty( "empresa" )
    public Short getEmpresa() {

        return this.empresa;
    }

    @JsonProperty( "lanctoContabil" )
    public String getLanctoContabil() {

        return this.lanctoContabil;
    }

    @JsonProperty( "vlrContabil" )
    public BigDecimal getVlrContabil() {

        return this.vlrContabil;
    }

    @JsonProperty( "vlrDiversaAcerto" )
    public BigDecimal getVlrDiversaAcerto() {

        return this.vlrDiversaAcerto;
    }

    @JsonProperty( "vlrDiversaCaixa" )
    public BigDecimal getVlrDiversaCaixa() {

        return this.vlrDiversaCaixa;
    }

    @JsonProperty( "vlrNotaEntrada" )
    public BigDecimal getVlrNotaEntrada() {

        return this.vlrNotaEntrada;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof LancamentoContabilTransportesDto)) return false;
        LancamentoContabilTransportesDto that = (LancamentoContabilTransportesDto) o;
        return Objects.equals(getEmpresa(), that.getEmpresa()) &&
                Objects.equals(getLanctoContabil(), that.getLanctoContabil()) &&
                Objects.equals(getVlrContabil(), that.getVlrContabil()) &&
                Objects.equals(getVlrDiversaAcerto(), that.getVlrDiversaAcerto()) &&
                Objects.equals(getVlrDiversaCaixa(), that.getVlrDiversaCaixa()) &&
                Objects.equals(getVlrNotaEntrada(), that.getVlrNotaEntrada());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getEmpresa(), getLanctoContabil(), getVlrContabil(), getVlrDiversaAcerto(), getVlrDiversaCaixa(), getVlrNotaEntrada());
    }

    @Override
    public String toString() {
        return "LancamentoContabilTransportesDto{" +
                "empresa=" + empresa +
                ", lanctoContabil='" + lanctoContabil + '\'' +
                ", vlrContabil=" + vlrContabil +
                ", vlrDiversaAcerto=" + vlrDiversaAcerto +
                ", vlrDiversaCaixa=" + vlrDiversaCaixa +
                ", vlrNotaEntrada=" + vlrNotaEntrada +
                '}';
    }
}

