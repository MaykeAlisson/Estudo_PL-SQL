package models.commons.dtos;

import java.io.Serializable;
import java.util.Date;

/**
 * Representa informações de clientes faturados em algum periodo.
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 06/09/2017
 */
public class ClienteFaturaPeriodoDto implements Serializable {

    private final Long idCliente;
    private final Date dataEmissao;
    private final Date dataLeitura;

    public ClienteFaturaPeriodoDto(final Long idCliente,
                                   final Date dataEmissao,
                                   final Date dataLeitura ) {

        this.idCliente = idCliente;
        this.dataEmissao = dataEmissao;
        this.dataLeitura = dataLeitura;
    }

    public Long getIdCliente() {

        return idCliente;
    }

    public Date getDataEmissao() {

        return dataEmissao;
    }

    public Date getDataLeitura() {

        return dataLeitura;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object obj ) {

        if ( this == obj ) return true;
        if ( obj == null || getClass() != obj.getClass() ) return false;
        ClienteFaturaPeriodoDto that  = (ClienteFaturaPeriodoDto) obj;
        if ( getIdCliente() != null ? !getIdCliente().equals( that.getIdCliente() ) : that.getIdCliente() != null ) return false;
        return true;
    }

    @Override
    public int hashCode() {

        return ( getIdCliente() != null ? getIdCliente().hashCode() : 0 );
    }

    @Override
    public String toString() {

        return "ClienteFaturaPeriodoDto { idCliente = " + idCliente + " }";
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}


