package models.commons.dtos;

import infra.model.Model;

import java.io.Serializable;
import java.util.Objects;

public class InfoAmbienteDto extends Model implements Serializable {

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // !!!!!!   FAVOR GERAR EQUALS E HASCODE  !!!!!!!!
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private Short      idEmpresa;
    private Short      tipoPessoa;
    private String     cnpj;
    private Short      codAmbiente;
    private String     iniValid;
    private String     fimValid;
    private String     descricaoAmbiente;
    private Short      localAmbiente;

    public Short getIdEmpresa() {
        return idEmpresa;
    }

    public void setIdEmpresa(Short idEmpresa) {
        this.idEmpresa = idEmpresa;
    }

    public Short getTipoPessoa() {
        return tipoPessoa;
    }

    public void setTipoPessoa(Short tipoPessoa) {
        this.tipoPessoa = tipoPessoa;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public Short getCodAmbiente() {
        return codAmbiente;
    }

    public void setCodAmbiente(Short codAmbiente) {
        this.codAmbiente = codAmbiente;
    }

    public String getIniValid() {
        return iniValid;
    }

    public void setIniValid(String iniValid) {
        this.iniValid = iniValid;
    }

    public String getFimValid() {
        return fimValid;
    }

    public void setFimValid(String fimValid) {
        this.fimValid = fimValid;
    }

    public String getDescricaoAmbiente() {
        return descricaoAmbiente;
    }

    public void setDescricaoAmbiente(String descricaoAmbiente) {
        this.descricaoAmbiente = descricaoAmbiente;
    }

    public Short getLocalAmbiente() {
        return localAmbiente;
    }

    public void setLocalAmbiente(Short localAmbiente) {
        this.localAmbiente = localAmbiente;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InfoAmbienteDto that = (InfoAmbienteDto) o;
        return Objects.equals(idEmpresa, that.idEmpresa) &&
                Objects.equals(tipoPessoa, that.tipoPessoa) &&
                Objects.equals(cnpj, that.cnpj) &&
                Objects.equals(codAmbiente, that.codAmbiente);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idEmpresa, tipoPessoa, cnpj, codAmbiente);
    }
}
