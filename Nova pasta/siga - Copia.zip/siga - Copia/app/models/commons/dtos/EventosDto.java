package models.commons.dtos;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

/**
 * Classe que representa informaþ§es...
 *
 * <p>Autor: Tiagopti</p>
 *
 * @since 18/10/2017
 */
public class EventosDto implements Serializable {

    private final Long idEventoCatalogo;
    private final String nomeEvento;
    private final String descricaoEvento;
    private final Short idEmpresa;
    private final String nomeEmpresa;
    private final Long ocorrencias;
    private final Long ultimoProcSucesso;


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CONSTRUCTOR
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public EventosDto(Long idEventoCatalogo, String nomeEvento, String descricaoEvento, Short idEmpresa, String nomeEmpresa, Long ocorrencias, Long ultimoProcSucesso) {
        this.idEventoCatalogo = idEventoCatalogo;
        this.nomeEvento = nomeEvento;
        this.descricaoEvento = descricaoEvento;
        this.idEmpresa = idEmpresa;
        this.nomeEmpresa = nomeEmpresa;
        this.ocorrencias = ocorrencias;
        this.ultimoProcSucesso = ultimoProcSucesso;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // GETTERS
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public Long getIdEventoCatalogo() {
        return idEventoCatalogo;
    }

    public String getNomeEvento() {
        return nomeEvento;
    }

    public String getDescricaoEvento() {
        return descricaoEvento;
    }

    public Short getIdEmpresa() {
        return idEmpresa;
    }

    public String getNomeEmpresa() {
        return nomeEmpresa;
    }

    public Long getOcorrencias() {
        return ocorrencias;
    }

    public Long getUltimoProcSucesso() {
        return ultimoProcSucesso;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASCODE
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof EventosDto)) return false;
        EventosDto that = (EventosDto) o;
        return Objects.equals(getIdEventoCatalogo(), that.getIdEventoCatalogo()) &&
                Objects.equals(getNomeEvento(), that.getNomeEvento()) &&
                Objects.equals(getIdEmpresa(), that.getIdEmpresa());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdEventoCatalogo(), getNomeEvento(), getIdEmpresa());
    }
}