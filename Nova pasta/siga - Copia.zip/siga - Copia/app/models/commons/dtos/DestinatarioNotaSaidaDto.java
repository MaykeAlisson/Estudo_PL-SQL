package models.commons.dtos;

import java.io.Serializable;

/**
 * Created by clebersilva on 9/1/16.
 */
public class DestinatarioNotaSaidaDto implements Serializable {

    private String idTipoDestinatario;
    private Long idDestinatario;

    public DestinatarioNotaSaidaDto(String idTipoDestinatario, Long idDestinatario) {
        this.idTipoDestinatario = idTipoDestinatario;
        this.idDestinatario = idDestinatario;
    }

    public String getIdTipoDestinatario() {
        return idTipoDestinatario;
    }

    public void setIdTipoDestinatario(String idTipoDestinatario) {
        this.idTipoDestinatario = idTipoDestinatario;
    }

    public Long getIdDestinatario() {
        return idDestinatario;
    }

    public void setIdDestinatario(Long idDestinatario) {
        this.idDestinatario = idDestinatario;
    }
}
