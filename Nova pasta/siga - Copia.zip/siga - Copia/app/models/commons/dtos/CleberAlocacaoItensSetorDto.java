package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;

import static infra.util.UtilCollections.isVazia;
import static java.util.Comparator.comparing;

public class CleberAlocacaoItensSetorDto implements Serializable {

    private String modulo;
    private Short rua;
    private Long predio;
    private BigDecimal peso;
    private Long item;
    private Long qtdLinhas;

    public CleberAlocacaoItensSetorDto(String modulo, Short rua, Long predio, BigDecimal peso, Long item,Long qtdLinhas) {
        this.modulo = modulo;
        this.rua = rua;
        this.predio = predio;
        this.peso = peso;
        this.item = item;
        this.qtdLinhas = qtdLinhas;
    }

    public String getModulo() {
        return modulo;
    }

    public void setModulo(String modulo) {
        this.modulo = modulo;
    }

    public Short getRua() {
        return rua;
    }

    public void setRua(Short rua) {
        this.rua = rua;
    }

    public Long getPredio() {
        return predio;
    }

    public void setPredio(Long predio) {
        this.predio = predio;
    }

    public BigDecimal getPeso() {
        return peso;
    }

    public void setPeso(BigDecimal peso) {
        this.peso = peso;
    }

    public Long getItem() {
        return item;
    }

    public void setItem(Long item) {
        this.item = item;
    }

    public Long getQtdLinhas() {
        return qtdLinhas;
    }

    public void setQtdLinhas(Long qtdLinhas) {
        this.qtdLinhas = qtdLinhas;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CleberAlocacaoItensSetorDto)) return false;
        CleberAlocacaoItensSetorDto that = (CleberAlocacaoItensSetorDto) o;
        return Objects.equals(getModulo(), that.getModulo()) &&
                Objects.equals(getRua(), that.getRua()) &&
                Objects.equals(getPredio(), that.getPredio()) &&
                Objects.equals(getPeso(), that.getPeso()) &&
                Objects.equals(getItem(), that.getItem()) &&
                Objects.equals(getQtdLinhas(), that.getQtdLinhas());
    }

    @Override
    public int hashCode() {

        return Objects.hash(getModulo(), getRua(), getPredio(), getPeso(), getItem(), getQtdLinhas());
    }

    @Override
    public String toString() {
        return "CleberAlocacaoItensSetorDto{" +
                "modulo='" + modulo + '\'' +
                ", rua=" + rua +
                ", predio=" + predio +
                ", peso=" + peso +
                ", item=" + item +
                ", qtdLinhas=" + qtdLinhas +
                '}';
    }

    public  static void sortPorPesoDesc(List<CleberAlocacaoItensSetorDto> cleberMudancaCelulaDtos) {
        if ( !isVazia(cleberMudancaCelulaDtos) )
            cleberMudancaCelulaDtos.sort(
                    comparing( CleberAlocacaoItensSetorDto::getPeso ).reversed()
            );

    }

}
