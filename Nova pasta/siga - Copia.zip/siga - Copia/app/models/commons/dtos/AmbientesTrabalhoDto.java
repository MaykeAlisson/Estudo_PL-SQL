package models.commons.dtos;

import infra.model.Model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

/**
 * Classe que representa informaþ§es da proc fisco.dbo.up_esocial_ambientes_trabalho
 *
 * <p>Autor: Silas Andrade</p>
 *
 * @since 03/06/2019
 */
public class AmbientesTrabalhoDto extends Model implements Serializable {


    private final Short idEmpresa;
    private final Short tipoPessoa;
    private final BigDecimal cnpj;
    private final Short codAmbiente;
    private final String nomeAmbiente;
    private final String descAmbiente;
    private final Short localAmbiente;
    private final Short tpInscAmbiente;
    private final BigDecimal nrInscAmbiente;
    private final Short codLotacao;


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CONSTRUCTOR
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    public AmbientesTrabalhoDto(Short idEmpresa,
                                Short tipoPessoa,
                                BigDecimal cnpj,
                                Short codAmbiente,
                                String nomeAmbiente,
                                String descAmbiente,
                                Short localAmbiente,
                                Short tpInscAmbiente,
                                BigDecimal nrInscAmbiente,
                                Short codLotacao) {
        this.idEmpresa = idEmpresa;
        this.tipoPessoa = tipoPessoa;
        this.cnpj = cnpj;
        this.codAmbiente = codAmbiente;
        this.nomeAmbiente = nomeAmbiente;
        this.descAmbiente = descAmbiente;
        this.localAmbiente = localAmbiente;
        this.tpInscAmbiente = tpInscAmbiente;
        this.nrInscAmbiente = nrInscAmbiente;
        this.codLotacao = codLotacao;
    }

    public Short getIdEmpresa() {
        return idEmpresa;
    }

    public Short getTipoPessoa() {
        return tipoPessoa;
    }

    public BigDecimal getCnpj() {
        return cnpj;
    }

    public Short getCodAmbiente() {
        return codAmbiente;
    }

    public String getNomeAmbiente() {
        return nomeAmbiente;
    }

    public String getDescAmbiente() {
        return descAmbiente;
    }

    public Short getLocalAmbiente() {
        return localAmbiente;
    }

    public Short getTpInscAmbiente() {
        return tpInscAmbiente;
    }

    public BigDecimal getNrInscAmbiente() {
        return nrInscAmbiente;
    }

    public Short getCodLotacao() {
        return codLotacao;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AmbientesTrabalhoDto that = (AmbientesTrabalhoDto) o;
        return Objects.equals(cnpj, that.cnpj);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cnpj);
    }
}
