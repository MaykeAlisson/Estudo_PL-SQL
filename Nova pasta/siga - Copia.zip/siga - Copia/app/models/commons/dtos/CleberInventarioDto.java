package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import infra.jsonDeserializer.LocalDateTimeSerializer;
import infra.util.UtilDate;
import models.domains.ebitda.DetalheCusto;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilNumero.dividir;
import static infra.util.UtilNumero.multiplicar;
import static java.util.Comparator.comparing;

/**
 * Classe que representa informações...
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 26/12/2018
 */
public class CleberInventarioDto implements Serializable {


    private final LocalDateTime dataInventario;
    private final Long mercadoria;
    private final BigDecimal qtdEstoque;
    private final String descricao;
    private final Long qtdPalete;
    private Integer qtdPaleteEmEstoque;

    private Integer qtdPaletesAlocados;


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CONSTRUCTOR
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public CleberInventarioDto(
            final Date dataInventario,
            final Long mercadoria,
            final BigDecimal qtdEstoque,
            final String descricao,
            final Long qtdPalete
    ) {

        this.dataInventario = UtilDate.toLocalDateTime(dataInventario);
        this.mercadoria = mercadoria;
        this.qtdEstoque = qtdEstoque;
        this.descricao = descricao;
        this.qtdPalete = qtdPalete;

        this.qtdPaleteEmEstoque = calcularQtdPaleteEmEstoque(qtdEstoque,qtdPalete);
        this.qtdPaletesAlocados = 0;

    }

    @JsonProperty( "dataInventario" )
    @JsonSerialize( using = LocalDateTimeSerializer.class )
    public LocalDateTime getDataInventario() {

        return this.dataInventario;
    }

    @JsonProperty( "mercadoria" )
    public Long getMercadoria() {

        return this.mercadoria;
    }

    @JsonProperty( "qtdEstoque" )
    public BigDecimal getQtdEstoque() {

        return this.qtdEstoque;
    }

    @JsonProperty( "descricao" )
    public String getDescricao() {

        return this.descricao;
    }

    @JsonProperty( "qtdPalete" )
    public Long getQtdPalete() {

        return this.qtdPalete;
    }

    @JsonProperty( "qtdPaleteEmEstoque" )
    public Integer getQtdPaleteEmEstoque() {

        return this.qtdPaleteEmEstoque;

    }

    @JsonProperty("qtdPaletesAlocados")
    public Integer getQtdPaletesAlocados() {

        return this.qtdPaletesAlocados == null ? 0 : qtdPaletesAlocados;
    }

    public void setQtdPaletesAlocados(final Integer qtdPaletesAlocados) {

        this.qtdPaletesAlocados = qtdPaletesAlocados;
    }

    private Integer getQtdPaletesAlocar() {

        return this.getQtdPaleteEmEstoque() - this.getQtdPaletesAlocados();
    }

    private Integer calcularQtdPaleteEmEstoque(final BigDecimal qtdEstoque, final Long qtdPorPalete) {


        int qtdInteiraPalletes = dividir(qtdEstoque, new BigDecimal(qtdPorPalete)).intValue();
        int qtdEstoqueEmPalletes = multiplicar(new BigDecimal(qtdInteiraPalletes), new BigDecimal(qtdPorPalete)).intValue();

        if (qtdEstoqueEmPalletes < qtdEstoqueEmPalletes) qtdInteiraPalletes++;

        return qtdInteiraPalletes;
    }

    public static void sortPorCompetenciaQtdPaleteAlocar(List<CleberInventarioDto> cleberInventarioDtos) {

        if ( !isVazia(cleberInventarioDtos) )
            cleberInventarioDtos.sort(
                    comparing( CleberInventarioDto::getDataInventario )
                    .thenComparing( CleberInventarioDto::getQtdPaletesAlocar ).reversed()
            );
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CleberInventarioDto)) return false;
        CleberInventarioDto that = (CleberInventarioDto) o;
        return getDataInventario().equals(that.getDataInventario()) &&
                getMercadoria().equals(that.getMercadoria()) &&
                getQtdEstoque().equals(that.getQtdEstoque()) &&
                getDescricao().equals(that.getDescricao()) &&
                getQtdPalete().equals(that.getQtdPalete()) &&
                getQtdPaleteEmEstoque().equals(that.getQtdPaleteEmEstoque()) &&
                getQtdPaletesAlocados().equals(that.getQtdPaletesAlocados());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getDataInventario(), getMercadoria(), getQtdEstoque(), getDescricao(), getQtdPalete(), getQtdPaleteEmEstoque(), getQtdPaletesAlocados());
    }


    @Override
    public String toString() {
        return "CleberInventarioDto{" +
                "dataInventario=" + dataInventario +
                ", mercadoria=" + mercadoria +
                ", qtdEstoque=" + qtdEstoque +
                ", descricao='" + descricao + '\'' +
                ", qtdPalete=" + qtdPalete +
                ", qtdPaleteEmEstoque=" + qtdPaleteEmEstoque +
                ", qtdPaletesAlocados=" + qtdPaletesAlocados +
                '}';
    }


}
