package models.commons.dtos;

import infra.model.Model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Classe que representa informaþ§es...
 *
 * <p>Autor: Tiagopti</p>
 *
 * @since 17/10/2017
 */
public class AvisoPrevioDto extends Model implements Serializable {

    private Short idEmpresa;
    private Short tipoPessoa;
    private BigDecimal cnpj;
    private Long matricula;
    private BigDecimal cpfTrab;
    private BigDecimal pisPasep;
    private Date dataAviso;
    private Date dataDesligamento;
    private Short tipoAviso;
    private String obsAviso;
    private Date dataCancAviso;
    private String obsCancAviso;
    private Short motivoCancAviso;

    public Short getIdEmpresa() {
        return idEmpresa;
    }

    public void setIdEmpresa(Short idEmpresa) {
        this.idEmpresa = idEmpresa;
    }

    public Short getTipoPessoa() {
        return tipoPessoa;
    }

    public void setTipoPessoa(Short tipoPessoa) {
        this.tipoPessoa = tipoPessoa;
    }

    public BigDecimal getCnpj() {
        return cnpj;
    }

    public void setCnpj(BigDecimal cnpj) {
        this.cnpj = cnpj;
    }

    public Long getMatricula() {
        return matricula;
    }

    public void setMatricula(Long matricula) {
        this.matricula = matricula;
    }

    public BigDecimal getCpfTrab() {
        return cpfTrab;
    }

    public void setCpfTrab(BigDecimal cpfTrab) {
        this.cpfTrab = cpfTrab;
    }

    public BigDecimal getPisPasep() {
        return pisPasep;
    }

    public void setPisPasep(BigDecimal pisPasep) {
        this.pisPasep = pisPasep;
    }

    public Date getDataAviso() {
        return dataAviso;
    }

    public void setDataAviso(Date dataAviso) {
        this.dataAviso = dataAviso;
    }

    public Date getDataDesligamento() {
        return dataDesligamento;
    }

    public void setDataDesligamento(Date dataDesligamento) {
        this.dataDesligamento = dataDesligamento;
    }

    public Short getTipoAviso() {
        return tipoAviso;
    }

    public void setTipoAviso(Short tipoAviso) {
        this.tipoAviso = tipoAviso;
    }

    public String getObsAviso() {
        return obsAviso;
    }

    public void setObsAviso(String obsAviso) {
        this.obsAviso = obsAviso;
    }

    public Date getDataCancAviso() {
        return dataCancAviso;
    }

    public void setDataCancAviso(Date dataCancAviso) {
        this.dataCancAviso = dataCancAviso;
    }

    public String getObsCancAviso() {
        return obsCancAviso;
    }

    public void setObsCancAviso(String obsCancAviso) {
        this.obsCancAviso = obsCancAviso;
    }

    public Short getMotivoCancAviso() {
        return motivoCancAviso;
    }

    public void setMotivoCancAviso(Short motivoCancAviso) {
        this.motivoCancAviso = motivoCancAviso;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AvisoPrevioDto that = (AvisoPrevioDto) o;

        if (idEmpresa != null ? !idEmpresa.equals(that.idEmpresa) : that.idEmpresa != null) return false;
        if (tipoPessoa != null ? !tipoPessoa.equals(that.tipoPessoa) : that.tipoPessoa != null) return false;
        if (cnpj != null ? !cnpj.equals(that.cnpj) : that.cnpj != null) return false;
        if (matricula != null ? !matricula.equals(that.matricula) : that.matricula != null) return false;
        if (cpfTrab != null ? !cpfTrab.equals(that.cpfTrab) : that.cpfTrab != null) return false;
        if (pisPasep != null ? !pisPasep.equals(that.pisPasep) : that.pisPasep != null) return false;
        if (dataAviso != null ? !dataAviso.equals(that.dataAviso) : that.dataAviso != null) return false;
        if (dataDesligamento != null ? !dataDesligamento.equals(that.dataDesligamento) : that.dataDesligamento != null)
            return false;
        if (tipoAviso != null ? !tipoAviso.equals(that.tipoAviso) : that.tipoAviso != null) return false;
        if (obsAviso != null ? !obsAviso.equals(that.obsAviso) : that.obsAviso != null) return false;
        if (dataCancAviso != null ? !dataCancAviso.equals(that.dataCancAviso) : that.dataCancAviso != null)
            return false;
        if (obsCancAviso != null ? !obsCancAviso.equals(that.obsCancAviso) : that.obsCancAviso != null) return false;
        return motivoCancAviso != null ? motivoCancAviso.equals(that.motivoCancAviso) : that.motivoCancAviso == null;
    }

    @Override
    public int hashCode() {
        int result = idEmpresa != null ? idEmpresa.hashCode() : 0;
        result = 31 * result + (tipoPessoa != null ? tipoPessoa.hashCode() : 0);
        result = 31 * result + (cnpj != null ? cnpj.hashCode() : 0);
        result = 31 * result + (matricula != null ? matricula.hashCode() : 0);
        result = 31 * result + (cpfTrab != null ? cpfTrab.hashCode() : 0);
        result = 31 * result + (pisPasep != null ? pisPasep.hashCode() : 0);
        result = 31 * result + (dataAviso != null ? dataAviso.hashCode() : 0);
        result = 31 * result + (dataDesligamento != null ? dataDesligamento.hashCode() : 0);
        result = 31 * result + (tipoAviso != null ? tipoAviso.hashCode() : 0);
        result = 31 * result + (obsAviso != null ? obsAviso.hashCode() : 0);
        result = 31 * result + (dataCancAviso != null ? dataCancAviso.hashCode() : 0);
        result = 31 * result + (obsCancAviso != null ? obsCancAviso.hashCode() : 0);
        result = 31 * result + (motivoCancAviso != null ? motivoCancAviso.hashCode() : 0);
        return result;
    }
}