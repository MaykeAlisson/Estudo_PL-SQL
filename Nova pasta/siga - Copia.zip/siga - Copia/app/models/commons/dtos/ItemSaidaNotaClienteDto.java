package models.commons.dtos;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilEnum.getEnum;
import static java.util.Comparator.comparing;
import static models.domains.vendas.TipoPedido.IdTipoPedido;

/**
 * Created by clebersilva on 11/02/17.
 */
public class ItemSaidaNotaClienteDto implements Serializable {

    private final Date idDataEmissao;
    private final Short idFilial;
    private final Long idNfSaida;
    private final Short idEmpresa;
    private final Short idSequencia;
    private final Long idMercadoria;
    private final IdTipoPedido idTipoPedido;

    public ItemSaidaNotaClienteDto( final Date idDataEmissao,
                                    final Short idFilial,
                                    final Long idNfSaida,
                                    final Short idEmpresa,
                                    final Short idSequencia,
                                    final Long idMercadoria,
                                    final Short idTipoPedido ) {

        this.idDataEmissao = idDataEmissao;
        this.idFilial = idFilial;
        this.idNfSaida = idNfSaida;
        this.idEmpresa = idEmpresa;
        this.idSequencia = idSequencia;
        this.idMercadoria = idMercadoria;
        this.idTipoPedido = getEnum( IdTipoPedido.class, idTipoPedido );
    }

    public Date getIdDataEmissao() {

        return idDataEmissao;
    }

    public Short getIdFilial() {

        return idFilial;
    }

    public Long getIdNfSaida() {

        return idNfSaida;
    }

    public Short getIdEmpresa() {

        return idEmpresa;
    }

    public Short getIdSequencia() {

        return idSequencia;
    }

    public Long getIdMercadoria() {

        return idMercadoria;
    }

    public IdTipoPedido getIdTipoPedido() {

        return idTipoPedido;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ItemSaidaNotaClienteDto)) return false;
        ItemSaidaNotaClienteDto that = (ItemSaidaNotaClienteDto) o;
        return Objects.equals(getIdDataEmissao(), that.getIdDataEmissao()) &&
                Objects.equals(getIdFilial(), that.getIdFilial()) &&
                Objects.equals(getIdNfSaida(), that.getIdNfSaida()) &&
                Objects.equals(getIdEmpresa(), that.getIdEmpresa()) &&
                Objects.equals(getIdSequencia(), that.getIdSequencia());
    }

    @Override
    public int hashCode() {

        return Objects.hash(getIdDataEmissao(), getIdFilial(), getIdNfSaida(), getIdEmpresa(), getIdSequencia());
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public static void orderByMercadoriaDataEmissao( List<ItemSaidaNotaClienteDto> itens ) {

        if( isVazia(itens) )
            return;

        itens.sort(
            comparing( ItemSaidaNotaClienteDto::getIdMercadoria )
            .thenComparing(ItemSaidaNotaClienteDto::getIdDataEmissao)
        );
    }
}
