package models.commons.dtos;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Objects;

import static infra.util.UtilDate.toLocalDateTime;

/**
 * Classe que representa informações...
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 04/10/2017
 */
public class EquipamentoPendenteRetornoDto implements Serializable {

    private final Short idEmpresa;
    private final Long idRepresentante;
    private final Long idSetor;
    private final String nomeRep;
    private final String nomeGerente;
    private final LocalDateTime dataMovto;
    private final Short idOcorEqpto;
    private final String situacao;
    private final String tipoEnvio;
    private final Short enderecoEnvio;
    private final String observacaoEnvio;
    private final Short tipoEqpto;
    private final Long idRemetente;
    private final String recEquipamento;
    private final String categoriaEqpto;
    private final String exigeRetorno;
    private final String descricao;
    private final LocalDateTime dataFim;
    private final String tipoConector;
    private final String iccid;


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CONSTRUCTOR
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public EquipamentoPendenteRetornoDto(
        final Short idEmpresa,
        final Long idRepresentante,
        final Long idSetor,
        final String nomeRep,
        final String nomeGerente,
        final Date dataMovto,
        final Short idOcorEqpto,
        final String situacao,
        final String tipoEnvio,
        final Short enderecoEnvio,
        final String observacaoEnvio,
        final Short tipoEqpto,
        final Long idRemetente,
        final String recEquipamento,
        final String categoriaEqpto,
        final String exigeRetorno,
        final String descricao,
        final Date dataFim,
        final String tipoConector,
        final String iccid
    ) {

        this.idEmpresa = idEmpresa;
        this.idRepresentante = idRepresentante;
        this.idSetor = idSetor;
        this.nomeRep = nomeRep;
        this.nomeGerente = nomeGerente;
        this.dataMovto = toLocalDateTime(dataMovto);
        this.idOcorEqpto = idOcorEqpto;
        this.situacao = situacao;
        this.tipoEnvio = tipoEnvio;
        this.enderecoEnvio = enderecoEnvio;
        this.observacaoEnvio = observacaoEnvio;
        this.tipoEqpto = tipoEqpto;
        this.idRemetente = idRemetente;
        this.recEquipamento = recEquipamento;
        this.categoriaEqpto = categoriaEqpto;
        this.exigeRetorno = exigeRetorno;
        this.descricao = descricao;
        this.dataFim = toLocalDateTime(dataFim);
        this.tipoConector = tipoConector;
        this.iccid = iccid;
    }

    public EquipamentoPendenteRetornoDto(
        final Short idEmpresa,
        final Long idRepresentante,
        final Long idSetor,
        final String nomeRep,
        final String nomeGerente,
        final Date dataMovto
    ) {
        this.idEmpresa = null;
        this.idRepresentante = null;
        this.idSetor = null;
        this.nomeRep = null;
        this.nomeGerente = null;
        this.dataMovto = null;
        this.idOcorEqpto = null;
        this.situacao = null;
        this.tipoEnvio = null;
        this.enderecoEnvio = null;
        this.observacaoEnvio = null;
        this.tipoEqpto = null;
        this.idRemetente = null;
        this.recEquipamento = null;
        this.categoriaEqpto = null;
        this.exigeRetorno = null;
        this.descricao = null;
        this.dataFim = null;
        this.tipoConector = null;
        this.iccid = null;
    }

    public Short getIdEmpresa() {

        return this.idEmpresa;
    }

    public Long getIdRepresentante() {

        return this.idRepresentante;
    }

    public Long getIdSetor() {

        return this.idSetor;
    }

    public String getNomeRep() {

        return this.nomeRep;
    }

    public String getNomeGerente() {

        return this.nomeGerente;
    }

    public LocalDateTime getDataMovto() {

        return this.dataMovto;
    }

    public Short getIdOcorEqpto() {

        return this.idOcorEqpto;
    }

    public String getSituacao() {

        return this.situacao;
    }

    public String getTipoEnvio() {

        return this.tipoEnvio;
    }

    public Short getEnderecoEnvio() {

        return this.enderecoEnvio;
    }

    public String getObservacaoEnvio() {

        return this.observacaoEnvio;
    }

    public Short getTipoEqpto() {

        return this.tipoEqpto;
    }

    public Long getIdRemetente() {

        return this.idRemetente;
    }

    public String getRecEquipamento() {

        return this.recEquipamento;
    }

    public String getCategoriaEqpto() {

        return this.categoriaEqpto;
    }

    public String getExigeRetorno() {

        return this.exigeRetorno;
    }

    public String getDescricao() {

        return this.descricao;
    }

    public LocalDateTime getDataFim() {

        return this.dataFim;
    }

    public String getTipoConector() {

        return this.tipoConector;
    }

    public String getIccid() {

        return this.iccid;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASCODE
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object o ) {

        if ( this == o ) return true;
        if ( !(o instanceof EquipamentoPendenteRetornoDto) ) return false;
        EquipamentoPendenteRetornoDto that = (EquipamentoPendenteRetornoDto) o;
        return Objects.equals(getIdEmpresa(), that.getIdEmpresa()) &&
                Objects.equals(getIdRepresentante(), that.getIdRepresentante()) &&
                Objects.equals(getIdSetor(), that.getIdSetor()) &&
                Objects.equals(getDataMovto(), that.getDataMovto()) &&
                Objects.equals(getIdOcorEqpto(), that.getIdOcorEqpto());
    }

    @Override
    public int hashCode() {

        return Objects.hash(getIdEmpresa(), getIdRepresentante(), getIdSetor(), getDataMovto(), getIdOcorEqpto());
    }
}


