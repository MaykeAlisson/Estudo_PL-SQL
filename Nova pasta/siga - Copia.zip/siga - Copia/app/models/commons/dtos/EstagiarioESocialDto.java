package models.commons.dtos;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;

/**
 * Classe que representa informaþ§es...
 *
 * <p>Autor: Fernandopti</p>
 *
 * @since 19/03/2018
 */
public class EstagiarioESocialDto implements Serializable {

    private Short idEmpresa;
    private Long matricula;
    private String estagioNatureza;
    private Short estagioNivel;
    private String estagioAreaAtuacao;
    private String estagioNroApoliceSeguro;
    private BigDecimal estagioVlrBolsa;
    private Date estagioDtPrevisaoTermino;
    private BigDecimal estagioCnpjInstituicao;
    private String estagioRazaoInstituicao;
    private BigDecimal estagioCpfSupervisor;
    private String estagioNomeSupervisor;

    public Short getIdEmpresa() {

        return this.idEmpresa;
    }

    public void setIdEmpresa( final Short idEmpresa ) {

        this.idEmpresa = idEmpresa;
    }

    public Long getMatricula() {

        return this.matricula;
    }

    public void setMatricula( final Long matricula ) {

        this.matricula = matricula;
    }

    public String getEstagioNatureza() {

        return this.estagioNatureza;
    }

    public void setEstagioNatureza( final String estagioNatureza ) {

        this.estagioNatureza = estagioNatureza;
    }

    public Short getEstagioNivel() {

        return this.estagioNivel;
    }

    public void setEstagioNivel( final Short estagioNivel ) {

        this.estagioNivel = estagioNivel;
    }

    public String getEstagioAreaAtuacao() {

        return this.estagioAreaAtuacao;
    }

    public void setEstagioAreaAtuacao( final String estagioAreaAtuacao ) {

        this.estagioAreaAtuacao = estagioAreaAtuacao;
    }

    public String getEstagioNroApoliceSeguro() {

        return this.estagioNroApoliceSeguro;
    }

    public void setEstagioNroApoliceSeguro( final String estagioNroApoliceSeguro ) {

        this.estagioNroApoliceSeguro = estagioNroApoliceSeguro;
    }

    public BigDecimal getEstagioVlrBolsa() {

        return this.estagioVlrBolsa;
    }

    public void setEstagioVlrBolsa( final BigDecimal estagioVlrBolsa ) {

        this.estagioVlrBolsa = estagioVlrBolsa;
    }

    public Date getEstagioDtPrevisaoTermino() {

        return this.estagioDtPrevisaoTermino;
    }

    public void setEstagioDtPrevisaoTermino( final Date estagioDtPrevisaoTermino ) {

        this.estagioDtPrevisaoTermino = estagioDtPrevisaoTermino;
    }

    public BigDecimal getEstagioCnpjInstituicao() {

        return this.estagioCnpjInstituicao;
    }

    public void setEstagioCnpjInstituicao( final BigDecimal estagioCnpjInstituicao ) {

        this.estagioCnpjInstituicao = estagioCnpjInstituicao;
    }

    public String getEstagioRazaoInstituicao() {

        return this.estagioRazaoInstituicao;
    }

    public void setEstagioRazaoInstituicao( final String estagioRazaoInstituicao ) {

        this.estagioRazaoInstituicao = estagioRazaoInstituicao;
    }

    public BigDecimal getEstagioCpfSupervisor() {

        return this.estagioCpfSupervisor;
    }

    public void setEstagioCpfSupervisor( final BigDecimal estagioCpfSupervisor ) {

        this.estagioCpfSupervisor = estagioCpfSupervisor;
    }

    public String getEstagioNomeSupervisor() {

        return this.estagioNomeSupervisor;
    }

    public void setEstagioNomeSupervisor( final String estagioNomeSupervisor ) {

        this.estagioNomeSupervisor = estagioNomeSupervisor;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        EstagiarioESocialDto that = (EstagiarioESocialDto) o;

        if (idEmpresa != null ? !idEmpresa.equals(that.idEmpresa) : that.idEmpresa != null) return false;
        if (matricula != null ? !matricula.equals(that.matricula) : that.matricula != null) return false;
        if (estagioNatureza != null ? !estagioNatureza.equals(that.estagioNatureza) : that.estagioNatureza != null)
            return false;
        if (estagioNivel != null ? !estagioNivel.equals(that.estagioNivel) : that.estagioNivel != null) return false;
        if (estagioAreaAtuacao != null ? !estagioAreaAtuacao.equals(that.estagioAreaAtuacao) : that.estagioAreaAtuacao != null)
            return false;
        if (estagioNroApoliceSeguro != null ? !estagioNroApoliceSeguro.equals(that.estagioNroApoliceSeguro) : that.estagioNroApoliceSeguro != null)
            return false;
        if (estagioVlrBolsa != null ? !estagioVlrBolsa.equals(that.estagioVlrBolsa) : that.estagioVlrBolsa != null)
            return false;
        if (estagioDtPrevisaoTermino != null ? !estagioDtPrevisaoTermino.equals(that.estagioDtPrevisaoTermino) : that.estagioDtPrevisaoTermino != null)
            return false;
        if (estagioCnpjInstituicao != null ? !estagioCnpjInstituicao.equals(that.estagioCnpjInstituicao) : that.estagioCnpjInstituicao != null)
            return false;
        if (estagioRazaoInstituicao != null ? !estagioRazaoInstituicao.equals(that.estagioRazaoInstituicao) : that.estagioRazaoInstituicao != null)
            return false;
        if (estagioCpfSupervisor != null ? !estagioCpfSupervisor.equals(that.estagioCpfSupervisor) : that.estagioCpfSupervisor != null)
            return false;
        return estagioNomeSupervisor != null ? estagioNomeSupervisor.equals(that.estagioNomeSupervisor) : that.estagioNomeSupervisor == null;
    }

    @Override
    public int hashCode() {
        int result = idEmpresa != null ? idEmpresa.hashCode() : 0;
        result = 31 * result + (matricula != null ? matricula.hashCode() : 0);
        result = 31 * result + (estagioNatureza != null ? estagioNatureza.hashCode() : 0);
        result = 31 * result + (estagioNivel != null ? estagioNivel.hashCode() : 0);
        result = 31 * result + (estagioAreaAtuacao != null ? estagioAreaAtuacao.hashCode() : 0);
        result = 31 * result + (estagioNroApoliceSeguro != null ? estagioNroApoliceSeguro.hashCode() : 0);
        result = 31 * result + (estagioVlrBolsa != null ? estagioVlrBolsa.hashCode() : 0);
        result = 31 * result + (estagioDtPrevisaoTermino != null ? estagioDtPrevisaoTermino.hashCode() : 0);
        result = 31 * result + (estagioCnpjInstituicao != null ? estagioCnpjInstituicao.hashCode() : 0);
        result = 31 * result + (estagioRazaoInstituicao != null ? estagioRazaoInstituicao.hashCode() : 0);
        result = 31 * result + (estagioCpfSupervisor != null ? estagioCpfSupervisor.hashCode() : 0);
        result = 31 * result + (estagioNomeSupervisor != null ? estagioNomeSupervisor.hashCode() : 0);
        return result;
    }
}
