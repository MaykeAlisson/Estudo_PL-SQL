package models.commons.dtos;


import java.io.Serializable;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;
import infra.model.Model;

/**
 * Classe que representa informaþ§es...
 *
 * <p>Autor: Victor.serafim</p>
 *
 * @since 04/12/2018
 */

public class JornadaMotoristaDto extends Model implements Serializable{



        private final Long funcionario;
        private final String email;
        private final Long idRegraAcesso;


        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        // CONSTRUCTOR
        //
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        public JornadaMotoristaDto(
                final Long funcionario,
                final String email,
                final Long idRegraAcesso
        ) {

            this.funcionario = funcionario;
            this.email = email;
            this.idRegraAcesso = idRegraAcesso;
        }

        @JsonProperty( "funcionario" )
        public Long getFuncionario() {

            return this.funcionario;
        }

        @JsonProperty( "email" )
        public String getEmail() {

            return this.email;
        }

        @JsonProperty( "idRegraAcesso" )
        public Long getIdRegraAcesso() {

            return this.idRegraAcesso;
        }


        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        // EQUALS & HASHCODE
        //
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////



    }