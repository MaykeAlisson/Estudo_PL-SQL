package models.commons.dtos;


import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Classe que representa informações...
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 24/10/2016
 */
public class DistribuicaoCustoCdaDto implements Serializable {

    private final Short idCda;
    private final BigDecimal valorCMV;
    private final BigDecimal peso;
    private final BigDecimal volumeEntrega;
    private final BigDecimal volumeTransbordo;
    private final BigDecimal qtdItem;

    public DistribuicaoCustoCdaDto( final Short idCda,
                                    final BigDecimal valorCMV,
                                    final BigDecimal peso,
                                    final BigDecimal volumeEntrega,
                                    final BigDecimal volumeTransbordo,
                                    final BigDecimal qtdItem ) {

        this.idCda = idCda;
        this.valorCMV = valorCMV;
        this.peso = peso;
        this.volumeEntrega = volumeEntrega;
        this.volumeTransbordo = volumeTransbordo;
        this.qtdItem = qtdItem;
    }

    public Short getIdCda() {

        return idCda;
    }

    public BigDecimal getValorCMV() {

        return valorCMV;
    }

    public BigDecimal getPeso() {

        return peso;
    }

    public BigDecimal getVolumeEntrega() {

        return volumeEntrega;
    }

    public BigDecimal getVolumeTransbordo() {
        return volumeTransbordo;
    }

    public BigDecimal getQtdItem() {

        return qtdItem;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object obj ) {

        if ( this == obj ) return true;
        if ( obj == null || getClass() != obj.getClass() ) return false;
        DistribuicaoCustoCdaDto that  = (DistribuicaoCustoCdaDto) obj;
        if ( getIdCda() != null ? !getIdCda().equals( that.getIdCda() ) : that.getIdCda() != null ) return false;
        return true;
    }

    @Override
    public int hashCode() {

        return ( getIdCda() != null ? getIdCda().hashCode() : 0 );
    }

    @Override
    public String toString() {

        return "DistribuicaoCustoCdaDto { idCda = " + idCda + " }";
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}


