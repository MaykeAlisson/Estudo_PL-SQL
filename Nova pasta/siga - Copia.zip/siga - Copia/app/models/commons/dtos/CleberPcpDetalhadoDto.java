package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

/**
 * Classe que representa informações...
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 26/01/2018
 */
public class CleberPcpDetalhadoDto implements Serializable {

    private Long idServico;
    private String tipoServico;
    private Date dataOrigem;
    private Date dataLiberacao;
    private Date dataLimite;
    private Date dataPrevistaRoteirizacao;
    private Date dataPrevistaSaida;
    private BigDecimal volumeTotal;
    private BigDecimal pesoTotal;
    private Long qtdRecipiente;
    private Long idPedido;
    private Short idSequencia;
    private Long mercadoria;
    private Short qtdVendida;
    private Short alturaVenda;
    private Short comprVenda;
    private Short larguraVenda;
    private BigDecimal pesoVenda;
    private Short idCda;
    private Long idServicoOrigem;
    private Date dataExecucao;
    private Long idLote;

    public Long getIdServico() {

        return this.idServico;
    }

    public void setIdServico( final Long idServico ) {

        this.idServico = idServico;
    }

    public String getTipoServico() {

        return this.tipoServico;
    }

    public void setTipoServico( final String tipoServico ) {

        this.tipoServico = tipoServico;
    }

    public Date getDataOrigem() {

        return this.dataOrigem;
    }

    public void setDataOrigem( final Date dataOrigem ) {

        this.dataOrigem = dataOrigem;
    }

    public Date getDataLiberacao() {

        return this.dataLiberacao;
    }

    public void setDataLiberacao( final Date dataLiberacao ) {

        this.dataLiberacao = dataLiberacao;
    }

    public Date getDataLimite() {

        return this.dataLimite;
    }

    public void setDataLimite( final Date dataLimite ) {

        this.dataLimite = dataLimite;
    }

    public Date getDataPrevistaRoteirizacao() {

        return this.dataPrevistaRoteirizacao;
    }

    public void setDataPrevistaRoteirizacao( final Date dataPrevistaRoteirizacao ) {

        this.dataPrevistaRoteirizacao = dataPrevistaRoteirizacao;
    }

    public Date getDataPrevistaSaida() {

        return this.dataPrevistaSaida;
    }

    public void setDataPrevistaSaida( final Date dataPrevistaSaida ) {

        this.dataPrevistaSaida = dataPrevistaSaida;
    }

    public BigDecimal getVolumeTotal() {

        return this.volumeTotal;
    }

    public void setVolumeTotal( final BigDecimal volumeTotal ) {

        this.volumeTotal = volumeTotal;
    }

    public BigDecimal getPesoTotal() {

        return this.pesoTotal;
    }

    public void setPesoTotal( final BigDecimal pesoTotal ) {

        this.pesoTotal = pesoTotal;
    }

    public Long getQtdRecipiente() {

        return this.qtdRecipiente;
    }

    public void setQtdRecipiente( final Long qtdRecipiente ) {

        this.qtdRecipiente = qtdRecipiente;
    }

    public Long getIdPedido() {

        return this.idPedido;
    }

    public void setIdPedido( final Long idPedido ) {

        this.idPedido = idPedido;
    }

    public Short getIdSequencia() {

        return this.idSequencia;
    }

    public void setIdSequencia( final Short idSequencia ) {

        this.idSequencia = idSequencia;
    }

    public Long getMercadoria() {

        return this.mercadoria;
    }

    public void setMercadoria( final Long mercadoria ) {

        this.mercadoria = mercadoria;
    }

    public Short getQtdVendida() {

        return this.qtdVendida;
    }

    public void setQtdVendida( final Short qtdVendida ) {

        this.qtdVendida = qtdVendida;
    }

    public Short getAlturaVenda() {

        return this.alturaVenda;
    }

    public void setAlturaVenda( final Short alturaVenda ) {

        this.alturaVenda = alturaVenda;
    }

    public Short getComprVenda() {

        return this.comprVenda;
    }

    public void setComprVenda( final Short comprVenda ) {

        this.comprVenda = comprVenda;
    }

    public Short getLarguraVenda() {

        return this.larguraVenda;
    }

    public void setLarguraVenda( final Short larguraVenda ) {

        this.larguraVenda = larguraVenda;
    }

    public BigDecimal getPesoVenda() {

        return this.pesoVenda;
    }

    public void setPesoVenda( final BigDecimal pesoVenda ) {

        this.pesoVenda = pesoVenda;
    }

    public Short getIdCda() {
        return idCda;
    }

    public void setIdCda(Short idCda) {
        this.idCda = idCda;
    }

    public Long getIdServicoOrigem() {
        return idServicoOrigem == null ? 0L : idServicoOrigem;
    }

    public void setIdServicoOrigem(Long idServicoOrigem) {
        this.idServicoOrigem = idServicoOrigem;
    }

    public Date getDataExecucao() {
        return dataExecucao;
    }

    public void setDataExecucao(Date dataExecucao) {
        this.dataExecucao = dataExecucao;
    }

    public Long getIdLote() {
        return idLote;
    }

    public void setIdLote(Long idLote) {
        this.idLote = idLote;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASCODE
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CleberPcpDetalhadoDto)) return false;
        CleberPcpDetalhadoDto that = (CleberPcpDetalhadoDto) o;
        return Objects.equals(getIdServico(), that.getIdServico()) &&
                Objects.equals(getIdPedido(), that.getIdPedido()) &&
                Objects.equals(getIdSequencia(), that.getIdSequencia()) &&
                Objects.equals(getMercadoria(), that.getMercadoria());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdServico(), getIdPedido(), getIdSequencia(), getMercadoria());
    }
}

