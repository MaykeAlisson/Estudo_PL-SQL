package models.commons.dtos;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

import static infra.util.UtilDate.isValida;

/**
 * Classe que representa informações sobre a finalizacao da baixa
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 30/07/2018
 */
public class EncerramentoBaixaDto implements Serializable {

    private final Short idEmpresa;
    private final Long idCarga;
    private final LocalDateTime dataBaixa;
    private final Long sequencia;
    private final Short idEquipeCarregamento;
    private final boolean existeBaixa;
    private final boolean existeEquipeCarregamento;

    public EncerramentoBaixaDto(
        final Short idEmpresa,
        final Long idCarga,
        final LocalDateTime dataBaixa,
        final Long sequencia,
        final Short idEquipeCarregamento
    ) {

        this.idEmpresa = idEmpresa;
        this.idCarga = idCarga;
        this.dataBaixa = dataBaixa;
        this.sequencia = sequencia;
        this.idEquipeCarregamento = idEquipeCarregamento;
        this.existeBaixa = isValida( dataBaixa ) && sequencia != null;
        this.existeEquipeCarregamento = idEquipeCarregamento != null && idEquipeCarregamento > 0;
    }

    public Short getIdEmpresa() {

        return idEmpresa;
    }

    public Long getIdCarga() {

        return idCarga;
    }

    public LocalDateTime getDataBaixa() {

        return dataBaixa;
    }

    public Long getSequencia() {

        return sequencia;
    }

    public Short getIdEquipeCarregamento() {

        return idEquipeCarregamento;
    }

    public boolean isExisteBaixa() {

        return existeBaixa;
    }

    public boolean isExisteEquipeCarregamento() {

        return existeEquipeCarregamento;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object o ) {

        if ( this == o ) return true;
        if ( !(o instanceof EncerramentoBaixaDto) ) return false;
        EncerramentoBaixaDto that = (EncerramentoBaixaDto) o;
        return Objects.equals(getIdEmpresa(), that.getIdEmpresa()) &&
                Objects.equals(getIdCarga(), that.getIdCarga());
    }

    @Override
    public int hashCode() {

        return Objects.hash(getIdEmpresa(), getIdCarga());
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
