package models.commons.dtos;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import models.commons.constantes.TipoDestinoMovimentoAlocacao;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe que representa informaþ§es sobre rateio de despesas.
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 25/05/2018
 */
public class DestinoRateioCustoDto implements Serializable {

    private final TipoDestinoMovimentoAlocacao tipoDestinoMovimentoAlocacao;
    private final Long codigoDestino;
    private final BigDecimal valor;

    @JsonCreator
    public DestinoRateioCustoDto(
        @JsonProperty( "tipoDestino" ) final String tipoDestinoMovimentoAlocacao,
        @JsonProperty( "codigoDestino" ) final Long codigoDestino,
        @JsonProperty( "valorDestino" ) final BigDecimal valor
    ) {

        this.tipoDestinoMovimentoAlocacao = getEnum(TipoDestinoMovimentoAlocacao.class, tipoDestinoMovimentoAlocacao);
        this.codigoDestino = codigoDestino;
        this.valor = valor;
    }

    public TipoDestinoMovimentoAlocacao getTipoDestinoMovimentoAlocacao() {

        return tipoDestinoMovimentoAlocacao;
    }

    public Long getCodigoDestino() {

        return codigoDestino;
    }

    public BigDecimal getValor() {

        return valor;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object obj ) {

        if ( this == obj ) return true;
        if ( !( obj instanceof DestinoRateioCustoDto ) ) return false;
        DestinoRateioCustoDto that = (DestinoRateioCustoDto) obj;
        return Objects.equals( getTipoDestinoMovimentoAlocacao(), that.getTipoDestinoMovimentoAlocacao() ) &&
                Objects.equals( getCodigoDestino(), that.getCodigoDestino() );
    }

    @Override
    public int hashCode() {

        return Objects.hash( getTipoDestinoMovimentoAlocacao(), getCodigoDestino() );
    }

    @Override
    public String toString() {

        return "DestinoRateioCustoDto { tipoDestinoMovimentoAlocacao = '" +
                tipoDestinoMovimentoAlocacao + "'" +
                ", codigoDestino = " + codigoDestino + " }";
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}
