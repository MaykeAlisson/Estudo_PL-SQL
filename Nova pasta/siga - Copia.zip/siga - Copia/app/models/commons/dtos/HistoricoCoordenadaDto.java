package models.commons.dtos;

import models.commons.constantes.CorRotaRastreador;
import models.commons.constantes.Direcao;
import models.commons.constantes.SimNao;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilDate.adicionarNMinutos;
import static infra.util.UtilDate.getDataComoString;
import static infra.util.UtilDate.toLocalDateTime;
import static infra.util.UtilEnum.getEnum;
import static java.util.Comparator.comparing;
import static java.util.Optional.empty;
import static java.util.Optional.of;
import static models.commons.constantes.SimNao.SIM;

/**
 * Classe que representa informações das coordenadas de uma viagem.
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 30/03/2017
 */
public class HistoricoCoordenadaDto implements Serializable {

    private final Long idHistoricoCoordenada;
    private final Short idVeiculo;
    private final LocalDateTime dataEvento;
    private final BigDecimal longitude;
    private final BigDecimal latitude;
    private final Direcao direcao;
    private final SimNao pontoPrincipal;
    private final boolean ehProntoPrincipal;
    private final BigDecimal odometro;
    private final Long tempoParada;
    private final LocalDateTime dataSaida;
    private final Short sequenciaPontoPrincipal;

    public HistoricoCoordenadaDto( final Long idHistoricoCoordenada,
                                   final Short idVeiculo,
                                   final LocalDateTime dataEvento,
                                   final BigDecimal longitude,
                                   final BigDecimal latitude,
                                   final Direcao direcao,
                                   final SimNao pontoPrincipal,
                                   final BigDecimal odometro,
                                   final Long tempoParada,
                                   final Short sequenciaPontoPrincipal ) {

        this.idHistoricoCoordenada = idHistoricoCoordenada;
        this.idVeiculo = idVeiculo;
        this.dataEvento = dataEvento;
        this.longitude = longitude;
        this.latitude = latitude;
        this.direcao = direcao;
        this.pontoPrincipal = pontoPrincipal;
        this.ehProntoPrincipal = ( pontoPrincipal != null && SIM.equals( pontoPrincipal ) ) && ( direcao != null );
        this.odometro = odometro;
        this.tempoParada = tempoParada == null ? 0 : tempoParada;
        this.dataSaida = this.tempoParada > 0 ? adicionarNMinutos( this.tempoParada, this.dataEvento ) : this.dataEvento;
        this.sequenciaPontoPrincipal = sequenciaPontoPrincipal == null ? 0 : sequenciaPontoPrincipal;
    }

    public HistoricoCoordenadaDto( final Long idHistoricoCoordenada,
                                   final Short idVeiculo,
                                   final Date dataEvento,
                                   final BigDecimal longitude,
                                   final BigDecimal latitude,
                                   final String direcao,
                                   final String pontoPrincipal,
                                   final BigDecimal odometro,
                                   final Long tempoParada,
                                   final Short sequenciaPontoPrincipal) {

        this(   idHistoricoCoordenada,
                idVeiculo,
                toLocalDateTime( dataEvento ),
                longitude,
                latitude,
                getEnum( Direcao.class, direcao ),
                getEnum( SimNao.class, pontoPrincipal ),
                odometro,
                tempoParada,
                sequenciaPontoPrincipal
        );
    }

    public Long getIdHistoricoCoordenada() {

        return idHistoricoCoordenada;
    }

    public Short getIdVeiculo( ) {

        return idVeiculo;
    }

    public LocalDateTime getDataEvento() {

        return dataEvento;
    }

    public boolean isMesmoDia( final LocalDate dataCompara ) {

        return getDataEvento() != null
                && dataCompara != null
                && Objects.equals( getDataEvento().toLocalDate(), dataCompara );
    }

    public BigDecimal getLongitude() {

        return longitude;
    }

    public BigDecimal getLatitude() {

        return latitude;
    }

    public Direcao getDirecao( ) {

        return direcao;
    }

    public SimNao getPontoPrincipal( ) {

        return pontoPrincipal;
    }

    public boolean isPontoPrincipal() {

        return ehProntoPrincipal;
    }

    public BigDecimal getOdometro( ) {

        return odometro;
    }

    public Long getTempoParada( ) {

        return tempoParada;
    }

    public LocalDateTime getDataSaida( ) {

        return dataSaida;
    }

    public Short getSequenciaPontoPrincipal() {
        return sequenciaPontoPrincipal;
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE & COMPARE
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object o ) {

        if ( this == o ) return true;
        if ( !(o instanceof HistoricoCoordenadaDto) ) return false;
        HistoricoCoordenadaDto that = (HistoricoCoordenadaDto) o;
        return Objects.equals(getIdHistoricoCoordenada(), that.getIdHistoricoCoordenada());
    }

    @Override
    public int hashCode() {

        return Objects.hash( getIdHistoricoCoordenada() );
    }

    @Override
    public String toString() {

        return "HistoricoCoordenadaDto { idHistoricoCoordenada = " + idHistoricoCoordenada + " }";
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // INTERFACES AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public interface InfoViagem {

        HistoricoCoordenadaDto getUltimaEntrega();
        List<DiaEntrega> getDiasDeEntrega();

        static InfoViagem newInstance( final HistoricoCoordenadaDto historicoCoordenada,
                                       final List<DiaEntrega> diaEntregas ) {

            return new InfoViagem() {

                @Override
                public HistoricoCoordenadaDto getUltimaEntrega() {
                    return historicoCoordenada;
                }

                @Override
                public List<DiaEntrega> getDiasDeEntrega() {
                    return diaEntregas;
                }
            };
        }
    }

    public interface DiaEntrega {

        LocalDate getDia();
        CorRotaRastreador getCor();

        static DiaEntrega newInstance( final LocalDate dia,
                                       final CorRotaRastreador corRotaRastreador ) {

            return new DiaEntrega() {

                @Override
                public LocalDate getDia() {
                    return dia;
                }

                @Override
                public CorRotaRastreador getCor() {
                    return corRotaRastreador;
                }
            };
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Ordena lista pelo id
     *
     * <p>Autor: GPortes</p>
     *
     * @param dtos
     */
    public static void orderById( List<HistoricoCoordenadaDto> dtos ) {

        if ( isVazia(dtos) )
            return;

        dtos.sort( comparing( HistoricoCoordenadaDto::getIdHistoricoCoordenada ) );
    }

    /**
     * Ordena lista pela data e Id
     *
     * <p>Autor: GPortes</p>
     *
     * @param dtos
     */
    public static void orderByData( List<HistoricoCoordenadaDto> dtos ) {

        if ( isVazia(dtos) )
            return;

        dtos.sort(
            comparing( HistoricoCoordenadaDto::getDataEvento )
                .thenComparing(HistoricoCoordenadaDto::getSequenciaPontoPrincipal)
        );
    }


    /**
     * Retorna informações da viagem.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dtos  Lista de históricos.
     *
     * @return  Informações da viagem.
     */
    public static Optional<InfoViagem> getInfoViagem( List<HistoricoCoordenadaDto> dtos ) {

        orderByData( dtos );

        final String formato  = "MM/dd/yy";
        String dataCompara = "";
        CorRotaRastreador corRotaRastreador = CorRotaRastreador.LINHA_AZUL;

        List<DiaEntrega> diasEntregas = new ArrayList<>(  );
        HistoricoCoordenadaDto ultimaCoordenada = null;

        for ( final HistoricoCoordenadaDto dto : dtos ) {

            if ( ultimaCoordenada == null )
                ultimaCoordenada = dto;
            else if ( Objects.equals( dto.getIdHistoricoCoordenada(), ultimaCoordenada.getIdHistoricoCoordenada() ) )
                ultimaCoordenada = dto;

            if ( "".equals( dataCompara ) || !Objects.equals( dataCompara, getDataComoString( dto.getDataEvento(), formato )  ) ) {
                diasEntregas.add( DiaEntrega.newInstance( dto.getDataEvento().toLocalDate(), corRotaRastreador )   );
                dataCompara = getDataComoString( dto.getDataEvento(), formato );
                corRotaRastreador = CorRotaRastreador.proximaCor( corRotaRastreador );
            }
        }

        if ( isVazia( diasEntregas ) || ultimaCoordenada == null )
            return empty();

        return of( InfoViagem.newInstance(ultimaCoordenada, diasEntregas) );
    }


}

