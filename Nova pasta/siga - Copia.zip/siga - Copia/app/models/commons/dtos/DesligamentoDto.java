package models.commons.dtos;

import infra.model.Model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

/**
 * Classe que representa informaþ§es...
 *
 * <p>Autor: Fernandopti</p>
 *
 * @since 30/11/2017
 */
public class DesligamentoDto extends Model implements Serializable {

    private Short idEmpresa;
    private Short tipoPessoa;
    private BigDecimal cnpj;
    private Long matricula;
    private BigDecimal cpfTrab;
    private BigDecimal pisPasep;
    private Long motivoDesligamento;
    private Date dataDesligamento;
    private String avisoPrevioPago;
    private Date dataProjecaoAviso;
    private Long indPensao;
    private BigDecimal percentualPensao;
    private BigDecimal valorPensao;
    private String nroCertidaoObito;
    private Long nroProcessoTrab;
    private Short indAvisoPrevioParc;
    private String obsDesligamento;
    private String idFolha;
    private Long grauExpAgenteNocivo;
    private Short indMultiploVinculo;
    private Date dataPagamento;
    private BigDecimal cnpjSucessora;
    private Short idLotacao;

    public Short getIdEmpresa() {

        return this.idEmpresa;
    }

    public void setIdEmpresa( final Short idEmpresa ) {

        this.idEmpresa = idEmpresa;
    }

    public Short getTipoPessoa() {

        return this.tipoPessoa;
    }

    public void setTipoPessoa( final Short tipoPessoa ) {

        this.tipoPessoa = tipoPessoa;
    }

    public BigDecimal getCnpj() {

        return this.cnpj;
    }

    public void setCnpj( final BigDecimal cnpj ) {

        this.cnpj = cnpj;
    }

    public Long getMatricula() {

        return this.matricula;
    }

    public void setMatricula( final Long matricula ) {

        this.matricula = matricula;
    }

    public BigDecimal getCpfTrab() {

        return this.cpfTrab;
    }

    public void setCpfTrab( final BigDecimal cpfTrab ) {

        this.cpfTrab = cpfTrab;
    }

    public BigDecimal getPisPasep() {

        return this.pisPasep;
    }

    public void setPisPasep( final BigDecimal pisPasep ) {

        this.pisPasep = pisPasep;
    }

    public Long getMotivoDesligamento() {

        return this.motivoDesligamento;
    }

    public void setMotivoDesligamento( final Long motivoDesligamento ) {

        this.motivoDesligamento = motivoDesligamento;
    }

    public Date getDataDesligamento() {

        return this.dataDesligamento;
    }

    public void setDataDesligamento( final Date dataDesligamento ) {

        this.dataDesligamento = dataDesligamento;
    }

    public String getAvisoPrevioPago() {

        return this.avisoPrevioPago;
    }

    public void setAvisoPrevioPago( final String avisoPrevioPago ) {

        this.avisoPrevioPago = avisoPrevioPago;
    }

    public Date getDataProjecaoAviso() {

        return this.dataProjecaoAviso;
    }

    public void setDataProjecaoAviso( final Date dataProjecaoAviso ) {

        this.dataProjecaoAviso = dataProjecaoAviso;
    }

    public Long getIndPensao() {

        return this.indPensao;
    }

    public void setIndPensao( final Long indPensao ) {

        this.indPensao = indPensao;
    }

    public BigDecimal getPercentualPensao() {

        return this.percentualPensao;
    }

    public void setPercentualPensao( final BigDecimal percentualPensao ) {

        this.percentualPensao = percentualPensao;
    }

    public BigDecimal getValorPensao() {

        return this.valorPensao;
    }

    public void setValorPensao( final BigDecimal valorPensao ) {

        this.valorPensao = valorPensao;
    }

    public String getNroCertidaoObito() {

        return this.nroCertidaoObito;
    }

    public void setNroCertidaoObito( final String nroCertidaoObito ) {

        this.nroCertidaoObito = nroCertidaoObito;
    }

    public Long getNroProcessoTrab() {

        return this.nroProcessoTrab;
    }

    public void setNroProcessoTrab( final Long nroProcessoTrab ) {

        this.nroProcessoTrab = nroProcessoTrab;
    }

    public Short getIndAvisoPrevioParc() {

        return this.indAvisoPrevioParc;
    }

    public void setIndAvisoPrevioParc( final Short indAvisoPrevioParc ) {

        this.indAvisoPrevioParc = indAvisoPrevioParc;
    }

    public String getObsDesligamento() {

        return this.obsDesligamento;
    }

    public void setObsDesligamento( final String obsDesligamento ) {

        this.obsDesligamento = obsDesligamento;
    }

    public String getIdFolha() {

        return this.idFolha;
    }

    public void setIdFolha( final String idFolha ) {

        this.idFolha = idFolha;
    }

    public Long getGrauExpAgenteNocivo() {

        return this.grauExpAgenteNocivo;
    }

    public void setGrauExpAgenteNocivo( final Long grauExpAgenteNocivo ) {

        this.grauExpAgenteNocivo = grauExpAgenteNocivo;
    }

    public Short getIndMultiploVinculo() {
        return indMultiploVinculo;
    }

    public void setIndMultiploVinculo(Short indMultiploVinculo) {
        this.indMultiploVinculo = indMultiploVinculo;
    }

    public Date getDataPagamento() {
        return dataPagamento;
    }

    public void setDataPagamento(Date dataPagamento) {
        this.dataPagamento = dataPagamento;
    }

    public BigDecimal getCnpjSucessora() {
        return cnpjSucessora;
    }

    public void setCnpjSucessora(BigDecimal cnpjSucessora) {
        this.cnpjSucessora = cnpjSucessora;
    }

    public Short getIdLotacao() {
        return idLotacao;
    }

    public void setIdLotacao(Short idLotacao) {
        this.idLotacao = idLotacao;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof DesligamentoDto)) return false;
        DesligamentoDto that = (DesligamentoDto) o;
        return Objects.equals(getIdEmpresa(), that.getIdEmpresa()) &&
                Objects.equals(getTipoPessoa(), that.getTipoPessoa()) &&
                Objects.equals(getCnpj(), that.getCnpj()) &&
                Objects.equals(getMatricula(), that.getMatricula()) &&
                Objects.equals(getCpfTrab(), that.getCpfTrab()) &&
                Objects.equals(getPisPasep(), that.getPisPasep()) &&
                Objects.equals(getMotivoDesligamento(), that.getMotivoDesligamento()) &&
                Objects.equals(getDataDesligamento(), that.getDataDesligamento()) &&
                Objects.equals(getAvisoPrevioPago(), that.getAvisoPrevioPago()) &&
                Objects.equals(getDataProjecaoAviso(), that.getDataProjecaoAviso()) &&
                Objects.equals(getIndPensao(), that.getIndPensao()) &&
                Objects.equals(getPercentualPensao(), that.getPercentualPensao()) &&
                Objects.equals(getValorPensao(), that.getValorPensao()) &&
                Objects.equals(getNroCertidaoObito(), that.getNroCertidaoObito()) &&
                Objects.equals(getNroProcessoTrab(), that.getNroProcessoTrab()) &&
                Objects.equals(getIndAvisoPrevioParc(), that.getIndAvisoPrevioParc()) &&
                Objects.equals(getObsDesligamento(), that.getObsDesligamento()) &&
                Objects.equals(getIdFolha(), that.getIdFolha()) &&
                Objects.equals(getGrauExpAgenteNocivo(), that.getGrauExpAgenteNocivo()) &&
                Objects.equals(getIndMultiploVinculo(),that.getIndMultiploVinculo()) &&
                Objects.equals(getDataPagamento(), that.getDataPagamento());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdEmpresa(), getTipoPessoa(), getCnpj(), getMatricula(), getCpfTrab(), getPisPasep(), getMotivoDesligamento(), getDataDesligamento(), getAvisoPrevioPago(), getDataProjecaoAviso(), getIndPensao(), getPercentualPensao(), getValorPensao(), getNroCertidaoObito(), getNroProcessoTrab(), getIndAvisoPrevioParc(), getObsDesligamento(), getIdFolha(), getGrauExpAgenteNocivo(),getIndMultiploVinculo(),getDataPagamento());
    }
}
