package models.commons.dtos;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import static infra.util.UtilCollections.isVazia;
import static java.util.Comparator.comparing;

/**
 * Classe que representa informações reduzidas do Cda
 *
 * <p>Autor: GPortes</p>
 *
 * @since 13/03/2017
 */
public class CdaTransbordoDto implements Serializable {

    private Short idCda;
    private Date dataTransbordo;

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CONSTRUCTOR
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public CdaTransbordoDto(
            final Short idCda,
            final Date dataTransbordo
    ) {
        this.idCda = idCda;
        this.dataTransbordo = dataTransbordo;
    }



    public Short getIdCda() {
        return idCda;
    }

    public void setIdCda(Short idCda) {
        this.idCda = idCda;
    }

    public Date getDataTransbordo() {
        return dataTransbordo;
    }

    public void setDataTransbordo(Date dataTransbordo) {
        this.dataTransbordo = dataTransbordo;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASCODE
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object o ) {

        if ( this == o ) return true;
        if ( !(o instanceof CdaTransbordoDto) ) return false;
        CdaTransbordoDto that = (CdaTransbordoDto) o;
        return Objects.equals(getIdCda(), that.getIdCda()) &&
                Objects.equals(getDataTransbordo(), that.getDataTransbordo());
    }

    @Override
    public int hashCode() {

        return Objects.hash(getIdCda(), getDataTransbordo());
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public static void orderByIdCdaData( List<CdaTransbordoDto> dtos ) {

        if ( !isVazia(dtos) )
            dtos.sort(
                comparing(CdaTransbordoDto::getIdCda)
                .thenComparing(CdaTransbordoDto::getDataTransbordo)
            );
    }

}


