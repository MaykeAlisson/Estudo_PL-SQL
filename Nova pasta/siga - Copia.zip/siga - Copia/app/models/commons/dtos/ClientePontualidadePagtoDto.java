package models.commons.dtos;

import models.commons.constantes.FaixaAcrescimoPagamento;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static infra.util.UtilCollections.containsKey;
import static infra.util.UtilCollections.isVazia;
import static java.util.Collections.emptyMap;
import static models.commons.constantes.FaixaAcrescimoPagamento.*;


/**
 * Classe que representa informações sobre a pontualidade de pagamentos do Cliente.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 11/02/2016
 */
public class ClientePontualidadePagtoDto implements Serializable {

    private final Long idCliente;
    private Map<FaixaAcrescimoPagamento, Integer> qtde = new HashMap<FaixaAcrescimoPagamento, Integer>( 1 );

    public ClientePontualidadePagtoDto( final Long idCliente,
                                        final Integer qtdBolEmDia,
                                        final Integer qtdBolAte05d,
                                        final Integer qtdDe06A10d,
                                        final Integer qtdDe11A15d,
                                        final Integer qtdDe16A20d,
                                        final Integer qtdDe21A30d,
                                        final Integer qtdMais30d ) {

        this( idCliente, new HashMap<FaixaAcrescimoPagamento, Integer>(1) {
                {
                    put( EM_DIA, qtdBolEmDia );
                    put( ATE_5_DIAS, qtdBolAte05d );
                    put( DE_6_A_10_DIAS, qtdDe06A10d );
                    put( DE_11_A_15_DIAS, qtdDe11A15d );
                    put( DE_16_A_20_DIAS, qtdDe16A20d );
                    put( DE_21_A_30_DIAS, qtdDe21A30d );
                    put( ACIMA_DE_30_DIAS, qtdMais30d );
                }
        });
    }

    public ClientePontualidadePagtoDto( final Long idCliente,
                                        final Map<FaixaAcrescimoPagamento, Integer> qtde ) {

        this.idCliente = idCliente;
        this.qtde = qtde;
    }

    public Long getIdCliente() {

        return idCliente;
    }

    public Map<FaixaAcrescimoPagamento, Integer> getQtde() {

        return qtde;
    }

    public Integer getQtde( FaixaAcrescimoPagamento faixaAcrescimoPagamento ) {

        return faixaAcrescimoPagamento != null ? containsKey( qtde, faixaAcrescimoPagamento ) ? qtde.get( faixaAcrescimoPagamento ) : 0 :  0;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object obj ) {

        if ( this == obj ) return true;
        if ( obj == null || getClass() != obj.getClass() ) return false;
        ClientePontualidadePagtoDto that  = (ClientePontualidadePagtoDto) obj;
        if ( getIdCliente() != null ? !getIdCliente().equals( that.getIdCliente() ) : that.getIdCliente() != null ) return false;
        return true;
    }

    @Override
    public int hashCode() {

        return ( getIdCliente() != null ? getIdCliente().hashCode() : 0 );
    }

    @Override
    public String toString() {

        return "ClientePontualidadePagtoDto { idCliente = " + idCliente + " }";
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Sumariza lista.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dtos      Lista de pontualidade de pagtos.
     *
     * @return Dados sumarizados.
     */
    public static Map<FaixaAcrescimoPagamento, Integer> sumarizar(final List<ClientePontualidadePagtoDto> dtos ) {

        if ( isVazia( dtos ) )
            return emptyMap();

        Map<FaixaAcrescimoPagamento, Integer> sumarizar = new HashMap<FaixaAcrescimoPagamento, Integer>(  );

        for ( ClientePontualidadePagtoDto dto : dtos ) {

            for ( FaixaAcrescimoPagamento faixaAcrescimoPagamento : FaixaAcrescimoPagamento.values() ) {
                int qtTotal = ( sumarizar.containsKey( faixaAcrescimoPagamento ) ? sumarizar.get( faixaAcrescimoPagamento ) : 0 ) +
                              dto.getQtde( faixaAcrescimoPagamento );
                sumarizar.put( faixaAcrescimoPagamento, qtTotal );
            }
        }

        return sumarizar;
    }

}


