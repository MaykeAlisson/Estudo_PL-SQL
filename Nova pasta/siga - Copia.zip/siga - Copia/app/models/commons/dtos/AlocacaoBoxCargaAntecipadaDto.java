package models.commons.dtos;

import java.io.Serializable;
import java.util.Map;
import java.util.Objects;

public class AlocacaoBoxCargaAntecipadaDto implements Serializable {
    private final String box;
    private final String boxCargaAntecipada;
    private final Map<String, String> boxesAlocados;

    public AlocacaoBoxCargaAntecipadaDto(String box, String boxCargaAntecipada, Map<String, String> boxesAlocados) {
        this.box = box;
        this.boxCargaAntecipada = boxCargaAntecipada;
        this.boxesAlocados = boxesAlocados;
    }

    public String getBox() {
        return box;
    }

    public String getBoxCargaAntecipada() {
        return boxCargaAntecipada;
    }

    public Map<String, String> getBoxesAlocados() {
        return boxesAlocados;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AlocacaoBoxCargaAntecipadaDto that = (AlocacaoBoxCargaAntecipadaDto) o;
        return Objects.equals(box, that.box) &&
                Objects.equals(boxCargaAntecipada, that.boxCargaAntecipada);
    }

    @Override
    public int hashCode() {

        return Objects.hash(box, boxCargaAntecipada);
    }
}
