package models.commons.dtos;

import java.io.Serializable;

/**
 * Classe que representa informações do Gerente de Transporte
 *
 * <p>Autor: Cleber</p>
 *
 * @since 17/08/2017
 */
public class GerenteTransporteDto implements Serializable {

    private final Short idGerente;
    private final Short idEmpresa;
    private final Long idFuncionario;

    public GerenteTransporteDto( final Short idGerente,
                                 final Short idEmpresa,
                                 final Long idFuncionario ) {

        this.idGerente = idGerente;
        this.idEmpresa = idEmpresa;
        this.idFuncionario = idFuncionario;
    }

    public Short getIdGerente() {

        return idGerente;
    }

    public Short getIdEmpresa() {

        return idEmpresa;
    }

    public Long getIdFuncionario() {

        return idFuncionario;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object obj ) {

        if ( this == obj ) return true;
        if ( obj == null || getClass() != obj.getClass() ) return false;
        GerenteTransporteDto that  = ( GerenteTransporteDto ) obj;
        if ( getIdGerente() != null ? !getIdGerente().equals( that.getIdGerente() ) : that.getIdGerente() != null ) return false;
        return true;
    }

    @Override
    public int hashCode() {

        return ( getIdGerente() != null ? getIdGerente().hashCode() : 0 );
    }

    @Override
    public String toString() {

        return "GerenteTransporteDto { idGerente = " + idGerente + " }";
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}


