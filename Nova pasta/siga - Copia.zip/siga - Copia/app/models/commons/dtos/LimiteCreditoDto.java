package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;

import static infra.util.UtilNumero.getOrElseZero;
import static infra.util.UtilString.getOrElse;


/**
 * Classe ref. aos limites de credito do cliente.
 *
 * <p>Autor: GPortes</p>
 *
 * @since  22/08/2014.
 */
public class LimiteCreditoDto implements Serializable {

    private Short idEmpresa;
    private Long idCliente;
    private Long idParametroAnalise;
    private String situacao;
    private BigDecimal limiteManual;
    private String motivoLimiteManual;
    private BigDecimal limiteRegraDataDeFundacao;
    private String motivoLimiteRegraDataDeFundacao;
    private BigDecimal vlrMinimo;
    private String motivoVlrMinimo;
    private String motivoAtraso;
    private BigDecimal vlrConstruido;
    private String motivoVlrConstruido;
    private Integer percAcrescimoPagto;
    private String motivoAcrescimoPagto;
    private Short percAcrescimoCidade;
    private String motivoAcrescimoCidade;
    private String motivoRedutor;
    private BigDecimal limiteFinal;
    private String motivoLimiteFinal;
    private BigDecimal limiteFinalComTolerancia;
    private String motivoLimiteFinalComTolerancia;

    private LimiteCreditoDto( models.commons.dtos.LimiteCreditoDto.Builder builder ) {

        this.idEmpresa = builder.idEmpresa;
        this.idCliente = builder.idCliente;
        this.situacao = builder.situacao;
        this.limiteManual = getOrElseZero( builder.limiteManual );
        this.motivoLimiteManual = getOrElse( builder.motivoLimiteManual, "" );
        this.limiteRegraDataDeFundacao = getOrElseZero( builder.limiteRegraDataDeFundacao );
        this.motivoLimiteRegraDataDeFundacao = getOrElse( builder.motivoLimiteRegraDataDeFundacao, "" );
        this.vlrMinimo = getOrElseZero( builder.vlrMinimo );
        this.motivoVlrMinimo = getOrElse( builder.motivoVlrMinimo, "" );
        this.vlrConstruido = getOrElseZero( builder.vlrConstruido );
        this.motivoVlrConstruido = getOrElse( builder.motivoVlrConstruido, "" );
        this.percAcrescimoPagto = getOrElseZero( builder.percAcrescimoPagto, Integer.class );
        this.motivoAcrescimoPagto = getOrElse( builder.motivoAcrescimoPagto, "" );
        this.percAcrescimoCidade = getOrElseZero( builder.percAcrescimoCidade, Short.class );
        this.motivoAcrescimoCidade = getOrElse( builder.motivoAcrescimoCidade, "" );
        this.motivoRedutor = getOrElse( builder.motivoRedutor, "" );
        this.limiteFinal = getOrElseZero( builder.limiteFinal );
        this.motivoLimiteFinal = getOrElse( builder.motivoLimiteFinal, "" );
        this.limiteFinalComTolerancia = getOrElseZero( builder.limiteFinalComTolerancia );
        this.motivoLimiteFinalComTolerancia = getOrElse( builder.motivoLimiteFinalComTolerancia, "" );
        this.motivoAtraso = getOrElse( builder.motivoAtraso, "" );
    }

    public static class Builder {

        private Short idEmpresa;
        private Long idCliente;
        private String situacao;
        private BigDecimal limiteManual;
        private String motivoLimiteManual;
        private BigDecimal limiteRegraDataDeFundacao;
        private String motivoLimiteRegraDataDeFundacao;
        private BigDecimal vlrMinimo;
        private String motivoVlrMinimo;
        private String motivoAtraso;
        private BigDecimal vlrConstruido;
        private String motivoVlrConstruido;
        private Integer percAcrescimoPagto;
        private String motivoAcrescimoPagto;
        private Short percAcrescimoCidade;
        private String motivoAcrescimoCidade;
        private String motivoRedutor;
        private BigDecimal limiteFinal;
        private String motivoLimiteFinal;
        private BigDecimal limiteFinalComTolerancia;
        private String motivoLimiteFinalComTolerancia;

        public Builder( final Short idEmpresa,
                        final Long idCliente ) {

            this.idEmpresa = idEmpresa;
            this.idCliente = idCliente;
        }

        public Builder comSituacao( final String situacao ) {

            this.situacao = situacao;
            return this;
        }

        public Builder comMotivoAtraso( final String motivoAtraso ) {

            this.motivoAtraso = motivoAtraso;
            return this;
        }

        public Builder comLimiteManual( final BigDecimal valor,
                                        final String motivo ) {

            this.limiteManual = valor;
            this.motivoLimiteManual = motivo;
            return this;
        }

        public Builder comLimitePorRegraDeDataDeFundacao( final BigDecimal valor,
                                                          final String motivo ) {

            this.limiteRegraDataDeFundacao = valor;
            this.motivoLimiteRegraDataDeFundacao = motivo;
            return this;
        }

        public Builder comVlrMinimo( final BigDecimal valor,
                                     final String motivo ) {

            this.vlrMinimo = valor;
            this.motivoVlrMinimo = motivo;
            return this;
        }

        public Builder comConstruido( final BigDecimal valor,
                                      final String motivo ) {

            this.vlrConstruido = valor;
            this.motivoVlrConstruido = motivo;
            return this;
        }

        public Builder comAcrescimoPagto( final Integer percentual,
                                          final String motivo ) {

            this.percAcrescimoPagto = percentual;
            this.motivoAcrescimoPagto = motivo;
            return this;
        }

        public Builder comAcrescimoCidade( final Short percentual,
                                           final String motivo ) {

            this.percAcrescimoCidade = percentual;
            this.motivoAcrescimoCidade = motivo;
            return this;
        }

        public Builder comRedutor( final String motivo ) {

            this.motivoRedutor = motivo;
            return this;
        }

        public Builder comLimiteFinal( final BigDecimal valor,
                                       final String motivo ) {

            this.limiteFinal = valor;
            this.motivoLimiteFinal = motivo;
            return this;
        }

        public Builder comLimiteFinalTolerancia( final BigDecimal valor,
                                                 final String motivo ) {

            this.limiteFinalComTolerancia = valor;
            this.motivoLimiteFinalComTolerancia = motivo;
            return this;
        }

        public LimiteCreditoDto builder() {

            return new LimiteCreditoDto( this );
        }
    }

    public Short getIdEmpresa() {
        return idEmpresa;
    }

    public Long getIdCliente() {
        return idCliente;
    }

    public Long getIdParametroAnalise() {
        return idParametroAnalise;
    }

    public String getSituacao() {
        return situacao;
    }

    public BigDecimal getLimiteManual() {
        return limiteManual;
    }

    public String getMotivoLimiteManual() {
        return motivoLimiteManual;
    }

    public BigDecimal getLimiteRegraDataDeFundacao() {
        return limiteRegraDataDeFundacao;
    }

    public String getMotivoLimiteRegraDataDeFundacao() {
        return motivoLimiteRegraDataDeFundacao;
    }

    public BigDecimal getVlrMinimo() {
        return vlrMinimo;
    }

    public String getMotivoVlrMinimo() {
        return motivoVlrMinimo;
    }

    public String getMotivoAtraso() {
        return motivoAtraso;
    }

    public BigDecimal getVlrConstruido() {
        return vlrConstruido;
    }

    public String getMotivoVlrConstruido() {
        return motivoVlrConstruido;
    }

    public Integer getPercAcrescimoPagto() {
        return percAcrescimoPagto;
    }

    public String getMotivoAcrescimoPagto() {
        return motivoAcrescimoPagto;
    }

    public Short getPercAcrescimoCidade() {
        return percAcrescimoCidade;
    }

    public String getMotivoAcrescimoCidade() {
        return motivoAcrescimoCidade;
    }

    public String getMotivoRedutor() {
        return motivoRedutor;
    }

    public BigDecimal getLimiteFinal() {
        return limiteFinal;
    }

    public String getMotivoLimiteFinal() {
        return motivoLimiteFinal;
    }

    public BigDecimal getLimiteFinalComTolerancia() {
        return limiteFinalComTolerancia;
    }

    public String getMotivoLimiteFinalComTolerancia() {
        return motivoLimiteFinalComTolerancia;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals(Object o) {

        if (this == o) return true;
        if (!(o instanceof LimiteCreditoDto)) return false;

        LimiteCreditoDto that = (LimiteCreditoDto) o;

        if (idCliente != null ? !idCliente.equals(that.idCliente) : that.idCliente != null) return false;
        if (idEmpresa != null ? !idEmpresa.equals(that.idEmpresa) : that.idEmpresa != null) return false;
        if (idParametroAnalise != null ? !idParametroAnalise.equals(that.idParametroAnalise) : that.idParametroAnalise != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {

        int result = idEmpresa != null ? idEmpresa.hashCode() : 0;
        result = 31 * result + (idCliente != null ? idCliente.hashCode() : 0);
        result = 31 * result + (idParametroAnalise != null ? idParametroAnalise.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "LimiteCreditoDto{" +
                "idEmpresa=" + idEmpresa +
                ", idCliente=" + idCliente +
                ", idParametroAnalise=" + idParametroAnalise +
                ", situacao='" + situacao + '\'' +
                ", limiteManual=" + limiteManual +
                ", motivoLimiteManual='" + motivoLimiteManual + '\'' +
                ", limiteRegraDataDeFundacao=" + limiteRegraDataDeFundacao +
                ", motivoLimiteRegraDataDeFundacao='" + motivoLimiteRegraDataDeFundacao + '\'' +
                ", vlrMinimo=" + vlrMinimo +
                ", motivoVlrMinimo='" + motivoVlrMinimo + '\'' +
                ", motivoAtraso='" + motivoAtraso + '\'' +
                ", vlrConstruido=" + vlrConstruido +
                ", motivoVlrConstruido='" + motivoVlrConstruido + '\'' +
                ", percAcrescimoPagto=" + percAcrescimoPagto +
                ", motivoAcrescimoPagto='" + motivoAcrescimoPagto + '\'' +
                ", percAcrescimoCidade=" + percAcrescimoCidade +
                ", motivoAcrescimoCidade='" + motivoAcrescimoCidade + '\'' +
                ", motivoRedutor='" + motivoRedutor + '\'' +
                ", limiteFinal=" + limiteFinal +
                ", motivoLimiteFinal='" + motivoLimiteFinal + '\'' +
                ", limiteFinalComTolerancia=" + limiteFinalComTolerancia +
                ", motivoLimiteFinalComTolerancia='" + motivoLimiteFinalComTolerancia + '\'' +
                '}';
    }
}
