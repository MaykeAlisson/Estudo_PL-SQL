package models.commons.dtos;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import models.commons.constantes.TipoLiberacao;

import java.io.Serializable;
import java.util.Objects;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe que representa informações recebidas da tela para processamento da
 * liberação dos recipientes para o box de armazenagem da antecipação, box liberação ou
 * box de carregamento.
 *
 * <p>Autor: Andre Luiz ALves de Faria </p>
 *
 * @since 19/07/2018
 */
public class LiberacaoCargaBoxDto implements Serializable {

    @JsonProperty( "balanca" )
    private final String balanca;

    @JsonProperty( "box" )
    private final String box;

    @JsonProperty( "qtdInfo" )
    private final Long qtdInfo;

    @JsonProperty( "qtdLiberacaoParcial" )
    private final Long qtdLiberacaoParcial;

    @JsonProperty( "idCarga" )
    private final Long idCarga;

    @JsonProperty( "boxCarregamento" )
    private final String boxCarregamento;

    @JsonProperty( "tipoLiberacao" )
    private final TipoLiberacao tipoLiberacao;

    @JsonProperty( "boxInformado" )
    private final String boxInformado;

    @JsonProperty( "digitoBoxInformado" )
    private final Short digitoBoxInformado;

    @JsonProperty( "qtdInformada" )
    private final Short qtdInformada;


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CONSTRUCTOR
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @JsonCreator
    public LiberacaoCargaBoxDto(
        @JsonProperty("balanca") final String balanca,
        @JsonProperty("box") final String box,
        @JsonProperty("qtdInfo") final Long qtdInfo,
        @JsonProperty("qtdLiberacaoParcial") final Long qtdLiberacaoParcial,
        @JsonProperty("idCarga") final Long idCarga,
        @JsonProperty("boxCarregamento") final String boxCarregamento,
        @JsonProperty("tipoLiberacao") final Short tipoLiberacao,
        @JsonProperty("boxInformado") final String boxInformado,
        @JsonProperty("digitoBoxInformado") final Short digitoBoxInformado,
        @JsonProperty("qtdInformada") final Short qtdLiberada
    ) {

        this.balanca = balanca;
        this.box = box;
        this.qtdInfo = qtdInfo;
        this.qtdLiberacaoParcial = qtdLiberacaoParcial;
        this.idCarga = idCarga;
        this.boxCarregamento = boxCarregamento;
        this.tipoLiberacao = getEnum( TipoLiberacao.class, tipoLiberacao );
        this.boxInformado = boxInformado;
        this.digitoBoxInformado = digitoBoxInformado;
        this.qtdInformada = qtdLiberada;
    }

    public String getBalanca() {

        return balanca;
    }

    public String getBox() {

        return box;
    }

    public Long getQtdInfo() {

        return qtdInfo;
    }

    public Long getQtdLiberacaoParcial() {

        return qtdLiberacaoParcial;
    }

    public Long getIdCarga() {

        return idCarga;
    }

    public String getBoxCarregamento() {

        return boxCarregamento;
    }

    public TipoLiberacao getTipoLiberacao() {

        return tipoLiberacao;
    }

    public String getBoxInformado() {

        return boxInformado;
    }

    public Short getDigitoBoxInformado() {

        return digitoBoxInformado;
    }

    public Short getQtdInformada() {

        return qtdInformada;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals(Object o) {

        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LiberacaoCargaBoxDto that = (LiberacaoCargaBoxDto) o;
        return Objects.equals(balanca, that.balanca) &&
                Objects.equals(box, that.box) &&
                Objects.equals(qtdInfo, that.qtdInfo) &&
                Objects.equals(qtdLiberacaoParcial, that.qtdLiberacaoParcial) &&
                Objects.equals(idCarga, that.idCarga) &&
                Objects.equals(boxCarregamento, that.boxCarregamento) &&
                tipoLiberacao == that.tipoLiberacao &&
                Objects.equals(boxInformado, that.boxInformado) &&
                Objects.equals(digitoBoxInformado, that.digitoBoxInformado) &&
                Objects.equals(qtdInformada, that.qtdInformada);
    }

    @Override
    public int hashCode() {

        return Objects.hash(balanca, box, qtdInfo, qtdLiberacaoParcial, idCarga, boxCarregamento, tipoLiberacao, boxInformado, digitoBoxInformado, qtdInformada);
    }

    @Override
    public String toString() {
        return "LiberacaoCargaBoxDto{" +
                "balanca='" + balanca + '\'' +
                ", box='" + box + '\'' +
                ", qtdInfo=" + qtdInfo +
                ", qtdLiberacaoParcial=" + qtdLiberacaoParcial +
                ", idCarga=" + idCarga +
                ", boxCarregamento='" + boxCarregamento + '\'' +
                ", tipoLiberacao=" + tipoLiberacao +
                ", boxInformado='" + boxInformado + '\'' +
                ", digitoBoxInformado=" + digitoBoxInformado +
                ", qtdInformada=" + qtdInformada +
                '}';
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
