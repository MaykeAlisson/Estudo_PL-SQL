package models.commons.dtos;

import infra.model.Model;

import java.io.Serializable;
import java.math.BigDecimal;
public class HorariosDto extends Model implements Serializable {

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // !!!!!!   FAVOR GERAR EQUALS E HASCODE  !!!!!!!!
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private Short idEmpresa;
    private Short tipoPessoa;
    private BigDecimal cnpj;
    private String codHorario;
    private String entrada;
    private String saida;
    private String inicioIntervalo;
    private String fimIntervalo;
    private String inicioIntervalo2;
    private String fimIntervalo2;
    private String flexivel;

    public Short getIdEmpresa() {

        return this.idEmpresa;
    }

    public void setIdEmpresa(final Short idEmpresa) {

        this.idEmpresa = idEmpresa;
    }

    public Short getTipoPessoa() {

        return this.tipoPessoa;
    }

    public void setTipoPessoa( final Short tipoPessoa ) {

        this.tipoPessoa = tipoPessoa;
    }

    public BigDecimal getCnpj() {

        return this.cnpj;
    }

    public void setCnpj( final BigDecimal cnpj ) {

        this.cnpj = cnpj;
    }

    public String getCodHorario() {

        return this.codHorario;
    }

    public void setCodHorario( final String codHorario ) {

        this.codHorario = codHorario;
    }

    public String getEntrada() {

        return this.entrada;
    }

    public void setEntrada( final String entrada ) {

        this.entrada = entrada;
    }

    public String getSaida() {

        return this.saida;
    }

    public void setSaida( final String saida ) {

        this.saida = saida;
    }

    public String getInicioIntervalo() {

        return this.inicioIntervalo;
    }

    public void setInicioIntervalo( final String inicioIntervalo ) {

        this.inicioIntervalo = inicioIntervalo;
    }

    public String getFimIntervalo() {

        return this.fimIntervalo;
    }

    public void setFimIntervalo( final String fimIntervalo ) {

        this.fimIntervalo = fimIntervalo;
    }

    public String getInicioIntervalo2() {

        return this.inicioIntervalo2;
    }

    public void setInicioIntervalo2( final String inicioIntervalo2 ) {

        this.inicioIntervalo2 = inicioIntervalo2;
    }

    public String getFimIntervalo2() {

        return this.fimIntervalo2;
    }

    public void setFimIntervalo2( final String fimIntervalo2 ) {

        this.fimIntervalo2 = fimIntervalo2;
    }

    public String getFlexivel() {

        return this.flexivel;
    }

    public void setFlexivel( final String flexivel ) {

        this.flexivel = flexivel;
    }

}
