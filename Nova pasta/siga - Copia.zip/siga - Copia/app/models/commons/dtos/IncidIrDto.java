package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

/**
 * Classe que representa informaþ§es...
 *
 * <p>Autor: Tiagopti</p>
 *
 * @since 31/07/2018
 */
public class IncidIrDto implements Serializable {

    private final Long id;
    private final BigDecimal cpf;
    private final Short categoria;
    private final BigDecimal vlrDependentes;
    private final Short tipoIncid;
    private final BigDecimal valorIncid;

    public IncidIrDto(
        final Long id,
        final BigDecimal cpf,
        final Short categoria,
        final BigDecimal vlrDependentes,
        final Short tipoIncid,
        final BigDecimal valorIncid
    ) {
        this.id = id;
        this.cpf = cpf;
        this.categoria = categoria;
        this.vlrDependentes = vlrDependentes;
        this.tipoIncid = tipoIncid;
        this.valorIncid = valorIncid;
    }

    public Long getId() {
        return id;
    }

    public BigDecimal getCpf() {
        return cpf;
    }

    public Short getCategoria() {
        return categoria;
    }

    public BigDecimal getVlrDependentes() {
        return vlrDependentes;
    }

    public Short getTipoIncid() {
        return tipoIncid;
    }

    public BigDecimal getValorIncid() {
        return valorIncid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof IncidIrDto)) return false;
        IncidIrDto that = (IncidIrDto) o;
        return Objects.equals(getId(), that.getId()) &&
                Objects.equals(getCpf(), that.getCpf()) &&
                Objects.equals(getCategoria(), that.getCategoria()) &&
                Objects.equals(getVlrDependentes(), that.getVlrDependentes()) &&
                Objects.equals(getTipoIncid(), that.getTipoIncid()) &&
                Objects.equals(getValorIncid(), that.getValorIncid());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getCpf(), getCategoria(), getVlrDependentes(), getTipoIncid(), getValorIncid());
    }
}

