package models.commons.dtos;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import infra.jsonDeserializer.LocalDateTimeISODeserializer;
import models.commons.constantes.Estado;
import models.commons.constantes.SituacaoPedidoPrincipia;
import models.commons.constantes.TipoEntregaECommerce;
import models.commons.constantes.TipoServicoCorreio;
import models.commons.constantes.TransportadoraOrigemECommerce;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilJson.toBigDecimal;
import static infra.util.UtilJson.toShort;
import static infra.util.UtilJson.toText;
import static infra.util.UtilNumero.convLong;
import static infra.util.UtilNumero.ehValorNegativo;
import static infra.util.UtilNumero.multiplicar;
import static infra.util.UtilNumero.subtrair;
import static infra.util.UtilNumero.toLong;
import static infra.util.UtilString.apenasNumero;
import static infra.util.UtilString.excluirPrimeiraPalavra;
import static infra.util.UtilString.isEmptyGet;
import static infra.util.UtilString.isVazia;
import static infra.util.UtilString.primeiraPalavra;
import static infra.util.UtilString.removerAcentosECaracteresEspeciais;
import static infra.util.UtilString.requireNonEmpty;
import static infra.util.UtilString.toUpperCase;
import static infra.util.UtilString.trim;
import static java.lang.String.format;
import static java.math.BigDecimal.ROUND_DOWN;
import static java.math.BigDecimal.ZERO;
import static java.util.Collections.emptyList;
import static java.util.Objects.requireNonNull;
import static java.util.regex.Pattern.CASE_INSENSITIVE;
import static models.commons.constantes.TipoEntregaECommerce.CORREIOS;
import static models.commons.constantes.TipoEntregaECommerce.TRANSPORTADORA;
import static models.commons.constantes.TipoServicoCorreio.PAC_CONTRATO_AGENCIA;
import static models.commons.constantes.TipoServicoCorreio.SEDEX_CONTRATO_AGENCIA;
import static models.domains.admin.Logradouro.IdLogradouro;
import static models.domains.admin.Logradouro.traduzLogradouroECommerce;

/**
 * Definição de dados do e-commerce.
 *
 * <p>Autor: GPortes</p>
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
public class DadosECommerceDto implements Serializable {

    private final Long idPedido;
    private final Pedido pedido;
    private final List<ItemPedido> itens;
    private final Cliente cliente;

    @JsonCreator
    public DadosECommerceDto(
        @JsonProperty( "id" ) final Long id,
        @JsonProperty( "total_price" ) final BigDecimal vlrTotalBruto,
        @JsonProperty( "status" ) final String situacaoECommerce,
        @JsonProperty( "source_id" ) final String idPedidoOrigem,
        @JsonProperty( "purchase_date" ) @JsonDeserialize( using = LocalDateTimeISODeserializer.class ) final LocalDateTime dataCompra,
        @JsonProperty( "freight_charged" ) final BigDecimal vlrFrete,
        @JsonProperty( "shipping_method" ) final String metodoEnvio,
        @JsonProperty( "products" ) final JsonNode nodeItens,
        @JsonProperty( "customer" ) final JsonNode nodeCliente
    ) {

        // Nro do pedido.
        this.idPedido = id;

        //
        // Itens.
        //
        if ( nodeItens != null && nodeItens.isArray() && nodeItens.size() > 0 ) {
            this.itens = new ArrayList<>( nodeItens.size() );
            nodeItens.forEach( node -> this.itens.add(
                new ItemPedidoBuilder( toText( node, "sku" ) )
                    .comPrecoUnitario( toBigDecimal( node, "price" ) )
                    .comQtdeVendida( toShort( node, "quantity" ) )
                    .build()
            ));
        } else {
            this.itens = emptyList();
        }

        //
        // Cliente / Endereço.
        //
        requireNonNull( nodeCliente, "Dados do cliente não estão preenchidos" );

        final JsonNode nodeEndereco = requireNonNull(
            nodeCliente.get( "address" ),
            "Dados do endereco não estão preenchidos"
        );

        this.cliente = new ClienteBuilder( toText( nodeCliente, "document" ) )
            .comNome( format( "%s %s",
                toText( nodeCliente, "first_name" ),
                toText( nodeCliente, "last_name") )
            )
            .comEmail( toText( nodeCliente, "email" ) )
            .comFone( toText( nodeCliente, "phone" ) )
            .comCep( toText( nodeEndereco, "postal_code" ) )
            .comEndereco( toText( nodeEndereco, "street" ) )
            .comNroEndereco( toShort( nodeEndereco, "number" ) )
            .comComplementoEndereco( toText( nodeEndereco, "complement" ) )
            .comEnderecoReferencia( toText( nodeEndereco, "reference" ) )
            .comBairro( toText( nodeEndereco, "neighborhood" ) )
            .comDescricaoCidade( toText( nodeEndereco, "city" ) )
            .comEstado( toText( nodeEndereco, "state" ) )
            .build();

        //
        // Pedido.
        //
        BigDecimal vlrTotalPedido = subtrair( vlrTotalBruto, vlrFrete );
        if ( vlrTotalPedido != null ) {
            vlrTotalPedido = vlrTotalPedido.setScale( 2, ROUND_DOWN );
            if ( ehValorNegativo( vlrTotalPedido ) )
                vlrTotalPedido = ZERO;
        }

        this.pedido = new PedidoBuilder( id )
            .comIdPedidoOrigem( idPedidoOrigem )
            .comDataCompra( dataCompra )
            .comVlrTotal( vlrTotalPedido )
            .comVlrFrete( vlrFrete )
            .comMetodoEnvio( metodoEnvio )
            .comSituacaoECommerce( situacaoECommerce )
            .comNomeDestinatarioEntrega( toText( nodeEndereco, "receiver_name" ) )
            .build();
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // GETTERS
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public Long getIdPedido() {

        return idPedido;
    }

    public Pedido getPedido() {

        return pedido;
    }

    public List<ItemPedido> getItens() {

        return itens;
    }

    public Cliente getCliente() {

        return cliente;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASCODE
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object o ) {

        if ( this == o ) return true;
        if ( !(o instanceof DadosECommerceDto) ) return false;
        DadosECommerceDto that = (DadosECommerceDto) o;
        return Objects.equals(idPedido, that.idPedido);
    }

    @Override
    public int hashCode() {

        return Objects.hash( idPedido );
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // DEFINICÃO DE PEDIDO:
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public class Pedido implements Serializable {

        private Long id;
        private String idPedidoOrigem;
        private BigDecimal vlrTotal;
        private SituacaoPedidoPrincipia situacaoECommerce;
        private LocalDateTime dataCompra;
        private BigDecimal vlrFrete;
        private String nomeDestinatarioEntrega;
        private TipoEntregaECommerce tipoEntregaECommerce;
        private TipoServicoCorreio tipoServicoCorreio;
        private TransportadoraOrigemECommerce transportadoraOrigemECommerce;

        public Pedido( final PedidoBuilder builder ) {

            this.id = builder.id;
            this.idPedidoOrigem = builder.idPedidoOrigem;
            this.vlrTotal = builder.vlrTotal;
            this.situacaoECommerce = builder.situacaoECommerce;
            this.dataCompra = builder.dataCompra;
            this.vlrFrete = builder.vlrFrete;
            this.nomeDestinatarioEntrega = builder.nomeDestinatarioEntrega;
            this.tipoEntregaECommerce = builder.tipoEntregaECommerce;
            this.tipoServicoCorreio = builder.tipoServicoCorreio;
            this.transportadoraOrigemECommerce = builder.transportadoraOrigemECommerce;
        }

        public Long getId() {

            return id;
        }

        public String getIdPedidoOrigem() {

            return idPedidoOrigem;
        }

        public BigDecimal getVlrTotal() {

            return vlrTotal;
        }

        public SituacaoPedidoPrincipia getSituacaoECommerce() {

            return situacaoECommerce;
        }

        public LocalDateTime getDataCompra() {

            return dataCompra;
        }

        public BigDecimal getVlrFrete() {

            return vlrFrete;
        }

        public String getNomeDestinatarioEntrega() {

            return nomeDestinatarioEntrega;
        }

        public TipoEntregaECommerce getTipoEntregaECommerce() {

            return tipoEntregaECommerce;
        }

        public TipoServicoCorreio getTipoServicoCorreio() {

            return tipoServicoCorreio;
        }

        public TransportadoraOrigemECommerce getTransportadoraOrigemECommerce() {

            return transportadoraOrigemECommerce;
        }

        @Override
        public boolean equals( Object o ) {

            if ( this == o ) return true;
            if ( !(o instanceof Pedido) ) return false;
            Pedido pedido = (Pedido) o;
            return Objects.equals(getId(), pedido.getId());
        }

        @Override
        public int hashCode() {

            return Objects.hash( getId() );
        }
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // DEFINICÃO DE ITENS DO PEDIDO:
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public class ItemPedido implements Serializable {

        private final String sku;
        private final Short qtdVendida;
        private final BigDecimal precoUnitario;
        private final BigDecimal precoItem;

        private ItemPedido( final ItemPedidoBuilder builder ) {

            this.sku = builder.sku;
            this.qtdVendida = builder.qtdVendida;
            this.precoUnitario = builder.precoUnitario;
            this.precoItem = multiplicar( this.precoUnitario, this.qtdVendida );
        }

        public String getSku() {

            return sku;
        }

        public Short getQtdVendida() {

            return qtdVendida;
        }

        public BigDecimal getPrecoUnitario() {

            return precoUnitario;
        }

        public BigDecimal getPrecoItem() {

            return precoItem;
        }

        @Override
        public boolean equals( Object o ) {

            if ( this == o ) return true;
            if ( !(o instanceof ItemPedido) ) return false;
            ItemPedido that = (ItemPedido) o;
            return Objects.equals(getSku(), that.getSku());
        }

        @Override
        public int hashCode() {

            return Objects.hash( getSku() );
        }

    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // DEFINICÃO DE DADOS DO CLIENTE:
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public class Cliente implements Serializable {

        private final Long cpf;
        private final String nome;
        private final String email;
        private final Long fone;
        private final Long cep;
        private final String descricaoCidade;
        private final Estado estado;
        private final IdLogradouro logradouro;
        private final String endereco;
        private final String nroEndereco;
        private final String complementoEndereco;
        private final String enderecoReferencia;
        private final String bairro;

        Cliente( final ClienteBuilder builder ) {

            this.cpf = builder.cpf;
            this.nome = builder.nome;
            this.email = builder.email;
            this.fone = builder.fone;
            this.cep = builder.cep;
            this.descricaoCidade = builder.descricaoCidade;
            this.estado = builder.estado;
            this.logradouro = builder.logradouro;
            this.endereco = builder.endereco;
            this.nroEndereco = builder.nroEndereco;
            this.complementoEndereco = builder.complementoEndereco;
            this.enderecoReferencia = builder.enderecoReferencia;
            this.bairro = builder.bairro;
        }

        public Long getCpf() {

            return cpf;
        }

        public String getNome() {

            return nome;
        }

        public String getEmail() {

            return email;
        }

        public Long getFone() {

            return fone;
        }

        public Long getCep() {

            return cep;
        }

        public String getDescricaoCidade() {

            return descricaoCidade;
        }

        public Estado getEstado() {

            return estado;
        }

        public IdLogradouro getLogradouro() {

            return logradouro;
        }

        public String getEndereco() {

            return endereco;
        }

        public String getNroEndereco() {

            return nroEndereco;
        }

        public String getComplementoEndereco() {

            return complementoEndereco;
        }

        public String getEnderecoReferencia() {

            return enderecoReferencia;
        }

        public String getBairro() {

            return bairro;
        }

        @Override
        public boolean equals( final Object o ) {

            if ( this == o ) return true;
            if ( !(o instanceof Cliente) ) return false;
            Cliente cliente = (Cliente) o;
            return Objects.equals(getCpf(), cliente.getCpf());
        }

        @Override
        public int hashCode() {

            return Objects.hash(getCpf());
        }
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // BUILDERS PARA CRIAÇÃO DE OBJETOS.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    private class PedidoBuilder {

        private Long id;
        private String idPedidoOrigem;
        private BigDecimal vlrTotal;
        private BigDecimal vlrFrete;
        private SituacaoPedidoPrincipia situacaoECommerce;
        private LocalDateTime dataCompra;
        private String nomeDestinatarioEntrega;
        private TipoEntregaECommerce tipoEntregaECommerce;
        private TipoServicoCorreio tipoServicoCorreio;
        private TransportadoraOrigemECommerce transportadoraOrigemECommerce;

        PedidoBuilder( final Long id ) {

            this.id = id;
            this.idPedidoOrigem = null;
            this.vlrTotal = ZERO;
            this.vlrFrete = ZERO;
            this.situacaoECommerce = null;
            this.dataCompra = null;
            this.nomeDestinatarioEntrega = null;
            this.tipoEntregaECommerce = null;
            this.tipoServicoCorreio = null;
            this.transportadoraOrigemECommerce = null;
        }

        private PedidoBuilder comIdPedidoOrigem( final String idPedidoOrigem ) {

            this.idPedidoOrigem = idPedidoOrigem;
            return this;
        }

        private PedidoBuilder comVlrTotal( final BigDecimal vlrTotal ) {

            this.vlrTotal = vlrTotal;
            return this;
        }

        private PedidoBuilder comVlrFrete( final BigDecimal vlrFrete ) {

            this.vlrFrete = vlrFrete;
            return this;
        }

        private PedidoBuilder comSituacaoECommerce( final String situacaoECommerce ) {

            this.situacaoECommerce = getEnum( SituacaoPedidoPrincipia.class, situacaoECommerce );
            return this;
        }

        private PedidoBuilder comDataCompra( final LocalDateTime dataCompra ) {

            this.dataCompra = dataCompra;
            return this;
        }

        private PedidoBuilder comMetodoEnvio( final String metodoEnvio ) {

            requireNonEmpty( metodoEnvio, "Tipo de Serviço de Entrega não enviado!!");

            switch ( isEmptyGet(metodoEnvio,"null").toUpperCase() ) {
                case "PAC":
                case "PAC FRETE GRÁTIS":
                case "#PAC PAC":
                case "PAC# PAC":
                    this.tipoEntregaECommerce = CORREIOS;
                    this.tipoServicoCorreio = PAC_CONTRATO_AGENCIA;
                    break;
                case "SEDEX":
                case "SEDEX# SEDEX":
                    this.tipoEntregaECommerce = CORREIOS;
                    this.tipoServicoCorreio = SEDEX_CONTRATO_AGENCIA;
                    break;
                case "EXP# FRENET TRANSPORTADORA TOTAL":
                case "EXP# FRENET FRETE GRÁTIS":
                    this.tipoEntregaECommerce = TRANSPORTADORA;
                    this.transportadoraOrigemECommerce = TransportadoraOrigemECommerce.TOTAL;
                    break;
                default:
                    boolean found = false;
                    final String[] criterios = { "(\\d+)# frenet sedex(.*)", "(\\d*)# frenet pac(.*)" };
                    for ( String regex : criterios ) {
                        final Matcher matcher = Pattern.compile( regex, CASE_INSENSITIVE ).matcher( metodoEnvio );
                        if ( matcher.find() ) {
                            this.tipoEntregaECommerce = CORREIOS;
                            this.tipoServicoCorreio = getEnum(TipoServicoCorreio.class, matcher.group(1));
                            found = true;
                            break;
                        }
                    }
                    if (!found)
                        throw new IllegalStateException( format(
                            "Tipo de Serviço de Entrega [%s] desconhecido!", metodoEnvio
                        ));
            }

            return this;
        }

        private PedidoBuilder comNomeDestinatarioEntrega( final String nomeDestinatarioEntrega ) {

            this.nomeDestinatarioEntrega = removerAcentosECaracteresEspeciais( toUpperCase( nomeDestinatarioEntrega ) );
            return this;
        }

        private Pedido build() {

            return new Pedido( this );
        }

    }

    private class ItemPedidoBuilder {

        private final String sku;
        private Short qtdVendida;
        private BigDecimal precoUnitario;

        ItemPedidoBuilder( final String sku ) {

            requireNonEmpty( sku, "Obrigatório informar [ sku ]" );

            this.sku = sku;
            this.qtdVendida = 0;
            this.precoUnitario = ZERO;
        }

        private ItemPedidoBuilder comQtdeVendida( final Short qtdVendida ) {

            this.qtdVendida = qtdVendida;
            return this;
        }

        private ItemPedidoBuilder comPrecoUnitario( final BigDecimal precoUnitario ) {

            if ( precoUnitario != null )
                this.precoUnitario = precoUnitario.setScale(2, ROUND_DOWN );

            return this;
        }

        private ItemPedido build() {

            return new ItemPedido( this );
        }
    }

    private class ClienteBuilder {

        private final Long cpf;
        private String nome;
        private String email;
        private Long fone;
        private Long cep;
        private String descricaoCidade;
        private Estado estado;
        private IdLogradouro logradouro;
        private String endereco;
        private String nroEndereco;
        private String complementoEndereco;
        private String enderecoReferencia;
        private String bairro;

        ClienteBuilder( final String cpf ) {

            requireNonEmpty( cpf, "CPF do cliente inválido" );

            this.cpf = toLong( cpf.replaceAll( "-", "" ) )
                        .orElseThrow( () -> new IllegalArgumentException( format (
                            "Nro do CPF inválido: %s", cpf
                        )));
            this.nome = null;
            this.email = null;
            this.fone = null;
            this.cep = null;
            this.descricaoCidade = null;
            this.estado = null;
            this.logradouro = null;
            this.endereco = null;
            this.nroEndereco = null;
            this.complementoEndereco = null;
            this.enderecoReferencia = null;
            this.bairro = null;
        }

        private ClienteBuilder comNome( final String nome ) {

            this.nome = toUpperCase( removerAcentosECaracteresEspeciais( nome ) );
            return this;
        }

        private ClienteBuilder comEmail( final String email ) {

            this.email = email;
            return this;
        }

        private ClienteBuilder comFone( final String fone ) {

            if ( !isVazia(fone) && apenasNumero(fone) )
                this.fone = convLong( fone.substring(2) );

            return this;
        }

        private ClienteBuilder comCep( final String cep ) {

            this.cep = convLong( cep );
            return this;
        }

        private ClienteBuilder comDescricaoCidade( final String descricaoCidade ) {

            this.descricaoCidade = toUpperCase( removerAcentosECaracteresEspeciais( descricaoCidade ) );
            return this;
        }

        private ClienteBuilder comEstado( final String estado ) {

            this.estado = getEnum( Estado.class, estado );
            return this;
        }

        private ClienteBuilder comEndereco( final String endereco ) {

            this.logradouro = traduzLogradouroECommerce( primeiraPalavra(endereco) ).orElse(null );
            this.endereco = this.logradouro != null
                ? trim( toUpperCase( removerAcentosECaracteresEspeciais( excluirPrimeiraPalavra( endereco ) ) ) )
                : toUpperCase( removerAcentosECaracteresEspeciais( endereco ) );
            return this;
        }

        private ClienteBuilder comNroEndereco( final Short nroEndereco ) {

            this.nroEndereco = nroEndereco != null ? nroEndereco.toString() : null;
            return this;
        }

        private ClienteBuilder comComplementoEndereco( final String complementoEndereco ) {

            this.complementoEndereco = toUpperCase( removerAcentosECaracteresEspeciais( complementoEndereco ) );
            return this;
        }

        private ClienteBuilder comEnderecoReferencia( final String enderecoReferencia ) {

            this.enderecoReferencia = toUpperCase( removerAcentosECaracteresEspeciais( enderecoReferencia ) );
            return this;
        }

        private ClienteBuilder comBairro( final String bairro ) {

            this.bairro = toUpperCase( removerAcentosECaracteresEspeciais( bairro ) );
            return this;
        }

        private Cliente build() {

            return new Cliente( this );
        }
    }
}
