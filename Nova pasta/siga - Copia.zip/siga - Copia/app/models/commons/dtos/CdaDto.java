package models.commons.dtos;

import models.commons.constantes.TipoCda;

import java.io.Serializable;

/**
 * Classe que representa informações reduzidas do Cda
 *
 * <p>Autor: GPortes</p>
 *
 * @since 13/03/2017
 */
public class CdaDto implements Serializable {

    private final Short idEmpresa;
    private final Short idCda;
    private final TipoCda tipo;
    private final String descricao;

    public CdaDto( final Short idEmpresa,
                   final Short idCda,
                   final TipoCda tipo,
                   final String descricao ) {

        this.idEmpresa = idEmpresa;
        this.idCda = idCda;
        this.tipo = tipo;
        this.descricao = descricao;
    }

    public Short getIdEmpresa( ) {

        return idEmpresa;
    }

    public Short getIdCda( ) {

        return idCda;
    }

    public TipoCda getTipo( ) {

        return tipo;
    }

    public String getDescricao( ) {

        return descricao;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object o ) {
        if ( this == o ) return true;
        if ( o == null || getClass( ) != o.getClass( ) ) return false;

        CdaDto cdaDto = (CdaDto) o;

        if ( getIdEmpresa( ) != null ? !getIdEmpresa( ).equals( cdaDto.getIdEmpresa( ) ) : cdaDto.getIdEmpresa( ) != null )
            return false;
        return getIdCda( ) != null ? getIdCda( ).equals( cdaDto.getIdCda( ) ) : cdaDto.getIdCda( ) == null;
    }

    @Override
    public int hashCode( ) {
        int result = getIdEmpresa( ) != null ? getIdEmpresa( ).hashCode( ) : 0;
        result = 31 * result + ( getIdCda( ) != null ? getIdCda( ).hashCode( ) : 0 );
        return result;
    }

    @Override
    public String toString( ) {
        return "CdaDto{" +
                "idEmpresa=" + idEmpresa +
                ", idCda=" + idCda +
                '}';
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}


