package models.commons.dtos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import infra.jsonDeserializer.LocalDateTimeSerializer;
import infra.util.UtilDate;

import static infra.util.UtilDate.toLocalDateTime;

/**
 * Classe que representa informações...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 07/11/2018
 */
public class ClienteDebitoNegociadoDto implements Serializable {

    private final Long cliente;
    private final String boletoOriginal;
    private final String boleto;
    private final Long seqDebito;
    private final BigDecimal vlrDocumento;
    private final BigDecimal vlrJuro;
    private final LocalDateTime dataNegociacao;
    private final LocalDateTime dataVencimento;


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CONSTRUCTOR
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public ClienteDebitoNegociadoDto(
        final Long cliente,
        final String boletoOriginal,
        final String boleto,
        final Long seqDebito,
        final BigDecimal vlrDocumento,
        final BigDecimal vlrJuro,
        final Date dataNegociacao,
        final Date dataVencimento
    ) {

        this.cliente = cliente;
        this.boletoOriginal = boletoOriginal;
        this.boleto = boleto;
        this.seqDebito = seqDebito;
        this.vlrDocumento = vlrDocumento;
        this.vlrJuro = vlrJuro;
        this.dataNegociacao = toLocalDateTime(dataNegociacao);
        this.dataVencimento = toLocalDateTime(dataVencimento);
    }

    @JsonProperty( "cliente" )
    public Long getCliente() {

        return this.cliente;
    }

    @JsonProperty( "boletoOriginal" )
    public String getBoletoOriginal() {

        return this.boletoOriginal;
    }

    @JsonProperty( "boleto" )
    public String getBoleto() {

        return this.boleto;
    }

    @JsonProperty( "seqDebito" )
    public Long getSeqDebito() {

        return this.seqDebito;
    }

    @JsonProperty( "vlrDocumento" )
    public BigDecimal getVlrDocumento() {

        return this.vlrDocumento;
    }

    @JsonProperty( "vlrJuro" )
    public BigDecimal getVlrJuro() {

        return this.vlrJuro;
    }

    @JsonProperty( "dataNegociacao" )
    @JsonSerialize( using = LocalDateTimeSerializer.class )
    public LocalDateTime getDataNegociacao() {

        return this.dataNegociacao;
    }

    @JsonProperty( "dataVencimento" )
    @JsonSerialize( using = LocalDateTimeSerializer.class )
    public LocalDateTime getDataVencimento() {

        return this.dataVencimento;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object o ) {

        if ( this == o ) return true;
        if ( !(o instanceof ClienteDebitoNegociadoDto) ) return false;
        ClienteDebitoNegociadoDto that = (ClienteDebitoNegociadoDto) o;
        return Objects.equals(getCliente(), that.getCliente()) &&
                Objects.equals(getBoletoOriginal(), that.getBoletoOriginal()) &&
                Objects.equals(getBoleto(), that.getBoleto()) &&
                Objects.equals(getSeqDebito(), that.getSeqDebito());
    }

    @Override
    public int hashCode() {

        return Objects.hash(getCliente(), getBoletoOriginal(), getBoleto(), getSeqDebito());
    }
}
