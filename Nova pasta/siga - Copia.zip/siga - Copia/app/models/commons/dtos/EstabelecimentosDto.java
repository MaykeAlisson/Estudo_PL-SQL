package models.commons.dtos;

import infra.model.Model;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Classe que representa informaþ§es...
 *
 * <p>Autor: Fernandopti</p>
 *
 * @since 18/10/2017
 */
public class EstabelecimentosDto extends Model implements Serializable {

    private Short idEmpresa;
    private Short tipoPessoa;
    private BigDecimal cnpj;
    private Long cnae;
    private BigDecimal aliqRat;
    private BigDecimal fap;
    private Long tipoProcessoRat;
    private String nroProcessoRat;
    private BigDecimal codSuspensaoRat;
    private Long tipoProcessoFap;
    private String nroProcessoFap;
    private BigDecimal codSuspensaoFap;
    private Long tpCaepf;
    private Short pontoEletronico;
    private Short indAprendiz;
    private String nroProcessoDispensaAprendiz;
    private String contrataPorEntidade;
    private Short indContratacaoPcd;


    public Short getIdEmpresa() {
        return idEmpresa;
    }

    public void setIdEmpresa(Short idEmpresa) {
        this.idEmpresa = idEmpresa;
    }

    public Short getTipoPessoa() {
        return tipoPessoa;
    }

    public void setTipoPessoa(Short tipoPessoa) {
        this.tipoPessoa = tipoPessoa;
    }

    public BigDecimal getCnpj() {
        return cnpj;
    }

    public void setCnpj(BigDecimal cnpj) {
        this.cnpj = cnpj;
    }

    public Long getCnae() {
        return cnae;
    }

    public void setCnae(Long cnae) {
        this.cnae = cnae;
    }

    public BigDecimal getAliqRat() {
        return aliqRat;
    }

    public void setAliqRat(BigDecimal aliqRat) {
        this.aliqRat = aliqRat;
    }

    public BigDecimal getFap() {
        return fap;
    }

    public void setFap(BigDecimal fap) {
        this.fap = fap;
    }

    public Long getTipoProcessoRat() {
        return tipoProcessoRat;
    }

    public void setTipoProcessoRat(Long tipoProcessoRat) {
        this.tipoProcessoRat = tipoProcessoRat;
    }

    public String getNroProcessoRat() {
        return nroProcessoRat;
    }

    public void setNroProcessoRat(String nroProcessoRat) {
        this.nroProcessoRat = nroProcessoRat;
    }

    public BigDecimal getCodSuspensaoRat() {
        return codSuspensaoRat;
    }

    public void setCodSuspensaoRat(BigDecimal codSuspensaoRat) {
        this.codSuspensaoRat = codSuspensaoRat;
    }

    public Long getTipoProcessoFap() {
        return tipoProcessoFap;
    }

    public void setTipoProcessoFap(Long tipoProcessoFap) {
        this.tipoProcessoFap = tipoProcessoFap;
    }

    public String getNroProcessoFap() {
        return nroProcessoFap;
    }

    public void setNroProcessoFap(String nroProcessoFap) {
        this.nroProcessoFap = nroProcessoFap;
    }

    public BigDecimal getCodSuspensaoFap() {
        return codSuspensaoFap;
    }

    public void setCodSuspensaoFap(BigDecimal codSuspensaoFap) {
        this.codSuspensaoFap = codSuspensaoFap;
    }

    public Long getTpCaepf() {
        return tpCaepf;
    }

    public void setTpCaepf(Long tpCaepf) {
        this.tpCaepf = tpCaepf;
    }

    public Short getPontoEletronico() {
        return pontoEletronico;
    }

    public void setPontoEletronico(Short pontoEletronico) {
        this.pontoEletronico = pontoEletronico;
    }

    public Short getIndAprendiz() {
        return indAprendiz;
    }

    public void setIndAprendiz(Short indAprendiz) {
        this.indAprendiz = indAprendiz;
    }

    public String getNroProcessoDispensaAprendiz() {
        return nroProcessoDispensaAprendiz;
    }

    public void setNroProcessoDispensaAprendiz(String nroProcessoDispensaAprendiz) {
        this.nroProcessoDispensaAprendiz = nroProcessoDispensaAprendiz;
    }

    public String getContrataPorEntidade() {
        return contrataPorEntidade;
    }

    public void setContrataPorEntidade(String contrataPorEntidade) {
        this.contrataPorEntidade = contrataPorEntidade;
    }

    public Short getIndContratacaoPcd() {
        return indContratacaoPcd;
    }

    public void setIndContratacaoPcd(Short indContratacaoPcd) {
        this.indContratacaoPcd = indContratacaoPcd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        EstabelecimentosDto that = (EstabelecimentosDto) o;

        if (idEmpresa != null ? !idEmpresa.equals(that.idEmpresa) : that.idEmpresa != null) return false;
        if (tipoPessoa != null ? !tipoPessoa.equals(that.tipoPessoa) : that.tipoPessoa != null) return false;
        if (cnpj != null ? !cnpj.equals(that.cnpj) : that.cnpj != null) return false;
        if (cnae != null ? !cnae.equals(that.cnae) : that.cnae != null) return false;
        if (aliqRat != null ? !aliqRat.equals(that.aliqRat) : that.aliqRat != null) return false;
        if (fap != null ? !fap.equals(that.fap) : that.fap != null) return false;
        if (tipoProcessoRat != null ? !tipoProcessoRat.equals(that.tipoProcessoRat) : that.tipoProcessoRat != null)
            return false;
        if (nroProcessoRat != null ? !nroProcessoRat.equals(that.nroProcessoRat) : that.nroProcessoRat != null)
            return false;
        if (codSuspensaoRat != null ? !codSuspensaoRat.equals(that.codSuspensaoRat) : that.codSuspensaoRat != null)
            return false;
        if (tipoProcessoFap != null ? !tipoProcessoFap.equals(that.tipoProcessoFap) : that.tipoProcessoFap != null)
            return false;
        if (nroProcessoFap != null ? !nroProcessoFap.equals(that.nroProcessoFap) : that.nroProcessoFap != null)
            return false;
        if (codSuspensaoFap != null ? !codSuspensaoFap.equals(that.codSuspensaoFap) : that.codSuspensaoFap != null)
            return false;
        if (tpCaepf != null ? !tpCaepf.equals(that.tpCaepf) : that.tpCaepf != null) return false;
        if (pontoEletronico != null ? !pontoEletronico.equals(that.pontoEletronico) : that.pontoEletronico != null)
            return false;
        if (indAprendiz != null ? !indAprendiz.equals(that.indAprendiz) : that.indAprendiz != null) return false;
        if (nroProcessoDispensaAprendiz != null ? !nroProcessoDispensaAprendiz.equals(that.nroProcessoDispensaAprendiz) : that.nroProcessoDispensaAprendiz != null)
            return false;
        if (contrataPorEntidade != null ? !contrataPorEntidade.equals(that.contrataPorEntidade) : that.contrataPorEntidade != null)
            return false;
        return indContratacaoPcd != null ? indContratacaoPcd.equals(that.indContratacaoPcd) : that.indContratacaoPcd == null;
    }

    @Override
    public int hashCode() {
        int result = idEmpresa != null ? idEmpresa.hashCode() : 0;
        result = 31 * result + (tipoPessoa != null ? tipoPessoa.hashCode() : 0);
        result = 31 * result + (cnpj != null ? cnpj.hashCode() : 0);
        result = 31 * result + (cnae != null ? cnae.hashCode() : 0);
        result = 31 * result + (aliqRat != null ? aliqRat.hashCode() : 0);
        result = 31 * result + (fap != null ? fap.hashCode() : 0);
        result = 31 * result + (tipoProcessoRat != null ? tipoProcessoRat.hashCode() : 0);
        result = 31 * result + (nroProcessoRat != null ? nroProcessoRat.hashCode() : 0);
        result = 31 * result + (codSuspensaoRat != null ? codSuspensaoRat.hashCode() : 0);
        result = 31 * result + (tipoProcessoFap != null ? tipoProcessoFap.hashCode() : 0);
        result = 31 * result + (nroProcessoFap != null ? nroProcessoFap.hashCode() : 0);
        result = 31 * result + (codSuspensaoFap != null ? codSuspensaoFap.hashCode() : 0);
        result = 31 * result + (tpCaepf != null ? tpCaepf.hashCode() : 0);
        result = 31 * result + (pontoEletronico != null ? pontoEletronico.hashCode() : 0);
        result = 31 * result + (indAprendiz != null ? indAprendiz.hashCode() : 0);
        result = 31 * result + (nroProcessoDispensaAprendiz != null ? nroProcessoDispensaAprendiz.hashCode() : 0);
        result = 31 * result + (contrataPorEntidade != null ? contrataPorEntidade.hashCode() : 0);
        result = 31 * result + (indContratacaoPcd != null ? indContratacaoPcd.hashCode() : 0);
        return result;
    }
}
