package models.commons.dtos;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;
import models.domains.ebitda.DetalheCusto;

import static infra.util.UtilCollections.isVazia;
import static java.util.Comparator.comparing;

/**
 * Classe que representa informações...
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 29/05/2019
 */
public class EventoCriticoRastreadorDto implements Serializable {


    private  String gerTran;
    private  String email;
    private  Short veiculo;
    private  String evento;
    private  Long qtdEvento;

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CONSTRUCTOR
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    public EventoCriticoRastreadorDto() {
    }

    public EventoCriticoRastreadorDto(
            final String gerTran,
            final String email,
            final Short veiculo,
            final String evento,
            final Long qtdEvento
    ) {

        this.gerTran = gerTran;
        this.email = email;
        this.veiculo = veiculo;
        this.evento = evento;
        this.qtdEvento = qtdEvento;
    }

    @JsonProperty( "gerTran" )
    public String getGerTran() {

        return this.gerTran;
    }

    @JsonProperty( "email" )
    public String getEmail() {

        return this.email;
    }

    @JsonProperty( "veiculo" )
    public Short getVeiculo() {

        return this.veiculo;
    }

    @JsonProperty( "Evento" )
    public String getEvento() {

        return this.evento;
    }

    @JsonProperty( "qtdEvento" )
    public Long getQtdEvento() {

        return this.qtdEvento;
    }

    public void setGerTran(String gerTran) {
        this.gerTran = gerTran;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setVeiculo(Short veiculo) {
        this.veiculo = veiculo;
    }

    public void setEvento(String evento) {
        this.evento = evento;
    }

    public void setQtdEvento(Long qtdEvento) {
        this.qtdEvento = qtdEvento;
    }

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof EventoCriticoRastreadorDto)) return false;
        EventoCriticoRastreadorDto that = (EventoCriticoRastreadorDto) o;
        return Objects.equals(getGerTran(), that.getGerTran()) &&
                Objects.equals(getVeiculo(), that.getVeiculo()) &&
                Objects.equals(getEvento(), that.getEvento()) &&
                Objects.equals(getQtdEvento(), that.getQtdEvento());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getGerTran(), getVeiculo(), getEvento(), getQtdEvento());
    }

    @Override
    public String toString() {
        return "EventoCriticoRastreadorDto{" +
                "gerTran='" + gerTran + '\'' +
                ", email='" + email + '\'' +
                ", veiculo=" + veiculo +
                ", evento='" + evento + '\'' +
                ", qtdEvento=" + qtdEvento +
                '}';
    }


    public static void sortPorVeiculo(List<EventoCriticoRastreadorDto> eventoCriticoRastreadorDtos) {

        if ( !isVazia(eventoCriticoRastreadorDtos) )
            eventoCriticoRastreadorDtos.sort( comparing(EventoCriticoRastreadorDto::getVeiculo) );
    }

}
