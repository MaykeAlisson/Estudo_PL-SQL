package models.commons.dtos;

import java.io.Serializable;
import java.util.Objects;

/**
 * Classe ref. a info. de consolidação de cargas antecipadas pendentes.
 *
 * <p>Autor: Cleber</p>
 *
 * @since  22/08/2014.
 */
public class ConsolidacaoCargaAntecipadaPendenteDto implements Serializable {

    private final Long idCarga;
    private final Long sequenciaDeBaixa;
    private final String boxOrigem;
    private final String boxDestino;
    private final String tipoBox;

    public ConsolidacaoCargaAntecipadaPendenteDto( final Long idCarga,
                                                   final Long sequenciaDeBaixa,
                                                   final String boxOrigem,
                                                   final String boxDestino,
                                                   final String tipoBox) {

        this.idCarga = idCarga;
        this.sequenciaDeBaixa = sequenciaDeBaixa;
        this.boxOrigem = boxOrigem;
        this.boxDestino = boxDestino;
        this.tipoBox = tipoBox;
    }

    public Long getIdCarga() {
        return idCarga;
    }

    public Long getSequenciaDeBaixa() {
        return sequenciaDeBaixa;
    }

    public String getBoxOrigem() {
        return boxOrigem;
    }

    public String getBoxDestino() {
        return boxDestino;
    }

    public String getTipoBox() {
        return tipoBox;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASHCODE.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object o ) {

        if ( this == o ) return true;
        if ( !(o instanceof ConsolidacaoCargaAntecipadaPendenteDto) ) return false;
        ConsolidacaoCargaAntecipadaPendenteDto that = (ConsolidacaoCargaAntecipadaPendenteDto) o;
        return Objects.equals(getIdCarga(), that.getIdCarga()) &&
                Objects.equals(getSequenciaDeBaixa(), that.getSequenciaDeBaixa()) &&
                Objects.equals(getBoxOrigem(), that.getBoxOrigem()) &&
                Objects.equals(getBoxDestino(), that.getBoxDestino()) &&
                Objects.equals(getTipoBox(), that.getTipoBox());
    }

    @Override
    public int hashCode() {

        return Objects.hash(getIdCarga(), getSequenciaDeBaixa(), getBoxOrigem(), getBoxDestino(), getTipoBox());
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}
