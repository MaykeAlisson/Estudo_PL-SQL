package models.commons.dtos;

import infra.model.Model;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Classe que representa informaþ§es...
 *
 * <p>Autor: Fernandopti</p>
 *
 * @since 17/10/2017
 */
public class CargoDto extends Model implements Serializable {

    private Short idEmpresa;
    private Short tipoPessoa;
    private BigDecimal cnpj;
    private Long funcao;
    private String descFuncao;
    private Long cbo;

    public Short getIdEmpresa() {

        return this.idEmpresa;
    }

    public void setIdEmpresa( final Short idEmpresa ) {

        this.idEmpresa = idEmpresa;
    }

    public Short getTipoPessoa() {

        return this.tipoPessoa;
    }

    public void setTipoPessoa( final Short tipoPessoa ) {

        this.tipoPessoa = tipoPessoa;
    }

    public BigDecimal getCnpj() {

        return this.cnpj;
    }

    public void setCnpj( final BigDecimal cnpj ) {

        this.cnpj = cnpj;
    }

    public Long getFuncao() {

        return this.funcao;
    }

    public void setFuncao( final Long funcao ) {

        this.funcao = funcao;
    }

    public String getDescFuncao() {

        return this.descFuncao;
    }

    public void setDescFuncao( final String descFuncao ) {

        this.descFuncao = descFuncao;
    }

    public Long getCbo() {

        return this.cbo;
    }

    public void setCbo( final Long cbo ) {

        this.cbo = cbo;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASCODE
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CargoDto cargoDto = (CargoDto) o;

        if (idEmpresa != null ? !idEmpresa.equals(cargoDto.idEmpresa) : cargoDto.idEmpresa != null) return false;
        if (tipoPessoa != null ? !tipoPessoa.equals(cargoDto.tipoPessoa) : cargoDto.tipoPessoa != null) return false;
        if (cnpj != null ? !cnpj.equals(cargoDto.cnpj) : cargoDto.cnpj != null) return false;
        if (funcao != null ? !funcao.equals(cargoDto.funcao) : cargoDto.funcao != null) return false;
        if (descFuncao != null ? !descFuncao.equals(cargoDto.descFuncao) : cargoDto.descFuncao != null) return false;
        return cbo != null ? cbo.equals(cargoDto.cbo) : cargoDto.cbo == null;
    }

    @Override
    public int hashCode() {
        int result = idEmpresa != null ? idEmpresa.hashCode() : 0;
        result = 31 * result + (tipoPessoa != null ? tipoPessoa.hashCode() : 0);
        result = 31 * result + (cnpj != null ? cnpj.hashCode() : 0);
        result = 31 * result + (funcao != null ? funcao.hashCode() : 0);
        result = 31 * result + (descFuncao != null ? descFuncao.hashCode() : 0);
        result = 31 * result + (cbo != null ? cbo.hashCode() : 0);
        return result;
    }
}
