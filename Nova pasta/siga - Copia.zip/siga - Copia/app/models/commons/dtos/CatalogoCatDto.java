package models.commons.dtos;

import infra.model.Model;

import java.io.Serializable;
import java.util.Objects;

public class CatalogoCatDto implements Serializable {

    private String codigo;
    private String descricao;

    public String getCodigo() {
        return codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public CatalogoCatDto(String codigo, String descricao) {
        this.codigo = codigo;
        this.descricao = descricao;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CatalogoCatDto)) return false;
        CatalogoCatDto that = (CatalogoCatDto) o;
        return Objects.equals(getCodigo(), that.getCodigo()) &&
                Objects.equals(getDescricao(), that.getDescricao());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getCodigo(), getDescricao());
    }
}