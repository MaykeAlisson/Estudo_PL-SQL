package models.commons.dtos;

import infra.util.UtilNumero;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import static infra.util.UtilCollections.isVazia;
import static java.util.Comparator.comparing;

/**
 * Classe que representa informações...
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 27/12/2017
 */
public class CleberProdutividadeEstoqueDto implements Serializable {

    private String tipo;
    private Long idLote;
    private String numeroVoco;
    private Short turno;
    private Long equipe;
    private Long setorSeparacao;
    private String dispositivo;
    private Long separador;
    private String nome;
    private Date dataInicioTarefa;
    private Date dataFimTarefa;
    private Date dataPrimeiraBalanca;
    private Date dataUltimaBalanca;
    private Long qtdRecipiente;
    private BigDecimal totalItens;
    private BigDecimal itensSeparacaoCliente;
    private BigDecimal itensSeparacaoMista;
    private String statusErro;
    private String erroSeparador;
    private Long primeiroSetor;
    private Long ultimoSetor;
    private Date dataTratadaInicioTarefa;
    private Date dataTratadaFimTarefa;
    private Date dataTratadaFimBalanca;
    private Long tempoSeparacao;
    private Long tempoBalanca;
    private Long tempoSegundosPorItemSeparado;
    private String observacao;
    private boolean descarte;

    public Long getSetorSeparacao() {
        return setorSeparacao;
    }

    public void setSetorSeparacao(Long setorSeparacao) {
        this.setorSeparacao = setorSeparacao;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Long getIdLote() {
        return idLote;
    }

    public void setIdLote(Long idLote) {
        this.idLote = idLote;
    }

    public String getNumeroVoco() {

        return this.numeroVoco;
    }

    public void setNumeroVoco( final String numeroVoco ) {

        this.numeroVoco = numeroVoco;
    }

    public Short getTurno() {

        return this.turno;
    }

    public void setTurno( final Short turno ) {

        this.turno = turno;
    }

    public String getDispositivo() {

        return this.dispositivo;
    }

    public void setDispositivo( final String dispositivo ) {

        this.dispositivo = dispositivo;
    }

    public Long getSeparador() {

        return this.separador == null ?  0L : this.separador;
    }

    public void setSeparador( final Long separador ) {

        this.separador = separador;
    }

    public String getNome() {

        return this.nome;
    }

    public void setNome( final String nome ) {

        this.nome = nome;
    }

    public Date getDataPrimeiraBalanca() {

        return this.dataPrimeiraBalanca;
    }

    public void setDataPrimeiraBalanca( final Date dataPrimeiraBalanca ) {

        this.dataPrimeiraBalanca = dataPrimeiraBalanca;
    }

    public Date getDataUltimaBalanca() {

        return this.dataUltimaBalanca;
    }

    public void setDataUltimaBalanca( final Date dataUltimaBalanca ) {

        this.dataUltimaBalanca = dataUltimaBalanca;
    }

    public Long getQtdRecipiente() {

        return this.qtdRecipiente;
    }

    public void setQtdRecipiente( final Long qtdRecipiente ) {

        this.qtdRecipiente = qtdRecipiente;
    }

    public BigDecimal getTotalItens() {

        return this.totalItens;
    }

    public void setTotalItens( final BigDecimal totalItens ) {

        this.totalItens = totalItens;
    }

    public BigDecimal getItensSeparacaoCliente() {

        return this.itensSeparacaoCliente;
    }

    public void setItensSeparacaoCliente( final BigDecimal itensSeparacaoCliente ) {

        this.itensSeparacaoCliente = itensSeparacaoCliente;
    }

    public BigDecimal getItensSeparacaoMista() {

        return this.itensSeparacaoMista;
    }

    public void setItensSeparacaoMista( final BigDecimal itensSeparacaoMista ) {

        this.itensSeparacaoMista = itensSeparacaoMista;
    }

    public Date getDataInicioTarefa() {
        return dataInicioTarefa;
    }

    public void setDataInicioTarefa(Date dataInicioTarefa) {
        this.dataInicioTarefa = dataInicioTarefa;
    }

    public Date getDataFimTarefa() {
        return dataFimTarefa;
    }

    public void setDataFimTarefa(Date dataFimTarefa) {
        this.dataFimTarefa = dataFimTarefa;
    }

    public String getStatusErro() {
        return statusErro;
    }

    public void setStatusErro(String statusErro) {
        this.statusErro = statusErro;
    }

    public String getErroSeparador() {
        return erroSeparador;
    }

    public void setErroSeparador(String erroSeparador) {
        this.erroSeparador = erroSeparador;
    }

    public Date getDataTratadaInicioTarefa() {
        return dataTratadaInicioTarefa;
    }

    public void setDataTratadaInicioTarefa(Date dataTratadaInicioTarefa) {
        this.dataTratadaInicioTarefa = dataTratadaInicioTarefa;
    }

    public Date getDataTratadaFimTarefa() {
        return dataTratadaFimTarefa;
    }

    public void setDataTratadaFimTarefa(Date dataTratadaFimTarefa) {
        this.dataTratadaFimTarefa = dataTratadaFimTarefa;
    }

    public Date getDataTratadaFimBalanca() {
        return dataTratadaFimBalanca;
    }

    public void setDataTratadaFimBalanca(Date dataTratadaFimBalanca) {
        this.dataTratadaFimBalanca = dataTratadaFimBalanca;
    }

    public Long getTempoSeparacao() {
        return tempoSeparacao;
    }

    public void setTempoSeparacao(Long tempoSeparacao) {
        this.tempoSeparacao = tempoSeparacao;
    }

    public Long getTempoBalanca() {
        return tempoBalanca;
    }

    public void setTempoBalanca(Long tempoBalanca) {
        this.tempoBalanca = tempoBalanca;
    }

    public Long getTempoSegundosPorItemSeparado() {
        return tempoSegundosPorItemSeparado;
    }

    public void setTempoSegundosPorItemSeparado(Long tempoSegundosPorItemSeparado) {
        this.tempoSegundosPorItemSeparado = tempoSegundosPorItemSeparado;
    }

    public String getObservacao() {
        return observacao == null ? "" : observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = this.observacao == null ? observacao : this.observacao + " - " + observacao;
    }

    public Long getPrimeiroSetor() {
        return primeiroSetor == null ? 0L : primeiroSetor;
    }

    public void setPrimeiroSetor(Long primeiroSetor) {
        this.primeiroSetor = primeiroSetor;
    }

    public Long getUltimoSetor() {
        return ultimoSetor == null ? 0L : ultimoSetor;
    }

    public void setUltimoSetor(Long ultimoSetor) {
        this.ultimoSetor = ultimoSetor;
    }

    public boolean isDescarte() {
        return descarte;
    }

    public void setDescarte(boolean descarte) {
        this.descarte = descarte;
    }

    public Long getEquipe() {
        return equipe;
    }

    public void setEquipe(Long equipe) {
        this.equipe = equipe;
    }

    public String getTipoSetor() {

        if (getPrimeiroSetor() == 0L || getUltimoSetor() == 0L) return "Outros";

        if (getPrimeiroSetor() >= 126L  && getUltimoSetor() <= 207L)  return "Sandalia";

        return "Fracionado";
    }

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASCODE
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CleberProdutividadeEstoqueDto)) return false;
        CleberProdutividadeEstoqueDto that = (CleberProdutividadeEstoqueDto) o;
        return Objects.equals(getIdLote(), that.getIdLote()) &&
                Objects.equals(getNumeroVoco(), that.getNumeroVoco()) &&
                Objects.equals(getTurno(), that.getTurno()) &&
                Objects.equals(getEquipe(), that.getEquipe()) &&
                Objects.equals(getDispositivo(), that.getDispositivo()) &&
                Objects.equals(getSeparador(), that.getSeparador()) &&
                Objects.equals(getNome(), that.getNome()) &&
                Objects.equals(getDataInicioTarefa(), that.getDataInicioTarefa()) &&
                Objects.equals(getDataFimTarefa(), that.getDataFimTarefa()) &&
                Objects.equals(getDataPrimeiraBalanca(), that.getDataPrimeiraBalanca());
    }

    @Override
    public int hashCode() {

        return Objects.hash(getIdLote(), getNumeroVoco(), getTurno(), getEquipe(), getDispositivo(), getSeparador(), getNome(), getDataInicioTarefa(), getDataFimTarefa(), getDataPrimeiraBalanca());
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODO AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public static void sortPorFuncionarioHorario(List<CleberProdutividadeEstoqueDto> lista) {

        if ( !isVazia(lista) )
            lista.sort(
                comparing(CleberProdutividadeEstoqueDto::getSeparador)
                .thenComparing(CleberProdutividadeEstoqueDto::getDataInicioTarefa)
            );
    }

}
