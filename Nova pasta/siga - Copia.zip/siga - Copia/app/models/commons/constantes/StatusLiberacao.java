package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de  Coluna status_liberacao tabela controle_liberacao_antecipacao...
 *
 * <p>Autor: Andre Luiz Alves de Faria </p>
 *
 * @since 19/07/2018
 */
public enum StatusLiberacao implements Constante<Short> {

    /**
     * 1
     */
    LIBERACAO_PARCIAL( "LIBERACAO PARCIAL", (short) 1 ),

    /**
     * 2
     */
    CONSOLIDADO( "CONSOLIDADO", (short) 2 ),

    /**
     * 3
     */
    LIBERADO_ENTREGA_BOX_LIBERACAO( "LIBERADO ENTREGA BOX LIBERACAO", (short) 3 ),

    /**
     * 4
     */
    ENTREGUE_BOX_LIBERACAO( "ENTREGUE BOX LIBERACAO", (short) 4 ),

    /**
     * 5
     */
    LIBERADO_ENTREGA_BOX_CARREGAMENTO( "LIBERADO ENTREGA BOX CARREGAMENTO", (short) 5 ),

    /**
     * 6
     */
    ENTREGUE_BOX_CARREGAMENTO( "ENTREGUE BOX CARREGAMENTO", (short) 6 ),

    /**
     * 7
     */
    FINALIZADO( "FINALIZADO", (short) 7 )
    ;

    private final String descricao;
    private final Short valor;

    StatusLiberacao(
        final String descricao,
        final Short valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public Short getValor() {

        return this.valor;
    }

    public static StatusLiberacao getInstance( Short valor ){
        for ( StatusLiberacao statusLiberacao: StatusLiberacao.values()){
            if ( statusLiberacao.getValor().equals( valor )){
                return statusLiberacao;
            }
        }
        return null;
    }
}

