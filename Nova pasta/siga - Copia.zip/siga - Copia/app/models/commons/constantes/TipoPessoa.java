package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de tipos de pessoas.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 08/09/2014
 */
public enum TipoPessoa implements Constante<Short> {

    /**
     * 1
     */
    JURIDICA("JURIDICA", (short) 1 ),

    /**
     * 2
     */
    FISICA("FISICA", (short) 2 ),

    /**
     * 3
     */
    PRODUTOR_RURAL("PRODUTOR RURAL", (short) 3 ),

    /**
     * 4
     */
    CEI("CEI", (short) 4 )

    ;

    private String descricao;
    private Short valor;

    TipoPessoa(
        final String descricao,
        final Short valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public Short getValor() {

        return valor;
    }

}
