package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de situações de carregamento
 *
 * <p>Autor: Jander Dutra</p>
 *
 * @since 14/03/2019
 */
public enum SituacaoCarregamento implements Constante<String> {

    /**
     * "A"
     */
    AGUARDANDO_CARREGAMENTO("AGUARDANDO CARREGAMENTO","A"),

    /**
     * "C"
     */
    CARREGADO("CARREGADO","C");

    private String chave;
    private String descricao;

    private SituacaoCarregamento(String descricao, String valor) {
        this.descricao = descricao;
        this.chave = valor;
    }

    @Override
    public String getDescricao() {
        return descricao;
    }

    @Override
    public String getValor() {
        return chave;
    }

}
