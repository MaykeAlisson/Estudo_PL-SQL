package models.commons.constantes;

/**
 * Interface para representação de chave "objeto/sequencia".
 *
 * <p>Autor: GPortes</p>
 */
public interface ObjetoSeq {

    /**
     * Nome do Objeto
     *
     * @return Nome do objeto.
     */
    String getObjeto();

    /**
     * Sequencia do Objeto.
     *
     * @return Sequencia do Objeto.
     */
    Short getSequencia();

    /**
     * Retorna nova instância de um objeto.
     *
     * <p>Autor: GPortes</p>
     *
     * @param objeto    Nome do objeto.
     * @param sequencia Sequencia
     *
     * @return Objeto do tipo ObjetoSeq
     */
    static ObjetoSeq newInstance(
        final String objeto,
        final Short sequencia
    ) {

        return new ObjetoSeq() {

            @Override
            public String getObjeto() {

                return objeto;
            }

            @Override
            public Short getSequencia() {

                return sequencia;
            }
        };
    }
}
