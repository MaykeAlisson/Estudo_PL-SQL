package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 13/01/2016
 */
public enum SituacaoAcerto implements Constante<Short> {

    /**
     * 1
     */
    EM_TRANSITO( "EM TRANSITO", (short) 1 ),

    /**
     * 3
     */
    EM_ACERTO( "EM ACERTO", (short) 3 ),

    /**
     * 4
     */
    LIBERADO( "LIBERADO", (short) 4 ),

    /**
     * 5
     */
    ENCERRADO( "ENCERRADO", (short) 5 )
    ;

    private final String descricao;
    private final Short valor;

    SituacaoAcerto( final String descricao,
                    final Short valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public Short getValor() {

        return valor;
    }

}
