package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de tipos de solução no sistema de Obrigações (RH)
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 04/10/2017
 */
public enum TipoSolucaoObrigacao implements Constante<String> {

    /**
     * "E"
     */
    EQUIPE( "EQUIPE", "E" ),

    /**
     * "U"
     */
    USUARIO( "USUARIO", "U" )
    ;

    private final String descricao;
    private final String valor;

    TipoSolucaoObrigacao( final String descricao,
                          final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }
}
