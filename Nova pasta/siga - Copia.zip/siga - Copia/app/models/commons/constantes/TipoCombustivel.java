package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de tipos de pessoas.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 08/09/2014
 */
public enum TipoCombustivel implements Constante<String> {

    /**
     * D
     */
    DIESEL( "DIESEL", "D" ),

    /**
     * S
     */
    FISICA( "S 10", "S" ),

    /**
     * A
     */
    ARLA( "ARLA", "A" ),

    /**
     * E
     */
    ETANOL( "ETANOL", "E" ),

    /**
     * G
     */
    GASOLINA( "GASOLINA", "G" )

    ;

    private String descricao;
    private String valor;

    TipoCombustivel( final String descricao,
                     final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }

}
