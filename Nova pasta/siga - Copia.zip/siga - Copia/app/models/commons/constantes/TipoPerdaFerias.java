package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 30/05/2018
 */
public enum TipoPerdaFerias implements Constante<String> {

    /**
     * "S"
     */
    SIM( "SIM", "S" ),

    /**
     * "N"
     */
    NAO( "NAO", "N" ),

    /**
     * "A"
     */
    ACERTO_INVALIDEZ( "ACERTO INVALIDEZ", "A" )
    ;

    private final String descricao;
    private final String valor;

    TipoPerdaFerias(
        final String descricao,
        final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }

}
