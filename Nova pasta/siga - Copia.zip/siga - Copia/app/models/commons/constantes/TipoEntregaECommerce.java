package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 23/05/2019
 */
public enum TipoEntregaECommerce implements Constante<Short> {

    /**
     * 1
     */
    CORREIOS( "CORREIOS", (short) 1 ),

    /**
     * 2
     */
    TRANSPORTADORA( "TRANSPORTADORA", (short) 2 ),

    /**
     * 3
     */
    ARCOM( "ARCOM", (short) 3 )
    ;

    private final String descricao;
    private final Short valor;

    TipoEntregaECommerce(
        final String descricao,
        final Short valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public Short getValor() {

        return this.valor;
    }

}
