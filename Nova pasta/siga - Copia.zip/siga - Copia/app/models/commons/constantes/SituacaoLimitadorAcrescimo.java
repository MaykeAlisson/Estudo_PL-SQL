package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 22/02/2016
 */
public enum SituacaoLimitadorAcrescimo implements Constante<Integer> {

    /**
     * 1
     */
    CLIENTE_IMPLANTACAO( "CLIENTE IMPLANTACAO", 1 ),

    /**
     * 2
     */
    CLIENTE_REIMPLANTACAO( "CLIENTE REIMPLANTACAO", 2 ),

    /**
     * 3
     */
    CLIENTE_NAO_IMPLANTACAO( "CLIENTE NAO IMPLANTACAO", 3 ),

    /**
     * 4
     */
    ATRASOS_MAIS_20_DIAS_ULT_30_DIAS( "ATRASOS_MAIS_20_DIAS_ULT_30_DIAS", 4 )
    ;

    private final String descricao;
    private final Integer valor;

    SituacaoLimitadorAcrescimo( final String descricao,
                                final Integer valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public Integer getValor() {

        return valor;
    }

}

