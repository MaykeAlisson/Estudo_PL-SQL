package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores dos tipos de carga.
 *
 * <p>Autor: Cleber</p>
 *
 * @since 08/09/2014
 */
public enum TipoCarga implements Constante<String> {

    /**
     * "B"
     */
    BALCAO("BALCAO","B"),

    /**
     * "C"
     */
    COMPLEMENTO("COMPLEMENTO","C"),

    /**
     * "D"
     */
    DIVERSOS("DIVERSOS","D"),

    /**
     * "N"
     */
    NORMAL("NORMAL","N"),

    /**
     * "A"
     */
    CONSUMO("CONSUMO","A"),

    /**
     * "T"
     */
    ANTECIPADA("ANTECIPADA","T"),

    /**
     * "P"
     */
    ANTECIPACAO_PESADO("ANTECIPACAO PESADO", "P")
    ;

    private String descricao;
    private String valor;

    TipoCarga( String descricao, String valor) {
        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {
        return descricao;
    }

    @Override
    public String getValor() {
        return valor;
    }

}
