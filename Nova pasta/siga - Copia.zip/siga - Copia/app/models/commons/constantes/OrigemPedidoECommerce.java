package models.commons.constantes;

import infra.model.Constante;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static infra.util.UtilConstante.requireNonNull;
import static infra.util.UtilEnum.getEnum;
import static java.util.Optional.empty;
import static java.util.Optional.of;
import static models.domains.estoque.DivisaoMerExclusiva.IdDivisaoMerExclusiva;

/**
 * Constante ref. ao conjunto de valores das lojas do e-commerce.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 02/01/2019
 */
public enum OrigemPedidoECommerce implements Constante<Short> {

    /**
     * 1
     */
    LOJA_INTEGRADA_DENTIL( "LOJA INTEGRADA DENTIL", (short) 1 ),

    /**
     * 2
     */
    LOJA_INTEGRADA_ISABABY( "LOJA INTEGRADA ISABABY", (short) 2 ),

    /**
     * 3
     */
    TELEARCOM( "TELEARCOM", (short) 3 ),

    ;

    private final String descricao;
    private final Short valor;

    OrigemPedidoECommerce(
        final String descricao,
        final Short valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public Short getValor() {

        return this.valor;
    }

    /**
     * Retorna se a origem do pedido pode atualizar o site e-commerce.
     *
     * <p>Autor: GPortes</p>
     *
     * @param origemPedidoECommerce Origem do pedido e-commerce.
     *
     * @return (true) se positivo e (false) o contrário.
     */
    public static boolean atualizarSiteECommerce( final OrigemPedidoECommerce origemPedidoECommerce ) {

        requireNonNull( origemPedidoECommerce, "Obrigatório informar argumento [origemPedidoECommerce]" );

        return !Objects.equals( origemPedidoECommerce, TELEARCOM );
    }

    /**
     * Retorna lojas do e-commerce.
     *
     * <p>Autor: GPortes</p>
     *
     * @return Lista de lojas
     */
    public static List<OrigemPedidoECommerce> buscarLojasECommerce() {

        return Stream.of( OrigemPedidoECommerce.values() )
            .filter( OrigemPedidoECommerce::atualizarSiteECommerce )
            .collect( Collectors.toList() );
    }

    /**
     * Retorna a origem da exclusividade.
     *
     * <p>Autor: GPortes</p>
     *
     * @param divisao Divisão ( exclusividade)
     *
     * @return Origem.
     */
    public static Optional<OrigemPedidoECommerce> getOrigemMercadoria( final IdDivisaoMerExclusiva divisao ) {

        if ( divisao != null )
            switch ( divisao ) {
                case ISABABY:
                    return of( LOJA_INTEGRADA_ISABABY );
                case DENTIL:
                    return of( LOJA_INTEGRADA_DENTIL );
            }

        return empty();
    }

    /**
     * @see OrigemPedidoECommerce#getOrigemMercadoria(IdDivisaoMerExclusiva)
     */
    public static Optional<OrigemPedidoECommerce> getOrigemMercadoria( final String divisao ) {

        return getOrigemMercadoria( getEnum( IdDivisaoMerExclusiva.class, divisao ) );
    }

}
