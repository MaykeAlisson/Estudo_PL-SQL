package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de consultas pessoas WS
 *
 * <p>Autor: GPortes</p>
 *
 * @since 30/08/2018
 */
public enum FonteConsultaPessoaWS implements Constante<Short> {

    /**
     * 1
     */
    CONFIE( "CONFIE", (short) 1 ),

    /**
     * 2
     */
    MIDAS( "MIDAS", (short) 2 )
    ;

    private final String descricao;
    private final Short valor;

    FonteConsultaPessoaWS(
        final String descricao,
        final Short valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public Short getValor() {

        return this.valor;
    }

}

