package models.commons.constantes;

import infra.model.Constante;

import static java.lang.String.format;
import static models.commons.constantes.ObjetoSeq.newInstance;

public enum CodigoRegraAcesso implements Constante<ObjetoSeq> {

    EXCLUI_IMAGEM_MSG(
        "PERMITE EXCLUIR IMAGENS DESTINADAS PARA O ENVIO DE MENSAGENS",
        newInstance("exclui_img_msg", (short) 1 )
    ),

    JORNADA_MOTORISTA(
        "PERMITE E. JORNADA DE TRABALHO DO MOTORISTA",
        newInstance("api_jornada_motorista", (short) 1 )
    ),

    PEDIDO_ECOMMERCE_CANCELA(
        "PERMITE CANCELAR PEDIDO E-COMMERCE",
        newInstance("cancela-ecommerce", (short) 1 )
    )
    ;

    private final String descricao;
    private final ObjetoSeq valor;

    CodigoRegraAcesso(
        final String descricao,
        final ObjetoSeq valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public ObjetoSeq getValor() {

        return this.valor;
    }

    public String getObjeto() {

        return getValor() != null ? getValor().getObjeto() : null;
    }

    public Short getSequencia() {

        return getValor() != null ? getValor().getSequencia() : null;
    }

    @Override
    public String toString() {

        return getValor() != null
                ? format( "Código: %s/%s", getValor().getObjeto(), getValor().getSequencia() )
                : "Código: ?/?";
    }
}
