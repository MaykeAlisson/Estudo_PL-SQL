package models.commons.constantes;

import infra.model.Constante;

import static java.lang.String.format;

/**
 * Constante ref. ao conjunto de valores de Impressao de Mapa.
 *
 * <p>Autor: Jander Dutra</p>
 *
 * @since 14/02/2019
 */
public enum ImpressoraMapa implements Constante<Short> {

    /**
     * 1
     */
    CENTRAL( "CENTRAL", (short) 1),

    /**
     * 2
     */
    PRODUCAO( "PRODUCAO", (short) 2)

    ;

    private final String descricao;
    private final Short valor;

    ImpressoraMapa(
            final String descricao,
            final Short valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public Short getValor() {

        return this.valor;
    }

    @Override
    public String toString() {

        return format( "%s (%d)", getDescricao(), getValor() );
    }
}
