package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores das situações das cargas.
 *
 * <p>Autor: Cleber</p>
 *
 * @since 08/09/2014
 */
public enum SituacaoCarga implements Constante<String> {

    /**
     * "B"
     */
    EM_DIGITACAO("EM DIGITAÇÃO","B"),

    /**
     * "D"
     */
    ROTERIZADA("ROTEIRIZADA","D"),

    /**
     * "F"
     */
    LIBERADA_PARA_MAPA("LIBERADA PARA MAPA","F"),

    /**
     * "G"
     */
    MAPA_EM_EMISSAO("MAPA EM EMISSÃO","G"),

    /**
     * "H"
     */
    MAPA_EMITIDO("MAPA EMITIDO","H"),

    /**
     * "I"
     */
    MAPA_EM_BAIXA("MAPA EM BAIXA","I"),

    /**
     * "J"
     */
    LIBERADA_PARA_SEPARACAO("LIBERADA PARA SEPARAÇÃO","J"),

    /**
     * "L"
     */
    EM_SEPARACAO("EM SEPARAÇÃO","L"),

    /**
     * "N"
     */
    EM_CARREGAMENTO("EM CARREGAMENTO","N"),

    /**
     * "P"
     */
    LIBERADA_PARA_NOTA("LIBERADA PARA NOTA","P"),

    /**
     * "R"
     */
    NOTA_FISCAL_EMITIDA("NOTA FISCAL EMITIDA","R"),

    /**
     * "T"
     */
    CARREGADA("CARREGADA","T"),

    /**
     * "U"
     */
    LIBERADA_PARA_TRANSPORTE("LIBERADA PARA TRANSPORTE","U"),

    /**
     * "V"
     */
    LIBERADA_PARA_VIAGEM("LIBERADA PARA VIAGEM","V"),

    /**
     * "W"
     */
    SAIU_PARA_TROCAR_NOTA("SAIU PARA TROCAR NOTA", "W"),

    /**
     * "X"
     */
    SAIU_PARA_VIAGEM("SAIU PARA VIAGEM","X"),

    /**
     * "Z"
     */
    CANCELADA("CANCELADA","Z")
    ;


    private String descricao;
    private String valor;

    SituacaoCarga( String descricao, String valor ) {
        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {
        return descricao;
    }

    @Override
    public String getValor() {
        return valor;
    }

}
