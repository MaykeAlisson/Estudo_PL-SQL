package models.commons.constantes;


import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/12/2015
 */
public enum SituacaoViagem implements Constante<String> {

    /**
     * "E"
     */
    EM_PREPARACAO( "EM PREPARAÇÃO", "E" ),

    /**
     * "V"
     */
    EM_VIAGEM( "EM VIAGEM", "V" ),

    /**
     * "P"
     */
    PARCIALMENTE_ENTREGUE( "PARCIALMENTE ENTREGUE", "P" ),

    /**
     * "F"
     */
    FINALIZADA( "FINALIZADA", "F" )
    ;

    private final String descricao;
    private final String valor;

    SituacaoViagem( final String descricao,
                    final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }

}
