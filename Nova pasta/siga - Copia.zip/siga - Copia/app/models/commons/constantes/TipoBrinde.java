package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 09/01/2019
 */
public enum TipoBrinde implements Constante<String> {

    /**
     * "C"
     */
    PROMOCAO_CLIENTE( "PROMOCAO CLIENTE", "C" ),

    /**
     * "R"
     */
    PROMOCAO_REPRESENTANTE( "PROMOCAO REPRESENTANTE", "R" ),

    /**
     * "D"
     */
    DISPLAY_CLIENTE( "DISPLAY CLIENTE", "D" ),

    /**
     * "M"
     */
    MERCADORIA_CLIENTE( "MERCADORIA CLIENTE", "M" )
    ;

    private final String descricao;
    private final String valor;

    TipoBrinde(
        final String descricao,
        final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public String getValor() {

        return this.valor;
    }

}
