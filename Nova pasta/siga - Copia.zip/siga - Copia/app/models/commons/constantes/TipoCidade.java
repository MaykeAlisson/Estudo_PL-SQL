package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 07/01/2016
 */
public enum TipoCidade implements Constante<String> {

    /**
     * "L"
     */
    LITORANEA( "LITORANEA", "L" ),

    /**
     * "N"
     */
    NORMAL( "NORMAL", "N" )
    ;

    private final String descricao;
    private final String valor;

    TipoCidade( final String descricao,
                final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }

}
