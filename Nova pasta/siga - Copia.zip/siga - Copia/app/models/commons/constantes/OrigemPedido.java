package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de Origens de Pedido.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 09/11/2015
 */
public enum OrigemPedido implements Constante<String> {

    /**
     * "I"
     */
    INTERNET( "INTERNET", "I" ),

    /**
     * "P"
     */
    IVENDAS( "IVENDAS", "P" ),

    /**
     * "T"
     */
    TELEARCOM( "TELEARCOM", "T" ),

    /**
     * "B"
     */
    BATCH_CONDUIT( "BATCH CONDUIT", "B" ),

    /**
     * "E"
     */
    EDI( "EDI", "E" ),

    /**
     * "V"
     */
    TELEVENDAS( "TELEVENDAS", "V" )
    ;

    private final String descricao;
    private final String valor;

    OrigemPedido( final String descricao,
                  final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }
}
