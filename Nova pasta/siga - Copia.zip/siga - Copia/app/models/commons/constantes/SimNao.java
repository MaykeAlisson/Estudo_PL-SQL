package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. a representação: S(Sim) / N(Não)
 *
 * <p>Autor: GPortes</p>
 *
 * @since 08/09/2014
 */
public enum SimNao implements Constante<String> {

    /**
     * "S"
     */
    SIM( "SIM", "S" ),


    /**
     * "N"
     */
    NAO( "NÃO", "N" );

    final private String descricao;
    final private String valor;

    SimNao( final String descricao,
            final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }

    public static SimNao getValor( boolean valor ) {

        return valor ? SIM : NAO;
    }

}
