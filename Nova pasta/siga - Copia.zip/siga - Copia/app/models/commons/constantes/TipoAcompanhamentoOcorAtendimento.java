package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 01/03/2019
 */
public enum TipoAcompanhamentoOcorAtendimento implements Constante<String> {

    /**
     * "S"
     */
    SIM( "SIM", "S" ),

    /**
     * "N"
     */
    NAO( "NAO", "N" ),

    /**
     * "E"
     */
    APENAS_ENVIA_EMAIL_MENSAGEM( "APENAS ENVIA EMAIL/MENSAGEM", "E" )
    ;

    private final String descricao;
    private final String valor;

    TipoAcompanhamentoOcorAtendimento(
        final String descricao,
        final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public String getValor() {

        return this.valor;
    }
}