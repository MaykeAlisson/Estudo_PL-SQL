package models.commons.constantes;

import java.util.Arrays;
import java.util.List;

/**
 * Classe responsavel por encapsular as constantes do eSocial
 *
 * @author fernandopti
 *
 */
public class ESocialConstantes {

	//eSocial
	public static final Long ID_SISTEMA = 1L;

	// Encode da Assinatura
	public static final String XMLSIG = "xmlns:ns2=\"http://www.w3.org/2000/09/xmldsig#\"";
	public static final String sha256 = "http://www.w3.org/2001/04/xmlenc#sha256";
	public static final String RASHA256 = "http://www.w3.org/2001/04/xmldsig-more#rsa-sha256";

	// Informações sobre certificados
	public static final int    SSL_PORT = 443;
	public static final String PROTOCOLO = "https";
	public static final String CAMINHO_CERTIFICADO = "C:/Projetos/eSocial/Certificados/arcom.pfx";
	public static final String ARCOM_ID ="1";
	public static final String ARCOM_TRANSPORTES_ID = "40";
	public static final String ARCOM_3E_ID = "78";
	public static final String ARCOM_LOGRIO_ID = "81";
	public static final String ARCOM_DILENE_ID = "93";
	public static final String ARCOM_VEICULOS_ID = "99";
	public static final String ARCOM_DE_ID = "131";
	public static final String ARCOM_CERT = "ARCOM S A:25769266000124";
	public static final String ARCOM_TRANSPORTES_CERT = "ARCOM TRANSPORTES LTDA:05008833000112";
	public static final String ARCOM_LOGRIO_CERT = "ARCOM LOGISTICA RIO LTDA:05222265000158";
	public static final String ARCOM_VEICULOS_CERT = "ARCOM VEICULOS LTDA:13916722000132";
	public static final String ARCOM_DILENE_CERT = "DILENE EMPREENDIMENTOS LTDA:11299924000157";
	public static final String ARCOM_3E_CERT = "3E VIGILANCIA E SEGURANCA EIRELI:07578814000157";
	public static final String ARCOM_DE_CERT = "DE PARTICIPACOES LTDA:26352830000171";

	// Identificação do Evento
	public static final Byte   PRODUCAO_DADOS_REAIS = new Byte("1"); // MUDAR PROD :1 MUDAR DEV :2
	public static final Byte   PRODUCAO_RESTRITA_DADOS_REAIS = new Byte("1");
	public static final Byte   PROCESSO_EMISSAO = new Byte("1");
	public static final String VERSAO_PROCESSO = "2.5.00";
	public static final String VERSAO_2402 = "2.4.02";
	public static final String VERSAO_2401 = "2.4.01";
	public static final Short  MESES_RETROAGIR = new Short("1");

	// Geração de arquivos
	public static final String EXTENSAO_XML = ".xml";

	// Scheduler
	public static final Integer AGORA = 0;
	public static final Integer MINUTOS_ENTRE_EXECUCOES = 5;
	public static final Integer MINUTOS_CONSULTAR = 5;

	// Dados do empregador
	public static final String CNPJ = "25769266000124"; //25769266000124 56772542000137
	public static final String TP_INSC_EMP = "1";
	public static final String ID_EVENTO = "#ID_EVENTO#";
	public static final String INICIO_VALIDADE = "2017-01"; // ANTIGO
	public static final String INICIO_VALIDADE_S1060 = "2019-01"; // ANTIGO
	public static final String INICIO_VALIDADE_PROD = "2018-01"; // ANTIGO
	public static final Short  ID_EMPRESA = new Short("1");
	public static final Long   USUARIO_ESOCIAL = new Long("1160");

	//Flags
	public static final String SIM = "S";
	public static final String NAO = "N";
	public static final String DESCONTO = "D";

	// Tipo dos Eventos
	public static final String INCLUSAO = "Inclusao";
	public static final String ALTERCAO = "Alteracao";
	public static final String EXCLUSAO = "Exclusao";

	// Data hora
	public static final String YYYY_MM = "yyyy-MM";
	public static final String YYYYMM = "yyyyMM";
	public static final String YYYYMMDD = "yyyyMMdd";
	public static final String YYYY_MM_DD = "yyyy-MM-dd";
	public static final String DD_MM_YYYY = "dd/MM/yyyy";
	public static final String DD_MM_YYYY_ = "dd-MM-yyyy";
	public static final String DD_MM_YYYY_HHMMSS = "dd/MM/yyyy HH:mm:ss";
	public static final String INICIO_NAO_PERIODICOS = "01/03/2018"; // MUDAR PROD DEV = '01/03/2017' PROD = '01/03/2018'
	public static final String INICIO_PERIODICOS = "01/05/2018"; // MUDAR PROD DEV = '01/05/2017' PROD = '01/05/2018'
	public static final String INICIO_PERIODICOS_DEMAIS_EMP = "01/01/2019"; // MUDAR PROD DEV = '01/01/2018' PROD = '01-01-2019'
	public static final String INICIO_NAO_PERIODICOS_DEMAIS_EMP = "10/10/2018"; // MUDAR PROD DEV = '10/10/2017' PROD = '10-10-2018'
	public static final String FGTS_MIN_DATE = "04/10/1988";
	public static final String INI_OBITO = "2018-03-01";

	// Nomenclatura de eventos
	public static final String S1000 = "S1000";
	public static final String S1005 = "S1005";
	public static final String S1010 = "S1010";
	public static final String S1020 = "S1020";
	public static final String S1030 = "S1030";
	public static final String S1040 = "S1040";
	public static final String S1050 = "S1050";
	public static final String S1060 = "S1060";
	public static final String S1070 = "S1070";
	public static final String S1200 = "S1200";
	public static final String S1202 = "S1202";
	public static final String S1210 = "S1210";
	public static final String S1250 = "S1250";
	public static final String S1260 = "S1260";
	public static final String S1270 = "S1270";
	public static final String S1280 = "S1280";
	public static final String S1295 = "S1295";
	public static final String S1298 = "S1298";
	public static final String S1299 = "S1299";
	public static final String S1300 = "S1300";
	public static final String S2100 = "S2100";
	public static final String S2190 = "S2190";
	public static final String S2200 = "S2200";
	public static final String S2205 = "S2205";
	public static final String S2206 = "S2206";
	public static final String S2210 = "S2210";
	public static final String S2221 = "S2221";
	public static final String S2220 = "S2220";
	public static final String S2230 = "S2230";
	public static final String S2250 = "S2250";
	public static final String S2298 = "S2298";
	public static final String S2299 = "S2299";
	public static final String S2300 = "S2300";
	public static final String S2306 = "S2306";
	public static final String S2399 = "S2399";
	public static final String S3000 = "S3000";
	public static final String S5001 = "S5001";
	public static final String S5002 = "S5002";
	public static final String S5011 = "S5011";
	public static final String S5012 = "S5012";

	// Exclusão de eventos
	public static final String D1000 = "D1000";
	public static final String D1005 = "D1005";
	public static final String D1010 = "D1010";
	public static final String D1020 = "D1020";
	public static final String D1030 = "D1030";
	public static final String D1040 = "D1040";
	public static final String D1050 = "D1050";
	public static final String D1060 = "D1060";
	public static final String D1070 = "D1070";
	public static final String D1200 = "D1200";
	public static final String D1202 = "D1202";
	public static final String D1210 = "D1210";
	public static final String D1250 = "D1250";
	public static final String D1260 = "D1260";
	public static final String D1270 = "D1270";
	public static final String D1280 = "D1280";
	public static final String D1295 = "D1295";
	public static final String D1298 = "D1298";
	public static final String D1299 = "D1299";
	public static final String D1300 = "D1300";
	public static final String D2100 = "D2100";
	public static final String D2190 = "D2190";
	public static final String D2200 = "D2200";
	public static final String D2205 = "D2205";
	public static final String D2206 = "D2206";
	public static final String D2210 = "D2210";
	public static final String D2220 = "D2220";
	public static final String D2230 = "D2230";
	public static final String D2250 = "D2250";
	public static final String D2298 = "D2298";
	public static final String D2299 = "D2299";
	public static final String D2300 = "D2300";
	public static final String D2306 = "D2306";
	public static final String D2399 = "D2399";
	public static final String D3000 = "D3000";
	public static final String D5001 = "D5001";

	//Verifica Cargo S2300
	public static final List<String> CARGOS_NAO_GERAR = Arrays.asList("721", "722", "901", "305", "771");
	public static final List<String> CARGOS_FUNCAO = Arrays.asList("201", "202", "721", "722", "731","305");
	public static final List<String> CARGOS_REMUNERA = Arrays.asList("721", "722", "305","771");
	public static final String DIRETOR_COM_FGTS = "721";
	public static final String DIRIGENTE_SINDICAL = "401";
	public static final String TRABALHADOR_CEDIDO = "410";
	public static final String ESTAGIARIO = "901";

	//Verifica se EVT tem info do trabalhador
	public static final List<String> EVT_TRAB = Arrays.asList("S1200","S1210","S2200","S2205","S2206","S2300","S2230","S2190","S2299");
	public static final List<String> EVT_FOLHA = Arrays.asList("S1200","S1202","S1210","S1250","S1298");

	//Verifica se deve-se enviar info complementar de quem não tem matrícula
	public static final List<String> EVT_COMPL = Arrays.asList("101","102","103","104","105","106","111","301","302","303","306","307","309");

	//Verifica tipos de rúbrica
	public static final List<String> RUBRICA_RETENCAO = Arrays.asList("31","32","33","34","35","51","52","53","54","55","81","82","83");
	public static final List<String> RUBRICA_PENSAO = Arrays.asList("51","52","53","54","55");
	public static final List<String> RUBRICA_DEDUCOES_E_RETENCOES = Arrays.asList("31","32","33","34","35","41","42","43","44","46","47","51","52","53","54","55","61","62","63","64");
	public static final List<String> RUBRICA_FERIAS = Arrays.asList("0","1","9","13","33","43","46","53","63","75","93");
	public static final List<String> RUBRICA_PENSAO_FERIAS = Arrays.asList("53");

	//Pais
	public static final String BRASIL = "105";

	//Lote
	public static final Integer EVENTOS_POR_LOTE = 50;
	public static final String DATA_ZERADA_PAR = "00000001";

	//Numerais
	public static final String DATA_ZERADA = "00000000";

	//Verificar Prod. / Des. e URL banco
	public static final String PRODUCAO = "P";
	public static final String DESENVOLVIMENTO = "D";
	public static final String URL = "db.default.url";
	public static final String PRODBD = "netuno";
	public static final Long URL_ENVIA = 710L;
	public static final Long URL_CONSULTA = 711L;

	//Códigos motivo de afastamento
	public static final String ACIDTRAB = "01";
	public static final String ACIDNAOTRAB = "03";
	public static final String INVALIDEZ = "06";
	public static final String OBITO = "10";
	public static final String CESSAO = "14";
	public static final String FERIAS = "15";
	public static final String MANDATOSINDICAL = "24";
	public static final String LICENCANAOREMU = "21";

	//Constantes para validação de permissão de processamento
	public static final Short SEQUENCIA_ESOCIAL = 1;
	public static final String PROC_ESOCIAL = "proc_esocial";
	public static final Long ANALISTAS = 141L;
	public static final Long DIRETOR_SUPER = 145L;
	public static final Long DIRETOR = 142L;

	//Textos
	public static final String SEM_MODIFICACOES = "Não existem modificações";
	public static final String EVENTO_EXCLUIDO = "Evento Inativo por exclusão (S-3000)";

	//tipoEnvio
	public enum TipoEvento{

		INICIAl("Informação Empregador / Tabelas", "1"),
		NAO_PERIODICO("Não periódico", "2"),
		PERIODICO("Periódico", "3"),
		EDF_REINF("EDF-Reinf","4")
		;

		private String nome;
		private String id;

		TipoEvento(String nome, String id){
			this.nome = nome;
			this.id = id;
		}

		public String getId(){
			return this.id;
		}

		public String getNome(){
			return this.nome;
		}


	}

	//Status Procesasmento
	public enum StatusProcessamento{

		AGUARDANDO_ENVIO("Aguardando Envio", "1"),
		AGUARDANDO_PROCESSAMENTO("Aguardando processamento", "2"),
		PROCESSADO_SUCESSO("Processado Sucesso", "3"),
		PROCESSADO_ERRO("Processado Erro", "4"),
		EVENTO_INATIVO("Evento Inativo", "5"),
		REPROCESSAR("Reprocessar", "6"),
		PROCESSAR_REINF("Aguardando Envio/Processamento","7"),
		PROCESSADO_AFAST("Processado Afastamento","8"),
		AGUARDANDO_PROCESSAMENTO_ALTERACAO("Aguardando Processamento Alteração","9");

		private String nome;
		private String id;

		StatusProcessamento(String nome, String id){
			this.nome = nome;
			this.id = id;
		}

		public Short getId(){
			return new Short(this.id);
		}

		public String getNome(){
			return this.nome;
		}


	}

}

