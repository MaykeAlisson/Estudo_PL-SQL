package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de Tipos de Retenção do representante.
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 16/06/2015
 */
public enum TipoRetencao implements Constante<String> {

    /**
     * "S"
     */
    SOLICITACAO( "SOLICITAÇÃO", "S" ),

    /**
     * "N"
     */
    NAO_RETEM_COMISSAO( "NÃO RETEM COMISSÃO", "N" )
    ;

    private final String descricao;
    private final String valor;

    TipoRetencao( final String descricao,
                  final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }

}
