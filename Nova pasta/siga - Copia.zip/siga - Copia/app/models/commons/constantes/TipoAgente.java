package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 27/07/2015
 */
public enum TipoAgente implements Constante<String> {

    /**
     * "E"
     */
    ENTREGA("ENTREGA","E"),

    /**
     * "R"
     */
    RECEBIMENTO("RECEBIMENTO","R"),

    /**
     * "V"
     */
    VOLTA_ENTREGA("VOLTA ENTREGA","V")
    ;

    private String descricao;
    private String valor;

    TipoAgente( String descricao, String valor ) {
        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {
        return descricao;
    }

    @Override
    public String getValor() {
        return valor;
    }

}
