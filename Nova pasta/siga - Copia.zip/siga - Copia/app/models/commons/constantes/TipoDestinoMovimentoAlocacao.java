package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 20/03/2017
 */
public enum TipoDestinoMovimentoAlocacao implements Constante<String> {

    /**
     * 1
     */
    CLIENTE( "CLIENTE", "CLIENTE" ),

    /**
     * 2
     */
    CIDADE( "CIDADE", "CIDADE" ),

    /**
     * 3
     */
    CDA( "CDA", "CDA" ),

    /**
     * 4
     */
    SETOR( "SETOR", "SETOR" )
    ;

    private final String descricao;
    private final String valor;

    TipoDestinoMovimentoAlocacao(
        final String descricao,
        final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }

}


