package models.commons.constantes;

import infra.model.Constante;

import java.util.Objects;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Victor.serafim</p>
 *
 * @since 12/12/2018
 */
public enum TipoFuncao implements Constante<String> {

    /**
     * "A"
     */
    AJUDANTE( "AJUDANTE", "A" ),

    /**
     * "T"
     */
    AJUDANTE_MOTORISTA( "AJUDANTE/MOTORISTA", "T" ),

    /**
     * "P"
     */
    APRENDIZ( "APRENDIZ", "P" ),

    /**
     * "M"
     */
    MOTORISTA( "MOTORISTA", "M" ),

    /**
     * "O"
     */
    OUTROS( "OUTROS", "O" ),

    /**
     * "S"
     */
    SEM_VINCULO( "SEM VINCULO", "S" ),

    /**
     * "V"
     */
    TELEVENDAS( "TELEVENDAS", "V" )
    ;

    private final String descricao;
    private final String valor;

    TipoFuncao(
        final String descricao,
        final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public String getValor() {

        return this.valor;
    }

    public static boolean isMotorista( final TipoFuncao tipoFuncao ) {

        return Objects.equals(tipoFuncao, MOTORISTA)
                || Objects.equals(tipoFuncao, AJUDANTE)
                || Objects.equals(tipoFuncao, AJUDANTE_MOTORISTA);
    }
}
