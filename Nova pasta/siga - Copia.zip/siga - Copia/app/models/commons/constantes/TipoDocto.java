package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 27/07/2015
 */
public enum TipoDocto implements Constante<Integer> {

    /**
     * 1
     */
    DUPLICATA("DUPLICATA",1),

    /**
     * 2
     */
    CHEQUE("CHEQUE",2)
    ;

    private String descricao;
    private Integer valor;

    TipoDocto( final String descricao,
               final Integer valor ) {
        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {
        return descricao;
    }

    @Override
    public Integer getValor() {
        return valor;
    }
}

