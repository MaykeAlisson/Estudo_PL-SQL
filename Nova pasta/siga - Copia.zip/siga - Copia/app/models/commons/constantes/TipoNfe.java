package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de tipos de notas fiscais eletronicas.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 16/06/2015
 */
public enum TipoNfe implements Constante<Integer> {

    /**
     * 0
     */
    ENTRADA("ENTRADA",0),

    /**
     * 1
     */
    SAIDA("SAIDA",1)
    ;

    private String descricao;
    private Integer valor;

    TipoNfe( String descricao, Integer valor ) {
        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {
        return descricao;
    }

    @Override
    public Integer getValor() {
        return valor;
    }

}
