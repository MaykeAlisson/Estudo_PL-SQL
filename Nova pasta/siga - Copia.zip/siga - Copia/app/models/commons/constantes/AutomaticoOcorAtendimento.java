package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 01/03/2019
 */
public enum AutomaticoOcorAtendimento implements Constante<String> {

    /**
     * "S"
     */
    SIM( "SIM", "S" ),

    /**
     * "N"
     */
    NAO( "NAO", "N" ),

    /**
     * "D"
     */
    DESATIVADO_MANUAL( "DESATIVADO MANUAL", "D" )
    ;

    private final String descricao;
    private final String valor;

    AutomaticoOcorAtendimento(
        final String descricao,
        final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public String getValor() {

        return this.valor;
    }
}
