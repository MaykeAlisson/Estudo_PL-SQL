package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Cleber</p>
 *
 * @since 06/02/2019
 */
public enum SituacaoCelula implements Constante<Short> {

    /**
     * 1
     */
    LIVRE( "LIVRE", (short) 1 ),

    /**
     * 2
     */
    OCUPADO( "OCUPADO", (short) 2 ),

    /**
     * 3
     */
    RESERVADO( "RESERVADO", (short) 3 ),

    /**
     * 4
     */
    SEPARADO( "SEPARADO", (short) 4 ),

    /**
     * 5
     */
    BLOQUEADO( "BLOQUEADO", (short) 5 ),

    /**
     * 6
     */
    BLOQUEADO_DEVOLUCAO( "BLOQUEADO DEVOLUCAO", (short) 6 ),

    /**
     * 7
     */
    BLOQUEADO_OFERTA( "BLOQUEADO OFERTA", (short) 7 ),

    /**
     * 8
     */
    DESEMBALADO( "DESEMBALADO", (short) 8 )
    ;

    private final String descricao;
    private final Short valor;

    SituacaoCelula(
            final String descricao,
            final Short valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public Short getValor() {

        return this.valor;
    }

}
