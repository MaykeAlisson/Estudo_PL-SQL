package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de possíveis para situações de baixa.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 08/09/2014
 */
public enum SituacaoBaixa implements Constante<Integer> {

    /**
     * 1
     */
    SEM_BAIXAR("SEM BAIXAR",1),

    /**
     * 2
     */
    BAIXADA("BAIXADA",2),

    /**
     * 3
     */
    CONFERIDA("CONFERIDA",3),

    /**
     * 4
     */
    LIBERADA("LIBERADA",4),

    /**
     * 5
     */
    CONSOLIDADA("CONSOLIDADA",5)

    ;

    SituacaoBaixa(String descricao, Integer valor) {
        this.descricao = descricao;
        this.valor = valor;
    }

    private String descricao;
    private Integer valor;

    @Override
    public String getDescricao() {
        return descricao;
    }

    @Override
    public Integer getValor() {
        return valor;
    }

}
