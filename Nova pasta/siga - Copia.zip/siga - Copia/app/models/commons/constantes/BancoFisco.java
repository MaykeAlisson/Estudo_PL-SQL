package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 14/08/2017
 */
public enum BancoFisco implements Constante<String> {

    /**
     * "fisco01"
     */
    FISCO01( "FISCO 01", "fisco01" ),

    /**
     * "fisco02"
     */
    FISCO02( "FISCO 02", "fisco02" ),

    /**
     * "fisco03"
     */
    FISCO03( "FISCO 03", "fisco03" ),

    /**
     * "fisco04"
     */
    FISCO04( "FISCO 04", "fisco04" ),

    /**
     * "fisco05"
     */
    FISCO05( "FISCO 05", "fisco05" ),

    /**
     * "fisco06"
     */
    FISCO06( "FISCO 06", "fisco06" ),

    /**
     * "fisco07"
     */
    FISCO07( "FISCO 07", "fisco07" ),

    /**
     * "fisco08"
     */
    FISCO08( "FISCO 08", "fisco08" ),

    /**
     * "fisco09"
     */
    FISCO09( "FISCO 09", "fisco09" ),

    /**
     * "fisco10"
     */
    FISCO10( "FISCO 10", "fisco10" ),

    /**
     * "fisco11"
     */
    FISCO11( "FISCO 11", "fisco11" )
    ;

    private final String descricao;
    private final String valor;

    BancoFisco( final String descricao,
                final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }

}



