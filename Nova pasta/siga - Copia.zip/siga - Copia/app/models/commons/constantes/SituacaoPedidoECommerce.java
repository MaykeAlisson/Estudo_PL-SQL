package models.commons.constantes;

import infra.model.Constante;

import java.util.List;

import static com.google.common.primitives.Shorts.asList;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 02/01/2019
 */
public enum SituacaoPedidoECommerce implements Constante<Short> {

    /**
     * 1 - PEDIDO BAIXADO DO SITE.
     */
    NAO_PROCESSADO( "NAO PROCESSADO", (short) 1 ),

    /**
     * 2 - PEDIDO COM INFORMAÇÕES INVALIDAS.
     */
    INCONSISTENCIA( "INCONSISTENCIA DE DADOS", (short) 2 ),

    /**
     * 3 - PEDIDO CANCELADO.
     */
    CANCELADO( "PEDIDO CANCELADO", (short) 3 ),

    /**
     * 4 - AGUARDANDO GERAÇÃO DO PEDIDO DE VENDA.
     */
    AGUARDANDO_PROCESSAMENTO( "AGUARDANDO PROCESSAMENTO", (short) 4 ),

    /**
     * 5 - PEDIDO DE VENDA GERADO ( PODE SER ROTEIRIZADO, SEPARADO E ETC.. )
     */
    PEDIDO_GERADO( "PEDIDO DE VENDA GERADO", (short) 5 ),

    /**
     * 6 - PEDIDO FINALIZADO.
     */
    ENTREGUE( "PEDIDO FINALIZADO", (short) 6 )
    ;

    private final String descricao;
    private final Short valor;

    SituacaoPedidoECommerce(
        final String descricao,
        final Short valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public Short getValor() {

        return this.valor;
    }

    public static List<Short> buscarSituacoesAvaliaPedidoAtrasado() {

        return asList(
            NAO_PROCESSADO.getValor(),
            INCONSISTENCIA.getValor(),
            AGUARDANDO_PROCESSAMENTO.getValor(),
            PEDIDO_GERADO.getValor()
        );
    }


}