package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 16/07/2018
 */
public enum TipoRegimeJornada implements Constante<Short> {

    /**
     * 1
     */
    SUBMETIDOS_A_HORARIO_DE_TRABALHO_CAPITULO_II_DA_CLT( "SUBMETIDOS A HORÁRIO DE TRABALHO ( CAPÍTULO II DA CLT )", (short) 1 ),

    /**
     * 2
     */
    ATIVIDADE_EXTERNA_ESPECIFICADA_NO_INCISO_I_DO_ARTIGO_62_DA_CLT( "ATIVIDADE EXTERNA ESPECIFICADA NO INCISO I DO ARTIGO 62 DA CLT", (short) 2 ),

    /**
     * 3
     */
    FUNCOES_ESPECIFICADAS_NO_INSICO_II_DO_ARTIGO_62_DA_CLT( "FUNÇÕES ESPECIFICADAS NO INSICO II DO ARTIGO 62 DA CLT", (short) 3 )
    ;

    private final String descricao;
    private final Short valor;

    TipoRegimeJornada(
        final String descricao,
        final Short valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public Short getValor() {

        return this.valor;
    }
}