package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de situações de notas fiscais de saída.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 16/06/2015
 */
public enum SituacaoNfSaida implements Constante<String> {

    /**
     * "C"
     */
    CANCELADO("CANCELADO","C"),

    /**
     * "N"
     */
    NORMAL("NORMAL","N"),

    /**
     * "R"
     */
    REFATURAMENTO("REFATURAMENTO","R"),

    /**
     * "Z"
     */
    EM_REEMISSÃO("EM REEMISSAO","Z")
    ;

    private String descricao;
    private String valor;

    SituacaoNfSaida( final String descricao,
                     final String valor ) {
        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {
        return descricao;
    }

    @Override
    public String getValor() {
        return valor;
    }

}

