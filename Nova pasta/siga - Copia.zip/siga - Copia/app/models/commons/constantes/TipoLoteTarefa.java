package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de tipos de lotes de tarefa.
 *
 * <p>Autor: Cleber</p>
 *
 * @since 08/09/2014
 */
public enum TipoLoteTarefa implements Constante<String> {

    /**
     * "Multi"
     */
    MULTI("MULTI","Multi"),

    /**
     * "Sequencial"
     */
    SEQUENCIAL("SEQUENCIAL","Sequencial")
    ;

    private String descricao;
    private String valor;

    TipoLoteTarefa( String descricao, String valor ) {
        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {
        return descricao;
    }

    @Override
    public String getValor() {
        return valor;
    }

}
