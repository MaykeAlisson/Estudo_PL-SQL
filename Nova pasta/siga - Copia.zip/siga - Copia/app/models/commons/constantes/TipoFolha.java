package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de Tipos de folhas.
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 18/06/2018
 */
public enum TipoFolha implements Constante<Short> {

    /**
     * 1
     */
    MENSAL( "MENSAL", (short) 1 ),

    /**
     * 2
     */
    FERIAS( "FERIAS", (short) 2 ),

    /**
     * 3
     */
    RESCISAO( "RESCISAO", (short) 3 ),

    /**
     * 4
     */
    DECIMO_TERCEIRO( "DECIMO TERCEIRO", (short) 4 ),

    /**
     * 5
     */
    DECIMO_TERCEIRO_1_PARCELA( "DECIMO TERCEIRO 1 PARCELA", (short) 5 ),

    /**
     * 6
     */
    EVENTUAIS( "EVENTUAIS", (short) 6 ),

    /**
     * 7
     */
    COMPLEMENTO_13( "COMPLEMENTO 13", (short) 7 ),

    /**
     * 8
     */
    RECLAMATORIA_TRABALHISTA( "RECLAMATORIA TRABALHISTA", (short) 8 ),

    /**
     * 9
     */
    RECALCULO_COMPLEMENTAR( "RECALCULO COMPLEMENTAR", (short) 9 )
    ;

    private final String descricao;
    private final Short valor;

    TipoFolha(
        final String descricao,
        final Short valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public Short getValor() {

        return valor;
    }
}