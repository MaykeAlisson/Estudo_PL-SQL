package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de Tipos de Cda
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 13/03/2017
 */
public enum TipoCda implements Constante<Integer> {

    /**
     * 1
     */
    CDA( "CDA", 1 ),

    /**
     * 2
     */
    CDM( "CDM", 2 )
    ;

    private final String descricao;
    private final Integer valor;

    TipoCda( final String descricao,
             final Integer valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public Integer getValor() {

        return valor;
    }

}