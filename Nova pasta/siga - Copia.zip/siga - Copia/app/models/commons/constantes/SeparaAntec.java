package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 02/05/2018
 */
public enum SeparaAntec implements Constante<String> {

    /**
     * "S"
     */
    SANDALIA( "SANDALIA", "S" ),

    /**
     * "N"
     */
    NAO( "NÃO", "N" ),

    /**
     * "E"
     */
    ESQUELETO( "ESQUELETO", "E" ),

    /**
     * "Z"
     */
    ENERGIZER( "ENERGIZER", "Z" ),

    /**
     * "C"
     */
    ESPECIAL( "ESPECIAL", "C" ),

    /**
     * "D"
     */
    CIDADE( "CIDADE", "D" ),

    /**
     * "U"
     */
    ANTECIPACAO_CLIENTE( "ANTECIPACÃO CLIENTE", "U" )
    ;

    private final String descricao;
    private final String valor;

    SeparaAntec( final String descricao,
                 final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }

}
