package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 18/12/2018
 */
public enum SexoCid implements Constante<String> {

    /**
     * "M"
     */
    MASCULINO("MASCULINO","M" ),

    /**
     * "F"
     */
    FEMININO("FEMININO","F" ),

    /**
     * "A"
     */
    AMBOX( "AMBOS", "A" )
    ;

    private String descricao;
    private String valor;

    SexoCid(
        final String descricao,
        final String valor
    ) {
        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {
        return descricao;
    }

    @Override
    public String getValor() {
        return valor;
    }
}
