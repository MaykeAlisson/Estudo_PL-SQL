package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 28/11/2016
 */
public enum TipoFeriado implements Constante<String> {

    /**
     * "B"
     */
    BANCARIO( "BANCARIO", "B" ),

    /**
     * "N"
     */
    NACIONAL( "NACIONAL", "N" ),

    /**
     * "R"
     */
    REGIONAL( "REGIONAL", "R" )
    ;

    private final String descricao;
    private final String valor;

    TipoFeriado( final String descricao,
                 final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }

}