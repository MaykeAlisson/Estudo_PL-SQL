package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de situações de carga antecipada
 *
 * <p>Autor: Cleber</p>
 *
 * @since 02/09/2014
 */
public enum SituacaoCargaAntecipada implements Constante<String> {

    /**
     * "A"
     */
    AGUARDANDO_ESCALA("AGUARDANDO ESCALA","A"),

    /**
     * "P"
     */
    ESCALADA("CARGA ESCALADA","E"),

    /**
     * "D"
     */
    DISPONIVEL("DISPONIVEL PARA PREPARACAO","D"),

    /**
     * "P"
     */
    PREPARADA("PREPARADA","P"),

    /**
     * "F"
     */
    FINALIZADA("FINALIZADA","F");

    private String chave;
    private String descricao;

    private SituacaoCargaAntecipada(String descricao, String valor) {
        this.descricao = descricao;
        this.chave = valor;
    }

    @Override
    public String getDescricao() {
        return descricao;
    }

    @Override
    public String getValor() {
        return chave;
    }

    @Override
    public String toString() {
        return "SituacaoCargaAntecipada{" +
                "chave='" + chave + '\'' +
                ", descricao='" + descricao + '\'' +
                '}';
    }

}
