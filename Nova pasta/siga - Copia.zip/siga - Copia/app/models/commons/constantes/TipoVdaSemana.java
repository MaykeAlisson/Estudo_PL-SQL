package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 07/01/2016
 */
public enum TipoVdaSemana implements Constante<String> {

    /**
     * "'0'"
     */
    VENDE_EM_TODAS_SEMANAS( "VENDE EM TODAS SEMANAS", "0" ),

    /**
     * "'1'"
     */
    VENDE_NESTA_SEMANA( "VENDE NESTA SEMANA", "1" ),

    /**
     * "'2'"
     */
    VENDA_NA_PROXIMA_SEMANA( "VENDA NA PROXIMA SEMANA", "2" )
    ;

    private final String descricao;
    private final String valor;

    TipoVdaSemana( final String descricao,
                   final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }
}
