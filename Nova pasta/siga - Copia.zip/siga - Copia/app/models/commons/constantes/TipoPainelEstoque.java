package models.commons.constantes;

import infra.model.Constante;

public enum TipoPainelEstoque implements Constante<Short> {

    /**
     * Carga
     */
    CARGA ( "CARGA ENTREGA", (short) 1 ),

    /**
     * Antecipacao
     */
    ANTECIPACAO ( "ANTECIPACAO", (short) 2  ),

    /**
     * PCP
     */
    PCP( "PCP", (short) 3  ),

    /**
     * CARGA ESPECIAL
     */
    ESPECIAL( "ESPECIAL", (short) 4 ),

    ;

    private final String descricao;
    private final Short valor;

    TipoPainelEstoque( final String descricao,
                final Short valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public Short getValor() {

        return valor;
    }

    @Override
    public String toString() {

        return "Painel: " + valor + " - " + descricao;
    }
}