package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 22/10/2015
 */
public enum TipoConector implements Constante<String> {

    /**
     * "S"
     */
    SETOR( "SETOR", "S" ),

    /**
     * "R"
     */
    SIG_TABLET( "SIG / TABLET", "R" ),

    /**
     * "B"
     */
    IFAZENDA( "IFAZENDA", "B" ),

    /**
     * "G"
     */
    GERENTE( "GERENTE", "G" ),

    /**
     * "C"
     */
    COORDENADOR( "COORDENADOR", "C" ),

    /**
     * "P"
     */
    PROMOTOR( "PROMOTOR", "P" )
    ;

    private final String descricao;
    private final String valor;

    TipoConector( final String descricao,
                  final String valor ) {
        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }

}
