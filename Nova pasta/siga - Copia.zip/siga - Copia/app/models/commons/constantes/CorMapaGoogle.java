package models.commons.constantes;

import infra.model.Constante;

public enum CorMapaGoogle implements Constante<Short> {

    /**
     * 1
     */
    VERDE("VERDE", (short) 1 ),

    /**
     * 2
     */
    VERMELHO("VERMELHO", (short) 2 ),

    /**
     * 3
     */
    AZUL("AZUL", (short) 3 ),

    /**
     * 4
     */
    AMARELO("AMARELO", (short) 4 ),

    /**
     * 5
     */
    LARANJA("LARANJA", (short) 5 )

    ;

    private String descricao;
    private Short valor;

    CorMapaGoogle( String descricao, Short valor ) {
        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public Short getValor() {

        return this.valor;
    }
}
