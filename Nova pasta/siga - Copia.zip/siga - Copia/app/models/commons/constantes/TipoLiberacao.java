package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Andre Luiz Alves de Faria</p>
 *
 * @since 11/07/2018
 */
public enum TipoLiberacao implements Constante<Short> {

    /**
     * 1
     */
    ANTECIPACAO( "ANTECIPAÇÃO", (short) 1 ),

    /**
     * 2
     */
    CARGA_NORMAL( "CARGA NORMAL", (short) 2 ),

    /**
     * 3
     */
    CONSOLIDACAO( "CONSOLIDAÇÃO", (short) 3 ),

    /**
     * 4
     */
    ENTREGA_BOX_LIBERACAO( "ENTREGA BOX LIBERACAO", (short) 4 )
    ;

    private final String descricao;
    private final Short valor;

    TipoLiberacao( final String descricao,
                   final Short valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public Short getValor() {

        return valor;
    }

}


