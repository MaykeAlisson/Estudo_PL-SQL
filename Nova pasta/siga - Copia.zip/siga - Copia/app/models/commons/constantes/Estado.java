package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. aos estados da federação.
 *
 * <p>Autor: Cleber</p>
 *
 * @since 08/09/2014
 */
public enum Estado implements Constante<String> {

    /**
     * "MG"
     */
    MINAS_GERAIS("MINAS GERAIS","MG"),

    /**
     * "SP"
     */
    SAO_PAULO("SAO PAULO", "SP"),

    /**
     * "BA"
     */
    BAHIA("BAHIA","BA"),

    /**
     * "RJ"
     */
    RIO_JANEIRO("RIO DE JANEIRO","RJ"),

    /**
     * AL
     */
    ALAGOAS( "ALAGOAS", "AL" ),

    /**
     * AM
     */
    AMAZONAS( "AMAZONAS", "AM" ),

    /**
     * AP
     */
    AMAPA( "AMAPA", "AP" ),

    /**
     * DF
     */
    DISTRITO_FEDERAL( "DISTRITO FEDERAL", "DF" ),

    /**
     * GO
     */
    GOIAS( "GOIAS", "GO" ),

    /**
     * MS
     */
    MATO_GROSSO_DO_SUL( "MATO GROSSO DO SUL", "MS" ),

    /**
     * PA
     */
    PARA( "PARÁ", "PA" ),

    /**
     * PI
     */
    PIAUI( "PIAUI", "PI" ),

    /**
     * RN
     */
    RIO_GRANDE_DO_NORTE( "RIO GRANDE DO NORTE", "RN" ),

    /**
     * RO
     */
    RONDONIA( "RONDONIA", "RO" ),

    /**
     * AC
     */
    ACRE( "ACRE", "AC" ),

    /**
     * CE
     */
    CEARA( "CEARA", "CE" ),

    /**
     * ES
     */
    ESPIRITO_SANTO( "ESPÍRITO SANTO", "ES" ),

    /**
     * MA
     */
    MARANHAO( "MARANHÃO", "MA" ),

    /**
     * MT
     */
    MATO_GROSSO( "MATO GROSSO", "MT" ),

    /**
     * PE
     */
    PERNAMBUCO( "PERNAMBUCO", "PE" ),

    /**
     * PR
     */
    PARAIBA( "PARAIBA", "PB" ),

    /**
     * RR
     */
    RORAIMA( "RORAIMA", "RR" ),

    /**
     * RS
     */
    RIO_GRANDE_DO_SUL( "RIO GRANDE DO SUL", "RS" ),

    /**
     * SC
     */
    SANTA_CATARINA( "SANTA_CATARINA", "SC" ),

    /**
     * SE
     */
    SERGIPE( "SERGIPE", "SE" ),

    /**
     * TO
     */
    TOCANTINS( "TOCANTINS", "TO" ),

    /**
     * PA
     */
    PARANA( "PARANA", "PR")

    ;

    private String descricao;
    private String uf;

    Estado( final String descricao,
            final String uf ) {

        this.descricao = descricao;
        this.uf = uf;
    }


    @Override
    public String getDescricao() {
        return descricao;
    }

    @Override
    public String getValor() {
        return uf;
    }

}
