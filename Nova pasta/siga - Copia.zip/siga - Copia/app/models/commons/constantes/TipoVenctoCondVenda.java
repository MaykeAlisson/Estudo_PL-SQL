package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 11/01/2017
 */
public enum TipoVenctoCondVenda implements Constante<String> {

    /**
     * "N"
     */
    NORMAL( "NORMAL", "N" ),

    /**
     * "A"
     */
    LOJAS_AMERICANAS( "LOJAS AMERICANAS", "A" ),

    /**
     * "C"
     */
    CARREFOUR( "CARREFOUR", "C" ),

    /**
     * "L"
     */
    LEROY( "LEROY", "L" )
    ;

    private final String descricao;
    private final String valor;

    TipoVenctoCondVenda( final String descricao,
                         final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }

}