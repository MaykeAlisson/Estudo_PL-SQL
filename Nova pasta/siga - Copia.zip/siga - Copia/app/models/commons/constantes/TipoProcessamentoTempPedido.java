package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 09/01/2019
 */
public enum TipoProcessamentoTempPedido implements Constante<String> {

    /**
     * "S"
     */
    PROCESSADO( "PROCESSADO", "S" ),

    /**
     * "N"
     */
    NAO_PROCESSADO( "NAO PROCESSADO", "N" ),

    /**
     * "A"
     */
    ANORMALIDADE( "ANORMALIDADE", "A" ),

    /**
     * "T"
     */
    EM_PROCESSAMENTO( "EM PROCESSAMENTO", "T" ),

    /**
     * "L"
     */
    ARGUARDANDO_LIBERACAO( "ARGUARDANDO LIBERAÇÃO", "L" ),

    /**
     * "V"
     */
    TELEVENDAS( "TELEVENDAS", "V" )
    ;

    private final String descricao;
    private final String valor;

    TipoProcessamentoTempPedido(
        final String descricao,
        final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public String getValor() {

        return this.valor;
    }

}
