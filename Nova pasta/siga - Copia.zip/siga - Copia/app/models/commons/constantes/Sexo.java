package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 16/06/2015
 */
public enum Sexo implements Constante<String> {

    /**
     * "M"
     */
    MASCULINO("MASCULINO","M"),

    /**
     * "F"
     */
    FEMININO("FEMININO","F")
    ;

    private String descricao;
    private String valor;

    Sexo(
        final String descricao,
        final String valor
    ) {
        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {
        return descricao;
    }

    @Override
    public String getValor() {
        return valor;
    }

}
