package models.commons.constantes;


import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 20/10/2015
 */
public enum Escolaridade implements Constante<Integer> {

    /**
     * 1
     */
    PRIMARIO_INCOMPLETO( "PRIMARIO INCOMPLETO", 1 ),

    /**
     * 2
     */
    PRIMARIO_COMPLETO( "PRIMARIO COMPLETO", 2 ),

    /**
     * 3
     */
    PRIMEIRO_GRAU_INCOMPLETO( "1 GRAU INCOMPLETO", 3 ),

    /**
     * 4
     */
    PRIMEIRO_GRAU_COMPLETO( "1 GRAU COMPLETO", 4 ),

    /**
     * 5
     */
    SEGUNDO_GRAU_INCOMPLETO( "2 GRAU INCOMPLETO", 5 ),

    /**
     * 6
     */
    SEGUNDO_GRAU_COMPLETO( "2 GRAU COMPLETO", 6 ),

    /**
     * 7
     */
    TERCEIRO_GRAU_INCOMPLETO( "3 GRAU INCOMPLETO", 7 ),

    /**
     * 8
     */
    TERCEIRO_GRAU_COMPLETO( "3 GRAU COMPLETO", 8 ),

    /**
     * 9
     */
    ACIMA_TERCEIRO_GRAU( "ACIMA 3 GRAU", 9 )
    ;

    private final String descricao;
    private final Integer valor;

    Escolaridade( final String descricao,
                  final Integer valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public Integer getValor() {

        return valor;
    }

}