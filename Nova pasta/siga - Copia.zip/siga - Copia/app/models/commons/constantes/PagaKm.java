package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/12/2015
 */
public enum PagaKm implements Constante<Short> {

    /**
     * 1
     */
    UDI_AO_DESTINO( "UDI AO DESTINO", (short) 1 ),

    /**
     * 2
     */
    CDA_AO_DESTINO( "CDA AO DESTINO", (short) 2 ),

    /**
     * 3
     */
    NAO_PAGA_KM( "NAO PAGA KM", (short) 3 )
    ;

    private final String descricao;
    private final Short valor;

    PagaKm( final String descricao,
            final Short valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public Short getValor() {

        return valor;
    }

}
