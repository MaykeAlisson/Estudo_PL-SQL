package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de tipos de serviço do correio
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 26/12/2018
 */
public enum TipoServicoCorreio implements Constante<String> {

    /**
     * 40215
     */
    SEDEX_10( "SEDEX 10", "40215" ),

    /**
     * 40169
     */
    SEDEX_12( "SEDEX 12", "40169" ),

    /**
     * 04162
     */
    SEDEX_CONTRATO_AGENCIA( "SEDEX CONTRATO AGENCIA", "04162" ),

    /**
     * 04693
     */
    PAC_GRANDES_FORMATOS( "PAC CONTRATO GRANDES FORMATOS", "04693" ),

    /**
     * 04669
     */
    PAC_CONTRATO_AGENCIA( "PAC CONTRATO AGENCIA", "04669" ),

    /**
     * 12556
     */
    CARGA_FATURA_SELO( "CARGA COM A FATURA SELO", "12556" )

    ;

    private final String descricao;
    private final String valor;

    TipoServicoCorreio(
        final String descricao,
        final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public String getValor() {

        return this.valor;
    }

}
