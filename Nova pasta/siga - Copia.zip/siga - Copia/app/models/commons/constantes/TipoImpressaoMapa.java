package models.commons.constantes;

import infra.model.Constante;

import static java.lang.String.format;

/**
 * Constante ref. ao conjunto de valores de Tipo Impressao de Mapa.
 *
 * <p>Autor: Jander Dutra</p>
 *
 * @since 14/02/2019
 */
public enum TipoImpressaoMapa implements Constante<String> {

    /**
     * T
     */
    TOTAL( "TOTAL", "T"),

    /**
     * P
     */
    PARCIAL( "PARCIAL", "P")

    ;

    private final String descricao;
    private final String valor;

    TipoImpressaoMapa(
            final String descricao,
            final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public String getValor() {

        return this.valor;
    }

    @Override
    public String toString() {

        return format( "%s (%s)", getDescricao(), getValor() );
    }
}
