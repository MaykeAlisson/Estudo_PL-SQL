package models.commons.constantes;

import infra.model.Constante;

/**
 *
 * <p>Autor: Alysson Myller</p>
 *
 * @since 23/07/2018
 */
public enum SituacaoComboioVeiculo implements Constante<String> {

    /**
     * A - Afastado do Comboio
     */
    AFASTADO_DO_COMBOIO("Afastado do Comboio", "A"),

    /**
     * D - Distanciando
     */
    DISTANCIANDO("Distanciando", "D"),

    /**
     * N - Normal
     */
    NORMAL("Normal", "N"),;

    private final String descricao;
    private final String valor;

    SituacaoComboioVeiculo(final String descricao,
                           final String valor) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }

}
