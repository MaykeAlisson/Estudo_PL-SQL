package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 07/01/2016
 */
public enum TipoCarregamento implements Constante<String> {

    /**
     * "N"
     */
    NORMAL( "NORMAL", "N" ),

    /**
     * "D"
     */
    DIANTEIRA( "DIANTEIRA", "D" ),

    /**
     * "T"
     */
    TRASEIRA( "TRASEIRA", "T" )
    ;

    private final String descricao;
    private final String valor;

    TipoCarregamento( final String descricao,
                      final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }

}