package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 12/12/2018
 */
public enum SituacaoFuncionario implements Constante<String> {

    /**
     * 0
     */
    AFAST_PARCIAL( "AFAST.PARCIAL", "0" ),

    /**
     * 1
     */
    ATESTADO_INTERNO( "ATESTADO INTERNO", "1" ),

    /**
     * 2
     */
    ATESTADO_TRANSCRICAO_EXTERNA( "ATESTADO TRANSCRIÇÃO EXTERNA", "2" ),

    /**
     * 3
     */
    DOACAO_DE_SANGUE( "DOAÇÃO DE SANGUE", "3" ),

    /**
     * 4
     */
    LICENCA_PATERNIDADE( "LICENÇA PATERNIDADE", "4" ),

    /**
     * 5
     */
    LICENCA_OBITO( "LICENÇA / ÓBITO", "5" ),

    /**
     * 6
     */
	AFAST_ACID_TRABALHO_TRAJETO_EMPRESA( "AFAST.ACID.TRABALHO TRAJETO (EMPRESA)", "6" ),

    /**
     * 7
     */
    LIC_MATERNIDADE_ADOCAO_ATE_1_ANO( "LIC.MATERNIDADE ADOÇÃO ATÉ 1 ANO", "7" ),

    /**
     * 8
     */
    LIC_MATERNIDADE_ADOCAO_DE_1_A_4_ANOS( "LIC.MATERNIDADE ADOÇÃO DE 1 A 4 ANOS", "8" ),

    /**
     * 9
     */
    LIC_MATERNIDADE_ADOCAO_DE_4_A_8_ANOS( "LIC.MATERNIDADE ADOÇÃO DE 4 A 8 ANOS", "9" ),

    /**
     * A
     */
    ATIVO( "ATIVO", "A" ),

    /**
     * B
     */
	AFAST_ACID_TRABALHO_TRAJETO_INSS( "AFAST.ACID.TRABALHO TRAJETO (INSS)", "B" ),

    /**
     * C
     */
    AFAST_ACID_TRABALHO_TIPICO_INSS( "AFAST.ACID.TRABALHO TÍPICO (INSS)", "C" ),

    /**
     * D
     */
    DEMITIDO( "DEMITIDO", "D" ),

    /**
     * E
     */
    LICENCA_MATERNIDADE( "LICENÇA MATERNIDADE", "E" ),

    /**
     * F
     */
    FERIAS( "FÉRIAS", "F" ),

    /**
     * G
     */
    LICENCA_CASAMENTO( "LICENÇA CASAMENTO", "G" ),

    /**
     * H
     */
    LICENCA_MATERNIDADE_CIDADA( "LICENÇA MATERNIDADE CIDADÃ", "H" ),

    /**
     * I
     */
	APOSENT_POR_INVALIDEZ( "APOSENT. POR INVALIDEZ", "I" ),

    /**
     * J
     */
    ACOMPANHAMENTO_DE_MEMBRO_DA_FAMILIA_ENFERMO( "ACOMPANHAMENTO DE MEMBRO DA FAMÍLIA ENFERMO", "J" ),

    /**
     * K
     */
    FALTA( "FALTA", "K" ),

    /**
     * L
     */
    LICENCA_SEM_VENCIMENTOS( "LICENÇA SEM VENCIMENTOS", "L" ),

    /**
     * M
     */
    SERVICO_MILITAR( "SERVIÇO MILITAR", "M" ),

    /**
     * O
     */
    TRANSFERIDO( "TRANSFERIDO", "O" ),

    /**
     * P
     */
	AFAST_DOENCA_INSS( "AFAST.DOENÇA (INSS)", "P" ),

    /**
     * R
     */
    LICENCA_REMUNERADA( "LICENÇA REMUNERADA", "R" ),

    /**
     * T
     */
	AFAST_ACID_TRABALHO_TIPICO_EMPRESA( "AFAST.ACID.TRABALHO TÍPICO (EMPRESA)", "T" ),

    /**
     * U
     */
    FALTA_JUSTIFICADA( "FALTA JUSTIFICADA", "U" ),

    /**
     * Z
     */
    SERVICO_EXTERNO( "SERVIÇO EXTERNO", "Z" )
    ;

    private final String descricao;
    private final String valor;

    SituacaoFuncionario(
        final String descricao,
        final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public String getValor() {

        return this.valor;
    }
}