package models.commons.constantes;



import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 30/05/2016
 */
public enum AtividadeCusto implements Constante<String> {

    /**
     * "T"
     */
    TRANSPORTE( "TRANSPORTE", "T" ),

    /**
     * "S"
     */
    SEGURANCA( "SEGURANCA", "S" ),

    /**
     * "F"
     */
    VENDA( "VENDA (FATURAMENTO)", "F" ),


    /**
     * "B"
     */
    TRANSPORTE_TRANSBORDO( "TRANSPORTE_TRANSBORDO", "B" ),

    /**
     * "0"
     */
    TRANSPORTE_TERCEIROS( "TRANSPORTE_TERCEIROS", "0" ),
    /**
     * "N"
     */
    TRANSPORTE_ENTREGA( "TRANSPORTE_ENTREGA", "N" ),

    /**
     * "V"
     */
    DESPESA_COM_VENDAS( "DESPESA_COM_VENDAS", "V" ),

    /**
     * "E"
     */
    ESTOQUE_MOVIMENTACAO( "ESTOQUE_MOVIMENTACAO", "E" ),

    /**
     * "R"
     */
    COMISSOES_REPRESENTANTES( "COMISSOES_REPRESENTANTES", "R" ),

    /**
     * "P"
     */
    CONTA_PERDIDA( "CONTA_PERDIDA", "P" ),

    /**
     * "N"
     */
    DESPESA_COM_TELEVENDAS( "DESPESA_COM_TELEVENDAS", "L" ),

    /**
     * "C"
     */
    COBRANCA( "COBRANCA", "C" ),

    /**
     * "1"
     */
    NAO_OPERACIONAL( "NAO_OPERACIONAL", "1" ),

    /**
     * "A"
     */
    ADMINISTRACAO( "ADMINISTRACAO", "A" ),

    ;

    private final String descricao;
    private final String valor;

    AtividadeCusto( final String descricao,
                    final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }

    /**
     * @author Alysson Myller
     * @since 23/04/2018
     *
     * @param valor
     * @return A instância da classe de acordo com o valor
     */
    public static AtividadeCusto getInstance(String valor){
        for (AtividadeCusto e : AtividadeCusto.values()){
            if (e.getValor().equals((valor))){
                return e;
            }
        }
        return null;
    }
}
