package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 18/07/2018
 */
public enum TipoArquivoAnexo implements Constante<Short> {

    /**
     * 0
     */
    NENHUM( "NENHUM", (short) 0 ),

    /**
     * 1
     */
    IMAGEM( "IMAGEM", (short) 1 ),

    /**
     * 2
     */
    HTML( "HTML", (short) 2 ),

    /**
     * 3
     */
    AUDIO( "ÁUDIO", (short) 3 ),

    /**
     * 4
     */
    VIDEO( "VÍDEO", (short) 4 )
    ;

    private final String descricao;
    private final Short valor;

    TipoArquivoAnexo(
        final String descricao,
        final Short valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public Short getValor() {

        return this.valor;
    }
}