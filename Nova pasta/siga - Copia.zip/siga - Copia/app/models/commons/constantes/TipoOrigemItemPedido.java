package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de tipo origem do item pedido
 *
 * <p>Autor: GPortes</p>
 *
 * @since 09/01/2019
 */
public enum TipoOrigemItemPedido implements Constante<Long> {

    /**
     * 0
     */
    NENHUM( "NENHUM", 0L ),

    /**
     * 1
     */
    LISTA( "LISTA", 1L ),

    /**
     * 2
     */
    MANUAL( "MANUAL", 2L ),

    /**
     * 3
     */
    CATALOGO( "CATALOGO", 3L ),

    /**
     * 4
     */
    BANNER( "BANNER", 4L )
    ;

    private final String descricao;
    private final Long valor;

    TipoOrigemItemPedido(
        final String descricao,
        final Long valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public Long getValor() {

        return this.valor;
    }
}
