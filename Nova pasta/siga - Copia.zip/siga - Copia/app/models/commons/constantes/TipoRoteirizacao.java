package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. a tipo de roteirização
 *
 * <p>Autor: Jander Dutra</p>
 *
 * @since 29/05/2019
 */
public enum TipoRoteirizacao implements Constante<String> {

    /**
     * "C"
     */
    CIDADE( "SIM", "C" ),

    /**
     * "D"
     */
    DESTINATARIO( "SIM", "D" ),

    /**
     * "T"
     */
    ANTECIPACAO_FRACIONADO( "SIM", "T" ),

    /**
     * "P"
     */
    ANTECIPACAO_CAIXA_FECHADA( "SIM", "P" ),

    /**
     * "F"
     */
    ANTECIPACAO_CAIXA_FECHADA_CLIENTE( "NÃO", "F" );

    final private String descricao;
    final private String valor;

    TipoRoteirizacao(final String descricao,
                     final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }

}
