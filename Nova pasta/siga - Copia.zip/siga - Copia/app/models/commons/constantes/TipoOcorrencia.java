package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de tipos de ocorrência.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 08/09/2014
 */
public enum TipoOcorrencia implements Constante<Integer> {

    /**
     * 0
     */
    CREDITO("CREDITO", 0),

    /**
     * 1
     */
    CADASTRAL("CADASTRAL", 1);

    private String descricao;
    private Integer valor;

    TipoOcorrencia( String descricao, Integer valor ) {
        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {
        return descricao;
    }

    @Override
    public Integer getValor() {
        return valor;
    }

}
