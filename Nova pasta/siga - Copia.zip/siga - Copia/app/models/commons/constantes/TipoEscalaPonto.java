package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 16/07/2018
 */
public enum TipoEscalaPonto implements Constante<Short> {

    /**
     * 0
     */
    SEM_ESCALA( "SEM ESCALA", (short) 0 ),

    /**
     * 1
     */
    ESCALA_NORMAL( "ESCALA NORMAL", (short) 1 ),

    /**
     * 2
     */
    ESCALA_12X36( "ESCALA 12X36", (short) 2 ),

    /**
     * 3
     */
    ESCALA_4X1( "ESCALA 4X1", (short) 3 )
    ;

    private final String descricao;
    private final Short valor;

    TipoEscalaPonto(
        final String descricao,
        final Short valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public Short getValor() {

        return this.valor;
    }
}