package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/12/2015
 */
public enum TipoViagem implements Constante<Short> {

    /**
     * 1
     */
    TROCA( "TROCA", (short) 1 ),

    /**
     * 2
     */
    TRANSBORDO( "TRANSBORDO", (short) 2 ),

    /**
     * 3
     */
    ENTREGA( "ENTREGA", (short) 3 ),

    /**
     * 4
     */
    TRANSPORTADORA( "TRANSPORTADORA", (short) 4 )
    ;

    private final String descricao;
    private final Short valor;

    TipoViagem( final String descricao,
                final Short valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public Short getValor() {

        return valor;
    }

}
