package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 06/03/2019
 */
public enum TipoPedidoEspecial implements Constante<Short> {

    /**
     * 0
     */
    NORMAL( "NORMAL", (short) 0 ),

    /**
     * 1
     */
    ESPECIAL( "ESPECIAL", (short) 1 )
    ;

    private final String descricao;
    private final Short valor;

    TipoPedidoEspecial(
        final String descricao,
        final Short valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public Short getValor() {

        return this.valor;
    }

}
