package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 15/02/2019
 */
public enum TipoRastreador implements Constante<Short> {

    /**
     * 1
     */
    OMNILINK( "OMNILINK", (short) 1 ),

    /**
     * 3
     */
    TELEMACHINE( "TELEMACHINE", (short) 3 )
    ;

    private final String descricao;
    private final Short valor;

    TipoRastreador(
            final String descricao,
            final Short valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public Short getValor() {

        return this.valor;
    }

}