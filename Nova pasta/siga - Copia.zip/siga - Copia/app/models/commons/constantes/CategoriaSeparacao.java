package models.commons.constantes;

import infra.model.Constante;

import static java.lang.String.format;

/**
 * Constante ref. ao conjunto de valores de Categoria de Separacao.
 *
 * <p>Autor: Jander Dutra</p>
 *
 * @since 14/02/2019
 */
public enum CategoriaSeparacao implements Constante<Short> {

    /**
     * 1
     */
    ALIMENTOS( "ALIMENTOS", (short)1),

    /**
     * 2
     */
    INFLAMAVEIS( "INFLAMAVEIS", (short)2),

    /**
     * 3
     */
    PILHAS_BATERIAS( "PILHAS/BATERIAS", (short)3),

    /**
     * 4
     */
    MEDICAMENTOS( "MEDICAMENTOS", (short)4),

    /**
     * 5
     */
    OUTROS( "OUTROS", (short)5)

    ;

    private final String descricao;
    private final Short valor;

    CategoriaSeparacao(final String descricao,
                       final Short valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {
        return descricao;
    }

    @Override
    public Short getValor() {
        return valor;
    }


    @Override
    public String toString() {

        return format( "%s (%d)", getDescricao(), getValor() );
    }
}
