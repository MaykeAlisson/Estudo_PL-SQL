package models.commons.constantes;

import infra.model.Constante;

import java.util.Arrays;

/**
 * Constante ref. ao conjunto de valores de tipos de roteirização antecipação
 *
 * <p>Autor: Jander Dutra</p>
 *
 * @since 02/01/2019
 */
public enum TipoRoteirizacaoAntecipacao implements Constante<Short> {

    /**
     * 1
     */
   FRACIONADO_ESTILO_CARGA( "FRACIONADO ESTILO CARGA", (short) 1, (short) 3 ),

    /**
     * 2
     */
    FRACIONADO_ESTILO_CONSOLIDACAO( "FRACIONADO ESTILO CONSOLIDACAO", (short) 2, (short) 4 ),

    /**
     * 3
     */
    FRACIONADO_ESTILO_CONSOLIDACAO_ALIMENTICIO( "FRACIONADO ESTILO CONSOLIDACAO ALIMENTICIO", (short) 3, (short) 6 ),

    /**
     * 4
     */
    CAIXA_FECHADA_MIX_FRACIONADO( "CAIXA FECHADA MIX FRACIONADO", (short) 4, (short) 3),

    ;

    private final String descricao;
    private final Short valor;
    private final Short tipoBoxAntecipacao;

    TipoRoteirizacaoAntecipacao(
            final String descricao,
            final Short valor,
            final Short tipoBoxAntecipacao
    ) {

        this.descricao = descricao;
        this.valor = valor;
        this.tipoBoxAntecipacao = tipoBoxAntecipacao;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public Short getValor() {

        return this.valor;
    }

    public Short getTipoBoxAntecipacao() {
        return tipoBoxAntecipacao;
    }

    /**
     * @param valor
     * @return A instância da classe de acordo com o valor
     */
    public static TipoRoteirizacaoAntecipacao getInstance(Short valor){
        return Arrays.stream(TipoRoteirizacaoAntecipacao.values())
                .filter(e -> e.getValor().equals(valor))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException(String.format("Tipo não suportado %d.", valor)));
    }
}
