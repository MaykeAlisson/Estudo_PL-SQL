package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de tipos de acertos.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 08/09/2014
 */
public enum TipoAcerto implements Constante<String> {

    /**
     * "C"
     */
    CAIXA("CAIXA","C"),

    /**
     * "M"
     */
    MOTORISTA("MOTORISTA","M"),

    /**
     * "B"
     */
    BAIXA("BAIXA","B"),

    /**
     * "J"
     */
    JURIDICO("JURIDICO","J"),

    /**
     * "P"
     */
    CONTA_PERDIDA("CONTA PERDIDA","P");

    private String valor;
    private String descricao;

    private TipoAcerto(String descricao, String valor) {
        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {
        return descricao;
    }

    @Override
    public String getValor() {
        return valor;
    }


}
