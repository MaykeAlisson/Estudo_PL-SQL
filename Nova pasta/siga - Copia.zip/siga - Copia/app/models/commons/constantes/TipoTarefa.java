package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de tipos de tarefas do sistema de obrigações(RH)
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 04/10/2017
 */
public enum TipoTarefa implements Constante<Integer> {

    /**
     * 1
     */
    DIA_UTIL( "DIA UTIL", 1 ),

    /**
     * 2
     */
    DIARIA( "DIARIA", 2 ),

    /**
     * 3
     */
    SEMANAL( "SEMANAL", 3 ),

    /**
     * 4
     */
    MENSAL( "MENSAL", 4 ),

    /**
     * 5
     */
    ANUAL( "ANUAL", 5 ),

    /**
     * 6
     */
    POR_PERIODO( "POR PERIODO", 6 )
    ;

    private final String descricao;
    private final Integer valor;

    TipoTarefa( final String descricao,
                final Integer valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public Integer getValor() {

        return valor;
    }

}
