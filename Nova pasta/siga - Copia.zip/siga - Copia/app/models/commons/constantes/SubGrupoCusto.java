package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 30/05/2016
 */
public enum SubGrupoCusto implements Constante<String> {

    /* Vagos:   K L Q U W   */

    /**
     * "Z"
     */
    RECEITAS( "RECEITAS", "Z" ),

    /**
     * "A"
     */
    FRETE_ENTREGA( "FRETE_ENTREGA", "A" ),

    /**
     * "X"
     */
    DESCARGA_MOVIMENTACAO( "DESCARGA_MOVIMENTACAO", "X" ),

    /**
     * "Y"
     */
    PESSOAL_MOTORISTAS( "PESSOAL_MOTORISTAS", "Y" ),

    /**
     * "F"
     */
    EVENTOS_CORPORATIVOS( "EVENTOS_CORPORATIVOS", "F" ),

    /**
     * "H
     */
    PROMOTORES_MERCHANDISING( "PROMOTORES_MERCHANDISING", "H" ),

    /**
     * "J"
     */
    JURIDICOS_CUSTAS( "JURIDICOS_CUSTAS", "J" ),

    /**
     * "N"
     */
    CONTABEIS( "CONTABEIS", "N" ),

    /**
     * "G"
     */
    ALUGUEIS( "ALUGUEIS", "G" ),

    /**
     * "C"
     */
    COMBUSTIVEIS( "COMBUSTIVEIS", "C" ),

    /**
     * "0"
     */
    IMPOSTOS( "IMPOSTOS", "0" ),

    /**
     * "4"
     */
    IMPOSTOS_BRINDES( "IMPOSTOS S/BRINDES", "4" ),

    /**
     * "5"
     */
    IMPOSTOS_BONIFICACOES( "IMPOSTOS S/BONIFICACOES", "5" ),

    /**
     * "B"
     */
    BRINDES( "BRINDES", "B" ),

    /**
     * "3"
     */
    BONIFICACOES( "BONIFICACOES", "3" ),


    /**
     * "1"
     */
    FATURAMENTO( "FATURAMENTO", "1" ),

    /**
     * "2"
     */
    CMV( "CMV", "2" ),

    /**
     * "I"
     */
    COMBUSTIVEIS_POSTO_INTERNO( "COMBUSTIVEIS POSTO INTERNO", "I" ),

    /**
     * "O"
     */
    OFICINA( "OFICINA", "O" ),

    /**
     * "T"
     */
    TELECOM_COMUNICACAO( "TELECOM_COMUNICACAO", "T" ),

    /**
     * "P"
     */
    PESSOAL( "PESSOAL", "P" ),

    /**
     * "D"
     */
    DIVERSOS( "DIVERSOS", "D" ),
    /**
     * "6"
     */
    DEVOLUCOES( "DEVOLUCOES", "6" ),

    /**
     * "V"
     */
    VIAGEM( "VIAGENS", "V" ),

    /**
     * "7"
     */
    PEDAGIO( "PEDAGIO", "7" ),
    /**
     * "8"
     */
    ELIMINACAO_TRANSP( "ELIMINACOES_TRANSPORTADORAS", "8" ),
    /**
     * "9"
     */
    AGUA_ENERGIA( "AGUA_ENERGIA", "9" ),
    /**
     * "S"
     */
    SEGURANCA( "SEGURANCA", "S" ),

    /**
     * "R"
     */
    TERCEIROS_TRANSBORDO( "TERCEIROS_TRANSBORDO", "R" ),

    /**
     * "E"
     */
    MANUTENCAO_E_MATERIAIS( "MANUTENCAO_E_MATERIAIS", "E" ),


    /**
     * "M"
     */
    COMISSAO_REPRESENTANTE( "COMISSAO_REPRESENTANTE", "M" )
    ;

    private final String descricao;
    private final String valor;

    SubGrupoCusto ( final String descricao,
                    final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }

    /**
     * @author Alysson Myller
     * @since 23/04/2018
     *
     * @param valor
     * @return A instância da classe de acordo com o valor
     */
    public static SubGrupoCusto getInstance(String valor){
        for (SubGrupoCusto e : SubGrupoCusto.values()){
            if (e.getValor().equals((valor))){
                return e;
            }
        }
        return null;
    }
}

