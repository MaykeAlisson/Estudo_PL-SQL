package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 16/06/2015
 */
public enum TipoRepresentante implements Constante<String> {

    /**
     * "G"
     */
    GERENTE( "GERENTE","G" ),

    /**
     * "R"
     */
    REPRESENTANTE( "REPRESENTANTE", "R" ),

    /**
     * "B"
     */
    BALCAO( "BALCÃO", "B" ),

    /**
     * "P"
     */
    PROMOTOR_DE_VENDA( "PROMOTOR DE VENDA", "P" ),

    /**
     * "M"
     */
    MOTORISTA( "MOTORISTA", "M" )
    ;

    private final String descricao;
    private final String valor;

    TipoRepresentante( final String descricao,
                       final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }

}