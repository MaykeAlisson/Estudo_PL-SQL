package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de tipos de geração de dados.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 10/01/2019
 */
public enum TipoDestinatarioGeracaoDado implements Constante<String> {

    /**
     * "S"
     */
    SETOR( "SETOR", "S" ),

    /**
     * "G"
     */
    GERENTE( "GERENTE", "G" ),

    /**
     * "N"
     */
    GENERICO( "GENERICO", "N" ),

    /**
     * "B"
     */
    BANCO_DE_DADOS( "BANCO DE DADOS", "B" )
    ;

    private final String descricao;
    private final String valor;

    TipoDestinatarioGeracaoDado(
        final String descricao,
        final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public String getValor() {

        return this.valor;
    }
}