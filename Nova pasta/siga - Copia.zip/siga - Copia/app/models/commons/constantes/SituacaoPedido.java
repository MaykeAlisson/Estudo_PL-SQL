package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de situações do pedido.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 08/09/2014
 */
public enum SituacaoPedido implements Constante<String> {

    /**
     * "P"
     */
    PENDENTE("PENDENTE","P"),

    /**
     * "A"
     */
    AVALIACAO("AVALIAÇÃO","A"),

    /**
     * "N"
     */
    NORMAL("NORMAL","N"),

    /**
     * "C"
     */
    CANCELADO("CANCELADO","C");

    private String valor;
    private String descricao;

    SituacaoPedido( final String descricao,
                    final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {
        return descricao;
    }

    @Override
    public String getValor() {
        return valor;
    }

    @Override
    public String toString() {
        return "SituacaoPedido{" +
                "valor='" + valor + '\'' +
                ", descricao='" + descricao + '\'' +
                '}';
    }

    public static boolean ehCancelado( final SituacaoPedido situacao ) {

        return situacao != null && CANCELADO.equals( situacao );
    }

    public static boolean ehPendente( final SituacaoPedido situacao ) {

        return situacao != null && PENDENTE.equals( situacao );
    }

    public static boolean ehNormal( final SituacaoPedido situacao ) {

        return situacao != null && NORMAL.equals( situacao );
    }

    public static boolean ehAvaliacao( final SituacaoPedido situacao ) {

        return situacao != null && AVALIACAO.equals( situacao );
    }

}
