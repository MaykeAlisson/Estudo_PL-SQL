package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de tipos de solicitante do sistema de Obrigações (RH)
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 04/10/2017
 */
public enum TipoSolicitanteObrigacao implements Constante<String> {

    /**
     * "U"
     */
    USUARIO( "USUARIO", "U" ),

    /**
     * "R"
     */
    REPRESENTANTE( "REPRESENTANTE", "R" ),

    /**
     * "F"
     */
    FORNECEDOR( "FORNECEDOR", "F" ),

    /**
     * "N"
     */
    FUNCIONARIO( "FUNCIONARIO", "N" ),

    /**
     * "C"
     */
    CLIENTE( "CLIENTE", "C" )
    ;

    private final String descricao;
    private final String valor;

    TipoSolicitanteObrigacao( final String descricao,
                              final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }

}
