package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 27/07/2015
 */
public enum CentroCusto implements Constante<Short> {

    TRANSPORTE("TRANSPORTE",(short) 10),
    INFORMATICA("INFORMATICA",(short) 12),
    SEGURANCA("SEGURANCA",(short) 81),
    PROMO_EVENTOS("PROMOCOES_EVENTOS",(short) 8),
    CONTABILIDADE("CONTABILIDADE",(short) 15),
    JURIDICO("JURIDICO",(short) 55),
    MANUTENCAO("MANUTENCAO",(short) 34)
    ;

    private String descricao;
    private Short valor;

    CentroCusto( final String descricao,
               final Short valor ) {
        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {
        return descricao;
    }

    @Override
    public Short getValor() {
        return valor;
    }
}

