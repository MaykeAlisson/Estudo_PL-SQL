package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 20/09/2018
 */
public enum TipoAnaliseCredito implements Constante<Integer> {

    /**
     * 1
     */
    PEDIDO_NORMAL( "PEDIDO NORMAL", 1 ),

    /**
     * 2
     */
    PEDIDO_ANTECIPADO( "PEDIDO ANTECIPADO", 2 ),

    /**
     * 3
     */
    PEDIDO_ECOMMERCE( "PEDIDO ECOMMERCE", 3 )
    ;

    private final String descricao;
    private final Integer valor;

    TipoAnaliseCredito(
        final String descricao,
        final Integer valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public Integer getValor() {

        return this.valor;
    }
}

