package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de tipos de destinatarios.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 08/09/2014
 */
public enum TipoDestinatario implements Constante<String> {

    /**
     * "C"
     */
    CLIENTE("CLIENTE","C") ,

    /**
     * "E"
     */
    EMPRESA("EMPRESA","E"),

    /**
     * "F"
     */
    FORNECEDOR("FORNECEDOR","F"),

    /**
     * "R"
     */
    REPRESENTANTE("REPRESENTANTE","R")
    ;

    private String descricao;
    private String valor;

    private TipoDestinatario(String descricao, String valor) {
        this.descricao = descricao;
        this.valor = valor;
    }


    @Override
    public String getDescricao() {
        return this.descricao;
    }

    @Override
    public String getValor() {
        return this.valor;
    }

}
