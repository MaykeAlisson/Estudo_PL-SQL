package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Antoniocarlos</p>
 *
 * @since 05/06/2019
 */
public enum TipoModeloEquipamento implements Constante<Short> {

    /**
     * 1
     */
    SMARTPHONE( "SMARTPHONE", (short) 1 ),

    /**
     * 2
     */
    TABLET( "TABLET", (short) 2 )
    ;

    private final String descricao;
    private final Short valor;

    TipoModeloEquipamento(
        final String descricao,
        final Short valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public Short getValor() {

        return this.valor;
    }

}