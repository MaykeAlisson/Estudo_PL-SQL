package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Victor.serafim</p>
 *
 * @since 11/12/2018
 */
public enum TipoSolicitacaoTelemachine implements Constante<Short> {

    /**
     * 15
     */
    ESTENDER_JORNADA_MOTORISTA( "ESTENDER JORNADA MOTORISTA", (short) 15 ),

    /**
     * 16
     */
    LIBERAR_JORNADA_MOTORISTA( "LIBERAR JORNADA_MOTORISTA", (short) 16 )
    ;

    private final String descricao;
    private final Short valor;

    TipoSolicitacaoTelemachine(
        final String descricao,
        final Short valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public Short getValor() {

        return this.valor;
    }

}