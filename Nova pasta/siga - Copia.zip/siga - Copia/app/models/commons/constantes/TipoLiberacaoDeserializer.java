package models.commons.constantes;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

import java.io.IOException;

import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;

public class TipoLiberacaoDeserializer extends StdDeserializer<TipoLiberacao> {

    public TipoLiberacaoDeserializer() {

        this(null);
    }

    public TipoLiberacaoDeserializer( final Class<TipoLiberacao> clazz ) {

        super(clazz);
    }

    @Override
    public TipoLiberacao deserialize(
        final JsonParser jsonParser,
        final DeserializationContext ctxt
    ) throws IOException {

        return getEnum( TipoLiberacao.class, toShort( jsonParser.getText() ).orElse(null ) );
    }
}
