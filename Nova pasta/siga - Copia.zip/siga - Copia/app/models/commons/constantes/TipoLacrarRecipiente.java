package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 28/12/2018
 */
public enum TipoLacrarRecipiente implements Constante<String> {

    /**
     * "S"
     */
    SIM( "SIM", "S" ),

    /**
     * "N"
     */
    NAO( "NAO", "N" ),

    /**
     * "G"
     */
    GRUPO_CIDADE( "GRUPO CIDADE", "G" )
    ;

    private final String descricao;
    private final String valor;

    TipoLacrarRecipiente(
        final String descricao,
        final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public String getValor() {

        return this.valor;
    }

}
