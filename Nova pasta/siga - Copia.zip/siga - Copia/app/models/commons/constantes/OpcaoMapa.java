package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de OpcaoMapa.
 *
 * <p>Autor: Jander Dutra</p>
 *
 * @since 27/12/2018
 */
public enum OpcaoMapa implements Constante<String> {
    /**
     * G
     */
    GERADO("GERADO", "G"),

    /**
     * R
     */
    RE_IMPRESSAO("RE_IMPRESSAO", "R");

    OpcaoMapa(String descricao, String valor) {
        this.descricao = descricao;
        this.valor = valor;
    }

    private final String valor;
    private final String descricao;

    public String getValor() {
        return valor;
    }

    public String getDescricao() {
        return descricao;
    }

}
