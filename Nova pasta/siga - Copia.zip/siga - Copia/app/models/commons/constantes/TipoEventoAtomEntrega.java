package models.commons.constantes;




import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 17/04/2017
 */
public enum TipoEventoAtomEntrega implements Constante<Integer> {

    /**
     * 01
     */
    ENTREGA_NÃO_INICIADA( "ENTREGA NAO INICIADA", 01 ),

    /**
     * 02
     */
    ENTREGA_INICIADA( "ENTREGA INICIADA", 02 ),

    /**
     * 03
     */
    ENTREGA_FINALIZADA( "ENTREGA FINALIZADA", 03 ),

    /**
     * 04
     */
    ENTREGA_TRANSFERIDA_PARA_OUTRO_ACERTO( "ENTREGA TRANSFERIDA PARA OUTRO ACERTO", 04 ),

    /**
     * 06
     */
    ENTREGA_RECEBIDA_DE_OUTRA_VIAGEM( "ENTREGA RECEBIDA DE OUTRA VIAGEM", 06 ),

    /**
     * 07
     */
    TROCA_DE_ENTREGA_POR_MOTIVO_HORARIO( "TROCA DE ENTREGA POR MOTIVO HORARIO", 07 ),

    /**
     * 08
     */
    TROCA_ENTREGA_POR_MOTIVO_VOLUME( "TROCA ENTREGA POR MOTIVO VOLUME", 8 ),

    /**
     * 09
     */
    TROCA_ENTREGA_POR_FALTA_DE_COORDENADAS( "TROCA ENTREGA POR FALTA DE COORDENADAS", 9 ),

    /**
     * 14
     */
    ENTREGA_ORIGINOU_TROCA( "ENTREGA QUE ORIGINOU TROCA", 14 ),

    /**
     * 50
     */
    ENTREGA_CANCELADA_CLIENTE_NÃO_PODE_ATENDER( "ENTREGA CANCELADA CLIENTE NAO PODE ATENDER", 50 ),

    /**
     * 51
     */
    ENTREGA_CANCELADA_INICIEI_POR_ENGANO( "ENTREGA CANCELADA INICIEI POR ENGANO", 51 ),

    /**
     * 52
     */
    ENTREGA_CANCELADA_DEVOLUÇÃO_TOTAL( "ENTREGA CANCELADA DEVOLUCAO TOTAL", 52 )
    ;

    private final String descricao;
    private final Integer valor;

    TipoEventoAtomEntrega( final String descricao,
                           final Integer valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public Integer getValor() {

        return valor;
    }

}

