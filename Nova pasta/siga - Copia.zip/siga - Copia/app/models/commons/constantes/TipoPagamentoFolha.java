package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 18/06/2018
 */
public enum TipoPagamentoFolha implements Constante<String> {

    /**
     * "C"
     */
    CHEQUE( "CHEQUE", "C" ),

    /**
     * "A"
     */
    ARQUIVO( "ARQUIVO", "A" ),

    /**
     * "E"
     */
    EVENTUAL( "EVENTUAL", "E" ),

    /**
     * "R"
     */
    RELATORIO( "RELATORIO", "R" )
    ;

    private final String descricao;
    private final String valor;

    TipoPagamentoFolha(
        final String descricao,
        final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }

}

