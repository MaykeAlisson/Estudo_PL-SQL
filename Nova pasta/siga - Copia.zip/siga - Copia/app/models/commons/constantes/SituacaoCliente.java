package models.commons.constantes;

public enum SituacaoCliente {

    IMPLANTACAO {

        @Override
        public SituacaoLimitadorAcrescimo getLimitador() {

            return SituacaoLimitadorAcrescimo.CLIENTE_IMPLANTACAO;
        }
    },

    NAO_IMPLANTACAO {

        @Override
        public SituacaoLimitadorAcrescimo getLimitador() {

            return SituacaoLimitadorAcrescimo.CLIENTE_NAO_IMPLANTACAO;
        }
    },

    REATIVADO {

        @Override
        public SituacaoLimitadorAcrescimo getLimitador() {

            return SituacaoLimitadorAcrescimo.CLIENTE_REIMPLANTACAO;
        }
    },

    REATIVADO_HOJE {

        @Override
        public SituacaoLimitadorAcrescimo getLimitador() {

            return SituacaoLimitadorAcrescimo.CLIENTE_REIMPLANTACAO;
        }
    };

    public abstract SituacaoLimitadorAcrescimo getLimitador();

    public static boolean isImplantadoOrReativado( final SituacaoCliente situacaoCliente ) {

        return IMPLANTACAO.equals( situacaoCliente ) || REATIVADO.equals( situacaoCliente ) || REATIVADO_HOJE.equals( situacaoCliente );
    }

    public static boolean isImplantado( final SituacaoCliente situacaoCliente ) {

        return IMPLANTACAO.equals( situacaoCliente );
    }

}