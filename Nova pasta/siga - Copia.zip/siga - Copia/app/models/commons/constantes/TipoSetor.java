package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de tipos de Setor.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 16/06/2015
 */
public enum TipoSetor implements Constante<String> {

    /**
     * "S"
     */
    SETOR( "SETOR", "S" ),

    /**
     * "G"
     */
    GERENCIAL( "GERENCIAL", "G" ),

    /**
     * "P"
     */
    PROMOTOR( "PROMOTOR", "P" ),

    /**
     * "D"
     */
    CLASSE_A_DOURADO( "CLASSE A DOURADO", "D" ),

    ;

    private final String descricao;
    private final String valor;

    TipoSetor( final String descricao,
               final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }
}
