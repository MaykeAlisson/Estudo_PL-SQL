package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 28/12/2018
 */
public enum TipoCompraConsumo implements Constante<String> {

    /**
     * "S"
     */
    NAO_CONTRIBUITE( "NAO CONTRIBUITE", "S" ),

    /**
     * "C"
     */
    CONSUMIDOR_FINAL( "CONSUMIDOR FINAL", "C" ),

    /**
     * "N"
     */
    NAO_COMPRA_CONSUMO( "NAO COMPRA CONSUMO", "N" ),

    /**
     * "I"
     */
    IMUNE_SEM_FINS_LUCRATIVO( "IMUNE SEM FINS LUCRATIVO", "I" )
    ;

    private final String descricao;
    private final String valor;

    TipoCompraConsumo(
        final String descricao,
        final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public String getValor() {

        return this.valor;
    }
}