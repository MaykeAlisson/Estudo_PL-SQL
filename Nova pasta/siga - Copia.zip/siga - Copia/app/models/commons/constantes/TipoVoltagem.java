package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de tipos de voltagem.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 09/01/2019
 */
public enum TipoVoltagem implements Constante<Short> {

    /**
     * 110
     */
    VOLTAGEM_110( "VOLTAGEM 110", (short) 110 ),

    /**
     * 220
     */
    VOLTAGEM_220( "VOLTAGEM 220", (short) 220 )
    ;

    private final String descricao;
    private final Short valor;

    TipoVoltagem(
        final String descricao,
        final Short valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public Short getValor() {

        return this.valor;
    }
}
