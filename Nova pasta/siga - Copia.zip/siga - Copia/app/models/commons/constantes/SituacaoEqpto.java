package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/10/2017
 */
public enum SituacaoEqpto implements Constante<String> {

    /**
     * "P"
     */
    PENDENTE( "PENDENTE", "P" ),

    /**
     * "S"
     */
    SOLUCIONADO( "SOLUCIONADO", "S" ),

    /**
     * "M"
     */
    MANUTENCAO( "MANUTENCAO", "M" )
    ;

    private final String descricao;
    private final String valor;

    SituacaoEqpto( final String descricao,
                   final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }
}
