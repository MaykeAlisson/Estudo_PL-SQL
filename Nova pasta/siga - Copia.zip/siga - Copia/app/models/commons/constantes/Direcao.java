package models.commons.constantes;

import infra.model.Constante;

import static java.lang.String.format;

/**
 * Constante ref. ao conjunto de valores de direções nas rotas do rastreador.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 30/03/2017
 */
public enum Direcao implements Constante<String> {

    /**
     * "LESTE"
     */
    LESTE( "LESTE", "Leste" ),

    /**
     * "NORDESTE"
     */
    NORDESTE( "NORDESTE", "Nordeste" ),

    /**
     * "NOROESTE"
     */
    NOROESTE( "NOROESTE", "Noroeste" ),

    /**
     * "NORTE"
     */
    NORTE( "NORTE", "Norte" ),

    /**
     * "OESTE"
     */
    OESTE( "OESTE", "Oeste" ),

    /**
     * "SUDESTE"
     */
    SUDESTE( "SUDESTE", "Sudeste" ),

    /**
     * "SUDOESTE"
     */
    SUDOESTE( "SUDOESTE", "Sudoeste" ),

    /**
     * "SUL"
     */
    SUL( "SUL", "Sul" ),

    /**
     * "CENTRO"
     */
    CENTRO( "CENTRO", "Centro");
    ;

    private final String descricao;
    private final String valor;

    Direcao( final String descricao,
             final String valor ) {

        this.descricao = descricao;
        this.valor = format("%-8s", valor);
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }
}
