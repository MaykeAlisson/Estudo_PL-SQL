package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 09/01/2019
 */
public enum SituacaoSetor implements Constante<String> {

    /**
     * "V"
     */
    VAGO( "VAGO", "V" ),

    /**
     * "F"
     */
    FERIAS( "FERIAS", "F" ),

    /**
     * "A"
     */
    AFASTADO( "AFASTADO", "A" ),

    /**
     * "N"
     */
    NORMAL( "NORMAL", "N" )
    ;

    private final String descricao;
    private final String valor;

    SituacaoSetor(
        final String descricao,
        final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public String getValor() {

        return this.valor;
    }

}
