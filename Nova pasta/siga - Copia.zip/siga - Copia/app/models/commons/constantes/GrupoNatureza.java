package models.commons.constantes;

import infra.model.Constante;

import static infra.util.UtilString.preencherComEspacosADireita;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 16/06/2015
 */
public enum GrupoNatureza implements Constante<String> {

    /**
     * "ATIVOCONS"
     */
    ATIVOCONS("ATIVOCONS","ATIVOCONS"),

    /**
     * "AVARIAPERD"
     */
    AVARIAPERD("AVARIAPERD","AVARIAPERD"),

    /**
     * "BAIXAENCER"
     */
    BAIXAENCER("BAIXAENCER","BAIXAENCER"),

    /**
     * "BONIFICCLI"
     */
    BONIFICCLI("BONIFICCLI","BONIFICCLI"),

    /**
     * "BRINDES"
     */
    BRINDES("BRINDES","BRINDES"),

    /**
     * "COMPCOMEST"
     */
    COMPCOMEST("COMPCOMEST","COMPCOMEST"),

    /**
     * "COMPRACOM"
     */
    COMPRACOM("COMPRACOM","COMPRACOM"),

    /**
     * "DEVBONIFIC"
     */
    DEVBONIFIC("DEVBONIFIC","DEVBONIFIC"),

    /**
     * "DEVCLI"
     */
    DEVCLI("DEVCLI","DEVCLI"),

    /**
     * "DEVCOMERC"
     */
    DEVCOMERC("DEVCOMERC","DEVCOMERC"),

    /**
     * "DEVCONSUMO"
     */
    DEVCONSUMO("DEVCONSUMO","DEVCONSUMO"),

    /**
     * "DEVENTSBT"
     */
    DEVENTSBT("DEVENTSBT","DEVENTSBT"),

    /**
     * "DEVEXPINDI"
     */
    DEVEXPINDI("DEVEXPINDI","DEVEXPINDI"),

    /**
     * "DEVFOR"
     */
    DEVFOR("DEVFOR","DEVFOR"),

    /**
     * "DEVOLEXTER"
     */
    DEVOLEXTER("DEVOLEXTER","DEVOLEXTER"),

    /**
     * "ENTBONIFIC"
     */
    ENTBONIFIC("ENTBONIFIC","ENTBONIFIC"),

    /**
     * "ENTDEVRLST"
     */
    ENTDEVRLST("ENTDEVRLST","ENTDEVRLST"),

    /**
     * "ENTDIPJ"
     */
    ENTDIPJ("ENTDIPJ","ENTDIPJ"),

    /**
     * "ENTRAATIVO"
     */
    ENTRAATIVO("ENTRAATIVO","ENTRAATIVO"),

    /**
     * "ENTRETDEMO"
     */
    ENTRETDEMO("ENTRETDEMO","ENTRETDEMO"),

    /**
     * "ENTRETREPA"
     */
    ENTRETREPA("ENTRETREPA","ENTRETREPA"),

    /**
     * "ENTSIMPREM"
     */
    ENTSIMPREM("ENTSIMPREM","ENTSIMPREM"),

    /**
     * "ENTSPED"
     */
    ENTSPED("ENTSPED","ENTSPED"),

    /**
     * "ENTTELECOM"
     */
    ENTTELECOM("ENTTELECOM","ENTTELECOM"),

    /**
     * "ENTTRANSF"
     */
    ENTTRANSF("ENTTRANSF","ENTTRANSF"),

    /**
     * "ENTTRFST"
     */
    ENTTRFST("ENTTRFST","ENTTRFST"),

    /**
     * "EXPINDIRET"
     */
    EXPINDIRET("EXPINDIRET","EXPINDIRET"),

    /**
     * "IMPDIRCOM"
     */
    IMPDIRCOM("IMPDIRCOM","IMPDIRCOM"),

    /**
     * "IMPDIRETA"
     */
    IMPDIRETA("IMPDIRETA","IMPDIRETA"),

    /**
     * "IMPIMOBILI"
     */
    IMPIMOBILI("IMPIMOBILI","IMPIMOBILI"),

    /**
     * "IPIBSICM"
     */
    IPIBSICM("IPIBSICM","IPIBSICM"),

    /**
     * "NFEDEVOL"
     */
    NFEDEVOL("NFEDEVOL","NFEDEVOL"),

    /**
     * "OUTSAIRLST"
     */
    OUTSAIRLST("OUTSAIRLST","OUTSAIRLST"),

    /**
     * "PERDA_DET"
     */
    PERDA_DET("PERDA_DET","PERDA_DET"),

    /**
     * "RECLASMERC"
     */
    RECLASMERC("RECLASMERC","RECLASMERC"),

    /**
     * "RESSARCST"
     */
    RESSARCST("RESSARCST","RESSARCST"),

    /**
     * "ROBSON"
     */
    ROBSON("ROBSON","ROBSON"),

    /**
     * "SAIDAATIVO"
     */
    SAIDAATIVO("SAIDAATIVO","SAIDAATIVO"),

    /**
     * "SAIDIPJ"
     */
    SAIDIPJ("SAIDIPJ","SAIDIPJ"),

    /**
     * "SREMESSA"
     */
    SREMESSA("SREMESSA","SREMESSA"),

    /**
     * "TRANSF"
     */
    TRANSF("TRANSF","TRANSF"),

    /**
     * "TRANSFCONS"
     */
    TRANSFCONS("TRANSFCONS","TRANSFCONS"),

    /**
     * "TRANSFFORA"
     */
    TRANSFFORA("TRANSFFORA","TRANSFFORA"),

    /**
     * "TRANSFSST"
     */
    TRANSFSST("TRANSFSST","TRANSFSST"),

    /**
     * "TRANSFST"
     */
    TRANSFST("TRANSFST","TRANSFST"),

    /**
     * "VDACOMST"
     */
    VDACOMST("VDACOMST","VDACOMST"),

    /**
     * "VDAISENTO"
     */
    VDAISENTO("VDAISENTO","VDAISENTO"),

    /**
     * "VDASEMST"
     */
    VDASEMST("VDASEMST","VDASEMST"),

    /**
     * "VENDAS"
     */
    VENDAS("VENDAS","VENDAS")
    ;

    private String descricao;
    private String valor;

    GrupoNatureza( final String descricao,
                   final String valor ) {
        this.descricao = descricao;
        this.valor = preencherComEspacosADireita( valor, 10 );
    }

    @Override
    public String getDescricao() {
        return descricao;
    }

    @Override
    public String getValor() {
        return valor;
    }

}
