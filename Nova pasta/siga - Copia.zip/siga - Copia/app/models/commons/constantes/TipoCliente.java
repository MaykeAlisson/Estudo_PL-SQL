package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de tipos de pedido.
 *
 * <p>Autor: Jander Dutra</p>
 *
 * @since 13/04/2019
 */
public enum TipoCliente implements Constante<String> {

    /**
     * "A"
     */
    ARCOM("ARCOM","A"),

    /**
     * "E"
     */
    ENERGIZER("ENERGIZER","E");

    private String valor;
    private String descricao;

    TipoCliente(final String descricao,
                final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {
        return descricao;
    }

    @Override
    public String getValor() {
        return valor;
    }

    @Override
    public String toString() {
        return "TipoCliente{" +
                "valor='" + valor + '\'' +
                ", descricao='" + descricao + '\'' +
                '}';
    }

}
