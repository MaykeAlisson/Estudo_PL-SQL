package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 10/05/2017
 */
public enum SituacaoVeiculo implements Constante<String> {

    /**
     * "N"
     */
    NORMAL( "NORMAL", "N" ),

    /**
     * "V"
     */
    VENDIDO( "VENDIDO", "V" ),

    /**
     * "P"
     */
    PENDENTE( "PENDENTE", "P" )
    ;

    private final String descricao;
    private final String valor;

    SituacaoVeiculo( final String descricao,
                     final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }
}
