package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 28/12/2018
 */
public enum TipoAgrupaBoleto implements Constante<String> {

    /**
     * "S"
     */
    VARIAS_NFS_NO_BOLETO( "VARIAS NFS NO BOLETO", "S" ),

    /**
     * "N"
     */
    UM_BOLETO_PARA_CADA_NF( "UM BOLETO PARA CADA NF", "N" ),

    /**
     * "E"
     */
    UM_BOLETO_PARA_CADA_NF_SEM_JURO( "UM BOLETO PARA CADA NF SEM JURO", "E" )
    ;

    private final String descricao;
    private final String valor;

    TipoAgrupaBoleto(
        final String descricao,
        final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public String getValor() {

        return this.valor;
    }

}
