package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 06/09/2018
 */
public enum SituacaoViagemBox implements Constante<String> {

    /**
     * "N"
     */
    NORMAL( "NORMAL", "N" ),

    /**
     * "E"
     */
    EMITIDO( "EMITIDO", "E" ),

    /**
     * "L"
     */
    LIBERADO( "LIBERADO", "L" ),

    /**
     * "F"
     */
    FINALIZADO( "FINALIZADO", "F" ),

    /**
     * "P"
     */
    PENDENTE( "PENDENTE", "P" ),

    /**
     * "A"
     */
    AGUARDANDO_ESCALA( "AGUARDANDO ESCALA", "A" )
    ;

    private final String descricao;
    private final String valor;

    SituacaoViagemBox(
        final String descricao,
        final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public String getValor() {

        return this.valor;
    }

}

