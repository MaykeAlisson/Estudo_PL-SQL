package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/12/2015
 */
public enum TipoVeiculoEscala implements Constante<Short> {

    /**
     * 1
     */
    CARRETA( "CARRETA", (short) 1 ),

    /**
     * 2
     */
    TOCO( "TOCO", (short) 2 ),

    /**
     * 3
     */
    TRUCADO( "TRUCADO", (short) 3 ),

    /**
     * 4
     */
    ESTENDIDO( "ESTENDIDO", (short) 4 )
    ;

    private final String descricao;
    private final Short valor;

    TipoVeiculoEscala( final String descricao,
                       final Short valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public Short getValor() {

        return valor;
    }

}
