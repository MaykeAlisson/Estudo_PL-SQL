package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Victor.serafim</p>
 *
 * @since 19/01/2019
 */
public enum OperacaoBaixaECommerce implements Constante<Short> {

    /**
     * 1
     */
    PAGTO( "PAGTO", (short) 1 ),

    /**
     * 2
     */
    REEMBOLSO( "REEMBOLSO", (short) 2 )
    ;

    private final String descricao;
    private final Short valor;

    OperacaoBaixaECommerce(
        final String descricao,
        final Short valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public Short getValor() {

        return this.valor;
    }

}
