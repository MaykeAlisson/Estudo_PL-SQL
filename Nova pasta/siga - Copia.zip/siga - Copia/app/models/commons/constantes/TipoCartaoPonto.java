package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 16/07/2018
 */
public enum TipoCartaoPonto implements Constante<String> {

    /**
     * "S"
     */
    SIM( "SIM", "S" ),

    /**
     * "N"
     */
    NAO( "NÃO", "N" ),

    /**
     * "L"
     */
    PAPELETA_SEM_TOLERANCIA( "PAPELETA SEM TOLERÂNCIA", "L" ),

    /**
     * "P"
     */
    PAPELETA_COM_TOLERANCIA( "PAPELETA COM TOLERÂNCIA", "P" )
    ;

    private final String descricao;
    private final String valor;

    TipoCartaoPonto(
        final String descricao,
        final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public String getValor() {

        return this.valor;
    }
}