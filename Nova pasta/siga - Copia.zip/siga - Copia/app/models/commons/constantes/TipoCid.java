package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 18/12/2018
 */
public enum TipoCid implements Constante<String> {

    /**
     * "C"
     */
    CATEGORIA( "CATEGORIA", "C" ),

    /**
     * "S"
     */
    SUB_CATEGORIA( "SUB CATEGORIA", "S" )
    ;

    private final String descricao;
    private final String valor;

    TipoCid(
        final String descricao,
        final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public String getValor() {

        return this.valor;
    }
}
