package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Antoniocarlos</p>
 *
 * @since 05/06/2019
 */
public enum TipoStatusEquipamento implements Constante<Short> {

    /**
     * 1
     */
    USUARIO( "USUARIO", (short) 1 ),

    /**
     * 2
     */
    MANUTENCAO( "MANUTENCAO", (short) 2 ),

    /**
     * 3
     */
    ROUBADO( "ROUBADO", (short) 3 ),

    /**
     * 4
     */
    SUCATEADO( "SUCATEADO", (short) 4 ),

    /**
     * 5
     */
    ESTOQUE( "ESTOQUE", (short) 5 )
    ;

    private final String descricao;
    private final Short valor;

    TipoStatusEquipamento(
            final String descricao,
            final Short valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public Short getValor() {

        return this.valor;
    }

}
