package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 30/03/2017
 */
public enum CorRotaRastreador implements Constante<String> {

    /**
     * "88CC3300"
     */
    LINHA_AZUL( "linhaAzul", "88CC3300" ),

    /**
     * "883CB371"
     */
    LINHA_VERDE( "linhaVerde", "883CB371" ),

    /**
     * "88FFFF00"
     */
    LINHA_AMARELA( "linhaAmarela", "88FFFF00" ),

    /**
     * "88FF1493"
     */
    LINHA_VERMELHA( "linhaVermelha", "88FF1493" ),

    /**
     * "88FF4500"
     */
    LINHA_LARANJA( "linhaLaranja", "88FF4500" )

    ;

    private final String descricao;
    private final String valor;

    CorRotaRastreador( final String descricao,
                       final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }

    public static CorRotaRastreador proximaCor( CorRotaRastreador corRotaRastreador ) {

        switch ( corRotaRastreador ) {
            case LINHA_AZUL:
                return LINHA_VERDE;
            case LINHA_VERDE:
                return LINHA_AMARELA;
            case LINHA_AMARELA:
                return LINHA_VERMELHA;
            case LINHA_VERMELHA:
                return LINHA_LARANJA;
        }

        return LINHA_AZUL;
    }

}

