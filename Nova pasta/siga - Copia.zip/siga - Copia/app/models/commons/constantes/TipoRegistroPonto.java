package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 11/07/2018
 */
public enum TipoRegistroPonto implements Constante<String> {

    /**
     * "O"
     */
    ORIGINAL( "ORIGINAL", "O" ),

    /**
     * "I"
     */
    INCLUIDO( "INCLUIDO", "I" ),

    /**
     * "P"
     */
    PRE_ASSINALADO( "PRE-ASSINALADO", "P" )
    ;

    private final String descricao;
    private final String valor;

    TipoRegistroPonto(
        final String descricao,
        final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }
}
