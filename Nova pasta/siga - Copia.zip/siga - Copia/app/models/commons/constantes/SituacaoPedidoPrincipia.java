package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 26/12/2018
 */
public enum SituacaoPedidoPrincipia implements Constante<String> {

    /**
     * "SHIPPED"
     */
    ENVIADO( "ENVIADO", "shipped" ),

    /**
     * "CONFIRMED"
     */
    PAGAMENTO_CONFIRMADO( "PAGAMENTO CONFIRMADO", "confirmed" ),

    /**
     * "DELIVERED"
     */
    ENTREGUE( "ENTREGUE", "delivered" ),

    /**
     * "CANCELED"
     */
    CANCELADO( "CANCELADO", "canceled" ),

    /**
     * "PENDENTE"
     */
    PENDENTE( "PENDENTE", "pending" )
    ;

    private final String descricao;
    private final String valor;

    SituacaoPedidoPrincipia(
        final String descricao,
        final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public String getValor() {

        return this.valor;
    }

}