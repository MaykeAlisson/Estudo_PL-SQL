package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 11/02/2016
 */
public enum FaixaAcrescimoPagamento implements Constante<Integer> {

    /**
     * 1
     */
    EM_DIA( "EM DIA", 1 ),

    /**
     * 2
     */
    ATE_5_DIAS( "ATE 5 DIAS", 2 ),

    /**
     * 3
     */
    DE_6_A_10_DIAS( "DE 6 A 10 DIAS", 3 ),

    /**
     * 4
     */
    DE_11_A_15_DIAS( "DE 11 A 15 DIAS", 4 ),

    /**
     * 5
     */
    DE_16_A_20_DIAS( "DE 16 A 20 DIAS", 5 ),

    /**
     * 6
     */
    DE_21_A_30_DIAS( "DE 21 A 30 DIAS", 6 ),

    /**
     * 7
     */
    ACIMA_DE_30_DIAS( "A MAIS DE 30 DIAS", 7 ),

    ;

    private final String descricao;
    private final Integer valor;

    FaixaAcrescimoPagamento( final String descricao,
                             final Integer valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public Integer getValor() {

        return valor;
    }

    @Override
    public String toString() {

        return this.getDescricao();
    }
}
