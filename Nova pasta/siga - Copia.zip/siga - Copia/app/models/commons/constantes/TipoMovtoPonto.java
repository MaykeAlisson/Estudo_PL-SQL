package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 11/07/2018
 */
public enum TipoMovtoPonto implements Constante<String> {

    /**
     * "E"
     */
    ENTRADA( "ENTRADA", "E" ),

    /**
     * "S"
     */
    SAIDA( "SAÍDA", "S" )
    ;

    private final String descricao;
    private final String valor;

    TipoMovtoPonto(
        final String descricao,
        final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }
}