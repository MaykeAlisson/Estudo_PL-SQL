package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 09/01/2019
 */
public enum TipoDescontoTempPedido implements Constante<String> {

    /**
     * "B"
     */
    BOLETO( "BOLETO", "B" ),

    /**
     * "V"
     */
    VERBA( "VERBA", "V" ),

    /**
     * "F"
     */
    BONIFICACAO( "BONIFICACAO", "F" )
    ;

    private final String descricao;
    private final String valor;

    TipoDescontoTempPedido(
        final String descricao,
        final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public String getValor() {

        return this.valor;
    }
}
