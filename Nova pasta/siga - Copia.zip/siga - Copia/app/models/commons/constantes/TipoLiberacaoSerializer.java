package models.commons.constantes;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;

import static infra.util.UtilConstante.getValor;

public class TipoLiberacaoSerializer extends StdSerializer<TipoLiberacao> {

    private static final long serialVersionUID = 1L;

    public TipoLiberacaoSerializer() {

        this(null );
    }

    public TipoLiberacaoSerializer( final Class<TipoLiberacao> clazz ) {

        super(clazz);
    }

    @Override
    public void serialize(
        final TipoLiberacao value,
        final JsonGenerator gen,
        final SerializerProvider provider
    ) throws IOException {

        gen.writeNumber( getValor(value) );
    }
}
