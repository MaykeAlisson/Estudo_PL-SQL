package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 24/01/2019
 */
public enum TipoAtualizacaoPreco implements Constante<String> {

    /**
     * "I"
     */
    INCLUSAO( "INCLUSÃO", "I" ),

    /**
     * "A"
     */
    ALTERACAO( "ALTERAÇÃO", "A" ),

    /**
     * "E"
     */
    EXCLUSAO( "EXCLUSÃO", "E" )
    ;

    private final String descricao;
    private final String valor;

    TipoAtualizacaoPreco(
        final String descricao,
        final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public String getValor() {

        return this.valor;
    }
}