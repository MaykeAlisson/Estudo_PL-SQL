package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores da carga especial.
 *
 * <p>Autor: Cleber</p>
 *
 * @since 08/09/2014
 */
public enum TipoCargaEspecial implements Constante<Integer> {

    /**
     * 0
     */
    NAO("NORMAL", 0),

    /**
     * 1
     */
    ENERGIZER("ENERGIZER", 1)

    ;

    private String descricao;
    private Integer valor;

    TipoCargaEspecial(String descricao, Integer valor) {
        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {
        return descricao;
    }

    @Override
    public Integer getValor() {
        return valor;
    }

}
