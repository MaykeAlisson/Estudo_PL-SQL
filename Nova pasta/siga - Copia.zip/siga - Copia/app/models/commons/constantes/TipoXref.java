package models.commons.constantes;

import infra.model.Constante;

import static java.lang.String.format;

/**
 * Constante ref. ao conjunto de valores de Tipo de referencia cruzada.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/12/2015
 */
public enum TipoXref implements Constante<String> {

    /**
     * alt_rua
     */
    ALT_RUA( "ALT_RUA", "alt_rua"),

    /**
     * siga
     */
    PROJETOS_JAVA( "PROJETOS JAVA", "java")

    ;

    private final String descricao;
    private final String valor;

    TipoXref(
        final String descricao,
        final String valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public String getValor() {

        return this.valor;
    }

    @Override
    public String toString() {

        return format( "%s (%s)", getDescricao(), getValor() );
    }
}
