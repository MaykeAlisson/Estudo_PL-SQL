package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores para coluna SITUACAO tabela move.box_carga_antecipada.
 *
 * <p>Autor: Andre Luiz Alves de Faria </p>
 *
 * @since 03/08/2018
 */
public enum SituacaoBoxCargaAntecipada implements Constante<String> {

    /**
     * "D"
     */
    DISPONIVEL( "DISPONIVEL", "D" ),

    /**
     * "O"
     */
    OCUPADO( "OCUPADO", "O" ),

    /**
     * "R"
     */
    RESERVADO( "RESERVADO", "R" ),

    /**
     * "C"
     */
    CANCELADO( "CANCELADO", "C" )
    ;

    private final String descricao;
    private final String valor;

    SituacaoBoxCargaAntecipada( final String descricao,
                                final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public String getValor() {

        return this.valor;
    }

}

