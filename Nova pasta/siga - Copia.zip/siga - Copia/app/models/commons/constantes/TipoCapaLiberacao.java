package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de tipos de capas de liberação
 *
 * <p>Autor: Cleber</p>
 *
 * @since 08/09/2014
 */
public enum TipoCapaLiberacao implements Constante<String> {

    /**
     * "P"
     */
    CAIXA_FECHADA("CAIXA FECHADA","P"),

    /**
     * "F"
     */
    FRACIONADO("FRACIONADO","F"),

    /**
     * "D"
     */
    COSMETICO("COSMETICO","D"),

    /**
     * "S"
     */
    SANDALIA("SANDALIA","S"),

    /**
     * "A"
     */
    ALIMENTICIO("CORTE_ALIMENTICIO","A")
    ;

    private final String descricao;
    private final String valor;

    TipoCapaLiberacao(String descricao, String valor) {
        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {
        return descricao;
    }

    @Override
    public String getValor() {
        return valor;
    }

}
