package models.commons.constantes;

import infra.model.Constante;

/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: GPortes</p>
 *
 * @since 28/02/2018
 */
public enum FechaSemana implements Constante<String> {

    /**
     * "S"
     */
    ROTEIRIZA( "ROTEIRIZA", "S" ),

    /**
     * "N"
     */
    NAO_ROTEIRIZA( "NAO ROTEIRIZA", "N" ),

    /**
     * "E"
     */
    ROTEIRIZA_EVENTUAL( "ROTEIRIZA EVENTUAL", "E" ),

    /**
     * "F"
     */
    ROTEIRIZA_E_FECHA( "ROTEIRIZA E FECHA", "F" )
    ;

    private final String descricao;
    private final String valor;

    FechaSemana( final String descricao,
                 final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }
}