package models.commons.constantes;

import infra.model.Constante;
/**
 * Constante ref. ao conjunto de valores de ...
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 30/05/2016
 */
public enum TipoAlocacaoCusto implements Constante<String> {

    /**
     * "D"
     */
    DIRETA( "ALOCACAO DIRETA", "D" ),

    /**
     * "I"
     */
    INDIRETA( "ALOCACAO INDIRETA", "I" ),

    /**
     * "R"
     */
    RESIDUAL( "RESIDUAL", "R" )
    ;

    private final String descricao;
    private final String valor;

    TipoAlocacaoCusto( final String descricao,
                       final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public String getValor() {

        return valor;
    }

}

