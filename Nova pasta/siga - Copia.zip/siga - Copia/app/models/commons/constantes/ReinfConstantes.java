package models.commons.constantes;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Month;

/**
 * Classe responsavel por encapsular as constantes do eSocial
 * 
 * @author fernandopti
 *
 */
public class ReinfConstantes {

    // Encode da Assinatura
	public static final String sha256 = "http://www.w3.org/2001/04/xmlenc#sha256";

	// Identificação do Evento
	public static final Byte   PRODUCAO_RESTRITA_DADOS_REAIS = new Byte("1"); // MUDAR PROD
	public static final Byte   PROCESSO_EMISSAO = new Byte("1");
	public static final String VERSAO_PROCESSO = "1.4.00";
	public static final Short  ID_SISTEMA = new Short("2");

	// Dados do empregador
	public static final String 		CNPJ = "25769266000124"; //25769266000124 56772542000137
	public static final String 		TP_INSC_EMP = "1";
	public static final String 		ID_EVENTO = "#ID_EVENTO#";
	public static final String 		INICIO_VALIDADE = "2018-05"; //MUDAR PROD
	public static final String 		INICIO_REINF_OUTRAS_EMPRESAS = "2019-01"; //MUDAR PROD
	public static final LocalDate 	INICIO_VALIDADE_LD = LocalDate.of(2018, Month.MAY, 1);
	public static final LocalDate 	INICIO_VALIDADE_OUTRAS_EMPRESAS = LocalDate.of(2018, Month.DECEMBER, 1);
	public static final BigDecimal 	TAXA_CONSTRUCAO_CIVIL = new BigDecimal("3.50");
	public static final Long 		DIA_FECHAMENTO_APURACAO = 6L;

	// WebServices
	public static final Long URL_ENVIA_CONSULTA = 704l;
	public static final Long URL_CONSULTA_INFORMACOES_CONSOLIDADAS = 705l;

	// Tipo dos Eventos
    public static final String INCLUSAO = "Inclusao";
    public static final String ALTERCAO = "Alteracao";
    public static final String EXCLUSAO = "Exclusao";

    // Data hora

	public static final String YYYYMM = "yyyyMM";
	public static final String YYYY_MM = "yyyy-MM";
	public static final String YYYY_MM_DD = "yyyy-MM-dd";
	public static final String DD_MM_YYYY = "dd/MM/yyyy";

    // Nomenclatura de eventos
	public static final String R1000 = "R1000";
	public static final String R1070 = "R1070";
	public static final String R2010 = "R2010";
	public static final String R2020 = "R2020";
	public static final String R2060 = "R2060";
	public static final String R2070 = "R2070";
	public static final String R2098 = "R2098";
	public static final String R2099 = "R2099";
	public static final String R5001 = "R5001";
	public static final String R5011 = "R5011";
	public static final String R9000 = "R9000";


	//tipoEnvio
	public enum TipoEvento{

		INICIAl("Informação Empregador / Tabelas", "1"),
		NAO_PERIODICO("Não periódico", "2"),
		PERIODICO("Periódico", "3"),
		EDF_REINF("EDF-Reinf","4")
		;

		private String nome;
		private String id;

		TipoEvento(String nome, String id){
			this.nome = nome;
			this.id = id;
		}

		public String getId(){
			return this.id;
		}

		public String getNome(){
			return this.nome;
		}


	}

	//Status Procesasmento
	public enum StatusProcessamento{

		AGUARDANDO_ENVIO("Aguardando Envio", "1"),
		AGUARDANDO_PROCESSAMENTO("Aguardando processamento", "2"),
		PROCESSADO_SUCESSO("Processado Sucesso", "3"),
		PROCESSADO_ERRO("Processado Erro", "4"),
		EVENTO_INATIVO("Evento Inativo", "5"),
		REPROCESSAR("Reprocessar", "6"),
		PROCESSAR_REINF("Aguardando Envio/Processamento","7"),
		PROCESSADO_AFAST("Processado Afastamento","8"),
		AGUARDANDO_PROCESSAMENTO_ALTERACAO("Aguardando Processamento Alteração","9");

		private String nome;
		private String id;

		StatusProcessamento(String nome, String id){
			this.nome = nome;
			this.id = id;
		}

		public Short getId(){
			return new Short(this.id);
		}

		public String getNome(){
			return this.nome;
		}


	}

	public enum PeriodoApuracaoStatus{

		ABERTO("Aberto", new Short("1")),
		FECHADO("Fechado", new Short("2")),
		AGUARDANDO_REABERTURA("Aguardando Reabertura", new Short("3"));

		private String nome;
		private Short id;

		PeriodoApuracaoStatus(String nome, Short id){
			this.nome = nome;
			this.id = id;
		}

		public Short getId(){
			return new Short(this.id);
		}

		public String getNome(){
			return this.nome;
		}


	}


}

