package models.commons.converters;

import models.commons.constantes.TipoCargaEspecial;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante CargaEspecial.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/09/2014.
 *
 * @see TipoCargaEspecial
 */
@Converter
public class TipoCargaEspecialConverter implements AttributeConverter<TipoCargaEspecial,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final TipoCargaEspecial tipoCargaEspecial ) {

        return tipoCargaEspecial != null ? tipoCargaEspecial.getValor() : null;
    }

    @Override
    public TipoCargaEspecial convertToEntityAttribute( Integer valor ) {

        return getEnum( TipoCargaEspecial.class, valor );
    }

}