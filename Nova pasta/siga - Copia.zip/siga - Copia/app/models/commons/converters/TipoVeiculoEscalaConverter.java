package models.commons.converters;

import models.commons.constantes.TipoVeiculoEscala;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoEscalaVeiculo
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/12/2015
 *
 * @see TipoVeiculoEscala
 */
@Converter
public class TipoVeiculoEscalaConverter implements AttributeConverter<TipoVeiculoEscala,Object> {

    @Override
    public Short convertToDatabaseColumn( final TipoVeiculoEscala tipoVeiculoEscala ) {

        return getValor( tipoVeiculoEscala );
    }

    @Override
    public TipoVeiculoEscala convertToEntityAttribute( final Object valor ) {

        return getEnum( TipoVeiculoEscala.class, valor != null ? ( (Integer) valor ).shortValue() : null );
    }
}

