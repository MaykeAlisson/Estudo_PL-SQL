package models.commons.converters;

import models.commons.constantes.TipoRetencao;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoRetencao
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 16/06/2015
 *
 * @see TipoRetencao
 */
@Converter
public class TipoRetencaoConverter implements AttributeConverter<TipoRetencao,String> {

    @Override
    public String convertToDatabaseColumn( final TipoRetencao tipoRetencao ) {

        return tipoRetencao != null ? tipoRetencao.getValor() : null;
    }

    @Override
    public TipoRetencao convertToEntityAttribute( final String valor ) {

        return getEnum( TipoRetencao.class, valor );
    }
}

