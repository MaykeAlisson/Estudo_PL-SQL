package models.commons.converters;

import models.commons.constantes.SituacaoVeiculo;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante SituacaoVeiculo
 *
 * <p>Autor: GPortes</p>
 *
 * @since 10/05/2017
 *
 * @see SituacaoVeiculo
 */
@Converter
public class SituacaoVeiculoConverter implements AttributeConverter<SituacaoVeiculo,String> {

    @Override
    public String convertToDatabaseColumn( final SituacaoVeiculo situacaoVeiculo ) {

        return situacaoVeiculo != null ? situacaoVeiculo.getValor() : null;
    }

    @Override
    public SituacaoVeiculo convertToEntityAttribute( final String situacaoVeiculo ) {

        return getEnum( SituacaoVeiculo.class, situacaoVeiculo );
    }
}

