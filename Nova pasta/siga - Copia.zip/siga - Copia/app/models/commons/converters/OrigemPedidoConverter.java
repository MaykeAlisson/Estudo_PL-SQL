package models.commons.converters;

import models.commons.constantes.OrigemPedido;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante OrigemPedido
 *
 * <p>Autor: GPortes</p>
 *
 * @since 09/11/2015
 *
 * @see OrigemPedido
 */
@Converter
public class OrigemPedidoConverter implements AttributeConverter<OrigemPedido,String> {

    @Override
    public String convertToDatabaseColumn( final OrigemPedido origemPedido ) {

        return origemPedido != null ? origemPedido.getValor() : null;
    }

    @Override
    public OrigemPedido convertToEntityAttribute( final String valor ) {

        return getEnum( OrigemPedido.class, valor );
    }
}

