package models.commons.converters;

import models.commons.constantes.TipoRegimeJornada;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;

/**
 * Classe converter para constante TipoRegimeJornada
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 16/07/2018
 *
 * @see models.commons.constantes.TipoRegimeJornada
 */
@Converter
public class TipoRegimeJornadaConverter implements AttributeConverter<TipoRegimeJornada,Object> {

    @Override
    public Short convertToDatabaseColumn( final TipoRegimeJornada tipoRegimeJornada ) {

        return getValor( tipoRegimeJornada );
    }

    @Override
    public TipoRegimeJornada convertToEntityAttribute( final Object valor ) {

        return getEnum( TipoRegimeJornada.class, toShort(valor) );
    }
}

