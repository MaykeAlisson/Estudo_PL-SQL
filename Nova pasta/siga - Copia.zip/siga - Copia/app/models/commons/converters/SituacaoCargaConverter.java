package models.commons.converters;

import models.commons.constantes.SituacaoCarga;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante SituacaoCarga.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/09/2014.
 *
 * @see SituacaoCarga
 */
@Converter
public class SituacaoCargaConverter implements AttributeConverter<SituacaoCarga,String> {

    @Override
    public String convertToDatabaseColumn( final SituacaoCarga situacaoCarga ) {

        return situacaoCarga != null ? situacaoCarga.getValor() : null;
    }

    @Override
    public SituacaoCarga convertToEntityAttribute(String valor) {

        return getEnum( SituacaoCarga.class, valor );
    }

}
