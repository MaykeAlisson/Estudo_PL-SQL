package models.commons.converters;

import models.commons.constantes.TipoCompraConsumo;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoCompraConsumo
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 28/12/2018
 *
 * @see TipoCompraConsumo
 */
@Converter
public class TipoCompraConsumoConverter implements AttributeConverter<TipoCompraConsumo,String> {

    @Override
    public String convertToDatabaseColumn( final TipoCompraConsumo tipoCompraConsumo ) {

        return getValor( tipoCompraConsumo );
    }

    @Override
    public TipoCompraConsumo convertToEntityAttribute( final String valor ) {

        return getEnum( TipoCompraConsumo.class, valor );
    }
}

