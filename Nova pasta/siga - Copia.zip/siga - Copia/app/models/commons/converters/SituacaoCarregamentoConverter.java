package models.commons.converters;

import models.commons.constantes.SituacaoCarregamento;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante SituacaoCarregamento.
 *
 * <p>Autor: Jander Dutra</p>
 *
 * @since 14/05/2019.
 *
 * @see SituacaoCarregamento
 */
@Converter
public class SituacaoCarregamentoConverter implements AttributeConverter<SituacaoCarregamento,String> {

        @Override
        public String convertToDatabaseColumn( final SituacaoCarregamento situacaoCargaAntecipada ) {

            return situacaoCargaAntecipada != null ? situacaoCargaAntecipada.getValor() : null;
        }

        @Override
        public SituacaoCarregamento convertToEntityAttribute(String valor ) {

            return getEnum(SituacaoCarregamento.class, valor);
        }
}
