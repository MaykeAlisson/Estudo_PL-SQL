package models.commons.converters;

import models.commons.constantes.Sexo;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante Sexo
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 16/06/2015
 *
 * @see Sexo
 */
@Converter
public class SexoConverter implements AttributeConverter<Sexo,String> {

    @Override
    public String convertToDatabaseColumn( Sexo sexo ) {

        return sexo != null ? sexo.getValor() : null;
    }

    @Override
    public Sexo convertToEntityAttribute( String valor ) {
        return getEnum( Sexo.class, valor );
    }
}

