package models.commons.converters;

import models.commons.constantes.TipoCapaLiberacao;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

@Converter
public class TipoCapaLiberacaoConverter implements AttributeConverter<TipoCapaLiberacao,String> {

    @Override
    public String convertToDatabaseColumn( final TipoCapaLiberacao tipoCapaLiberacao) {

        return tipoCapaLiberacao != null ? tipoCapaLiberacao.getValor() : null;
    }

    @Override
    public TipoCapaLiberacao convertToEntityAttribute(String valor) {

        return getEnum(TipoCapaLiberacao.class, valor);
    }

}
