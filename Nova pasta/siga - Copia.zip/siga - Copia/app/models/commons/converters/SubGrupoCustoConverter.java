package models.commons.converters;

import models.commons.constantes.SubGrupoCusto;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante AtividadeCusto
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 30/05/2016
 *
 * @see SubGrupoCusto
 */
@Converter
public class SubGrupoCustoConverter implements AttributeConverter<SubGrupoCusto,String> {

    @Override
    public String convertToDatabaseColumn( final SubGrupoCusto subGrupoCusto ) {

        return subGrupoCusto != null ? subGrupoCusto.getValor() : null;
    }

    @Override
    public SubGrupoCusto convertToEntityAttribute( final String valor ) {

        return getEnum( SubGrupoCusto.class, valor );
    }
}

