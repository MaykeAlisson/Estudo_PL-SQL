package models.commons.converters;

import models.commons.constantes.BandeiraCartao;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValorInteger;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;

/**
 * Classe converter para constante BandeiraCartao
 *
 * <p>Autor: Victor.serafim</p>
 *
 * @since 19/01/2019
 *
 * @see models.commons.constantes.BandeiraCartao
 */
@Converter
public class BandeiraCartaoConverter implements AttributeConverter<BandeiraCartao,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final BandeiraCartao bandeiraCartao ) {

        return getValorInteger( bandeiraCartao );
    }

    @Override
    public BandeiraCartao convertToEntityAttribute( final Integer valor ) {

        return getEnum( BandeiraCartao.class, toShort(valor) );
    }
}


