package models.commons.converters;

import models.commons.constantes.TipoPedidoEspecial;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValorInteger;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;

/**
 * Classe converter para constante TipoPedidoEspecial
 *
 * <p>Autor: GPortes</p>
 *
 * @since 06/03/2019
 *
 * @see models.commons.constantes.TipoPedidoEspecial
 */
@Converter
public class TipoPedidoEspecialConverter implements AttributeConverter<TipoPedidoEspecial,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final TipoPedidoEspecial tipoPedidoEspecial ) {

        return getValorInteger( tipoPedidoEspecial );
    }

    @Override
    public TipoPedidoEspecial convertToEntityAttribute( final Integer valor ) {

        return getEnum( TipoPedidoEspecial.class, toShort(valor) );
    }
}

