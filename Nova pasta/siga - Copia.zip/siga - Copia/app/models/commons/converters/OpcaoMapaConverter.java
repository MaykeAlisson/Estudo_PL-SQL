package models.commons.converters;

import models.commons.constantes.ImpressoraMapa;
import models.commons.constantes.OpcaoMapa;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante OpcaoMapa
 *
 * <p>Autor: Jander Dutra</p>
 *
 * @since 14/02/2019
 *
 * @see OpcaoMapa
 */
@Converter
public class OpcaoMapaConverter implements AttributeConverter<OpcaoMapa,String> {

    @Override
    public String convertToDatabaseColumn( final OpcaoMapa opcaoMapa ) {

        return opcaoMapa != null ? opcaoMapa.getValor() : null;
    }

    @Override
    public OpcaoMapa convertToEntityAttribute(String valor ) {
        return getEnum(OpcaoMapa.class, valor);
    }
}

