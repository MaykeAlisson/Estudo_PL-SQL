package models.commons.converters;

import models.commons.constantes.TipoVoltagem;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValorInteger;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;

/**
 * Classe converter para constante TipoVoltagem
 *
 * <p>Autor: GPortes</p>
 *
 * @since 09/01/2019
 *
 * @see models.commons.constantes.TipoVoltagem
 */
@Converter
public class TipoVoltagemConverter implements AttributeConverter<TipoVoltagem,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final TipoVoltagem tipoVoltagem ) {

        return getValorInteger( tipoVoltagem );
    }

    @Override
    public TipoVoltagem convertToEntityAttribute( final Integer valor ) {

        return getEnum( TipoVoltagem.class, toShort(valor) );
    }
}


