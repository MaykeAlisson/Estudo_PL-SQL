package models.commons.converters;

import models.commons.constantes.SituacaoAcerto;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;
import static java.lang.Integer.valueOf;

/**
 * Classe converter para constante SituacaoAcerto
 *
 * <p>Autor: GPortes</p>
 *
 * @since 13/01/2016
 *
 * @see SituacaoAcerto
 */
@Converter
public class SituacaoAcertoConverter implements AttributeConverter<SituacaoAcerto,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final SituacaoAcerto situacaoAcerto ) {

        return situacaoAcerto != null ? valueOf( situacaoAcerto.getValor() ) : null;
    }

    @Override
    public SituacaoAcerto convertToEntityAttribute( final Integer valor ) {

        return getEnum( SituacaoAcerto.class, valor.shortValue() );
    }
}


