package models.commons.converters;

import models.commons.constantes.SituacaoViagem;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante SituacaoViagem
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/12/2015
 *
 * @see SituacaoViagem
 */
@Converter
public class SituacaoViagemConverter implements AttributeConverter<SituacaoViagem,String> {

    @Override
    public String convertToDatabaseColumn( final SituacaoViagem situacaoViagem ) {

        return situacaoViagem != null ? situacaoViagem.getValor() : null;
    }

    @Override
    public SituacaoViagem convertToEntityAttribute( final String valor ) {

        return getEnum( SituacaoViagem.class, valor );
    }
}

