package models.commons.converters;

import models.commons.constantes.TipoCartaoPonto;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoCartaoPonto
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 16/07/2018
 *
 * @see models.commons.constantes.TipoCartaoPonto
 */
@Converter
public class TipoCartaoPontoConverter implements AttributeConverter<TipoCartaoPonto,String> {

    @Override
    public String convertToDatabaseColumn( final TipoCartaoPonto tipoCartaoPonto ) {

        return getValor( tipoCartaoPonto );
    }

    @Override
    public TipoCartaoPonto convertToEntityAttribute( final String valor ) {

        return getEnum( TipoCartaoPonto.class, valor );
    }
}




