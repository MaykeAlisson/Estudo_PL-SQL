package models.commons.converters;

import models.commons.constantes.TipoNfe;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoNfe
 *
 * <p>Autor: GPortes</p>
 *
 * @since 16/06/2015
 *
 * @see TipoNfe
 *
 */
@Converter
public class TipoNfeConverter implements AttributeConverter<TipoNfe,Integer> {

    @Override
    public Integer convertToDatabaseColumn( TipoNfe tipoNfe ) {

        return tipoNfe != null ? tipoNfe.getValor() : null;
    }

    @Override
    public TipoNfe convertToEntityAttribute( Integer valor ) {

        return getEnum( TipoNfe.class, valor );
    }
}

