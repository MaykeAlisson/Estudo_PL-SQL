package models.commons.converters;

import models.commons.constantes.TipoAgrupaBoleto;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoAgrupaBoleto
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 28/12/2018
 *
 * @see TipoAgrupaBoleto
 */
@Converter
public class TipoAgrupaBoletoConverter implements AttributeConverter<TipoAgrupaBoleto,String> {

    @Override
    public String convertToDatabaseColumn( final TipoAgrupaBoleto tipoAgrupaBoleto ) {

        return getValor( tipoAgrupaBoleto );
    }

    @Override
    public TipoAgrupaBoleto convertToEntityAttribute( final String valor ) {

        return getEnum( TipoAgrupaBoleto.class, valor );
    }
}

