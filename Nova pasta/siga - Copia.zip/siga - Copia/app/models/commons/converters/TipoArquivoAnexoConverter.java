package models.commons.converters;

import models.commons.constantes.TipoArquivoAnexo;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;

/**
 * Classe converter para constante TipoArquivoAnexo
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 18/07/2018
 *
 * @see models.commons.constantes.TipoArquivoAnexo
 */
@Converter
public class TipoArquivoAnexoConverter implements AttributeConverter<TipoArquivoAnexo,Object> {

    @Override
    public Short convertToDatabaseColumn( final TipoArquivoAnexo tipoArquivoAnexo ) {

        return getValor( tipoArquivoAnexo );
    }

    @Override
    public TipoArquivoAnexo convertToEntityAttribute( final Object valor ) {

        return getEnum( TipoArquivoAnexo.class, toShort( valor ) );
    }
}

