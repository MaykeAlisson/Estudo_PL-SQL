package models.commons.converters;

import models.commons.constantes.TipoFuncao;

import models.commons.constantes.TipoFuncao;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoFuncao
 *
 * <p>Autor: Victor.serafim</p>
 *
 * @since 12/12/2018
 *
 * @see models.commons.constantes.TipoFuncao
 */
@Converter
public class TipoFuncaoConverter implements AttributeConverter<TipoFuncao,String> {

    @Override
    public String convertToDatabaseColumn( final TipoFuncao tipoFuncao ) {

        return getValor( tipoFuncao );
    }

    @Override
    public TipoFuncao convertToEntityAttribute( final String valor ) {

        return getEnum( TipoFuncao.class, valor );
    }
}
