package models.commons.converters;

import models.commons.constantes.TipoBrinde;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoBrinde
 *
 * <p>Autor: GPortes</p>
 *
 * @since 09/01/2019
 *
 * @see models.commons.constantes.TipoBrinde
 */
@Converter
public class TipoBrindeConverter implements AttributeConverter<TipoBrinde,String> {

    @Override
    public String convertToDatabaseColumn( final TipoBrinde tipoBrinde ) {

        return getValor( tipoBrinde );
    }

    @Override
    public TipoBrinde convertToEntityAttribute( final String valor ) {

        return getEnum( TipoBrinde.class, valor );
    }
}

