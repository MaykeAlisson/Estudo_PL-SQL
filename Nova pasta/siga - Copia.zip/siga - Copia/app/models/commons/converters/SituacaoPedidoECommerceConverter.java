package models.commons.converters;

import models.commons.constantes.SituacaoPedidoECommerce;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValorInteger;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;

/**
 * Classe converter para constante SituacaoPedidoECommerce
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 02/01/2019
 *
 * @see SituacaoPedidoECommerce
 */
@Converter
public class SituacaoPedidoECommerceConverter implements AttributeConverter<SituacaoPedidoECommerce,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final SituacaoPedidoECommerce situacaoPedidoECommerce ) {

        return getValorInteger( situacaoPedidoECommerce );
    }

    @Override
    public SituacaoPedidoECommerce convertToEntityAttribute( final Integer valor ) {

        return getEnum( SituacaoPedidoECommerce.class, toShort(valor) );
    }
}