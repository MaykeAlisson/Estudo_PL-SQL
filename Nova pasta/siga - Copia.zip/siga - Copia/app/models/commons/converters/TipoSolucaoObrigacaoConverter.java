package models.commons.converters;

import models.commons.constantes.TipoSolucaoObrigacao;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoSolucaoObrigacao
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 04/10/2017
 *
 * @see models.commons.constantes.TipoSolucaoObrigacao
 */
@Converter
public class TipoSolucaoObrigacaoConverter implements AttributeConverter<TipoSolucaoObrigacao,String> {

    @Override
    public String convertToDatabaseColumn( final TipoSolucaoObrigacao tipoSolucaoObrigacao ) {


        return getValor( tipoSolucaoObrigacao );
    }

    @Override
    public TipoSolucaoObrigacao convertToEntityAttribute( final String valor ) {

        return getEnum( TipoSolucaoObrigacao.class, valor );
    }
}


//  @Convert( converter = TipoSolucaoObrigacaoConverter.class )


