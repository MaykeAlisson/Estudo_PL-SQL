package models.commons.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValorInteger;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;
import static models.domains.vendas.FormaPagamento.IdFormaPagamento;

/**
 * Classe converter para constante IdFormaPagamento.
 *
 * <p>Autor: Gportes</p>
 *
 * @since 17/01/2018.
 *
 * @see IdFormaPagamento
 */
@Converter
public class FormaPagamentoConverter implements AttributeConverter<IdFormaPagamento,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final IdFormaPagamento formaPagamento ) {

        return getValorInteger( formaPagamento );
    }

    @Override
    public IdFormaPagamento convertToEntityAttribute( final Integer valor ) {

        return getEnum( IdFormaPagamento.class, toShort(valor) );
    }
}
