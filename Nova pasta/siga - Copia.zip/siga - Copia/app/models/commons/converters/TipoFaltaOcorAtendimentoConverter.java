package models.commons.converters;

import models.commons.constantes.TipoFaltaOcorAtendimento;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import static infra.util.UtilConstante.getValorInteger;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;

/**
 * Classe converter para constante TipoFaltaOcorAtendimento
 *
 * <p>Autor: GPortes</p>
 *
 * @since 01/03/2019
 *
 * @see models.commons.constantes.TipoFaltaOcorAtendimento
 */
@Converter
public class TipoFaltaOcorAtendimentoConverter implements AttributeConverter<TipoFaltaOcorAtendimento,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final TipoFaltaOcorAtendimento tipoFaltaOcorAtendimento ) {

        return getValorInteger( tipoFaltaOcorAtendimento );
    }

    @Override
    public TipoFaltaOcorAtendimento convertToEntityAttribute( final Integer valor ) {

        return getEnum( TipoFaltaOcorAtendimento.class, toShort(valor) );
    }
}

