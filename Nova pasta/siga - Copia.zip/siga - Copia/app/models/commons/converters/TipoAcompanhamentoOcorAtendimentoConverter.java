package models.commons.converters;

import models.commons.constantes.TipoAcompanhamentoOcorAtendimento;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoAcompanhamentoOcorAtendimento
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 01/03/2019
 *
 * @see models.commons.constantes.TipoAcompanhamentoOcorAtendimento
 */
@Converter
public class TipoAcompanhamentoOcorAtendimentoConverter implements AttributeConverter<TipoAcompanhamentoOcorAtendimento,String> {

    @Override
    public String convertToDatabaseColumn( final TipoAcompanhamentoOcorAtendimento tipoAcompanhamentoOcorAtendimento ) {

        return getValor( tipoAcompanhamentoOcorAtendimento );
    }

    @Override
    public TipoAcompanhamentoOcorAtendimento convertToEntityAttribute( final String valor ) {

        return getEnum( TipoAcompanhamentoOcorAtendimento.class, valor );
    }
}

