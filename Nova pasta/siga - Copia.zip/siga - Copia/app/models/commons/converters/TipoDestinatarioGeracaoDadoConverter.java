package models.commons.converters;

import models.commons.constantes.TipoDestinatarioGeracaoDado;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoDestinatarioGeracaoDado
 *
 * <p>Autor: GPortes</p>
 *
 * @since 10/01/2019
 *
 * @see models.commons.constantes.TipoDestinatarioGeracaoDado
 */
@Converter
public class TipoDestinatarioGeracaoDadoConverter implements AttributeConverter<TipoDestinatarioGeracaoDado,String> {

    @Override
    public String convertToDatabaseColumn( final TipoDestinatarioGeracaoDado tipoDestinatarioGeracaoDado ) {

        return getValor( tipoDestinatarioGeracaoDado );
    }

    @Override
    public TipoDestinatarioGeracaoDado convertToEntityAttribute( final String valor ) {

        return getEnum( TipoDestinatarioGeracaoDado.class, valor );
    }
}

