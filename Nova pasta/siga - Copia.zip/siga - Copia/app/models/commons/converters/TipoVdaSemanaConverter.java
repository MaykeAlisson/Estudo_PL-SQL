package models.commons.converters;

import models.commons.constantes.TipoVdaSemana;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoVdaSemana
 *
 * <p>Autor: GPortes</p>
 *
 * @since 07/01/2016
 *
 * @see TipoVdaSemana
 */
@Converter
public class TipoVdaSemanaConverter implements AttributeConverter<TipoVdaSemana,String> {

    @Override
    public String convertToDatabaseColumn( final TipoVdaSemana tipoVdaSemana ) {

        return tipoVdaSemana != null ? tipoVdaSemana.getValor() : null;
    }

    @Override
    public TipoVdaSemana convertToEntityAttribute( final String valor ) {

        return getEnum( TipoVdaSemana.class, valor );
    }
}
