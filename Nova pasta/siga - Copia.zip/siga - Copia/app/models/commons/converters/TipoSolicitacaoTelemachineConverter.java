package models.commons.converters;

import models.commons.constantes.TipoSolicitacaoTelemachine;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;
import static java.lang.Integer.valueOf;

/**
 * Classe converter para constante TipoSolicitacaoTelemachine
 *
 * <p>Autor: Victor.serafim</p>
 *
 * @since 11/12/2018
 *
 * @see models.commons.constantes.TipoSolicitacaoTelemachine
 */
@Converter
public class TipoSolicitacaoTelemachineConverter implements AttributeConverter<TipoSolicitacaoTelemachine,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final TipoSolicitacaoTelemachine tipoSolicitacaoTelemachine ) {

        return valueOf( getValor(tipoSolicitacaoTelemachine) );
    }

    @Override
    public TipoSolicitacaoTelemachine convertToEntityAttribute( final Integer valor ) {

        return getEnum( TipoSolicitacaoTelemachine.class, toShort(valor) );
    }
}


