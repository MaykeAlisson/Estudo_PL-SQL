package models.commons.converters;

import models.commons.constantes.TipoOrigemItemPedido;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;


/**
 * Classe converter para constante TipoOrigemItemPedido
 *
 * <p>Autor: GPortes</p>
 *
 * @since 09/01/2019
 *
 * @see models.commons.constantes.TipoOrigemItemPedido
 */
@Converter
public class TipoOrigemItemPedidoConverter implements AttributeConverter<TipoOrigemItemPedido,Long> {

    @Override
    public Long convertToDatabaseColumn( final TipoOrigemItemPedido tipoOrigemItemPedido ) {

        return getValor( tipoOrigemItemPedido );
    }

    @Override
    public TipoOrigemItemPedido convertToEntityAttribute( final Long valor ) {

        return getEnum( TipoOrigemItemPedido.class, valor );
    }
}

