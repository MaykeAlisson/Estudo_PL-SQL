package models.commons.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValorInteger;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;
import static models.domains.vendas.TipoPedido.IdTipoPedido;

/**
 * Classe converter para constante IdTipoPedido.
 *
 * <p>Autor: Gportes</p>
 *
 * @since 17/01/2018.
 *
 * @see IdTipoPedido
 */
@Converter
public class TipoPedidoConverter implements AttributeConverter<IdTipoPedido,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final IdTipoPedido tipoPedido ) {

        return getValorInteger( tipoPedido );
    }

    @Override
    public IdTipoPedido convertToEntityAttribute( final Integer valor ) {

        return getEnum( IdTipoPedido.class, toShort(valor) );
    }
}