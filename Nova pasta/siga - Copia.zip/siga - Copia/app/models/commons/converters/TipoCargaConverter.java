package models.commons.converters;

import models.commons.constantes.TipoCarga;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoCarga.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/09/2014.
 *
 * @see TipoCarga
 */
@Converter
public class TipoCargaConverter implements AttributeConverter<TipoCarga,String> {

    @Override
    public String convertToDatabaseColumn( final TipoCarga tipoCarga ) {

        return tipoCarga != null ? tipoCarga.getValor() : null;
    }

    @Override
    public TipoCarga convertToEntityAttribute( final String valor ) {

        return getEnum( TipoCarga.class, valor );
    }

}