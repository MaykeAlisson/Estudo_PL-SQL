package models.commons.converters;

import models.commons.constantes.TipoCliente;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;


/**
 * Classe converter para constante TipoCliente.
 *
 * <p>Autor: Jander Dutra</p>
 *
 * @since 13/04/2019.
 *
 * @see models.commons.constantes.SituacaoPedido
 */
@Converter
public class TipoClienteConverter implements AttributeConverter<TipoCliente,String> {

    @Override
    public String convertToDatabaseColumn( final TipoCliente tipoCliente ) {

        return tipoCliente != null ? tipoCliente.getValor() : null;
    }

    @Override
    public TipoCliente convertToEntityAttribute( final String valor ) {

        return getEnum(TipoCliente.class, valor);
    }
}
