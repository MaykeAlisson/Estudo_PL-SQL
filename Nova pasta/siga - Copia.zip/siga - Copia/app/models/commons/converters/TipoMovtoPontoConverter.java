package models.commons.converters;

import models.commons.constantes.TipoMovtoPonto;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoMovtoPonto
 *
 * <p>Autor: GPortes</p>
 *
 * @since 11/07/2018
 *
 * @see models.commons.constantes.TipoMovtoPonto
 */
@Converter
public class TipoMovtoPontoConverter implements AttributeConverter<TipoMovtoPonto,String> {

    @Override
    public String convertToDatabaseColumn( final TipoMovtoPonto tipoMovtoPonto ) {

        return getValor( tipoMovtoPonto );
    }

    @Override
    public TipoMovtoPonto convertToEntityAttribute( final String valor ) {

        return getEnum( TipoMovtoPonto.class, valor );
    }
}

