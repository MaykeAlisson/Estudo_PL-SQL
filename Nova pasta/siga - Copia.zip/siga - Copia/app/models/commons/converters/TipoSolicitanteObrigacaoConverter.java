package models.commons.converters;


import models.commons.constantes.TipoSolicitanteObrigacao;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoSolicitanteObrigacao
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 04/10/2017
 *
 * @see models.commons.constantes.TipoSolicitanteObrigacao
 */
@Converter
public class TipoSolicitanteObrigacaoConverter implements AttributeConverter<TipoSolicitanteObrigacao,String> {

    @Override
    public String convertToDatabaseColumn( TipoSolicitanteObrigacao tipoSolicitanteObrigacao ) {

        return getValor( tipoSolicitanteObrigacao );
    }

    @Override
    public TipoSolicitanteObrigacao convertToEntityAttribute( final String valor ) {

        return getEnum( TipoSolicitanteObrigacao.class, valor );
    }
}
