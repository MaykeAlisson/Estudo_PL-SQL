package models.commons.converters;

import models.commons.constantes.TipoObservacaoPedido;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValorInteger;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;

/**
 * Classe converter para constante TipoObservacaoPedido
 *
 * <p>Autor: GPortes</p>
 *
 * @since 18/02/2019
 *
 * @see models.commons.constantes.TipoObservacaoPedido
 */
@Converter
public class TipoObservacaoPedidoConverter implements AttributeConverter<TipoObservacaoPedido,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final TipoObservacaoPedido tipoObservacaoPedido ) {

        return getValorInteger( tipoObservacaoPedido );
    }

    @Override
    public TipoObservacaoPedido convertToEntityAttribute( final Integer valor ) {

        return getEnum( TipoObservacaoPedido.class, toShort(valor) );
    }
}

