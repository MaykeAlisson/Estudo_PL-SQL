package models.commons.converters;

import models.commons.constantes.TipoAlocacaoCusto;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoAlocacaoCusto
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 30/05/2016
 *
 * @see TipoAlocacaoCusto
 */
@Converter
public class TipoAlocacaoCustoConverter implements AttributeConverter<TipoAlocacaoCusto,String> {

    @Override
    public String convertToDatabaseColumn( final TipoAlocacaoCusto tipoAlocacaoCusto ) {

        return tipoAlocacaoCusto != null ? tipoAlocacaoCusto.getValor() : null;
    }

    @Override
    public TipoAlocacaoCusto convertToEntityAttribute( final String valor ) {

        return getEnum( TipoAlocacaoCusto.class, valor );
    }
}

