package models.commons.converters;

import models.commons.constantes.TipoAcerto;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoAcerto.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/09/2014.
 *
 * @see TipoAcerto
 */
@Converter
public class TipoAcertoConverter implements AttributeConverter<TipoAcerto,String> {

    @Override
    public String convertToDatabaseColumn( final TipoAcerto tipoAcerto ) {

        return tipoAcerto != null ? tipoAcerto.getValor() : null;
    }

    @Override
    public TipoAcerto convertToEntityAttribute( final String valor ) {

        return getEnum(TipoAcerto.class, valor);
    }

}
