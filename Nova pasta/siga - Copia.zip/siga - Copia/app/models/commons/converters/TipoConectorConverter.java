package models.commons.converters;

import models.commons.constantes.TipoConector;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoConector
 *
 * <p>Autor: GPortes</p>
 *
 * @since 22/10/2015
 *
 * @see TipoConector
 */
@Converter
public class TipoConectorConverter implements AttributeConverter<TipoConector,String> {

    @Override
    public String convertToDatabaseColumn( final TipoConector tipoConector ) {

        return tipoConector != null ? tipoConector.getValor() : null;
    }

    @Override
    public TipoConector convertToEntityAttribute( final String valor ) {

        return getEnum( TipoConector.class, valor );
    }
}

