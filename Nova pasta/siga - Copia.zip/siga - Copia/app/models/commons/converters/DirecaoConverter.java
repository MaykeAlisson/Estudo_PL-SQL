package models.commons.converters;


import models.commons.constantes.Direcao;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante Direcao
 *
 * <p>Autor: GPortes</p>
 *
 * @since 30/03/2017
 *
 * @see Direcao
 */
@Converter
public class DirecaoConverter implements AttributeConverter<Direcao,String> {

    @Override
    public String convertToDatabaseColumn( final Direcao direcao ) {

        return direcao != null ? direcao.getValor() : null;
    }

    @Override
    public Direcao convertToEntityAttribute( final String valor ) {

        return getEnum( Direcao.class, valor );
    }
}


