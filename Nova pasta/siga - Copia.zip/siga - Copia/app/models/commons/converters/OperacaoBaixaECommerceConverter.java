package models.commons.converters;

import models.commons.constantes.OperacaoBaixaECommerce;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValorInteger;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;

/**
 * Classe converter para constante TipoPagtoECommerce
 *
 * <p>Autor: Victor.serafim</p>
 *
 * @since 19/01/2019
 *
 * @see OperacaoBaixaECommerce
 */
@Converter
public class OperacaoBaixaECommerceConverter implements AttributeConverter<OperacaoBaixaECommerce,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final OperacaoBaixaECommerce tipoPagtoECommerce ) {

        return getValorInteger( tipoPagtoECommerce );
    }

    @Override
    public OperacaoBaixaECommerce convertToEntityAttribute(final Integer valor ) {

        return getEnum( OperacaoBaixaECommerce.class, toShort(valor) );
    }
}

