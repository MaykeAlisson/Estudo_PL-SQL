package models.commons.converters;

import models.commons.constantes.SituacaoFuncionario;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante SituacaoFuncionario
 *
 * <p>Autor: GPortes</p>
 *
 * @since 12/12/2018
 *
 * @see models.commons.constantes.SituacaoFuncionario
 */
@Converter
public class SituacaoFuncionarioConverter implements AttributeConverter<SituacaoFuncionario,String> {

    @Override
    public String convertToDatabaseColumn( final SituacaoFuncionario situacaoFuncionario ) {

        return getValor( situacaoFuncionario );
    }

    @Override
    public SituacaoFuncionario convertToEntityAttribute( final String valor ) {

        return getEnum( SituacaoFuncionario.class, valor );
    }
}