package models.commons.converters;

import models.commons.constantes.TipoMovto;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoMovto
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 26/02/2018
 *
 * @see models.commons.constantes.TipoMovto
 */
@Converter
public class TipoMovtoConverter implements AttributeConverter<TipoMovto,String> {

    @Override
    public String convertToDatabaseColumn( final TipoMovto tipoMovto ) {

        return getValor( tipoMovto );
    }

    @Override
    public TipoMovto convertToEntityAttribute( final String valor ) {

        return getEnum( TipoMovto.class, valor );
    }
}

