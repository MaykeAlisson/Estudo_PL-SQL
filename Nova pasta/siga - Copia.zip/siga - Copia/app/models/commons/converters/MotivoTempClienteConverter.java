package models.commons.converters;

import models.commons.constantes.MotivoTempCliente;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante MotivoTempCliente
 *
 * <p>Autor: GPortes</p>
 *
 * @since 11/01/2019
 *
 * @see models.commons.constantes.MotivoTempCliente
 */
@Converter
public class MotivoTempClienteConverter implements AttributeConverter<MotivoTempCliente,String> {


    @Override
    public String convertToDatabaseColumn( final MotivoTempCliente motivoTempCliente ) {

        return getValor(motivoTempCliente);
    }

    @Override
    public MotivoTempCliente convertToEntityAttribute( final String valor ) {

        return getEnum( MotivoTempCliente.class, valor );
    }
}


//  @Convert( converter = MotivoTempPedidoConverter.class )

