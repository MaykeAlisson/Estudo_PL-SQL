package models.commons.converters;

import models.commons.constantes.TipoDestinatario;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;


/**
 * Classe converter para constante TipoDestinatario.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/09/2014.
 *
 * @see TipoDestinatario
 */
@Converter
public class TipoDestinatarioConverter implements AttributeConverter<TipoDestinatario,String> {

    @Override
    public String convertToDatabaseColumn( final TipoDestinatario tipoDestinatario ) {

        return tipoDestinatario != null ? tipoDestinatario.getValor() : null;
    }

    @Override
    public TipoDestinatario convertToEntityAttribute( String valor ) {

        return getEnum(TipoDestinatario.class, valor);
    }

}
