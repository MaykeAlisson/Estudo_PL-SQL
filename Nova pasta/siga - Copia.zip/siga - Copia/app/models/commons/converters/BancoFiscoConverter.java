package models.commons.converters;

import models.commons.constantes.BancoFisco;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante BancoFisco
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 14/08/2017
 *
 * @see models.commons.constantes.BancoFisco
 */
@Converter
public class BancoFiscoConverter implements AttributeConverter<BancoFisco,String> {

    @Override
    public String convertToDatabaseColumn( final BancoFisco bancoFisco ) {

        return bancoFisco != null ? bancoFisco.getValor() : null;
    }

    @Override
    public BancoFisco convertToEntityAttribute( final String valor ) {

        return getEnum( BancoFisco.class, valor );
    }
}
