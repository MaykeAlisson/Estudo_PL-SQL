package models.commons.converters;

import models.commons.constantes.FechaSemana;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante FechaSemana
 *
 * <p>Autor: GPortes</p>
 *
 * @since 28/02/2018
 *
 * @see models.commons.constantes.FechaSemana
 */
@Converter
public class FechaSemanaConverter implements AttributeConverter<FechaSemana,String> {

    @Override
    public String convertToDatabaseColumn( final FechaSemana fechaSemana ) {

        return getValor( fechaSemana );
    }

    @Override
    public FechaSemana convertToEntityAttribute( final String valor ) {

        return getEnum( FechaSemana.class, valor );
    }
}