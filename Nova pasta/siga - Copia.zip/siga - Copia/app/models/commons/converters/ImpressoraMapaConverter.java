package models.commons.converters;

import models.commons.constantes.ImpressoraMapa;
import models.commons.constantes.PagaKm;
import models.commons.constantes.TipoImpressaoMapa;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante ImpressoraMapa
 *
 * <p>Autor: Jander Dutra</p>
 *
 * @since 14/02/2019
 *
 * @see ImpressoraMapa
 */
@Converter
public class ImpressoraMapaConverter implements AttributeConverter<ImpressoraMapa,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final ImpressoraMapa impressoraMapa ) {

        return impressoraMapa != null ? impressoraMapa.getValor().intValue() : null;
    }

    @Override
    public ImpressoraMapa convertToEntityAttribute(Integer valor ) {
        return getEnum(ImpressoraMapa.class, valor == null ? null : valor.shortValue());
    }
}

