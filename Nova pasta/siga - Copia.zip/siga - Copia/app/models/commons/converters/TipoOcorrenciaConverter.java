package models.commons.converters;

import models.commons.constantes.TipoOcorrencia;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoOcorrencia.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/09/2014.
 *
 * @see TipoOcorrencia
 */
@Converter
public class TipoOcorrenciaConverter implements AttributeConverter<TipoOcorrencia,Integer>  {

    @Override
    public Integer convertToDatabaseColumn( final TipoOcorrencia tipoOcorrencia ) {

        return tipoOcorrencia != null ? tipoOcorrencia.getValor() : null;
    }

    @Override
    public TipoOcorrencia convertToEntityAttribute( Integer valor ) {

        return getEnum(TipoOcorrencia.class, valor);
    }

}
