package models.commons.converters;

import models.commons.constantes.TipoStatusEquipamento;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import static infra.util.UtilConstante.getValorInteger;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;

/**
 * Classe converter para constante TipoStatusEquipamento
 *
 * <p>Autor: Antoniocarlos</p>
 *
 * @since 05/06/2019
 *
 * @see models.commons.constantes.TipoStatusEquipamento
 */
@Converter
public class TipoStatusEquipamentoConverter implements AttributeConverter<TipoStatusEquipamento,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final TipoStatusEquipamento tipoStatusEquipamento ) {

        return getValorInteger( tipoStatusEquipamento );
    }

    @Override
    public TipoStatusEquipamento convertToEntityAttribute( final Integer valor ) {

        return getEnum( TipoStatusEquipamento.class, toShort(valor) );
    }
}


