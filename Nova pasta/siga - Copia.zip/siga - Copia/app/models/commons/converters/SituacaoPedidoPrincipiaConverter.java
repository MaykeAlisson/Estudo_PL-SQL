package models.commons.converters;

import models.commons.constantes.SituacaoPedidoPrincipia;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante SituacaoPedidoPrincipia
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 26/12/2018
 *
 * @see SituacaoPedidoPrincipia
 */
@Converter
public class SituacaoPedidoPrincipiaConverter implements AttributeConverter<SituacaoPedidoPrincipia,String> {

    @Override
    public String convertToDatabaseColumn( final SituacaoPedidoPrincipia situacaoPedidoPrincipia ) {

        return getValor( situacaoPedidoPrincipia );
    }

    @Override
    public SituacaoPedidoPrincipia convertToEntityAttribute( final String valor ) {

        return getEnum( SituacaoPedidoPrincipia.class, valor );
    }
}




