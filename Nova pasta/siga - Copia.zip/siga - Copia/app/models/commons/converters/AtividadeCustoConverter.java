package models.commons.converters;

import models.commons.constantes.AtividadeCusto;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante AtividadeCusto
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 30/05/2016
 *
 * @see AtividadeCusto
 */
@Converter
public class AtividadeCustoConverter implements AttributeConverter<AtividadeCusto,String> {

    @Override
    public String convertToDatabaseColumn( final AtividadeCusto atividadeCusto ) {

        return atividadeCusto != null ? atividadeCusto.getValor() : null;
    }

    @Override
    public AtividadeCusto convertToEntityAttribute( final String valor ) {

        return getEnum( AtividadeCusto.class, valor );
    }
}

