package models.commons.converters;


import models.commons.constantes.TipoFeriado;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoFeriado
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 28/11/2016
 *
 * @see TipoFeriado
 */
@Converter
public class TipoFeriadoConverter implements AttributeConverter<TipoFeriado,String> {

    @Override
    public String convertToDatabaseColumn( final TipoFeriado tipoFeriado ) {

        return tipoFeriado != null ? tipoFeriado.getValor() : null;
    }

    @Override
    public TipoFeriado convertToEntityAttribute( final String valor ) {

        return getEnum( TipoFeriado.class, valor );
    }
}

