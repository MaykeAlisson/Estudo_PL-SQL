package models.commons.converters;

import models.commons.constantes.TipoMovimentacao;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoMovimentacao
 *
 * <p>Autor: GPortes</p>
 *
 * @since 13/04/2017
 *
 * @see TipoMovimentacao
 */
@Converter
public class TipoMovimentacaoConverter implements AttributeConverter<TipoMovimentacao,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final TipoMovimentacao tipoMovimentacao ) {

        return tipoMovimentacao != null ? tipoMovimentacao.getValor() : null;
    }

    @Override
    public TipoMovimentacao convertToEntityAttribute( final Integer valor ) {

        return getEnum( TipoMovimentacao.class, valor );
    }
}

