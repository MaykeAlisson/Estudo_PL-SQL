package models.commons.converters;

import models.commons.constantes.TipoDocto;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoDocto
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 27/07/2015
 *
 * @see TipoDocto
 */
@Converter
public class TipoDoctoConverter implements AttributeConverter<TipoDocto,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final TipoDocto tipoDocto ) {

        return tipoDocto != null ? tipoDocto.getValor() : null;
    }

    @Override
    public TipoDocto convertToEntityAttribute( final Integer valor ) {

        return getEnum( TipoDocto.class, valor );
    }
}

