package models.commons.converters;


import infra.util.UtilNumero;
import models.commons.constantes.TipoBrinde;
import models.domains.move.TipoCelula;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilConstante.getValorInteger;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoBrinde
 *
 * <p>Autor: GPortes</p>
 *
 * @since 09/01/2019
 *
 * @see models.commons.constantes.TipoBrinde
 */
@Converter
public class TipoCelulaConverter implements AttributeConverter<TipoCelula.IdTipoCelula,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final TipoCelula.IdTipoCelula idTipoCelula ) {

        return getValorInteger( idTipoCelula );
    }

    @Override
    public TipoCelula.IdTipoCelula convertToEntityAttribute( final Integer valor ) {

        return getEnum( TipoCelula.IdTipoCelula.class, UtilNumero.toShort(valor ));
    }
}

