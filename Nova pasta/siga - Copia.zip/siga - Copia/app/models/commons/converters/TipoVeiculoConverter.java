package models.commons.converters;

import models.commons.constantes.TipoVeiculo;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoVeiculo
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 09/06/2016
 *
 * @see TipoVeiculo
 */
@Converter
public class TipoVeiculoConverter implements AttributeConverter<TipoVeiculo,String> {

    @Override
    public String convertToDatabaseColumn( final TipoVeiculo tipoVeiculo ) {

        return tipoVeiculo != null ? tipoVeiculo.getValor() : null;
    }

    @Override
    public TipoVeiculo convertToEntityAttribute( final String valor ) {

        return getEnum( TipoVeiculo.class, valor );
    }
}

