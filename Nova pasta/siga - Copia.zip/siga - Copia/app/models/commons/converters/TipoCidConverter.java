package models.commons.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoCid
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 18/12/2018
 *
 * @see models.commons.constantes.TipoCid
 */
@Converter
public class TipoCidConverter implements AttributeConverter<models.commons.constantes.TipoCid,String> {

    @Override
    public String convertToDatabaseColumn( final models.commons.constantes.TipoCid tipoCid ) {

        return getValor( tipoCid );
    }

    @Override
    public models.commons.constantes.TipoCid convertToEntityAttribute( final String valor ) {

        return getEnum( models.commons.constantes.TipoCid.class, valor );
    }
}
