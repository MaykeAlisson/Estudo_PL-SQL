package models.commons.converters;

import models.commons.constantes.TipoLoteTarefa;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante SituacaoPedido.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/09/2014.
 *
 * @see models.commons.constantes.SituacaoPedido
 */
@Converter
public class TipoLoteTarefaConverter implements AttributeConverter<TipoLoteTarefa,String> {

    @Override
    public String convertToDatabaseColumn( final TipoLoteTarefa tipoLoteTarefa ) {

        return tipoLoteTarefa != null ? tipoLoteTarefa.getValor() : null;
    }

    @Override
    public TipoLoteTarefa convertToEntityAttribute( final String valor ) {

        return getEnum(TipoLoteTarefa.class, valor);
    }

}

