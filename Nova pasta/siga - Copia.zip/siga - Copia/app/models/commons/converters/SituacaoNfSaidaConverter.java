package models.commons.converters;


import models.commons.constantes.SituacaoNfSaida;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante SituacaoNfSaida
 *
 * <p>Autor: GPortes</p>
 *
 * @since 16/06/2015
 *
 * @see SituacaoNfSaida
 */
@Converter
public class SituacaoNfSaidaConverter implements AttributeConverter<SituacaoNfSaida,String> {

    @Override
    public String convertToDatabaseColumn( SituacaoNfSaida situacaoNfSaida ) {

        return situacaoNfSaida != null ? situacaoNfSaida.getValor() : null;
    }

    @Override
    public SituacaoNfSaida convertToEntityAttribute( String valor ) {

        return getEnum( SituacaoNfSaida.class, valor );
    }
}

