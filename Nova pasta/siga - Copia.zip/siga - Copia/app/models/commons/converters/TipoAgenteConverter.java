package models.commons.converters;

import models.commons.constantes.TipoAgente;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoAgente
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 27/07/2015
 *
 * @see TipoAgente
 */
@Converter
public class TipoAgenteConverter implements AttributeConverter<TipoAgente,String> {

    @Override
    public String convertToDatabaseColumn( final TipoAgente tipoAgente ) {

        return tipoAgente != null ? tipoAgente.getValor() : null;
    }

    @Override
    public TipoAgente convertToEntityAttribute( String valor ) {
        return getEnum(TipoAgente.class, valor);
    }
}

