package models.commons.converters;

import models.commons.constantes.Estado;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante Estado.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/09/2014.
 *
 * @see Estado
 */
@Converter
public class EstadoConverter implements AttributeConverter<Estado,String> {

    @Override
    public String convertToDatabaseColumn( final Estado estado ) {

        return estado != null ? estado.getValor() : null;
    }

    @Override
    public Estado convertToEntityAttribute( final String valor ) {

        return getEnum(Estado.class, valor);
    }

}
