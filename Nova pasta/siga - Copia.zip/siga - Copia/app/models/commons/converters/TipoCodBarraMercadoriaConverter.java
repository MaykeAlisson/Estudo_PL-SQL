package models.commons.converters;

import models.commons.constantes.TipoCodBarraMercadoria;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValorInteger;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;

/**
 * Classe converter para constante TipoCodBarraMercadoria
 *
 * <p>Autor: GPortes</p>
 *
 * @since 28/12/2018
 *
 * @see TipoCodBarraMercadoria
 */
@Converter
public class TipoCodBarraMercadoriaConverter implements AttributeConverter<TipoCodBarraMercadoria,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final TipoCodBarraMercadoria tipoCodBarraMercadoria ) {

        return getValorInteger( tipoCodBarraMercadoria );
    }

    @Override
    public TipoCodBarraMercadoria convertToEntityAttribute( final Integer valor ) {

        return getEnum( TipoCodBarraMercadoria.class, toShort(valor) );
    }
}

