package models.commons.converters;

import models.commons.constantes.SimNao;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;


/**
 * Classe converter para constante SituacaoPedido.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/09/2014.
 *
 * @see models.commons.constantes.SituacaoPedido
 */
@Converter
public class SimNaoConverter implements AttributeConverter<SimNao,String> {

    @Override
    public String convertToDatabaseColumn( final SimNao simNao ) {

        return simNao != null ? simNao.getValor() : null;
    }

    @Override
    public SimNao convertToEntityAttribute( final String valor ) {

        return getEnum(SimNao.class, valor);
    }
}
