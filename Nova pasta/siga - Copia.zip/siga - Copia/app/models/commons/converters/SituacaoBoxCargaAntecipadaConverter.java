package models.commons.converters;

import models.commons.constantes.SituacaoBaixa;
import models.commons.constantes.SituacaoBoxCargaAntecipada;

import javax.persistence.AttributeConverter;
import javax.persistence.Convert;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante SituacaoBoxCargaAntecipada
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/09/2014.
 *
 * @see SituacaoBaixa
 */
@Convert
public class SituacaoBoxCargaAntecipadaConverter implements AttributeConverter<SituacaoBoxCargaAntecipada,String> {

    @Override
    public String convertToDatabaseColumn( final SituacaoBoxCargaAntecipada situacaoBoxCargaAntecipada ) {

        return getValor( situacaoBoxCargaAntecipada );
    }

    @Override
    public SituacaoBoxCargaAntecipada convertToEntityAttribute( final String value ) {

        return getEnum( SituacaoBoxCargaAntecipada.class, value );
    }
}
