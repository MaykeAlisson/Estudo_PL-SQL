package models.commons.converters;

import models.commons.constantes.TipoCda;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoCda
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 13/03/2017
 *
 * @see TipoCda
 */
@Converter
public class TipoCdaConverter implements AttributeConverter<TipoCda,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final TipoCda tipoCda ) {

        return tipoCda != null ? tipoCda.getValor() : null;
    }

    @Override
    public TipoCda convertToEntityAttribute( final Integer valor ) {

        return getEnum( TipoCda.class, valor );
    }
}



