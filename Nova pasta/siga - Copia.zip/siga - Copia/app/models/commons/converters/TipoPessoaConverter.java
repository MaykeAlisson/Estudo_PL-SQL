package models.commons.converters;

import models.commons.constantes.TipoPessoa;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;


/**
 * Classe converter para constante TipoPessoa.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/09/2014.
 *
 * @see TipoPessoa
 */
@Converter
public class TipoPessoaConverter implements AttributeConverter<TipoPessoa,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final TipoPessoa tipoPessoa ) {

        return tipoPessoa != null ? getValor( tipoPessoa ).intValue() : null;
    }

    @Override
    public TipoPessoa convertToEntityAttribute( final Integer valor ) {

        return getEnum( TipoPessoa.class, toShort(valor) );
    }

}