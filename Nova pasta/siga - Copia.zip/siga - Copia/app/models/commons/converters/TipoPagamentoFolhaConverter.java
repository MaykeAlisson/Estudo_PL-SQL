package models.commons.converters;

import models.commons.constantes.TipoPagamentoFolha;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoPagamentoFolha
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 18/06/2018
 *
 * @see models.commons.constantes.TipoPagamentoFolha
 */
@Converter
public class TipoPagamentoFolhaConverter implements AttributeConverter<TipoPagamentoFolha,String> {

    @Override
    public String convertToDatabaseColumn( final TipoPagamentoFolha tipoPagamento ) {

        return getValor( tipoPagamento );
    }

    @Override
    public TipoPagamentoFolha convertToEntityAttribute( final String valor ) {

        return getEnum( TipoPagamentoFolha.class, valor );
    }
}

