package models.commons.converters;

import models.commons.constantes.StatusIntegracaoElasticSearch;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante StatusIntegracaoElasticSearch
 *
 * <p>Autor: Jander Dutra</p>
 *
 * @since 14/02/2019
 *
 * @see StatusIntegracaoElasticSearch
 */
@Converter
public class StatusIntegracaoElasticSearchConverter implements AttributeConverter<StatusIntegracaoElasticSearch,String> {

    @Override
    public String convertToDatabaseColumn( final StatusIntegracaoElasticSearch statusIntegracaoES ) {

        return statusIntegracaoES != null ? statusIntegracaoES.getValor() : null;
    }

    @Override
    public StatusIntegracaoElasticSearch convertToEntityAttribute(String valor ) {
        return getEnum( StatusIntegracaoElasticSearch.class, valor);
    }
}

