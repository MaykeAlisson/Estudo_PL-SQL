package models.commons.converters;

import models.commons.constantes.TipoFolha;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValorInteger;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;

/**
 * Classe converter para constante TipoFolha
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 18/06/2018
 *
 * @see models.commons.constantes.TipoFolha
 */
@Converter
public class TipoFolhaConverter implements AttributeConverter<TipoFolha,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final TipoFolha tipoFolha ) {

        return getValorInteger( tipoFolha );
    }

    @Override
    public TipoFolha convertToEntityAttribute( final Integer valor ) {

        return getEnum( TipoFolha.class, toShort( valor ) );
    }
}