package models.commons.converters;

import models.commons.constantes.TransportadoraOrigemECommerce;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValorInteger;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;

/**
 * Classe converter para constante TransportadoraOrigemECommerce
 *
 * <p>Autor: GPortes</p>
 *
 * @since 22/05/2019
 *
 * @see models.commons.constantes.TransportadoraOrigemECommerce
 */
@Converter
public class TransportadoraOrigemECommerceConverter implements AttributeConverter<TransportadoraOrigemECommerce,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final TransportadoraOrigemECommerce transportadoraOrigemECommerce ) {

        return getValorInteger( transportadoraOrigemECommerce );
    }

    @Override
    public TransportadoraOrigemECommerce convertToEntityAttribute( final Integer valor ) {

        return getEnum( TransportadoraOrigemECommerce.class, toShort(valor) );
    }
}