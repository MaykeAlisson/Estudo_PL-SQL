package models.commons.converters;

import models.commons.constantes.SituacaoBaixa;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante models.constantes.SituacaoBaixa.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/09/2014.
 *
 * @see SituacaoBaixa
 */
@Converter
public class SituacaoBaixaConverter implements AttributeConverter<SituacaoBaixa,Integer> {

    @Override
    public Integer convertToDatabaseColumn( SituacaoBaixa situacaoBaixa ) {

        return situacaoBaixa != null ? situacaoBaixa.getValor() : null;
    }

    @Override
    public SituacaoBaixa convertToEntityAttribute(Integer valor) {

        return getEnum(SituacaoBaixa.class, valor);
    }

}
