package models.commons.converters;

import models.commons.constantes.TipoPerdaFerias;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoPerdaFeria
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 30/05/2018
 *
 * @see models.commons.constantes.TipoPerdaFerias
 */
@Converter
public class TipoPerdaFeriasConverter implements AttributeConverter<TipoPerdaFerias,String> {

    @Override
    public String convertToDatabaseColumn( final TipoPerdaFerias tipoPerdaFeria ) {

        return getValor( tipoPerdaFeria );
    }

    @Override
    public TipoPerdaFerias convertToEntityAttribute( final String valor ) {

        return getEnum( TipoPerdaFerias.class, valor );
    }
}