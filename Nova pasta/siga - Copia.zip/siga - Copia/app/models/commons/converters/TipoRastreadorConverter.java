package models.commons.converters;

import models.commons.constantes.TipoRastreador;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValorInteger;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;

/**
 * Classe converter para constante TipoRastreador
 *
 * <p>Autor: GPortes</p>
 *
 * @since 15/02/2019
 *
 * @see models.commons.constantes.TipoRastreador
 */
@Converter
public class TipoRastreadorConverter implements AttributeConverter<TipoRastreador,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final TipoRastreador tipoRastreador ) {

        return getValorInteger( tipoRastreador );
    }

    @Override
    public TipoRastreador convertToEntityAttribute( final Integer valor ) {

        return getEnum( TipoRastreador.class, toShort(valor) );
    }
}


