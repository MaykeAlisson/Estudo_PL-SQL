package models.commons.converters;

import models.commons.constantes.AutomaticoOcorAtendimento;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante AutomaticoOcorAtendimento
 *
 * <p>Autor: GPortes</p>
 *
 * @since 01/03/2019
 *
 * @see models.commons.constantes.AutomaticoOcorAtendimento
 */
@Converter
public class AutomaticoOcorAtendimentoConverter implements AttributeConverter<AutomaticoOcorAtendimento,String> {

    @Override
    public String convertToDatabaseColumn( final AutomaticoOcorAtendimento automaticoOcorAtendimento ) {

        return getValor( automaticoOcorAtendimento );
    }

    @Override
    public AutomaticoOcorAtendimento convertToEntityAttribute( final String valor ) {

        return getEnum( AutomaticoOcorAtendimento.class, valor );
    }
}

