package models.commons.converters;

import models.commons.constantes.TipoCarregamento;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoCarregamento
 *
 * <p>Autor: GPortes</p>
 *
 * @since 07/01/2016
 *
 * @see TipoCarregamento
 */
@Converter
public class TipoCarregamentoConverter implements AttributeConverter<TipoCarregamento,String> {

    @Override
    public String convertToDatabaseColumn( final TipoCarregamento tipoCarregamento ) {

        return tipoCarregamento != null ? tipoCarregamento.getValor() : null;
    }

    @Override
    public TipoCarregamento convertToEntityAttribute( final String valor ) {

        return getEnum( TipoCarregamento.class, valor );
    }
}

