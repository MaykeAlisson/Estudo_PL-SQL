package models.commons.converters;

import models.commons.constantes.TipoEnvioEqpto;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoEnvioEqpto
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/10/2017
 *
 * @see models.commons.constantes.TipoEnvioEqpto
 */
@Converter
public class TipoEnvioEqptoConverter implements AttributeConverter<TipoEnvioEqpto,String> {

    @Override
    public String convertToDatabaseColumn( final TipoEnvioEqpto tipoEnvioEqpto ) {

        return getValor( tipoEnvioEqpto );
    }

    @Override
    public TipoEnvioEqpto convertToEntityAttribute( final String valor ) {

        return getEnum( TipoEnvioEqpto.class, valor );
    }
}

