package models.commons.converters;

import models.commons.constantes.TipoAgente;
import models.commons.constantes.TipoImpressaoMapa;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoImpressaoMapa
 *
 * <p>Autor: Jander Dutra</p>
 *
 * @since 14/02/2019
 *
 * @see TipoImpressaoMapa
 */
@Converter
public class TipoImpressaoMapaConverter implements AttributeConverter<TipoImpressaoMapa,String> {

    @Override
    public String convertToDatabaseColumn( final TipoImpressaoMapa tipoImpressaoMapa ) {

        return tipoImpressaoMapa != null ? tipoImpressaoMapa.getValor() : null;
    }

    @Override
    public TipoImpressaoMapa convertToEntityAttribute(String valor ) {
        return getEnum(TipoImpressaoMapa.class, valor);
    }
}

