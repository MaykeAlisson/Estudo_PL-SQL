package models.commons.converters;

import models.commons.constantes.TipoEscalaPonto;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;

/**
 * Classe converter para constante TipoEscalaPonto
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 16/07/2018
 *
 * @see models.commons.constantes.TipoEscalaPonto
 */
@Converter
public class TipoEscalaPontoConverter implements AttributeConverter<TipoEscalaPonto,Object> {

    @Override
    public Short convertToDatabaseColumn( final TipoEscalaPonto tipoEscalaPonto ) {

        return getValor( tipoEscalaPonto );
    }

    @Override
    public TipoEscalaPonto convertToEntityAttribute( final Object valor ) {

        return getEnum( TipoEscalaPonto.class, toShort(valor) );
    }
}

