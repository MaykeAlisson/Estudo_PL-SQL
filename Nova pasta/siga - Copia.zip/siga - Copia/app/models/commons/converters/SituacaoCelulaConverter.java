package models.commons.converters;

import models.commons.constantes.SituacaoCelula;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValorInteger;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;

/**
 * Classe converter para constante SituacaoCelula
 *
 * <p>Autor: Cleber</p>
 *
 * @since 06/02/2019
 *
 * @see models.commons.constantes.SituacaoCelula
 */
@Converter
public class SituacaoCelulaConverter implements AttributeConverter<SituacaoCelula,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final SituacaoCelula situacaoCelula ) {

        return getValorInteger( situacaoCelula );
    }

    @Override
    public SituacaoCelula convertToEntityAttribute( final Integer valor ) {

        return getEnum( SituacaoCelula.class, toShort(valor) );
    }
}

