package models.commons.converters;

import models.commons.constantes.TipoRegistroPonto;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoRegistroPonto
 *
 * <p>Autor: GPortes</p>
 *
 * @since 11/07/2018
 *
 * @see models.commons.constantes.TipoRegistroPonto
 */
@Converter
public class TipoRegistroPontoConverter implements AttributeConverter<TipoRegistroPonto,String> {

    @Override
    public String convertToDatabaseColumn( final TipoRegistroPonto tipoRegistroPonto ) {

        return getValor( tipoRegistroPonto );
    }

    @Override
    public TipoRegistroPonto convertToEntityAttribute( final String valor ) {

        return getEnum( TipoRegistroPonto.class, valor );
    }
}

