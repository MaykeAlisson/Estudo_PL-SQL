package models.commons.converters;

import models.commons.constantes.TipoEntregaECommerce;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import static infra.util.UtilConstante.getValorInteger;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;

/**
 * Classe converter para constante TipoEntregaECommerce
 *
 * <p>Autor: GPortes</p>
 *
 * @since 23/05/2019
 *
 * @see models.commons.constantes.TipoEntregaECommerce
 */
@Converter
public class TipoEntregaECommerceConverter implements AttributeConverter<TipoEntregaECommerce,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final TipoEntregaECommerce tipoEntregaECommerce ) {

        return getValorInteger( tipoEntregaECommerce );
    }

    @Override
    public TipoEntregaECommerce convertToEntityAttribute( final Integer valor ) {

        return getEnum( TipoEntregaECommerce.class, toShort(valor) );
    }
}

