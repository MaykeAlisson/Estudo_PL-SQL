package models.commons.converters;

import models.commons.constantes.PagaKm;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante PagaKm
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/12/2015
 *
 * @see PagaKm
 */
@Converter
public class PagaKmConverter implements AttributeConverter<PagaKm,Object> {

    @Override
    public Short convertToDatabaseColumn( final PagaKm pagaKm ) {

        return pagaKm != null ? pagaKm.getValor() : null;
    }

    @Override
    public PagaKm convertToEntityAttribute( final Object valor ) {

        return getEnum( PagaKm.class, valor != null ? ( (Integer) valor ).shortValue() : null );
    }
}

