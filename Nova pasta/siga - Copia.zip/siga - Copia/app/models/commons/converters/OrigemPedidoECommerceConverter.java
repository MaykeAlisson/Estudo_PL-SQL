package models.commons.converters;

import models.commons.constantes.OrigemPedidoECommerce;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValorInteger;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;

/**
 * Classe converter para constante OrigemPedidoECommerce
 *
 * <p>Autor: GPortes</p>
 *
 * @since 02/01/2019
 *
 * @see OrigemPedidoECommerce
 */
@Converter
public class OrigemPedidoECommerceConverter implements AttributeConverter<OrigemPedidoECommerce,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final OrigemPedidoECommerce origemPedidoECommerce ) {

        return getValorInteger( origemPedidoECommerce );
    }

    @Override
    public OrigemPedidoECommerce convertToEntityAttribute( final Integer valor ) {

        return getEnum( OrigemPedidoECommerce.class, toShort(valor) );
    }
}