package models.commons.converters;

import models.commons.constantes.TipoCombustivel;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoCombustivel
 *
 * <p>Autor: Cleber</p>
 *
 * @since 13/06/2016
 *
 * @see TipoCombustivel
 */
@Converter
public class TipoCombustivelConverter implements AttributeConverter<TipoCombustivel,String> {

    @Override
    public String convertToDatabaseColumn( final TipoCombustivel tipoCombustivel ) {

        return tipoCombustivel != null ? tipoCombustivel.getValor() : null;
    }

    @Override
    public TipoCombustivel convertToEntityAttribute( final String valor ) {

        return getEnum( TipoCombustivel.class, valor );
    }
}


