package models.commons.converters;

import models.commons.constantes.TipoLacrarRecipiente;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoLacrarRecipiente
 *
 * <p>Autor: GPortes</p>
 *
 * @since 28/12/2018
 *
 * @see TipoLacrarRecipiente
 */
@Converter
public class TipoLacrarRecipienteConverter implements AttributeConverter<TipoLacrarRecipiente,String> {

    @Override
    public String convertToDatabaseColumn( final TipoLacrarRecipiente tipoLacrarRecipiente ) {

        return getValor( tipoLacrarRecipiente );
    }

    @Override
    public TipoLacrarRecipiente convertToEntityAttribute( final String valor ) {

        return getEnum( TipoLacrarRecipiente.class, valor );
    }
}


