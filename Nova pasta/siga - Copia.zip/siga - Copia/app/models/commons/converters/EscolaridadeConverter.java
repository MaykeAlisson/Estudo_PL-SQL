package models.commons.converters;

import models.commons.constantes.Escolaridade;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante Escolaridade
 *
 * <p>Autor: GPortes</p>
 *
 * @since 20/10/2015
 *
 * @see Escolaridade
 */
@Converter
public class EscolaridadeConverter implements AttributeConverter<Escolaridade,Integer> {


    @Override
    public Integer convertToDatabaseColumn( Escolaridade escolaridade ) {

        return escolaridade != null ? escolaridade.getValor() : null;
    }

    @Override
    public Escolaridade convertToEntityAttribute( Integer valor ) {

        return getEnum( Escolaridade.class, valor );
    }
}