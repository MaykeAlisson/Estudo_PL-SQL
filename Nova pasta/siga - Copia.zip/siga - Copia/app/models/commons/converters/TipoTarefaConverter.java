package models.commons.converters;

import models.commons.constantes.TipoTarefa;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoTarefa
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 04/10/2017
 *
 * @see models.commons.constantes.TipoTarefa
 */
@Converter
public class TipoTarefaConverter implements AttributeConverter<TipoTarefa,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final TipoTarefa tipoTarefa ) {

        return getValor( tipoTarefa );
    }

    @Override
    public TipoTarefa convertToEntityAttribute( final Integer valor ) {

        return getEnum( TipoTarefa.class, valor );
    }
}

