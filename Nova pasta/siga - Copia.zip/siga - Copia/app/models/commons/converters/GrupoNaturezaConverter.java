package models.commons.converters;

import models.commons.constantes.GrupoNatureza;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante GrupoNatureza
 *
 * <p>Autor: GPortes</p>
 *
 * @since 16/06/2015
 *
 * @see GrupoNatureza
 */
@Converter
public class GrupoNaturezaConverter implements AttributeConverter<GrupoNatureza,String> {

    @Override
    public String convertToDatabaseColumn( GrupoNatureza grupoNatureza ) {

        return grupoNatureza != null ? grupoNatureza.getValor() : null;
    }

    @Override
    public GrupoNatureza convertToEntityAttribute( String valor ) {

        return getEnum( GrupoNatureza.class, valor );
    }
}

