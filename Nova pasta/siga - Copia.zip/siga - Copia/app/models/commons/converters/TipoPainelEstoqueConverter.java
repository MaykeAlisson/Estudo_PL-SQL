package models.commons.converters;

import models.commons.constantes.TipoPainelEstoque;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValorInteger;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;

/**
 * Classe converter para constante TipoPainelEstoque
 *
 * <p>Autor: Cléber</p>
 *
 * @since 03/05/2018
 *
 * @see TipoPainelEstoque
 */
@Converter
public class TipoPainelEstoqueConverter implements AttributeConverter<TipoPainelEstoque,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final TipoPainelEstoque tipoPainelEstoque ) {

        return getValorInteger( tipoPainelEstoque );
    }

    @Override
    public TipoPainelEstoque convertToEntityAttribute( final Integer valor ) {

        return getEnum( TipoPainelEstoque.class, toShort(valor) );
    }
}

