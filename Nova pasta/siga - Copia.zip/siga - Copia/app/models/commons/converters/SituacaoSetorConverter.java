package models.commons.converters;

import models.commons.constantes.SituacaoSetor;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante SituacaoSetor
 *
 * <p>Autor: GPortes</p>
 *
 * @since 09/01/2019
 *
 * @see models.commons.constantes.SituacaoSetor
 */
@Converter
public class SituacaoSetorConverter implements AttributeConverter<SituacaoSetor,String> {

    @Override
    public String convertToDatabaseColumn( final SituacaoSetor situacaoSetor ) {

        return getValor( situacaoSetor );
    }

    @Override
    public SituacaoSetor convertToEntityAttribute( final String valor ) {

        return getEnum( SituacaoSetor.class, valor );
    }
}

