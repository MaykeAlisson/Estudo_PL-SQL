package models.commons.converters;

import models.commons.constantes.StatusLiberacao;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;

/**
 * Classe converter para constante models.constantes.StatusLiberacao.
 *
 * <p>Autor: Andre Luiz Alves de Faria </p>
 *
 * @since 08/08/2018.
 *
 * @see StatusLiberacao
 */
@Converter
public class StatusLiberacaoConverter implements AttributeConverter<StatusLiberacao, Integer> {

    @Override
    public Integer convertToDatabaseColumn( final StatusLiberacao statusLiberacao ) {

        final Short valor = getValor( statusLiberacao );
        return valor != null ? valor.intValue() : null;
    }

    @Override
    public StatusLiberacao convertToEntityAttribute( final Integer valor ) {

        return getEnum( StatusLiberacao.class, toShort(valor) );
    }

}
