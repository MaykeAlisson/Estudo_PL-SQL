package models.commons.converters;

import models.commons.constantes.FaixaAcrescimoPagamento;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante FaixaAcrescimoPagamento
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 11/02/2016
 *
 * @see FaixaAcrescimoPagamento
 */
@Converter
public class FaixaAcrescimoPagamentoConverter implements AttributeConverter<FaixaAcrescimoPagamento,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final FaixaAcrescimoPagamento faixaAcrescimoPagamento ) {

        return faixaAcrescimoPagamento != null ? faixaAcrescimoPagamento.getValor() : null;
    }

    @Override
    public FaixaAcrescimoPagamento convertToEntityAttribute( final Integer valor ) {

        return getEnum( FaixaAcrescimoPagamento.class, valor );
    }
}


