package models.commons.converters;

import models.commons.constantes.TipoServicoCorreio;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoServicoCorreio
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 26/12/2018
 *
 * @see TipoServicoCorreio
 */
@Converter
public class TipoServicoCorreioConverter implements AttributeConverter<TipoServicoCorreio,String> {

    @Override
    public String convertToDatabaseColumn( final TipoServicoCorreio tipoServicoCorreio ) {

        return getValor(tipoServicoCorreio);
    }

    @Override
    public TipoServicoCorreio convertToEntityAttribute( final String valor ) {

        return getEnum( TipoServicoCorreio.class, valor );
    }
}
