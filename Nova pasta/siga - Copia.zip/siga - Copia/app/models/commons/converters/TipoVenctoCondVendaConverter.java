package models.commons.converters;


import models.commons.constantes.TipoVenctoCondVenda;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoVenctoCondVenda
 *
 * <p>Autor: GPortes</p>
 *
 * @since 11/01/2017
 *
 * @see TipoVenctoCondVenda
 */
@Converter
public class TipoVenctoCondVendaConverter implements AttributeConverter<TipoVenctoCondVenda,String> {

    @Override
    public String convertToDatabaseColumn( final TipoVenctoCondVenda tipoVenctoCondVenda ) {

        return tipoVenctoCondVenda != null ? tipoVenctoCondVenda.getValor() : null;
    }

    @Override
    public TipoVenctoCondVenda convertToEntityAttribute( final String valor ) {

        return getEnum( TipoVenctoCondVenda.class, valor );
    }
}
