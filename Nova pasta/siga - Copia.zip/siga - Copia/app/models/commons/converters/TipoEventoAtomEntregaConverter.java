package models.commons.converters;


import models.commons.constantes.TipoEventoAtomEntrega;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoEventoAtomEntrega
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 17/04/2017
 *
 * @see TipoEventoAtomEntrega
 */
@Converter
public class TipoEventoAtomEntregaConverter implements AttributeConverter<TipoEventoAtomEntrega,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final TipoEventoAtomEntrega tipoEventoAtomEntrega ) {

        return tipoEventoAtomEntrega != null ? tipoEventoAtomEntrega.getValor() : null;
    }

    @Override
    public TipoEventoAtomEntrega convertToEntityAttribute( final Integer valor ) {

        return getEnum( TipoEventoAtomEntrega.class, valor );
    }
}

