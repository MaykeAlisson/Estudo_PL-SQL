package models.commons.converters;

import models.commons.constantes.TipoCidade;
        import javax.persistence.AttributeConverter;
        import javax.persistence.Converter;
        import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoCidade
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 07/01/2016
 *
 * @see TipoCidade
 */
@Converter
public class TipoCidadeConverter implements AttributeConverter<TipoCidade,String> {

    @Override
    public String convertToDatabaseColumn( final TipoCidade tipoCidade ) {

        return tipoCidade != null ? tipoCidade.getValor() : null;
    }

    @Override
    public TipoCidade convertToEntityAttribute( final String valor ) {

        return getEnum( TipoCidade.class, valor );
    }
}

