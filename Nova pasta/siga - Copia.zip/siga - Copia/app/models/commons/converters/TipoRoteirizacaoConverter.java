package models.commons.converters;

import models.commons.constantes.TipoRoteirizacao;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;


/**
 * Classe converter para constante TipoRoteirizacao.
 *
 * <p>Autor: Jander Dutra</p>
 *
 * @since 29/05/2019.
 *
 * @see models.commons.constantes.TipoRoteirizacao
 */
@Converter
public class TipoRoteirizacaoConverter implements AttributeConverter<TipoRoteirizacao,String> {

    @Override
    public String convertToDatabaseColumn( final TipoRoteirizacao simNao ) {

        return simNao != null ? simNao.getValor() : null;
    }

    @Override
    public TipoRoteirizacao convertToEntityAttribute( final String valor ) {

        return getEnum(TipoRoteirizacao.class, valor);
    }
}
