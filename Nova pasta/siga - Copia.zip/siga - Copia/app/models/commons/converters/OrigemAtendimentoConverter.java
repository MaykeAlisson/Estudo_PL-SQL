package models.commons.converters;

import models.commons.constantes.OrigemAtendimento;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante OrigemAtendimento
 *
 * <p>Autor: GPortes</p>
 *
 * @since 01/03/2019
 *
 * @see models.commons.constantes.OrigemAtendimento
 */
@Converter
public class OrigemAtendimentoConverter implements AttributeConverter<OrigemAtendimento,String> {

    @Override
    public String convertToDatabaseColumn( final OrigemAtendimento origemAtendimento ) {

        return getValor( origemAtendimento );
    }

    @Override
    public OrigemAtendimento convertToEntityAttribute( final String valor ) {

        return getEnum( OrigemAtendimento.class, valor );
    }
}

