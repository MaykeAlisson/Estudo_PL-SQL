package models.commons.converters;

import models.commons.constantes.TipoAtualizacaoPreco;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoAtualizacaoPreco
 *
 * <p>Autor: GPortes</p>
 *
 * @since 24/01/2019
 *
 * @see models.commons.constantes.TipoAtualizacaoPreco
 */
@Converter
public class TipoAtualizacaoPrecoConverter implements AttributeConverter<TipoAtualizacaoPreco,String> {

    @Override
    public String convertToDatabaseColumn( final TipoAtualizacaoPreco tipoAtualizacaoPreco ) {

        return getValor( tipoAtualizacaoPreco );
    }

    @Override
    public TipoAtualizacaoPreco convertToEntityAttribute( final String valor ) {

        return getEnum( TipoAtualizacaoPreco.class, valor );
    }
}

