package models.commons.converters;

import models.commons.constantes.Sexo;
import models.commons.constantes.SexoCid;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante Sexo
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 16/06/2015
 *
 * @see Sexo
 */
@Converter
public class SexoCidConverter implements AttributeConverter<SexoCid,String> {

    @Override
    public String convertToDatabaseColumn( final SexoCid sexo ) {

        return getValor( sexo );
    }

    @Override
    public SexoCid convertToEntityAttribute( final String valor ) {

        return getEnum( SexoCid.class, valor );
    }
}
