package models.commons.converters;

import models.commons.constantes.SituacaoLimitadorAcrescimo;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante SituacaoLimitadorAcrescimo
 *
 * <p>Autor: GPortes</p>
 *
 * @since 22/02/2016
 *
 * @see SituacaoLimitadorAcrescimo
 */
@Converter
public class SituacaoLimitadorAcrescimoConverter implements AttributeConverter<SituacaoLimitadorAcrescimo,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final SituacaoLimitadorAcrescimo obj ) {

        return obj.getValor();
    }

    @Override
    public SituacaoLimitadorAcrescimo convertToEntityAttribute( final Integer valor ) {

        return getEnum( SituacaoLimitadorAcrescimo.class, valor );
    }
}

