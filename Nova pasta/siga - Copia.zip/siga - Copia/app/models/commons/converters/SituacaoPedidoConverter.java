package models.commons.converters;

import models.commons.constantes.SituacaoPedido;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante SituacaoPedido.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/09/2014.
 *
 * @see SituacaoPedido
 */
@Converter
public class SituacaoPedidoConverter implements AttributeConverter<SituacaoPedido,String> {

    @Override
    public String convertToDatabaseColumn( final SituacaoPedido situacaoPedido ) {

        return situacaoPedido != null ? situacaoPedido.getValor() : null;
    }

    @Override
    public SituacaoPedido convertToEntityAttribute( final String valor ) {

        return getEnum( SituacaoPedido.class, valor );
    }
}
