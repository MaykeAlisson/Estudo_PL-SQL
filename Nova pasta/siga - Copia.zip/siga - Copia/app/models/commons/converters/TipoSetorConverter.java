package models.commons.converters;

import models.commons.constantes.TipoSetor;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoSetor
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 16/06/2015
 *
 * @see TipoSetor
 */

@Converter
public class TipoSetorConverter implements AttributeConverter<TipoSetor,String> {

    @Override
    public String convertToDatabaseColumn( final TipoSetor tipoSetor ) {

        return tipoSetor != null ? tipoSetor.getValor() : null;
    }

    @Override
    public TipoSetor convertToEntityAttribute( final String valor ) {

        return getEnum( TipoSetor.class, valor );
    }
}
