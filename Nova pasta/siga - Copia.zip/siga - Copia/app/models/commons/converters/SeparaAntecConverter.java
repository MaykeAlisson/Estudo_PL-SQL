package models.commons.converters;

import models.commons.constantes.SeparaAntec;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante SeparaAntec
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 02/05/2018
 *
 * @see models.commons.constantes.SeparaAntec
 */
@Converter
public class SeparaAntecConverter implements AttributeConverter<SeparaAntec,String> {

    @Override
    public String convertToDatabaseColumn( final SeparaAntec separaAntec ) {

        return getValor( separaAntec );
    }

    @Override
    public SeparaAntec convertToEntityAttribute( final String valor ) {

        return getEnum( SeparaAntec.class, valor );
    }
}
