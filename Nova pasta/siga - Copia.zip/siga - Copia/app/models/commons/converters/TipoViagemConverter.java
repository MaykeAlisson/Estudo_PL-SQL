package models.commons.converters;

import models.commons.constantes.TipoViagem;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;
import static java.lang.Integer.valueOf;

/**
 * Classe converter para constante TipoViagem
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/12/2015
 *
 * @see TipoViagem
 */
@Converter
public class TipoViagemConverter implements AttributeConverter<TipoViagem,Integer> {

    @Override
    public Integer convertToDatabaseColumn( final TipoViagem tipoViagem ) {

        return tipoViagem != null ? valueOf( tipoViagem.getValor() ) : null;
    }

    @Override
    public TipoViagem convertToEntityAttribute( final Integer valor ) {

        return getEnum( TipoViagem.class, valor != null ? valor.shortValue() : null );
    }


}


