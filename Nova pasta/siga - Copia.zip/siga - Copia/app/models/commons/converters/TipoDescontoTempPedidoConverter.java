package models.commons.converters;

import models.commons.constantes.TipoDescontoTempPedido;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante TipoDescontoTempPedido
 *
 * <p>Autor: GPortes</p>
 *
 * @since 09/01/2019
 *
 * @see models.commons.constantes.TipoDescontoTempPedido
 */
@Converter
public class TipoDescontoTempPedidoConverter implements AttributeConverter<TipoDescontoTempPedido,String> {

    @Override
    public String convertToDatabaseColumn( final TipoDescontoTempPedido tipoDescontoTempPedido ) {

        return getValor( tipoDescontoTempPedido );
    }

    @Override
    public TipoDescontoTempPedido convertToEntityAttribute( final String valor ) {

        return getEnum( TipoDescontoTempPedido.class, valor );
    }
}


