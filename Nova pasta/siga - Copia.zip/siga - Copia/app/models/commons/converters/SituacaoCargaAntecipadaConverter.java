package models.commons.converters;

import models.commons.constantes.SituacaoCargaAntecipada;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante SituacaoPedido.
 *
 * <p>Autor: Cleber</p>
 *
 * @since 05/09/2014.
 *
 * @see SituacaoCargaAntecipada
 */
@Converter
public class SituacaoCargaAntecipadaConverter implements AttributeConverter<SituacaoCargaAntecipada,String> {

        @Override
        public String convertToDatabaseColumn( final SituacaoCargaAntecipada situacaoCargaAntecipada ) {

            return situacaoCargaAntecipada != null ? situacaoCargaAntecipada.getValor() : null;
        }

        @Override
        public SituacaoCargaAntecipada convertToEntityAttribute( String valor ) {

            return getEnum(SituacaoCargaAntecipada.class, valor);
        }
}
