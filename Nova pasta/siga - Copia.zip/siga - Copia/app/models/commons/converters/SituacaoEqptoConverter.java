package models.commons.converters;

import models.commons.constantes.SituacaoEqpto;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;

/**
 * Classe converter para constante SolucaoEqpto
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/10/2017
 *
 * @see models.commons.constantes.SituacaoEqpto
 */
@Converter
public class SituacaoEqptoConverter implements AttributeConverter<SituacaoEqpto,String> {

    @Override
    public String convertToDatabaseColumn( final SituacaoEqpto situacaoEqpto ) {

        return getValor( situacaoEqpto );
    }

    @Override
    public SituacaoEqpto convertToEntityAttribute( final String valor ) {

        return getEnum( SituacaoEqpto.class, valor );
    }
}