package controllers.eSocial;

import controllers.AuthController;
import infra.exceptions.BusinessException;
import infra.util.UtilDate;
import models.commons.constantes.ESocialConstantes;
import models.commons.constantes.ReinfConstantes;
import models.commons.dtos.EmpregadoresESocialDto;
import models.commons.dtos.EventosDto;
import models.commons.dtos.ProcessoStatusDto;
import models.domains.admin.Parametro;
import models.eSocial.RetornoDadosLote;
import models.repository.admin.ParametroRepository;
import models.repository.admin.SistemaRepository;
import models.repository.fisco.PeriodoApuracaoRepository;
import models.repository.fisco.ProcessoRepository;
import models.repository.rh.UsuarioAcessoRepository;
import play.db.jpa.Transactional;
import play.mvc.Result;
import services.admin.SchedulerService;
import services.eSocial.ConsultaLoteService;
import services.eSocial.ESocialService;
import services.eSocial.EnviaLoteService;
import services.eSocial.EsocialEmailService;
import services.eSocial.S1000Service;
import services.eSocial.S1005Service;
import services.eSocial.S1010Service;
import services.eSocial.S1020Service;
import services.eSocial.S1030Service;
import services.eSocial.S1050Service;
import services.eSocial.S1060Service;
import services.eSocial.S1200Service;
import services.eSocial.S1250Service;
import services.eSocial.S2200Service;
import services.eSocial.S2210Service;
import services.eSocial.S2220Service;
import services.eSocial.S2221Service;
import services.eSocial.S2230Service;
import services.eSocial.S2250Service;
import services.eSocial.S2299Service;
import services.eSocial.S2300Service;
import services.eSocial.S2399Service;
import services.eSocial.impl.ESocialUtil;
import services.reinf.eventos.EnviaConsultaLoteService;
import services.reinf.eventos.R1000Service;
import services.reinf.eventos.R2010Service;
import services.reinf.eventos.R2020Service;
import services.reinf.eventos.R2098Service;
import services.reinf.eventos.R2099Service;

import javax.inject.Inject;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static infra.util.UtilException.getExceptionComoString;
import static infra.util.UtilSistema.logaSeDesenvolvimento;
import static models.commons.constantes.ESocialConstantes.ARCOM_DILENE_ID;
import static models.commons.constantes.ESocialConstantes.ARCOM_ID;
import static models.commons.constantes.ESocialConstantes.INICIO_NAO_PERIODICOS;
import static models.commons.constantes.ESocialConstantes.INICIO_NAO_PERIODICOS_DEMAIS_EMP;
import static models.commons.constantes.ESocialConstantes.USUARIO_ESOCIAL;
import static models.domains.pbatch.PlbEscalonamento.ESOCIAL_CONSULTAR_RETORNO_EVENTOS;
import static models.domains.pbatch.PlbEscalonamento.ESOCIAL_EVENTOS_NAO_PERIODICOS;

public class ApiESocialController extends AuthController {

    private static final String PROCESSADO_SUCESSO = "OK";

    // Service eSocial:
    private final S1000Service s1000Service;
    private final S1005Service s1005Service;
    private final S1010Service s1010Service;
    private final S1020Service s1020Service;
    private final S1030Service s1030Service;
    private final S1050Service s1050Service;
    private final S1060Service s1060Service;
    private final S1200Service s1200Service;
    private final S1250Service s1250Service;
    private final S2200Service s2200Service;
    private final S2210Service s2210Service;
    private final S2221Service s2221Service;
    private final S2299Service s2299Service;
    private final S2300Service s2300Service;
    private final S2399Service s2399Service;
    private final S2230Service s2230Service;
    private final S2250Service s2250Service;
    private final EnviaLoteService enviaLoteService;
    private final SchedulerService schedulerService;
    private final ConsultaLoteService consultaLoteService;
    private final EsocialEmailService esocialEmailService;
    private final ESocialService eSocialService;

    //Service EFD-Reinf
    private final R1000Service r1000Service;
    private final R2010Service r2010Service;
    private final R2020Service r2020Service;
    private final R2098Service r2098Service;
    private final R2099Service r2099Service;
    private final EnviaConsultaLoteService enviaConsultaLoteService;

    // Repository
    private final SistemaRepository sistemaRepository;
    private final ProcessoRepository processoRepository;
    private final ParametroRepository parametroRepository;
    private final PeriodoApuracaoRepository periodoApuracaoRepository;
    private final UsuarioAcessoRepository usuarioAcessoRepository;

    @Inject
    public ApiESocialController(
            final S1000Service s1000Service,
            final S1005Service s1005Service,
            final S1010Service s1010Service,
            final S1020Service s1020Service,
            final S1030Service s1030Service,
            final S1050Service s1050Service,
            final S1060Service s1060Service,
            final S1200Service s1200Service,
            final S1250Service s1250Service,
            final S2200Service s2200Service,
            final S2220Service s2220Service,
            final S2210Service s2210Service,
            final S2221Service s2221Service,
            final S2299Service s2299Service,
            final S2300Service s2300Service,
            final S2399Service s2399Service,
            final S2230Service s2230Service,
            final S2250Service s2250Service,
            final EnviaLoteService enviaLoteService,
            final SchedulerService schedulerService,
            final ConsultaLoteService consultaLoteService,
            final EsocialEmailService esocialEmailService,
            final ESocialService eSocialService,
            final R1000Service r1000Service,
            final R2010Service r2010Service,
            final R2020Service r2020Service,
            final R2098Service r2098Service,
            final R2099Service r2099Service,
            final EnviaConsultaLoteService enviaConsultaLoteService,
            final SistemaRepository sistemaRepository,
            final ProcessoRepository processoRepository,
            final ParametroRepository parametroRepository,
            final PeriodoApuracaoRepository periodoApuracaoRepository,
            final UsuarioAcessoRepository usuarioAcessoRepository
    ) {

        this.s1000Service = s1000Service;
        this.s1005Service = s1005Service;
        this.s1010Service = s1010Service;
        this.s1020Service = s1020Service;
        this.s1030Service = s1030Service;
        this.s1050Service = s1050Service;
        this.s1060Service = s1060Service;
        this.s1200Service = s1200Service;
        this.s1250Service = s1250Service;
        this.s2200Service = s2200Service;
        this.s2210Service = s2210Service;
        this.s2221Service = s2221Service;
        this.r2020Service = r2020Service;
        this.s2299Service = s2299Service;
        this.s2300Service = s2300Service;
        this.s2399Service = s2399Service;
        this.s2230Service = s2230Service;
        this.s2250Service = s2250Service;
        this.enviaLoteService = enviaLoteService;
        this.schedulerService = schedulerService;
        this.consultaLoteService = consultaLoteService;
        this.esocialEmailService = esocialEmailService;
        this.eSocialService = eSocialService;
        this.r1000Service = r1000Service;
        this.r2010Service = r2010Service;
        this.r2098Service = r2098Service;
        this.r2099Service = r2099Service;
        this.enviaConsultaLoteService = enviaConsultaLoteService;
        this.sistemaRepository = sistemaRepository;
        this.processoRepository = processoRepository;
        this.parametroRepository = parametroRepository;
        this.periodoApuracaoRepository = periodoApuracaoRepository;
        this.usuarioAcessoRepository = usuarioAcessoRepository;
    }

    /**
     * Expõe serviço para geração de lotes de envio
     *
     * <p>
     * Autor: Fernando Vicente
     * </p>
     *
     *
     * @return OK se processo ocorreu sem problemas.
     */
    @Transactional
    public Result gerarEventoSchedule(String tpEvento) {

        try {
            List<RetornoDadosLote> retornoDadosLoteList = new ArrayList<>();

            List<EmpregadoresESocialDto> empregadoresList = processoRepository.buscarEmpregadoresESocial();

            StringBuilder sb = new StringBuilder();

            if (tpEvento.equals(ESocialConstantes.TipoEvento.INICIAl.getId()) || tpEvento.equals(ESocialConstantes.TipoEvento.NAO_PERIODICO.getId()) || tpEvento.equals(ESocialConstantes.TipoEvento.PERIODICO.getId()) ){

                boolean agendarNaoPeridico = false;
                boolean agendarRetornoEventos = false;

                // Busca Lista de empresas que devem ser executadas pelo eSocial
                for (EmpregadoresESocialDto empregador : empregadoresList){

                    Optional<String> parametro = parametroRepository.buscarCaminho(empregador.getEmpresa(), Parametro.IdParametro.EMPRESAS_GERADORAS_DE_ESOCIAL_EFD_REINF);

                    // Criação de datas constantes, necessárias para o processamento do evento.
                    SimpleDateFormat sdf = new SimpleDateFormat(ESocialConstantes.DD_MM_YYYY);
                    LocalDateTime eSocialInicio;
                    if (empregador.getEmpresa().toString().equals(ARCOM_ID) || empregador.getEmpresa().toString().equals(ARCOM_DILENE_ID)){
                        eSocialInicio = UtilDate.toLocalDateTime(sdf.parse(INICIO_NAO_PERIODICOS));
                    } else {
                        eSocialInicio = UtilDate.toLocalDateTime(sdf.parse(INICIO_NAO_PERIODICOS_DEMAIS_EMP));
                    }

                    // Verifica se é necessária a execução do evento para essa empresa no respectivo ambiente
                    if (parametro.isPresent()) {
                        if ( ESocialUtil.ambProducao()) {
                            if (!parametro.get().equals(ESocialConstantes.PRODUCAO)) {
                                continue;
                            }
                        } else {
                            if (!parametro.get().equals(ESocialConstantes.DESENVOLVIMENTO)) {
                                continue;
                            }
                        }
                    }

                    if (tpEvento.equals(ESocialConstantes.TipoEvento.INICIAl.getId())){

                        sb.append(s1000Service.evtInformacoesEmpregador(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S1000)));
                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.INICIAl.getId()));

                        sb.append(s1005Service.tabEstabelecimentosObrasUop(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S1005)));
                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.INICIAl.getId()));

                        sb.append(s1010Service.tabRubricas(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S1010)));
                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.INICIAl.getId()));

                        sb.append(s1020Service.tabLotacaoTributaria(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S1020)));
                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.INICIAl.getId()));

                        sb.append(s1030Service.tabCargos(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S1030)));
                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.INICIAl.getId()));

                        sb.append(s1050Service.tabHorariosTurnos(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S1050)));
                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.INICIAl.getId()));

                        //TODO  Silas Andrade - Liberar S1060 dia 01/06/2019. Info Ambientes.
//                        sb.append(s1060Service.tabAmbientesTrabalho(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA,empregador,ESocialConstantes.S1060)));
//                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.INICIAl.getId()));

                        agendarNaoPeridico = true;


                    } else if (tpEvento.equals(ESocialConstantes.TipoEvento.NAO_PERIODICO.getId())) {

                        // Ajuste de faseamento para novas empresas integrantes do eSocial

                        if (UtilDate.ehMaior(sistemaRepository.getDataHojeHora(), eSocialInicio)){

                            sb.append(s2200Service.admissaoIngressoTrabalhador(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S2200)));
                            retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.NAO_PERIODICO.getId()));

                            sb.append(s2300Service.trabalhadorSemVinculoInicio(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S2300)));
                            retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.NAO_PERIODICO.getId()));

                            sb.append(s2250Service.avisoPrevio(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S2250)));
                            retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.NAO_PERIODICO.getId()));

                            //Todo Silas Andrade - Liberar S2110 dia 01/06/2019. CAT.
//                            sb.append(s2210Service.comunicacaoAcidenteTrabalho(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA,empregador,ESocialConstantes.S2210)));
//                            retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.NAO_PERIODICO.getId()));

                            //Todo Silas Andrade - Liberar S2110 dia 01/06/2019. Exame Toxicologico Motorista.
//                            sb.append(s2221Service.exameToxicologicoMotoristaProfissional(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA,empregador,ESocialConstantes.S2221)));
//                            retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.NAO_PERIODICO.getId()));

                            sb.append(s2399Service.trabalhadorSemVinculoTermino(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S2399), 0l,null));
                            retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.NAO_PERIODICO.getId()));

                            //Todo Silas - Em teste Aquisição produtor rural(S1250) em auto com tipo de evento periodico
                            sb.append(s1250Service.aquisicaoProducaoRural(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S1250)));
                            retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.PERIODICO.getId()));
                        }

                        agendarRetornoEventos = true;



                    } else if (tpEvento.equals(ESocialConstantes.TipoEvento.PERIODICO.getId())){

//                        s1200Service.criarRemuneracaoTrabalhadorVinculadoRGPS(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S1200));
//                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.PERIODICO.getId()));
//                        Logger.info("1200 processado para empresa: " + empregador.getEmpresa() + "\n");

//                        s1250Service.aquisicaoProducaoRural(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S1250));
//                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.PERIODICO.getId()));

//                        agendarRetornoEventos = true;
//
//                        final String origem = this.getClass().getName();
//                        schedulerService.agendar( ESOCIAL_CONSULTAR_RETORNO_EVENTOS, ESocialConstantes.MINUTOS_CONSULTAR, origem );
                    }

                }

                final String origem = this.getClass().getName();

                if ( agendarRetornoEventos )
                    schedulerService.agendar( ESOCIAL_CONSULTAR_RETORNO_EVENTOS, ESocialConstantes.MINUTOS_CONSULTAR, origem );

                if ( agendarNaoPeridico )
                    schedulerService.agendar( ESOCIAL_EVENTOS_NAO_PERIODICOS, ESocialConstantes.MINUTOS_ENTRE_EXECUCOES, origem );
            }

            if (sb.toString().equals("")){
                return ok(PROCESSADO_SUCESSO);
            } else {
                return badRequest(sb.toString());
            }

        } catch (Throwable e) {
            return badRequest(getExceptionComoString(e));
        }

    }

//     * Expõe serviço para geração de lotes de envio
//     *
//     * <p>
//     * Autor: Fernando Vicente
//     * </p>
//     *
//     *
//     * @return OK se processo ocorreu sem problemas.

    @Transactional
    public Result gerarEventoReinfSchedule() {

        try {

            List<EmpregadoresESocialDto> empregadoresList = processoRepository.buscarEmpregadoresESocial();
            final String origem = this.getClass().getName();

            for (EmpregadoresESocialDto empregador : empregadoresList){

                Optional<String> parametro = parametroRepository.buscarCaminho(empregador.getEmpresa(), Parametro.IdParametro.EMPRESAS_GERADORAS_DE_ESOCIAL_EFD_REINF);

//                if(!empregador.getEmpresa().equals( new Short ("1")) /*&& !empregador.getEmpresa().equals( new Short ("93"))*/){
//                    continue;
//                }
                 //Verifica se é necessária a execução do evento para essa empresa no respectivo ambiente
                 if (parametro.isPresent()) {
                    if ( ESocialUtil.ambProducao()) {
                        if (!parametro.get().equals(ESocialConstantes.PRODUCAO)) {
                            continue;
                        }
                    } else {
                        if (!parametro.get().equals(ESocialConstantes.DESENVOLVIMENTO)) {
                            continue;
                        }
                    }
                 }
//                if (!empregador.getEmpresa().equals( new Short ("1")) && !empregador.getEmpresa().equals( new Short ("93"))) {
//                    r1000Service.informacoesContribuinte(processoRepository.novoProcesso(ReinfConstantes.ID_SISTEMA.longValue(), empregador, ReinfConstantes.R1000));
//                    enviaConsultaLoteService.buscaEventosEnvio(ESocialConstantes.TipoEvento.EDF_REINF.getId());
//                    logaSeDesenvolvimento( origem , "R1000 processado para empresa: " + empregador.getEmpresa());
//                }

                r2010Service.retContribPrevServicosTomados(processoRepository.novoProcesso(ReinfConstantes.ID_SISTEMA.longValue(), empregador, ReinfConstantes.R2010));
                enviaConsultaLoteService.buscaEventosEnvio(ESocialConstantes.TipoEvento.EDF_REINF.getId());
                logaSeDesenvolvimento( origem , "R2010 processado para empresa: " + empregador.getEmpresa());
//
                if (empregador.getEmpresa().equals( new Short ("78"))) {
                    r2020Service.retContribPrevServicosPrestados(processoRepository.novoProcesso(ReinfConstantes.ID_SISTEMA.longValue(), empregador, ReinfConstantes.R2020));
                    enviaConsultaLoteService.buscaEventosEnvio(ESocialConstantes.TipoEvento.EDF_REINF.getId());
                    logaSeDesenvolvimento( origem , "R2020 processado para empresa: " + empregador.getEmpresa());
                }

                periodoApuracaoRepository.fecharPeriodosAbertos(ReinfConstantes.ID_SISTEMA, empregador.getEmpresa());
                enviaConsultaLoteService.buscaEventosEnvio(ESocialConstantes.TipoEvento.EDF_REINF.getId());
                logaSeDesenvolvimento( origem , "R2099 processado para empresa: " + empregador.getEmpresa());

            }

            return ok(PROCESSADO_SUCESSO);

        } catch (Throwable e) {
            return badRequest(getExceptionComoString(e));
        }

    }

    /**
     * Expõe serviço consulta de lotes pendentes para consulta agendada.
     *
     * <p>
     * Autor: Fernando Vicente
     * </p>
     *
     *
     * @return OK se processo ocorreu sem problemas.
     */
    @Transactional
    public Result consultaLotesPendentes() {

        try {
            consultaLoteService.buscaLotesPendentes();

            // Realiza envio de email após o processo
            List<EmpregadoresESocialDto> empregadoresList = processoRepository.buscarEmpregadoresESocial();
            List<EventosDto> eventosDtoList = usuarioAcessoRepository.buscaEventos(USUARIO_ESOCIAL);
            List<ProcessoStatusDto> processoStatusList = processoRepository.buscaStatusProcessamentoErro();
            for (EmpregadoresESocialDto empregador : empregadoresList){
                esocialEmailService.enviarRelatorio(eventosDtoList,empregador.getEmpresa());
            }

            // Caso haja algum processo há mais de 1 hora sem envio/processamento
            if (!processoStatusList.isEmpty()) {
                if (processoStatusList.get(0).getStatusProcessamento().equals(ESocialConstantes.StatusProcessamento.AGUARDANDO_ENVIO.getId())){
                    return badRequest("Existem eventos do eSocial com erro e/ou atraso no envio!");
                } else {
                    return badRequest("Existem eventos do eSocial sem retorno há mais de 1 hora!");
                }
            }
            return ok(PROCESSADO_SUCESSO);
        } catch (Throwable e) {
            return badRequest(getExceptionComoString(e));
        }
    }

    /**
     * Realiza agendamento dos serviços
     *
     * @param idAgendamento
     * @param minutos
     * @param dispacher
     * @throws BusinessException
     */
    /*private void agendar( final long idAgendamento,
                          final int minutos,
                          final String dispacher ) throws BusinessException {

        final Date dataAgendamento = adicionarNMinutos(minutos, sistemaRepository.getHoje());

        Optional<Long> possivel = schedulerService.agendar(
                new ScheduleDto
                        .Builder(idAgendamento)
                        .comDataAgendamento(dataAgendamento)
                        .comDispatcher(dispacher)
                        .build()
        );

        if ( possivel.isPresent() )
            Logger.info( "Agendou processo: {} => {}", idAgendamento, dataAgendamento);
        else
            throw new BusinessException( format("Nao consegui agendar Id: %s", idAgendamento));
    }*/

    /**
     * Expõe serviço de envio de e-mail do eSocial
     *
     * <p>
     * Autor: Tiago Silveira
     * </p>
     *
     *
     * @return OK se processo ocorreu sem problemas.
     */
    @Transactional
    public Result emailEsocial() throws BusinessException {

        try {
            // Realiza envio de email após o processo
            List<EmpregadoresESocialDto> empregadoresList = processoRepository.buscarEmpregadoresESocial();
            List<EventosDto> eventosDtoList = usuarioAcessoRepository.buscaEventos(USUARIO_ESOCIAL);
            for (EmpregadoresESocialDto empregador : empregadoresList){
                esocialEmailService.enviarRelatorio(eventosDtoList,empregador.getEmpresa());
            }
            return ok(PROCESSADO_SUCESSO);
        } catch ( Throwable e ) {
            return badRequest(getExceptionComoString(e));
        }
    }

}
