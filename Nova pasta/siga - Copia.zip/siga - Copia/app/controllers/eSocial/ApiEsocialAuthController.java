package controllers.eSocial;

import controllers.AuthController;
import infra.binders.ShortBinder;
import infra.exceptions.BusinessException;
import infra.powerbatch.PBatchParam;
import infra.util.UtilDate;
import models.commons.constantes.ESocialConstantes;
import models.commons.dtos.EmpregadoresESocialDto;
import models.commons.dtos.ProcessoStatusDto;
import models.domains.admin.Parametro;
import models.domains.fisco.ESocialEvtXml;
import models.domains.fisco.ESocialPeriodoApuracao;
import models.domains.fisco.EvtControle;
import models.eSocial.InfoExclusao;
import models.eSocial.RetornoDadosLote;
import models.repository.admin.ParametroRepository;
import models.repository.admin.SistemaRepository;
import models.repository.fisco.EvtCatalogoRepository;
import models.repository.fisco.EvtControleAlteracaoRepository;
import models.repository.fisco.EvtControleRepository;
import models.repository.fisco.EvtOcorrenciaRepository;
import models.repository.fisco.EvtXmlRepository;
import models.repository.fisco.LoteEnvioRepository;
import models.repository.fisco.PeriodoApuracaoRepository;
import models.repository.fisco.ProcessoRepository;
import models.repository.rh.UsuarioAcessoRepository;
import models.repository.seguranca.PerfilRegraAcessoRepository;
import play.db.jpa.Transactional;
import play.mvc.Result;
import services.admin.SchedulerService;
import services.eSocial.ConsultaLoteService;
import services.eSocial.DadosFechamentoPeriodicosService;
import services.eSocial.ESocialService;
import services.eSocial.EnviaLoteService;
import services.eSocial.S1000Service;
import services.eSocial.S1005Service;
import services.eSocial.S1010Service;
import services.eSocial.S1020Service;
import services.eSocial.S1030Service;
import services.eSocial.S1050Service;
import services.eSocial.S1060Service;
import services.eSocial.S1200Service;
import services.eSocial.S1210Service;
import services.eSocial.S1298Service;
import services.eSocial.S1299Service;
import services.eSocial.S2200Service;
import services.eSocial.S2230Service;
import services.eSocial.S2250Service;
import services.eSocial.S2299Service;
import services.eSocial.S2300Service;
import services.eSocial.S2399Service;
import services.eSocial.S3000Service;
import services.eSocial.impl.ESocialUtil;
import services.eSocial.impl.S1060Impl;

import javax.inject.Inject;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static infra.binders.ShortBinder.getValue;
import static infra.util.UtilDate.toDate;
import static infra.util.UtilException.getException;
import static infra.util.UtilException.getExceptionComoString;
import static infra.util.UtilSistema.logaSeDesenvolvimento;
import static models.commons.constantes.ESocialConstantes.ARCOM_DILENE_ID;
import static models.commons.constantes.ESocialConstantes.ARCOM_ID;
import static models.commons.constantes.ESocialConstantes.INICIO_NAO_PERIODICOS;
import static models.commons.constantes.ESocialConstantes.INICIO_NAO_PERIODICOS_DEMAIS_EMP;
import static models.commons.constantes.ESocialConstantes.PROC_ESOCIAL;
import static models.commons.constantes.ESocialConstantes.SEQUENCIA_ESOCIAL;
import static play.libs.Json.toJson;
import static services.eSocial.impl.ESocialUtil.getStringFromBlob;

public class ApiEsocialAuthController extends AuthController {

    // Service:
    private final EnviaLoteService enviaLoteService;
    private final ConsultaLoteService consultaLoteService;
    private final S1000Service s1000Service;
    private final S1005Service s1005Service;
    private final S1010Service s1010Service;
    private final S1020Service s1020Service;
    private final S1030Service s1030Service;
    private final S1050Service s1050Service;
    private final S1060Service s1060Service;
    private final S1200Service s1200Service;
    private final S1210Service s1210Service;
    private final S1298Service s1298Service;
    private final S1299Service s1299Service;
    private final S2200Service s2200Service;
    private final S2250Service s2250Service;
    private final S2299Service s2299Service;
    private final S2230Service s2230Service;
    private final S2300Service s2300Service;
    private final S2399Service s2399Service;
    private final S3000Service s3000Service;
    private final DadosFechamentoPeriodicosService dadosFechamentoPeriodicosService;
    private final SchedulerService schedulerService;
    private final ESocialService eSocialService;

    // Repository:
    private final EvtOcorrenciaRepository ocorrenciaRepository;
    private final EvtCatalogoRepository evtCatalogoRepository;
    private final EvtXmlRepository xmlRepository;
    private final EvtControleRepository evtControleRepository;
    private final ProcessoRepository processoRepository;
    private final SistemaRepository sistemaRepository;
    private final ParametroRepository parametroRepository;
    private final PerfilRegraAcessoRepository perfilRegraAcessoRepository;
    private final UsuarioAcessoRepository usuarioAcessoRepository;
    private final PeriodoApuracaoRepository periodoApuracaoRepository;
    private final EvtControleAlteracaoRepository evtControleAlteracaoRepository;
    private final LoteEnvioRepository loteEnvioRepository;



    @Inject
    public ApiEsocialAuthController(
            final DadosFechamentoPeriodicosService dadosFechamentoPeriodicosService,
            ESocialService eSocialService, final EvtOcorrenciaRepository ocorrenciaRepository,
            final EvtCatalogoRepository evtCatalogoRepository,
            final EvtXmlRepository xmlRepository,
            final EvtControleRepository evtControleRepository,
            final ProcessoRepository processoRepository,
            final ConsultaLoteService consultaLoteService,
            final SistemaRepository sistemaRepository,
            final ParametroRepository parametroRepository,
            final S2230Service s2230Service,
            final EnviaLoteService enviaLoteService,
            final PerfilRegraAcessoRepository perfilRegraAcessoRepository,
            final S1000Service s1000Service,
            final S1005Service s1005Service,
            final S1010Service s1010Service,
            final S1020Service s1020Service,
            final S1030Service s1030Service,
            final S1050Service s1050Service,
            final S1060Service s1060Service,
            final S1200Service s1200Service,
            final S1210Service s1210Service,
            final S1298Service s1298Service,
            final S1299Service s1299Service,
            final S2200Service s2200Service,
            final S2250Service s2250Service,
            final S2299Service s2299Service,
            final S2300Service s2300Service,
            final S2399Service s2399Service,
            final S3000Service s3000Service,
            final SchedulerService schedulerService,
            final UsuarioAcessoRepository usuarioAcessoRepository,
            final PeriodoApuracaoRepository periodoApuracaoRepository,
            final EvtControleAlteracaoRepository evtControleAlteracaoRepository,
            final LoteEnvioRepository loteEnvioRepository) {
        this.dadosFechamentoPeriodicosService = dadosFechamentoPeriodicosService;
        this.eSocialService = eSocialService;
        this.ocorrenciaRepository = ocorrenciaRepository;
        this.evtCatalogoRepository = evtCatalogoRepository;
        this.xmlRepository = xmlRepository;
        this.evtControleRepository = evtControleRepository;
        this.processoRepository = processoRepository;
        this.consultaLoteService = consultaLoteService;
        this.sistemaRepository = sistemaRepository;
        this.parametroRepository = parametroRepository;
        this.s2230Service = s2230Service;
        this.enviaLoteService = enviaLoteService;
        this.perfilRegraAcessoRepository = perfilRegraAcessoRepository;
        this.s1000Service = s1000Service;
        this.s1005Service = s1005Service;
        this.s1010Service = s1010Service;
        this.s1020Service = s1020Service;
        this.s1030Service = s1030Service;
        this.s1050Service = s1050Service;
        this.s1060Service = s1060Service;
        this.s1200Service = s1200Service;
        this.s1210Service = s1210Service;
        this.s1298Service = s1298Service;
        this.s1299Service = s1299Service;
        this.s2200Service = s2200Service;
        this.s2250Service = s2250Service;
        this.s2299Service = s2299Service;
        this.s2300Service = s2300Service;
        this.s2399Service = s2399Service;
        this.s3000Service = s3000Service;
        this.schedulerService = schedulerService;
        this.usuarioAcessoRepository = usuarioAcessoRepository;
        this.periodoApuracaoRepository = periodoApuracaoRepository;
        this.evtControleAlteracaoRepository = evtControleAlteracaoRepository;
        this.loteEnvioRepository = loteEnvioRepository;

    }

    @Transactional( readOnly = true )
    public Result buscarEventos() {

        try {
            return ok( toJson( usuarioAcessoRepository.buscaEventos( getRequest().getIdUsuario())));
        } catch ( Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }

    @Transactional( readOnly = true )
    public Result visualizaEventos(
            final String evento,
            final ShortBinder empresa
    ) {

        try {
            return ok( toJson( evtControleRepository.buscarDetalhamentoEventos( evento , getValue(empresa) )));
        } catch ( Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }

    @Transactional( readOnly = true )
    public Result visualizaOcorrencias(
        final String evento,
        final Long empresa
    ) {

        try {
            return ok( toJson( ocorrenciaRepository.buscarOcorrenciasPorEvento( empresa.toString(), evtCatalogoRepository.buscaCatalogoPorEvento(evento).getId().toString() )));
        } catch ( Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }

    @Transactional( readOnly = true )
    public Result visualizaXml( final String idEvento) {

        try {
            EvtControle evtControle = evtControleRepository.buscaEventoPorIdEvento(idEvento);
            Optional<ESocialEvtXml> eSocialEvtXmlDto = xmlRepository.findById(evtControle.getIdXml());

            StringBuilder xmls = new StringBuilder();
            xmls.append(getStringFromBlob(eSocialEvtXmlDto.get().getArquivoXml()));
            if (evtControle.getIdEventoPai()!= null) {
                Optional<EvtControle> evtControlePai = evtControleRepository.findById(evtControle.getIdEventoPai());
                if (evtControlePai.isPresent()) {
                    eSocialEvtXmlDto = xmlRepository.findById(evtControlePai.get().getIdXml());
                    xmls.append("xml2");
                    xmls.append(getStringFromBlob(eSocialEvtXmlDto.get().getArquivoXml()));
                }
            }
            return ok( toJson(xmls.toString()));
        } catch ( Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }

    @Transactional( readOnly = true )
    public Result visualizaExecucoes( ) {

        try {
            List<ProcessoStatusDto> processoStatusList = processoRepository.buscaStatusProcessamento();
            return ok( toJson(processoStatusList));
        } catch ( Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }

    @Transactional
    public Result consultaLotesPendentes() {
        try {
            String retorno = consultaLoteService.buscaLotesPendentesPost();
            return ok(toJson(retorno));
        } catch ( Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }

    @Transactional
    public Result verificarPermissao() {
        try {
            String retorno = perfilRegraAcessoRepository.isPermiteAcesso(SEQUENCIA_ESOCIAL,PROC_ESOCIAL,getRequest().getIdPerfil());
            return ok(toJson(retorno));
        } catch ( Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }

    @Transactional
    public Result buscarStatusEventosPeriodicos(Long idEventoCatalogo , Long empresa , String mes , String ano) {
        try {
            List<String> list = evtControleRepository.buscarStatusEventosPeriodicos(idEventoCatalogo,empresa,mes + '-' + ano + "-01");
            return ok(toJson(list.isEmpty() ? "Envio Pendente" : list.get(0)));
        } catch ( Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }

    @Transactional
    public Result buscarStatusPeriodoApuracao( Long empresa , String mes , String ano, ShortBinder indApuracao) {
        try {
            List<ESocialPeriodoApuracao> perApurList = periodoApuracaoRepository.buscarPeriodoApuracao(ESocialConstantes.ID_SISTEMA.shortValue(),empresa.shortValue(),mes + '-' + ano + "-01",indApuracao.getValue());
            return ok(toJson(perApurList.isEmpty() ? "Envio Pendente" : perApurList.get(0).getStatusPeriodoApuracao()));
        } catch ( Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }

    @Transactional
    public Result download( Long tipo , Long empresa ,  String mes , String ano) {

        try {
            StringBuilder sb = dadosFechamentoPeriodicosService.buscarDadosFechamentoPeriodicos( tipo.shortValue(), empresa.shortValue(),Long.valueOf(ano), Short.valueOf(mes));
            return ok(toJson(sb));
        } catch (BusinessException e) {
            return badRequest(getExceptionComoString(e));
        }
    }

    @Transactional
    public Result agendarEvento( ) {

         return ok();
//        try {
//
//            final String tipoEvento = getString("tipoEvento");
//
//            requireNonEmpty(tipoEvento,"Favor informar o evento" );
//
//            final String origem = this.getClass().getName();
//            schedulerService.agendar(
//                    new ScheduleDto.Builder( ESOCIAL_GERAR_EVENTO )
//                            .comDataAgendamento( adicionarNMinutos(1, toLocalDateTime(sistemaRepository.getHoje()) ) )
//                            .comDispatcher( origem )
//                            .comArgumento( new PBatchParam.Builder().comString(1,tipoEvento).build() )
//                            .build()
//            );
//            return ok();
//        } catch ( Throwable e ) {
//            return badRequest(getExceptionComoString(e));
//        }
    }

    /**
     * Serviço responsavel por criar nova data de alteracao para evento.
     *
     * <p>
     * Autor: Fernando Vicente
     * </p>
     *
     *
     * @return OK se processo ocorreu sem problemas.
     */
    @Transactional
    public Result gerarDataAlteracao(String ano, String mes, String dia, String idEvento) {
        try{

            String retorno = "Sucesso";
            LocalDate localDate = LocalDate.of( Integer.parseInt(ano) , Integer.parseInt(mes), Integer.parseInt(dia) );
            evtControleAlteracaoRepository.novaAlteracao( Long.parseLong(idEvento), toDate(localDate),null);

            return ok(retorno);
        } catch (Throwable e) {
            return badRequest(getExceptionComoString(e));
        }
    }

    @Transactional
    public Result geraEventosPorTipo( ) {

        try {
            final PBatchParam pBatchParam = getPowerBatchParam()
                    .orElseThrow(() -> new BusinessException("Faltou definir o tipo de evento para processar"));
            geraEventos(pBatchParam.getString(1));
            return ok();
        } catch ( Throwable e ) {
            return badRequestRollback(e);
        }
    }

    @Transactional
    public Result geraEventos(String tpEvento) {

        try {
            List<RetornoDadosLote> retornoDadosLoteList = new ArrayList<>();
            Date inicio = sistemaRepository.getHoje();
            final String origem = this.getClass().getName();
            List<EmpregadoresESocialDto> empregadoresList = processoRepository.buscarEmpregadoresESocial();

            //tpEvento = "D1210E1" + "ID1257692660000002018080617113303183";
            if (tpEvento.equals(ESocialConstantes.TipoEvento.INICIAl.getId()) || tpEvento.equals(ESocialConstantes.TipoEvento.NAO_PERIODICO.getId()) || tpEvento.equals(ESocialConstantes.TipoEvento.PERIODICO.getId()) ){

                // Busca Lista de empresas que devem ser executadas pelo eSocial
                for (EmpregadoresESocialDto empregador : empregadoresList){

                    //if (empregador.getEmpresa() == 78) { continue; }
                    //if (empregador.getEmpresa() != 1) { continue; }
                    Optional<String> parametro = parametroRepository.buscarCaminho(empregador.getEmpresa(), Parametro.IdParametro.EMPRESAS_GERADORAS_DE_ESOCIAL_EFD_REINF);

                    // Criação de datas constantes, necessárias para o processamento do evento.
                    SimpleDateFormat sdf = new SimpleDateFormat(ESocialConstantes.DD_MM_YYYY);
                    LocalDateTime eSocialInicio;
                    if (empregador.getEmpresa().toString().equals(ARCOM_ID) || empregador.getEmpresa().toString().equals(ARCOM_DILENE_ID)){
                        eSocialInicio = UtilDate.toLocalDateTime(sdf.parse(INICIO_NAO_PERIODICOS));
                    } else {
                        eSocialInicio = UtilDate.toLocalDateTime(sdf.parse(INICIO_NAO_PERIODICOS_DEMAIS_EMP));
                    }
                    // Verifica se é necessária a execução do evento para essa empresa no respectivo ambiente
					if (parametro.isPresent()) {
						if (ESocialUtil.ambProducao()) {
							if (!parametro.get().equals(ESocialConstantes.PRODUCAO)) {
								continue;
							}
						} else {
							if (!parametro.get().equals(ESocialConstantes.DESENVOLVIMENTO)) {
								continue;
							}
						}
					} else {
						//Logger.info("Empresa não encontrada na tabela Parametro - ESOCIAL!");
					}
                    if (tpEvento.equals(ESocialConstantes.TipoEvento.INICIAl.getId())){

//                        s1000Service.evtInformacoesEmpregador(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S1000));
//                        logaSeDesenvolvimento( origem , "s1000 finalizado" );
//                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.INICIAl.getId()));
//////
//                        s1005Service.tabEstabelecimentosObrasUop(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S1005));
//                        logaSeDesenvolvimento( origem , "s1005 finalizado" );
//                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.INICIAl.getId()));
//
//                        s1010Service.tabRubricas(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S1010));
//                        logaSeDesenvolvimento( origem , "s1010 finalizado" );
//                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.NAO_PERIODICO.getId()));
//
//                        s1020Service.tabLotacaoTributaria(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S1020));
//                        logaSeDesenvolvimento( origem , "s1020 finalizado" );
//                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.INICIAl.getId()));
//
//                        s1030Service.tabCargos(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S1030));
//                        logaSeDesenvolvimento( origem , "s1030 finalizado" );
//                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.INICIAl.getId()));
////
//                        s1050Service.tabHorariosTurnos(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S1050));
//                        logaSeDesenvolvimento( origem , "s1050 finalizado" );
//                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.INICIAl.getId()));

//                          s1060Service.tabAmbientesTrabalho(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA,empregador,ESocialConstantes.S1060));
//                          retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.INICIAl.getId()));


                    } else if (tpEvento.equals(ESocialConstantes.TipoEvento.NAO_PERIODICO.getId())) {

                        // Ajuste de faseamento para novas empresas integrantes do eSocial
                        if (UtilDate.ehMaior(sistemaRepository.getDataHojeHora(), eSocialInicio)){

                            s2200Service.admissaoIngressoTrabalhador(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S2200));
                            logaSeDesenvolvimento( origem , "s2200 finalizado" );
                            retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.NAO_PERIODICO.getId()));
//
//                            s2300Service.trabalhadorSemVinculoInicio(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S2300));
//                            logaSeDesenvolvimento( origem , "s2300 finalizado" );
//                            retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.NAO_PERIODICO.getId()));
////
//                            s2250Service.avisoPrevio(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S2250));
//                            logaSeDesenvolvimento( origem , "s2250 finalizado" );
//                            retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.NAO_PERIODICO.getId()));
//
//                            s2230Service.afastamentoTemporario(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S2230));
//                            logaSeDesenvolvimento( origem , "s2230 finalizado" );
//                            retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.NAO_PERIODICO.getId()));
//
//                            s2299Service.desligamento(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S2299), 0L, null);
//                            logaSeDesenvolvimento( origem , "s2299 finalizado" );
//                            retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.NAO_PERIODICO.getId()));
//
//                            s2399Service.trabalhadorSemVinculoTermino(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S2299), 0l,null);
//                            logaSeDesenvolvimento( origem , "s2399 finalizado" );
//                            retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.NAO_PERIODICO.getId()));
                        }


                    } else if (tpEvento.equals(ESocialConstantes.TipoEvento.PERIODICO.getId())){
//                          ocorrenciaRepository.delete(48985l);
//                          ocorrenciaRepository.delete(48976l);
                            //processoRepository.delete(94708l);
//                        evt = evtControleRepository.findById(79938l).get();
//                        evt.setStatusProcessamento(new Short("1"));
//                        evt.setIdLoteEnvio(null);
//                        evtControleRepository.save(evt);
//                        evt = evtControleRepository.findById(79939l).get();
//                        evt.setStatusProcessamento(new Short("1"));
//                        evt.setIdLoteEnvio(null);
//                        evtControleRepository.save(evt);
//                        evt = evtControleRepository.findById(79940l).get();
//                        evt.setStatusProcessamento(new Short("1"));
//                        evt.setIdLoteEnvio(null);
//                        evtControleRepository.save(evt);
//                        evt = evtControleRepository.findById(79941l).get();
//                        evt.setStatusProcessamento(new Short("1"));
//                        evt.setIdLoteEnvio(null);
//                        evtControleRepository.save(evt);
//                        evt = evtControleRepository.findById(79942l).get();
//                        evt.setStatusProcessamento(new Short("1"));
//                        evt.setIdLoteEnvio(null);
//                        evtControleRepository.save(evt);
//                        evt = evtControleRepository.findById(79943l).get();
//                        evt.setStatusProcessamento(new Short("1"));
//                        evt.setIdLoteEnvio(null);
//                        evtControleRepository.save(evt);
//                        evt = evtControleRepository.findById(79944l).get();
//                        evt.setStatusProcessamento(new Short("1"));
//                        evt.setIdLoteEnvio(null);
//                        evtControleRepository.save(evt);
//                        evt = evtControleRepository.findById(79945l).get();
//                        evt.setStatusProcessamento(new Short("1"));
//                        evt.setIdLoteEnvio(null);
//                        evt = evtControleRepository.findById(79946l).get();
//                        evt.setStatusProcessamento(new Short("1"));
//                        evt.setIdLoteEnvio(null);
//                        evtControleRepository.save(evt);
//                        evt = evtControleRepository.findById(79947l).get();
//                        evt.setStatusProcessamento(new Short("1"));
//                        evt.setIdLoteEnvio(null);
//                        evtControleRepository.save(evt);
//                        evt = evtControleRepository.findById(79948l).get();
//                        evt.setStatusProcessamento(new Short("1"));
//                        evt.setIdLoteEnvio(null);
//                        evtControleRepository.save(evt);
//						s1200Service.criarRemuneracaoTrabalhadorVinculadoRGPS(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S1200));
//						retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.PERIODICO.getId()));
//
//                        s1210Service.criarPagamentoDeRendimentosDoTrabalho(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S1210));
//                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.PERIODICO.getId()));
//
//						s1298Service.reaberturaEventosPeriodicos(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S1298));
//						retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.PERIODICO.getId()));
//
//                        s1299Service.fechamentoEventosPeriodicos(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empregador, ESocialConstantes.S1299));
//                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.PERIODICO.getId()));
                    }

                }

            }

            // Caso sejam eventos unitários :
            else {

                // Recupera id da empresa
                String idEmpresa;
                // Verifica se é uma execução ou exclusão (contém o ID) de evento
                if (tpEvento.contains("I")) {
                    idEmpresa = tpEvento.substring(6,tpEvento.indexOf("I"));
                }
                // Verifica se é uma execução de evento periódico com competência
                else if (tpEvento.contains("C")) {
                    idEmpresa = tpEvento.substring(6,tpEvento.indexOf("C"));
                } else {
                    idEmpresa = tpEvento.substring(6);
                }
                // Filtra na lista de empregadores a empresa com id indicado
                Optional<EmpregadoresESocialDto> empresa = empregadoresList.stream()
                        .filter(emp -> idEmpresa.equals(emp.getEmpresa().toString()))
                        .findAny();

                if (empresa.isPresent()) {

                    // Salva informações de exclusão para usar em caso de exclusão
                    InfoExclusao infoExclusao = new InfoExclusao();
                    infoExclusao.setTpEvento(tpEvento.substring(0, 5));
                    infoExclusao.setTpEventoAux(tpEvento);
                    infoExclusao.setOp(tpEvento.substring(0, 1));
                    infoExclusao.setEmpresa(empresa);
                    infoExclusao.setRetornoDadosLoteList(retornoDadosLoteList);
                    if (infoExclusao.getTpEvento().matches(ESocialConstantes.S1000+"|"+ESocialConstantes.D1000))    {
                        infoExclusao.setProcesso(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empresa.get(), ESocialConstantes.S1000));
                        verificaExc(infoExclusao);
                        s1000Service.evtInformacoesEmpregador(infoExclusao.getProcesso());
                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.INICIAl.getId()));
                    } else if (infoExclusao.getTpEvento().matches(ESocialConstantes.S1005+"|"+ESocialConstantes.D1005)) {
                        infoExclusao.setProcesso(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empresa.get(), ESocialConstantes.S1005));
                        verificaExc(infoExclusao);
                        s1005Service.tabEstabelecimentosObrasUop(infoExclusao.getProcesso());
                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.INICIAl.getId()));
                    } else if (infoExclusao.getTpEvento().matches(ESocialConstantes.S1010+"|"+ESocialConstantes.D1010)) {
                        infoExclusao.setProcesso(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empresa.get(), ESocialConstantes.S1010));
                        verificaExc(infoExclusao);
                        s1010Service.tabRubricas(infoExclusao.getProcesso());
                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.INICIAl.getId()));
                    } else if (infoExclusao.getTpEvento().matches(ESocialConstantes.S1020+"|"+ESocialConstantes.D1020)) {
                        infoExclusao.setProcesso(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empresa.get(), ESocialConstantes.S1020));
                        verificaExc(infoExclusao);
                        s1020Service.tabLotacaoTributaria(infoExclusao.getProcesso());
                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.INICIAl.getId()));
                    } else if (infoExclusao.getTpEvento().matches(ESocialConstantes.S1030+"|"+ESocialConstantes.D1030)) {
                        infoExclusao.setProcesso(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empresa.get(), ESocialConstantes.S1030));
                        verificaExc(infoExclusao);
                        s1030Service.tabCargos(infoExclusao.getProcesso());
                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.INICIAl.getId()));
                    } else if (infoExclusao.getTpEvento().matches(ESocialConstantes.S1050+"|"+ESocialConstantes.D1050)) {
                        infoExclusao.setProcesso(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empresa.get(), ESocialConstantes.S1050));
                        verificaExc(infoExclusao);
                        s1050Service.tabHorariosTurnos(infoExclusao.getProcesso());
                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.INICIAl.getId()));
                    } else if (infoExclusao.getTpEvento().matches(ESocialConstantes.S2230)) {
                        infoExclusao.setProcesso(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empresa.get(), ESocialConstantes.S2230));
                        verificaExc(infoExclusao);
                        s2230Service.afastamentoTemporario(infoExclusao.getProcesso());
                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.NAO_PERIODICO.getId()));
                    } else if (infoExclusao.getTpEvento().matches(ESocialConstantes.S2230)) {
                        infoExclusao.setProcesso(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empresa.get(), ESocialConstantes.S2250));
                        verificaExc(infoExclusao);
                        s2250Service.avisoPrevio(infoExclusao.getProcesso());
                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.NAO_PERIODICO.getId()));
                    } else if (infoExclusao.getTpEvento().matches(ESocialConstantes.S2299+"|"+ESocialConstantes.D2299)) {
                        infoExclusao.setProcesso(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, empresa.get(), ESocialConstantes.S2299));
                        verificaExc(infoExclusao);
                        s2299Service.desligamento(infoExclusao.getProcesso(), 0L, null);
                        retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.NAO_PERIODICO.getId()));
                    } else if (infoExclusao.getTpEvento().matches(ESocialConstantes.S1200+"|"+ESocialConstantes.D1200+
                            "|"+ESocialConstantes.S1210+"|"+ESocialConstantes.D1210+
                            "|"+ESocialConstantes.S1298+"|"+ESocialConstantes.D1298+
                            "|"+ESocialConstantes.S1299+"|"+ESocialConstantes.D1299+
                            "|"+ESocialConstantes.S2200+"|"+ESocialConstantes.D2200+
                            "|"+ESocialConstantes.S2300+"|"+ESocialConstantes.D2300+
                            "|"+ESocialConstantes.D2205+"|"+ESocialConstantes.D2206+
                            "|"+ESocialConstantes.D2230)) {
                        verificaExc(infoExclusao);
                        retornoDadosLoteList = infoExclusao.getRetornoDadosLoteList();
                    }
                } else if (tpEvento.equals("ReprocessarLotes")) {
                    retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.INICIAl.getId()));
                    retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.NAO_PERIODICO.getId()));
                    retornoDadosLoteList.addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.PERIODICO.getId()));
                }

            }

            return ok(toJson(retornoDadosLoteList));
        } catch (Throwable e) {
            return badRequest(getExceptionComoString(e));
        }

    }

    /**
     * Verificar operação
     *
     * @return
     */
    public InfoExclusao verificaExc(InfoExclusao infoExclusao) throws Exception {
        if (infoExclusao.getOp().equals("D")){
            if (infoExclusao.getTpEvento().matches(ESocialConstantes.D1200+"|"+ESocialConstantes.D1210+"|"+ESocialConstantes.D2200+"|"+ESocialConstantes.D2300+"|"+ESocialConstantes.D2205+"|"+ESocialConstantes.D2206+"|"+ESocialConstantes.D2230)) {
                s3000Service.exclusaoEventos(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, infoExclusao.getEmpresa().get(), ESocialConstantes.S3000),infoExclusao.getTpEventoAux().substring(infoExclusao.getTpEventoAux().indexOf("I")));
                infoExclusao.getRetornoDadosLoteList().addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.NAO_PERIODICO.getId()));
            } else {
                infoExclusao.getProcesso().setExclusao("S");
            }
        } else {
            final String origem = this.getClass().getName();
            if ( infoExclusao.getTpEvento().equals(ESocialConstantes.S1200 ) ) {
                s1200Service.criarRemuneracaoTrabalhadorVinculadoRGPS(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, infoExclusao.getEmpresa().get(), ESocialConstantes.S1200),infoExclusao.getTpEventoAux().substring(infoExclusao.getTpEventoAux().indexOf("C")+1));
                logaSeDesenvolvimento( origem , "s1200 finalizado" );
                infoExclusao.getRetornoDadosLoteList().addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.PERIODICO.getId()));
            } else if ( infoExclusao.getTpEvento().equals(ESocialConstantes.S1210 ) ) {
                s1210Service.criarPagamentoDeRendimentosDoTrabalho(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, infoExclusao.getEmpresa().get(), ESocialConstantes.S1210),infoExclusao.getTpEventoAux().substring(infoExclusao.getTpEventoAux().indexOf("C")+1));
                logaSeDesenvolvimento( origem , "s1210 finalizado" );
                infoExclusao.getRetornoDadosLoteList().addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.PERIODICO.getId()));
            } else if ( infoExclusao.getTpEvento().equals(ESocialConstantes.S1298 ) ) {
                s1298Service.reaberturaEventosPeriodicos(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, infoExclusao.getEmpresa().get(), ESocialConstantes.S1298),infoExclusao.getTpEventoAux().substring(infoExclusao.getTpEventoAux().indexOf("C")+1));
                infoExclusao.getRetornoDadosLoteList().addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.PERIODICO.getId()));
            } else if ( infoExclusao.getTpEvento().equals(ESocialConstantes.S1299 ) ) {
                s1299Service.fechamentoEventosPeriodicos(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, infoExclusao.getEmpresa().get(), ESocialConstantes.S1299),infoExclusao.getTpEventoAux().substring(infoExclusao.getTpEventoAux().indexOf("C")+1));
                infoExclusao.getRetornoDadosLoteList().addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.PERIODICO.getId()));
            } else if ( infoExclusao.getTpEvento().equals(ESocialConstantes.S2200 ) ) {
                s2200Service.admissaoIngressoTrabalhador(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, infoExclusao.getEmpresa().get(), ESocialConstantes.S2200));
                infoExclusao.getRetornoDadosLoteList().addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.NAO_PERIODICO.getId()));
            } else if ( infoExclusao.getTpEvento().equals(ESocialConstantes.S2300 ) ) {
                infoExclusao.setProcesso(processoRepository.novoProcesso(ESocialConstantes.ID_SISTEMA, infoExclusao.getEmpresa().get(), ESocialConstantes.S2300));
                s2300Service.trabalhadorSemVinculoInicio(infoExclusao.getProcesso());
                infoExclusao.getRetornoDadosLoteList().addAll(enviaLoteService.buscaEventosEnvioTst(ESocialConstantes.TipoEvento.NAO_PERIODICO.getId()));
            } else {
                infoExclusao.getProcesso().setExclusao("N");
            }
            //schedulerService.agendar( ESOCIAL_CONSULTAR_RETORNO_EVENTOS, ESocialConstantes.MINUTOS_CONSULTAR, origem );
        }
        return infoExclusao;
    }
}
