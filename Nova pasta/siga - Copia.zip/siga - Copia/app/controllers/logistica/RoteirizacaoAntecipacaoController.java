package controllers.logistica;

import controllers.AuthController;
import infra.binders.ShortBinder;
import models.commons.dtos.DestinatarioRoteirizacaoAntecipacaoDto;
import play.db.jpa.Transactional;
import play.mvc.Result;
import services.logistica.RoteirizacaoAntecipacaoDelegateService;

import static infra.binders.ShortBinder.getValue;

import javax.inject.Inject;

import java.util.List;

import static infra.util.UtilException.getException;
import static models.domains.admin.Empresa.IdEmpresa.ARCOM;
import static play.libs.Json.toJson;

public class RoteirizacaoAntecipacaoController extends AuthController {

    private final RoteirizacaoAntecipacaoDelegateService roteirizacaoAntecipacaoDelegateService;

    @Inject
    public RoteirizacaoAntecipacaoController(final RoteirizacaoAntecipacaoDelegateService roteirizacaoAntecipacaoDelegateService ) {
        this.roteirizacaoAntecipacaoDelegateService = roteirizacaoAntecipacaoDelegateService;
    }

    @Transactional( readOnly = true )
    public Result buscarDestinatariosRoteirizacaoAntecipacao(final ShortBinder filtroRoteirizacaoAntecipacao,
                                                             final String idGrupoCidade,
                                                             final List<ShortBinder> diasSemana) {
        try {
            return ok( toJson( roteirizacaoAntecipacaoDelegateService.buscarDestinatariosRoteirizacaoAntecipacao(getValue(filtroRoteirizacaoAntecipacao), ARCOM.getValor(), idGrupoCidade, getValue(diasSemana)) ) );
        } catch ( Throwable ex ) {
            ex.printStackTrace();
            return badRequest( getException( ex ) );
        }
    }

    @Transactional( readOnly = true )
    public Result salvarDestinatariosRoteirizacaoAntecipacao() {
        try {
            return ok( toJson(roteirizacaoAntecipacaoDelegateService.salvarRoteirizacaoAntecipacao(getShort("filtroRoteirizacaoAntecipacao"), ARCOM.getValor(), getRequest().getIdUsuario(), getList("pedidoItensAntecipacao", DestinatarioRoteirizacaoAntecipacaoDto.class))));
        } catch ( final Throwable e ) {
            return badRequestRollback( e );
        }
    }

    @Transactional( readOnly = true )
    public Result previsaoBoxRoteirizacaoAntecipacao() {
        try {
            return ok( toJson(roteirizacaoAntecipacaoDelegateService.previsaoBoxRoteirizacaoAntecipacao(getShort("filtroRoteirizacaoAntecipacao"), ARCOM.getValor(), getRequest().getIdUsuario(), getList("pedidoItensAntecipacao", DestinatarioRoteirizacaoAntecipacaoDto.class))));
        } catch ( final Throwable e ) {
            return badRequestRollback( e );
        }
    }

}
