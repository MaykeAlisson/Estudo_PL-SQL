package controllers.logistica;

import controllers.AuthController;
import controllers.binders.ArquivoBinder;
import controllers.binders.EstadoBinder;
import infra.binders.LocalDateBinder;
import play.db.jpa.Transactional;
import play.mvc.Result;
import play.mvc.Results;
import services.logistica.EstatisticaUfuService;

import javax.inject.Inject;
import java.nio.file.Path;

import static controllers.binders.ArquivoBinder.getValue;
import static controllers.binders.EstadoBinder.getValue;
import static infra.binders.LocalDateBinder.getValue;
import static infra.util.UtilException.getException;


/**
 * Controller responsável por gerar estatisticas Ufu
 *
 * @author Mayke.Furtado
 *
 * @since 28/05/2019
 */
public class EstatisticaUfuController extends AuthController {

    // Service:
    private final EstatisticaUfuService estatisticaUfuService;

    // Construtor
    @Inject
    public EstatisticaUfuController(final EstatisticaUfuService estatisticaUfuService){
        this.estatisticaUfuService = estatisticaUfuService;
    }

    @Transactional( readOnly = true )
    public Result gerarEstatisticas(
        final LocalDateBinder dataInicioBinder,
        final LocalDateBinder dataFimBinder,
        final EstadoBinder estadoBinder
        ) {

            try {
                return estatisticaUfuService.gerarArquivoUfu(
                    getValue( dataInicioBinder ),
                    getValue( dataFimBinder ),
                    getValue( estadoBinder )
                )
                .map( Path::toFile )
                .map( Results::ok )
                .orElse( noContent() );
            } catch ( final Throwable e ) {
                return badRequest(getException(e));
            }

        }
//    }

}
