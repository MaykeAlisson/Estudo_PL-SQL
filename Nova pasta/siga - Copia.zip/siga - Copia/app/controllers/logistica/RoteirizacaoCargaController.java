package controllers.logistica;

import controllers.AuthController;
import infra.binders.LocalDateBinder;
import models.commons.dtos.DestinatarioRoteirizacaoCargaDto;
import models.commons.dtos.TemplateZonaRoteirizacaoDto;
import play.db.jpa.Transactional;
import play.mvc.Result;
import services.logistica.RoteirizacaoCargaService;

import javax.inject.Inject;

import static infra.binders.LocalDateBinder.getValue;
import static infra.util.UtilException.getException;
import static models.domains.admin.Empresa.IdEmpresa.ARCOM;
import static play.libs.Json.toJson;

public class RoteirizacaoCargaController extends AuthController {

    private final RoteirizacaoCargaService roteirizacaoCargaService;

    @Inject
    public RoteirizacaoCargaController(final RoteirizacaoCargaService roteirizacaoCargaService ) {
        this.roteirizacaoCargaService = roteirizacaoCargaService;
    }

    @Transactional(readOnly = true)
    public Result buscarDestinatariosRoteirizacaoCarga(final String idGrupoCidade
                                                      ,final LocalDateBinder dataLimitePedidos
                                                      ,final String ignorarDiaRoteirizacao
                                                      ,final String pesquisaComTemplate
                                                      ) {
        try {
            return ok( toJson( roteirizacaoCargaService.buscarDestinatariosRoteirizacaoCarga( ARCOM.getValor(), idGrupoCidade, getValue(dataLimitePedidos), ignorarDiaRoteirizacao, pesquisaComTemplate) ) );
        } catch ( Throwable ex ) {
            ex.printStackTrace();
            return badRequest( getException( ex ) );
        }
    }

    @Transactional()
    public Result salvarRoteirizacaoCarga() {
        try {
            roteirizacaoCargaService.salvarRoteirizacaoCarga(ARCOM.getValor(), getString("idGrupoCidade"), getList("destinatariosRoteirizacaoCarga", DestinatarioRoteirizacaoCargaDto.class), getRequest().getIdUsuario());
            return ok();
        } catch ( final Throwable e ) {
            e.printStackTrace();
            return badRequestRollback( e );
        }
    }

    @Transactional()
    public Result salvarTemplateZonaRoteirizacao() {
        try {
            roteirizacaoCargaService.salvarTemplateZonaRoteirizacao(getList("templateZonaRoteirizacao", TemplateZonaRoteirizacaoDto.class));
            return ok();
        } catch ( final Throwable e ) {
            e.printStackTrace();
            return badRequestRollback( e );
        }
    }
}
