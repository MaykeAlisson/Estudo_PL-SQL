package controllers.apoio;

import controllers.AuthController;
import play.db.jpa.Transactional;
import play.mvc.Result;
import services.admin.ApoioService;

import javax.inject.Inject;

import static infra.util.UtilException.getException;
import static play.libs.Json.toJson;

/**
 * Controladora para atender requisições do depto de apoio.
 *
 * <p>Autor: GPortes</p>
 */
public class ApiApoioController extends AuthController {

    // Service:
    private final ApoioService apoioService;

    @Inject
    public ApiApoioController( final ApoioService apoioService ) {

        this.apoioService = apoioService;
    }

    @Transactional( readOnly = true )
    public Result buscarSetoresLigacoesNaoAtendidas() {

        try {
            return ok( toJson( apoioService.buscarLigacoesNaoAtendidas() ) );
        } catch ( Throwable e ) {
            return badRequest( getException(e) );
        }
    }
}
