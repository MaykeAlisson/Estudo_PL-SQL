package controllers;

import play.mvc.Controller;
import play.mvc.Result;

import java.util.Objects;

import static java.lang.String.format;

/**
 * Created by alysson on 10/05/2018.
 */
public class FrontEndController extends Controller {

    /**
     * Tratamento para requisições do front-end ( javascript )
     * <p>Redirecionamos todas requisições para /</p>
     *
     * <p>Autor: GPortes</p>
     *
     * @param file
     *
     * @return
     */
    public Result index( String file ) {

        if ( file != null ) {
            String mime = null;
            if ( file.lastIndexOf(".css") > 0 ) mime = "text/css";
            if ( file.lastIndexOf(".js") > 0 ) mime = "text/javascript";
            if ( Objects.nonNull(mime) )
                return ok( FrontEndController.class.getResourceAsStream( format("/public/dist/%s", file) ) ).as( mime );
        }

        return ok( FrontEndController.class.getResourceAsStream("/public/dist/index.html") ).as("text/html");
    }

    /**
     * Tratamento para CORS.
     *
     * <p>Autor: GPortes</p>
     *
     * @param path
     *
     * @return
     */
    public Result options( String path ) {

        response().setHeader("Access-Control-Allow-Origin", "*" );
        response().setHeader("Allow", "*" );
        response().setHeader("Access-Control-Allow-Methods", "POST, GET, PUT, DELETE, OPTIONS" );
        response().setHeader("Access-Control-Allow-Headers", "Access-Control-Allow-Headers, Origin, X-Requested-With, Content-Type, Accept, Authorization" );
        return ok();
    }
}