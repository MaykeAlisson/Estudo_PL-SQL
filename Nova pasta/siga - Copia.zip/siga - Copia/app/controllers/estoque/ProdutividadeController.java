package controllers.estoque;

import com.fasterxml.jackson.databind.node.ObjectNode;
import controllers.AuthController;
import infra.binders.LocalDateBinder;
import infra.binders.LongBinder;
import infra.binders.ShortBinder;
import models.repository.move.RuaBaixaRepository;
import play.db.jpa.Transactional;
import play.mvc.Result;

import javax.inject.Inject;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import static infra.binders.LocalDateBinder.getValue;
import static infra.binders.LongBinder.getValue;
import static infra.binders.ShortBinder.getValue;
import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilDate.toDate;
import static infra.util.UtilException.getException;
import static java.util.stream.Collectors.toList;
import static models.domains.admin.Empresa.IdEmpresa.ARCOM;
import static play.libs.Json.newObject;
import static play.libs.Json.toJson;


/**
 * Controller responsável por informações sobre Produtividade.
 *
 * @author Cleber
 *
 * @since 10/08/14
 */
public class ProdutividadeController extends AuthController {

    private static final Short TODOS_TURNOS = -1;
    private static final Long TODOS_SETORES = -1L;
    private static final Short DIARIO = -1;

    // Repository:
    private final RuaBaixaRepository ruaBaixaRepository;

    @Inject
    public ProdutividadeController( final RuaBaixaRepository ruaBaixaRepository ) {

        this.ruaBaixaRepository = ruaBaixaRepository;
    }

    @Transactional( readOnly = true )
    public Result buscar(
        final LocalDateBinder dataBinder,
        final ShortBinder turnoBinder,
        final LongBinder setorBinder,
        final ShortBinder horaBinder,
        final LongBinder idFuncionario
    ) {

        try {

            final Date dataPesquisa = toDate( getValue(dataBinder) );
            final Short turno = getValue( turnoBinder );

            if ( turno != null ) {

                final Long setor = getValue(setorBinder);
                final Short hora = getValue(horaBinder);

                if ( setor == null && hora == null )
                    return ok( toJson(
                        Objects.equals( turno, TODOS_TURNOS )
                        ? ruaBaixaRepository.listaProdutividadePorHora( ARCOM.getValor(), dataPesquisa )
                        : ruaBaixaRepository.listaProdutividadePorHoraTurno( ARCOM.getValor(),dataPesquisa, turno )
                    ));

                if ( setor != null && hora != null ) {

                    // todos setores do dia.
                    if ( Objects.equals(setor, TODOS_SETORES) && Objects.equals(hora, DIARIO) )
                        return ok( toJson(
                            ruaBaixaRepository.findPessoaPorTurno( ARCOM.getValor(), dataPesquisa, turno )
                        ));

                    // diario por setor.
                    if ( !Objects.equals(setor, TODOS_SETORES) && Objects.equals(hora, DIARIO) )
                        return ok( toJson(
                            ruaBaixaRepository.findPessoaPorTurnoSetor( ARCOM.getValor(), dataPesquisa, turno, setor )
                        ));

                    // todos setores de uma hora.
                    if ( Objects.equals(setor, TODOS_SETORES) && !Objects.equals(hora, DIARIO) )
                        return ok( toJson(
                            ruaBaixaRepository.findPessoaPorHoraTurno( ARCOM.getValor(), dataPesquisa, turno, hora )
                        ));

                    return ok( toJson(
                        ruaBaixaRepository.findPessoaPorHoraTurnoSetor( ARCOM.getValor(), dataPesquisa, turno, hora, setor )
                    ));

                }

                return noContent();
            }

            if ( idFuncionario != null ) {

                final List<ObjectNode> dados = ruaBaixaRepository.buscarTotalPor(
                    ARCOM,
                    dataBinder.getValue(),
                    getValue(idFuncionario)
                )
                .stream()
                .map(dto -> newObject()
                    .put("hora", dto.getHora() )
                    .put("totalSeparado", dto.getTotalSeparado() )
                )
                .collect( toList() );

                return isVazia(dados) ? noContent() : ok(toJson(dados));
            }

            return noContent();

        } catch ( final Throwable e ) {

            return badRequest( getException(e) );
        }
    }
}