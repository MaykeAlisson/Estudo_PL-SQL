package controllers.estoque;

import controllers.AuthController;
import models.commons.dtos.EtiquetaLiberadaParaMovimentacaoDto;
import models.commons.dtos.LiberacaoCargaBoxDto;
import models.commons.dtos.MovimentaEtiquetaParaBoxDto;
import play.db.jpa.Transactional;
import play.mvc.Result;
import services.estoque.LiberacaoConsolidacaoCargaService;

import javax.inject.Inject;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static infra.util.UtilCollections.isVazia;
import static models.commons.constantes.TipoLiberacao.ENTREGA_BOX_LIBERACAO;
import static models.domains.admin.Empresa.IdEmpresa.ARCOM;
import static play.libs.Json.fromJson;
import static play.libs.Json.toJson;
import static services.estoque.LiberacaoConsolidacaoCargaService.ENT_BOX_LIBERACAO;

public class LiberacaoConsolidacaoCargaController extends AuthController {

    private final LiberacaoConsolidacaoCargaService liberacaoConsolidacaoCargaService;

    @Inject
    public LiberacaoConsolidacaoCargaController(
        final LiberacaoConsolidacaoCargaService liberacaoConsolidacaoCargaService
    ) {

        this.liberacaoConsolidacaoCargaService = liberacaoConsolidacaoCargaService;
    }

    @Transactional( readOnly = true )
    public Result buscarLiberacoesPendentes() {

        try {
            return ok( toJson( liberacaoConsolidacaoCargaService.buscarLiberacoesPendentes( ) ) );
        } catch ( Throwable e ) {
            return badRequestRollback( e );
        }
    }

    @Transactional
    public Result liberarPalete() {

        try {
            final LiberacaoCargaBoxDto dto = fromJson( getJsonBody(), LiberacaoCargaBoxDto.class );

            final Map<String, Object> retorno = new HashMap<>(2);

            if ( Objects.equals( dto.getTipoLiberacao(), ENTREGA_BOX_LIBERACAO ) ) {
                retorno.put(ENT_BOX_LIBERACAO, true);
            }
            else {
                 final Map<String, Object> procedimento = liberacaoConsolidacaoCargaService
                        .liberarAntecipacaoParcialmente(dto, getRequest().getIdUsuario(), ARCOM.getValor());

                if ( isVazia(procedimento) )
                    return noContent();

                if (procedimento.containsKey(ENT_BOX_LIBERACAO)) {
                    retorno.put(ENT_BOX_LIBERACAO, procedimento.get(ENT_BOX_LIBERACAO));
                    if ( !(boolean) procedimento.get(ENT_BOX_LIBERACAO))
                        retorno.put("liberacoes", liberacaoConsolidacaoCargaService.buscarLiberacoesPendentes());
                }
                else {
                        retorno.put("exibirMensagemBox", procedimento.get("nroBoxLiberacao"));
                        retorno.put("liberacoes", liberacaoConsolidacaoCargaService.buscarLiberacoesPendentes());
                    }
            }

            return ok( toJson(retorno) );

        } catch ( final Throwable e ) {

            return badRequestRollback( e );
        }
    }

    @Transactional
    public Result atualizarBoxLiberacao() {

        try {
            liberacaoConsolidacaoCargaService.atualizarBoxLiberacao(
                fromJson( getJsonBody(), LiberacaoCargaBoxDto.class ),
                getRequest().getIdUsuario(),
                ARCOM.getValor()
            );
            return ok( toJson( liberacaoConsolidacaoCargaService.buscarLiberacoesPendentes( ) ) );
        } catch ( Throwable e ) {
            return badRequestRollback( e );
        }
    }

    @Transactional( readOnly = true )
    public Result buscarEtiquetaLiberadaParaMovimentacao( ) {

        try {
            final List<EtiquetaLiberadaParaMovimentacaoDto> dtos =
                    liberacaoConsolidacaoCargaService.buscarEtiquetaLiberadaParaMovimentacao( ARCOM.getValor() );
            return isVazia(dtos) ? noContent() : ok( toJson(dtos ) );
        } catch ( Throwable e ) {
            return badRequestRollback( e );
        }
    }

    @Transactional
    public Result movimentaEtiquetaParaBox( ){

        try {
            liberacaoConsolidacaoCargaService.movimentaEtiquetaParaBox(
                fromJson( getJsonBody(), MovimentaEtiquetaParaBoxDto.class ),
                getRequest().getIdUsuario(),
                ARCOM.getValor()
            );
            return ok();
        } catch ( Throwable e ) {
            return badRequestRollback( e );
        }
    }
}
