package controllers.estoque;

import controllers.AuthController;
import play.db.jpa.Transactional;
import play.mvc.Result;
import services.ecommerce.ECommerceService;

import javax.inject.Inject;

public class MercadoriaController extends AuthController {

    private final ECommerceService eCommerceService;

    @Inject
    public MercadoriaController( final ECommerceService eCommerceService ) {

        this.eCommerceService = eCommerceService;
    }

    @Transactional
    public Result atualizarMercadoriaECommerce() {

        try {
            eCommerceService.atualizarMercadorias();
            return ok();
        } catch ( final Throwable e ) {
            return badRequestRollback( e );
        }
    }

}
