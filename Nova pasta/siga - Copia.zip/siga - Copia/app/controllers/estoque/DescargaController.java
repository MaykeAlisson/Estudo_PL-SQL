package controllers.estoque;

import controllers.AuthController;
import infra.binders.LongBinder;
import models.commons.dtos.DescargasAbertoDto;
import models.repository.estoque.DescargaRepository;
import play.db.jpa.Transactional;
import play.mvc.Result;

import javax.inject.Inject;
import java.util.List;

import static infra.binders.LongBinder.getValue;
import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilException.getException;
import static play.libs.Json.toJson;

/**
 * Controller responsável por informações sobre Entrega de page portaria.
 *
 * @author Mayke.Furtado
 *
 * @since 24/05/2019
 */
public class DescargaController extends AuthController {

    // Repository:
    private final DescargaRepository descargaRepository;

    // Construtor
    @Inject
    public DescargaController ( final DescargaRepository descargaRepository){

        this.descargaRepository = descargaRepository;

    }

    @Transactional
    public Result buscarDescargasEmAberto(){

            try {
                List<DescargasAbertoDto> descarga = descargaRepository.buscarDescargasEmAberto();
                if (isVazia(descarga)){
                    return noContent();
                }else{
                    return ok(toJson(descarga));
                }
            }catch (Throwable e){
                return badRequest(getException(e));
            }

    }

}



