package controllers.estoque;

import controllers.AuthController;
import models.commons.dtos.PainelEstoqueDto;
import models.commons.dtos.ResumoPainelEstoqueDto;
import play.db.jpa.Transactional;
import play.mvc.Result;
import services.custos.PcpService;

import javax.inject.Inject;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilDate.FORMATO_DATA_HORA_MINUTO;
import static infra.util.UtilDate.getDataComoString;
import static infra.util.UtilException.getException;
import static java.util.Map.Entry;
import static java.util.stream.Collectors.toMap;
import static play.libs.Json.toJson;

public class PcpController extends AuthController {

    // Service:
    private final PcpService pcpService;

    @Inject
    public PcpController( final PcpService pcpService ) {

        this.pcpService = pcpService;
    }

    @Transactional
    public Result gerarDemandaPendente() {

        try {
            pcpService.gerarDemandaEstoquePendente();
            return ok();
        } catch ( Throwable e ) {
            return badRequestRollback( e );
        }
    }

    @Transactional
    public Result atualizarPainel() {

        try {
            pcpService.atualizarPainelEstoque();
            return ok();
        } catch ( Throwable e ) {
            return badRequestRollback( e );
        }
    }

    @Transactional( readOnly = true )
    public Result buscarDadosPainel() {
        try {
            Map<LocalDateTime, List<PainelEstoqueDto>> dados = pcpService.buscarDadosPainel();
            if ( isVazia(dados) ) return noContent();

            return ok(toJson(
                dados
                    .entrySet()
                    .stream()
                    .map(item -> {
                        final Map<String, Object> jsonPainel = new HashMap<>(1);
                        jsonPainel.put("dtUltimaAtualizacao", getDataComoString(item.getKey(), FORMATO_DATA_HORA_MINUTO));
                        jsonPainel.put("paineis", item.getValue());
                        return jsonPainel;
                    })
                    .flatMap(e -> e.entrySet().stream())
                    .collect(toMap(Entry::getKey, Entry::getValue))
            ));
        } catch ( Throwable e ) {
            return badRequest( getException(e) );
        }
    }

    @Transactional( readOnly = true )
    public Result buscarResumoPainel() {

        try {
            final Map<LocalDateTime, ResumoPainelEstoqueDto> dados = pcpService.buscarResumoPainelEstoque();

            if ( isVazia(dados) ) return noContent();

            return ok( toJson(
                dados
                .entrySet()
                .stream()
                .map( resumo -> {
                    final Map<String, Object> jsonPainel = new HashMap<>(1);
                    jsonPainel.put( "dataLeitura", getDataComoString( resumo.getKey(), FORMATO_DATA_HORA_MINUTO ) );
                    jsonPainel.put( "painel", resumo.getValue() );
                    return jsonPainel;
                })
                .flatMap( e -> e.entrySet().stream() )
                .collect( toMap( Entry::getKey, Entry::getValue ) )
            ));
        } catch ( Throwable e ) {
            return badRequest( getException(e) );
        }
    }

    @Transactional
    public Result atualizarQtdPessoas() {

        try {
            pcpService.atualizarQtdPessoas(
                getLong("matricula" ),
                getLong("qtdFracionado" ),
                getLong("qtdAlimenticio" ),
                getLong("qtdConsolidacao" ),
                getLong("qtdCaixaFechada" )
            );
            return ok();
        } catch ( Throwable e ) {
            return badRequestRollback( e );
        }
    }

    @Transactional
    public Result criarPainel() {

        try {
            pcpService.criarPainel( getShort( "idEmpresa" ) ,getLong( "idCarga" ) );
            return ok();
        } catch ( Throwable e ) {
            return badRequestRollback( e );
        }
    }

}
