package controllers.analistas;

import com.fasterxml.jackson.databind.JsonNode;
import controllers.AuthController;
import infra.util.UtilDate;
import models.commons.dtos.ResultadoParcialPromocaoDto;
import models.repository.admin.SistemaRepository;
import models.repository.vendas.PromocaoRepository;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.Result;

import javax.inject.Inject;
import java.time.LocalDate;
import java.util.List;

import static infra.util.UtilCollections.isVazia;
import static models.domains.admin.Empresa.IdEmpresa.ARCOM;

public class AntonioController extends AuthController {


    private final PromocaoRepository promocaoRepository;
    private final SistemaRepository sistemaRepository;

    @Inject
    public AntonioController(PromocaoRepository promocaoRepository, SistemaRepository sistemaRepository) {
        this.promocaoRepository = promocaoRepository;
        this.sistemaRepository = sistemaRepository;
    }

    @Transactional
    public Result index() {

        try {

            LocalDate dataBase = LocalDate.of(2019,4,8);

            final List<ResultadoParcialPromocaoDto> dados = promocaoRepository.buscarResultadoParcial(
                ARCOM,
                promocaoRepository.buscarPromocoesDaSemana(ARCOM, dataBase)
            );

            if ( isVazia(dados) )
                return noContent();

            JsonNode jsonNode = Json.toJson(dados);
            return ok( jsonNode );

        } catch ( final Throwable e ) {

            return badRequestRollback( e );
        }
    }

}
