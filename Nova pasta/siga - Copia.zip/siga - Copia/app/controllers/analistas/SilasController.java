package controllers.analistas;

import com.fasterxml.jackson.databind.JsonNode;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;
import services.admin.FornecedorService;
import javax.inject.Inject;
import java.util.HashMap;
import java.util.Map;



import static infra.util.UtilException.getException;
import static play.libs.Json.toJson;

public class SilasController extends Controller {

    // Service:
    private final FornecedorService fornecedorService;

    @Inject
    public SilasController( final FornecedorService fornecedorService ) { this.fornecedorService = fornecedorService; }

    @Transactional
    public Result testar() {

        Map<String,String> retorno = new HashMap<>();
        retorno.put("senha","1234");

        JsonNode jsonNode = Json.toJson(retorno);

        return ok( jsonNode );
    }

    @Transactional( readOnly = true )
    public Result buscarFornecedorWs(String cnpj) {
        try {
            return ok( toJson( fornecedorService.buscarFornecedorWs(cnpj) ) );
        } catch ( Throwable e ) {
            return badRequest( getException(e) );
        }
    }


    /**
     *
     *  routes /api/module/recurso
     *  +      |  ( status da requisicao ok - 200  badRequest- 400 - noContent,
     *  |      +
     *  +--- controller ( classes que extends Controller - AuthController
     *          +
     *          |
     *          + --- service
     *                +- service
     *                +- repository -> banco de dados
     *
     *
     *
     *
     */


}
