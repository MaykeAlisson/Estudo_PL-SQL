package controllers.analistas;

import controllers.binders.AtividadeCustoBinder;
import infra.binders.DateBinder;
import infra.binders.ShortBinder;
import infra.exceptions.BusinessException;
import infra.util.UtilArquivo;
import infra.util.UtilDate;
import infra.util.UtilNumero;
import infra.util.UtilString;
import models.commons.annotations.Siga;
import models.commons.dtos.EnvelopeDto;
import models.commons.dtos.VendaSetorMapexDto;
import models.repository.admin.ParametroRepository;
import models.repository.admin.SistemaRepository;
import models.repository.vendas.DebitoRepository;
import models.repository.vendas.SetorRepository;
import play.Logger;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;
import services.admin.EmailService;
import services.custos.AlocacaoCustoService;
import services.custos.AlocacaoReceitaService;
import services.custos.AlocarDespesaService;
import services.custos.CusteioClienteService;
import services.custos.CustoTransporteService;
import services.custos.CustoVendasService;
import services.custos.PcpService;
import services.mapas.MapaService;
import views.html.api.transporte.geolocalizacao.localVeiculo;

import javax.inject.Inject;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static infra.util.UtilArquivo.getPastaTemporaria;
import static infra.util.UtilArquivo.gravarTexto;
import static infra.util.UtilDate.getDataComoString;
import static infra.util.UtilDate.getValue;
import static infra.util.UtilDate.toLocalDate;
import static infra.util.UtilDate.toLocalDateTime;
import static infra.util.UtilException.getExceptionComoString;
import static java.lang.String.format;
import static models.domains.admin.Empresa.IdEmpresa.ARCOM;


/**
 *
 */
public class CleberController extends Controller {

    private static String PROCESSAMENTO_OK = "OK";

    // Service:
    private final AlocacaoCustoService alocacaoCustoService;
    private final CustoTransporteService custoTransporteService;
    private final CusteioClienteService custeioClienteService;
    private final AlocacaoReceitaService alocacaoReceitaService;
    private final CustoVendasService custoVendasService;
    private final EmailService emailService;
    private final EmailService emailErro;
    private final PcpService pcpService;
    private final AlocarDespesaService alocarDespesaService;
    private final MapaService mapaService;

    // Repository:
    private final ParametroRepository parametroRepository;
    private final SistemaRepository sistemaRepository;
    private final DebitoRepository debitoRepository;
    private final SetorRepository setorRepository;


    @Inject
    public CleberController(
            final AlocacaoCustoService alocacaoCustoService,
            final CustoTransporteService custoTransporteService,
            final CusteioClienteService custeioClienteService,
            final AlocacaoReceitaService alocacaoReceitaService,
            final CustoVendasService custoVendasService,
            final EmailService emailService,
            final @Siga EmailService emailErro,
            final MapaService mapaService,
            final SistemaRepository sistemaRepository,
            final DebitoRepository debitoRepository,
            final PcpService pcpService,
            final ParametroRepository parametroRepository,
            final AlocarDespesaService alocarDespesaService,
            SetorRepository setorRepository) {

        this.alocacaoCustoService = alocacaoCustoService;
        this.custoTransporteService = custoTransporteService;
        this.custeioClienteService = custeioClienteService;
        this.alocacaoReceitaService = alocacaoReceitaService;
        this.custoVendasService = custoVendasService;
        this.emailService = emailService;
        this.emailErro = emailErro;
        this.mapaService = mapaService;
        this.sistemaRepository = sistemaRepository;
        this.debitoRepository = debitoRepository;
        this.pcpService = pcpService;
        this.parametroRepository = parametroRepository;
        this.alocarDespesaService = alocarDespesaService;
        this.setorRepository = setorRepository;
    }

    @Transactional(readOnly = true)
    public Result gerarPlanilhaCusto(final DateBinder dataCompetencia, final ShortBinder idCda, final AtividadeCustoBinder atividadeCusto) {

        try {
            pcpService.gerarDetalheEbitda(toLocalDate(dataCompetencia.getValue()),atividadeCusto.getValue(),idCda.getValue());
            return ok(  );

        } catch ( final Throwable e ) {
            return badRequest( e.getMessage() );
        }

    }

    @Transactional
    public Result fecharRateioCliente(final Long idEbitdaCusteio) {
        try {
            custeioClienteService.fecharRateioCliente(idEbitdaCusteio);
            return ok(PROCESSAMENTO_OK);
        } catch ( Throwable e ) {
            
            return erro(e);
        }
    }


    public Result api() {


        response().setHeader("Access-Control-Allow-Origin", "*" );

        Map<String,Object> map = new HashMap<>();

        map.put("title","Titulo do Cartao");
        map.put("subTitle","Sub-Titulo do Cartao Aderbal");
        return ok(Json.toJson(map));

    }
    @Transactional
    public Result gerarShellServicosPendentes() {

        try {
            return ok( alocacaoCustoService.gerarShellServicosPendentes());
        } catch (Throwable e) {
            
            return erro(e);
        }
    }

    @Transactional
    public Result gerarShellAcompanhamentoEntrega() {

        try {
            return ok( custoTransporteService.gerarShellAcompanhamentoEntrega());
        } catch (Throwable e) {
            
            return erro(e);
        }
    }

    @Transactional
    public Result gerarInformacoesEntregas() {

        try {
            custoTransporteService.gerarInformacoesEntregas();
            return ok(PROCESSAMENTO_OK);
        } catch (Throwable e) {
            
            return erro(e);
        }
    }

    @Transactional
    public Result alocarCustoBonificacao(final DateBinder data) {

        try {
            custoVendasService.alocarCustosBrindesBonificacoes(data.getValue());
            return ok(PROCESSAMENTO_OK);
        } catch (Throwable e) {
            
            return erro(e);
        }
    }

    @Transactional
    public Result atualizarDadosEntrega() {

        try {
            custoTransporteService.atualizarDadosEntrega();
            return ok(PROCESSAMENTO_OK);
        } catch (Throwable e) {
            
            return erro(e);
        }
    }

    @Transactional
    public Result gerarLocalizacaoVeiculo(ShortBinder idGerente) {

        try {


            //final String nomeArquivo = format( "%smapaGerente-%s.html", "/Users/clebersilva/Desktop/", idGerente.getValue() );
            final String nomeArquivo = format( "%smapaGerente-%s.html", parametroRepository.buscarCaminhoGravarArquivoEmail(ARCOM), idGerente.getValue() );
            final String textArquivo = localVeiculo.render(custoTransporteService.gerarMapaLocalizacaoVeiculo(idGerente.getValue())).body();

            if ( !UtilArquivo.gravarTexto( nomeArquivo, textArquivo ))
                return badRequest( format( "Falha ao gravar arquivo: %s", nomeArquivo ) );

            Logger.info("Nome do arquivo gerado: {}",nomeArquivo);

            final EnvelopeDto envelopeDto = new EnvelopeDto
                    .Builder( "Mapa de Localizacao de veiculo" )
                    .comMensagem( "Segue anexo o mapa com as localizacoes dos veiculos \n" + custoTransporteService.getLegendaCoresMapaLocalizacao() )
                    .comArquivos( nomeArquivo )
                    .comDestinatarios( custoTransporteService.getEmailGerenteTransporte(idGerente.getValue()), "regis@arcom.com.br" )
                    .comExclusao()
                    .build();
            emailService.enviar( envelopeDto );

            return ok(PROCESSAMENTO_OK);

        } catch (Throwable e) {
            
            return erro(e);
        }
    }

    @Transactional
    public Result atualizarAcompanhamentoEntrega(Long id) {

        try {
            custoTransporteService.atualizarAcompanhamentoEntrega(id);
            return ok(PROCESSAMENTO_OK);
        } catch (Throwable e) {
            
            return erro(e);
        }
    }

    @Transactional
    public Result alocarRateio(final long idControleCstCliente) {

        try {
            custeioClienteService.alocarControleCstCliente(idControleCstCliente);
            return ok(PROCESSAMENTO_OK);
        } catch (Throwable e) {
            
            return erro(e);
        }
    }

    @Transactional
    public Result calcularEstatisticaViagem() {

        try {
            custoTransporteService.recalcularEstatisticaViagem();
            return ok(PROCESSAMENTO_OK);
        } catch (Throwable e) {
            
            return erro(e);
        }
    }

    @Transactional
    public Result gerarShellRateio() {

        try {
            return ok( custeioClienteService.gerarShellRateio() );
        } catch (Throwable e) {
            
            return erro(e);
        }
    }

    @Transactional
    public Result gerarDashboardCda() {

        try {
            return ok( custoTransporteService.gerarDashboardCda() );
        } catch (Throwable e) {
            
            return erro(e);
        }
    }

    /*
    @Transactional
    public Result criarRegraCustoFuncionarioPorThread(final String processo,final ShortBinder idThread) {

        try {
            FuncionarioAlocacaoCustoService.processarThreadAlocacaoFuncionario(processo,idThread.getValue());
            return ok(PROCESSAMENTO_OK);
        } catch (Throwable e) {
            
            return erro(e);
        }
    }

    @Transactional
    public Result alocarDespesaFGTSPorThread(final String processo,final ShortBinder idThread) {

        try {
            CustoPessoalService.processarThreadAlocacaoDespesasFGTS(processo,idThread.getValue());
            return ok(PROCESSAMENTO_OK);
        } catch (Throwable e) {
            
            return erro(e);
        }
    }

    @Transactional
    public Result alocarPrevidenciaSocialPorThread(final String processo,final ShortBinder idThread) {

        try {
            CustoPessoalService.processarThreadAlocacaoPrevidenciaSocial(processo,idThread.getValue());
            return ok(PROCESSAMENTO_OK);
        } catch (Throwable e) {
            
            return erro(e);
        }
    }

    @Transactional
    public Result agendarAlocacaoAjustesReceita(final DateBinder dataCompetencia) {
        try {
            return ok(AlocacaoReceitaService.agendarAlocacaoResiduaisCmvImpostos(dataCompetencia.getValue()));
        } catch (Throwable e) {
            
            return erro(e);
        }
    }
    @Transactional
    public Result gerarScriptAlocacaoReceita(final DateBinder dataCompetencia) {
        try {
            return ok(AlocacaoReceitaService.agendarAlocacaoResiduaisCmvImpostos(dataCompetencia.getValue()));
        } catch (Throwable e) {
            
            return erro(e);
        }
    }
    */

//    @Transactional
//    public Result agendarEbitda(final DateBinder dataCompetencia, final String processo) {
//        try {
//            alocacaoReceitaService.agendarAlocacaoResiduaisCmvImpostos(dataCompetencia.getValue(),processo);
//            return ok(PROCESSAMENTO_OK);
//        } catch (Throwable e) {
//            
//            return erro(e);
//        }
//    }

    @Transactional
    public Result agendarAlocacaoReceita(final DateBinder dataEmissao) {
        try {
            alocacaoReceitaService.agendarAlocacaoReceitas( ARCOM.getValor(),dataEmissao.getValue());
            return ok(PROCESSAMENTO_OK);
        } catch (Throwable e) {
            
            return erro(e);
        }
    }

    @Transactional
    public Result gerarShellRecuperacao(final String tipoProcesso) {
        try {
            return ok( alocacaoCustoService.gerarShellRecuperacao(tipoProcesso) );
        } catch (Throwable e) {
            
            return erro(e);
        }
    }

    @Transactional
    public Result gerarShellFechamentoCusteio(final DateBinder dataCompetencia) {
        try {
            return ok( custeioClienteService.gerarShellFechamentoCusteio(dataCompetencia.getValue()) );
        } catch (Throwable e) {
            
            return erro(e);
        }
    }

    /*
    @Transactional
    public Result alocarFichaFinanceiraPorThread(final String processo,final ShortBinder idThread) {

        try {
            CustoPessoalService.processarThreadAlocacaoFichaFinanceira(processo,idThread.getValue());
            return ok(PROCESSAMENTO_OK);
        } catch (Throwable e) {
            
            return erro(e);
        }
    }


    @Transactional
    public Result alocarFeriasProvisionadasPorThread(final String processo,final ShortBinder idThread) {

        try {
            CustoPessoalService.processarThreadAlocacaoFeriasProvisionadas(processo,idThread.getValue());
            return ok(PROCESSAMENTO_OK);
        } catch (Throwable e) {
            
            return erro(e);
        }
    }

    @Transactional
    public Result alocarProvisaoDecimoTerceiroPorThread(final String processo,final ShortBinder idThread) {

        try {
            CustoPessoalService.processarThreadAlocacaoProvisaoDecimoTerceiro(processo,idThread.getValue());
            return ok(PROCESSAMENTO_OK);
        } catch (Throwable e) {
            
            return erro(e);
        }
    }

    @Transactional
    public Result alocarDiariasPorThread(final String processo,final ShortBinder idThread) {

        try {
            CustoPessoalService.processarThreadAlocacaoDiariasMotoristas(processo,idThread.getValue());
            return ok(PROCESSAMENTO_OK);
        } catch (Throwable e) {
            
            return erro(e);
        }
    }
    */

    @Transactional
    public Result processarIdRecuperacao( final Long idSigaRecuperacao) {

        try {
            alocacaoCustoService.processarIdRecuperacao(idSigaRecuperacao);
            return ok( PROCESSAMENTO_OK );
        }
        catch (Throwable e) {
            
            return erro(e);
        }
    }


//    @Transactional
//    public Result processarIdRecuperacaobackup( final Long idSigaRecuperacao ) {
//
//        try {
//            alocacaoCustoService.processarIdRecuperacao(idSigaRecuperacao);
//            return ok(PROCESSAMENTO_OK);
//        } catch (Throwable e) {
//            
//            return erro(e);
//        }
//    }

    /*
    @Transactional
    public Result processarIdRecuperacao(final long idSigaRecuperacao)  {

        //Logger.info ("Processando recuperacao " +  idSigaRecuperacao);

        try {
            AlocacaoCustoService.processarIdRecuperacao(idSigaRecuperacao);
            return ok(PROCESSAMENTO_OK);
        } catch (Throwable e) {
            
            return erro(e);
        }

    }

    @Transactional
    public Result alocarDespesaMedicaPorThread(final String processo,final ShortBinder idThread) {

        try {
            CustoPessoalService.processarThreadAlocacaoDespesaMedica(processo,idThread.getValue());
            return ok(PROCESSAMENTO_OK);
        } catch (Throwable e) {
            
            return erro(e);
        }
    }
    @Transactional
    public Result testeCleberCriarRegraAlocacaoPessoal(final ShortBinder idEmpresa, final DateBinder dataCompetencia) {

        System.out.println("Criando Regras de alocacao de custo de pessoal");
        try {
            FuncionarioAlocacaoCustoService.criarRegraAlocacao(idEmpresa.getValue(),dataCompetencia.getValue());
            return ok(PROCESSAMENTO_OK);
        } catch ( Throwable e ) {
            
            return erro(e);
        }
    }

    @Transactional
    public Result identificarDespesaVendas(final DateBinder dataCompetencia) {

        System.out.println("Criando Regras de alocacao de Despesa de Vendas");
        try {
            CustoVendasService.identificarDespesaVendas(dataCompetencia.getValue());
            return ok(PROCESSAMENTO_OK);
        } catch ( Throwable e ) {
            
            return erro(e);
        }
    }
    */

    @Transactional
    public Result gerarServicoResiduais(final DateBinder dataCompetencia) {

        try {
            return ok( alocacaoCustoService.gerarServicoResiduais(dataCompetencia.getValue()) );
        } catch ( Throwable e ) {
            
            return erro(e);
        }
    }

    @Transactional
    public Result alocarResidual(final long idControleCusto) {

        try {
            alocacaoCustoService.identificarValoresResiduais(idControleCusto);
            return ok(PROCESSAMENTO_OK);
        } catch ( Throwable e ) {
            
            return erro(e);
        }
    }

    @Transactional
    public Result agendar(final DateBinder dataCompetencia, final String tipoApuracao) {

        try {
            alocacaoCustoService.agendar(dataCompetencia.getValue(),tipoApuracao);
            return ok(PROCESSAMENTO_OK);
        } catch ( Throwable e ) {
            
            return erro(e);
        }
    }

    @Transactional
    public Result gerarRateiosEventuais(final DateBinder dataCompetencia) {

        try {
            custeioClienteService.gerarRateiosEventuais(dataCompetencia.getValue());
            return ok(PROCESSAMENTO_OK);
        } catch ( Throwable e ) {

            return erro(e);
        }
    }


    @Transactional
    public Result alocarDespesaPromotores(final DateBinder dataCompetencia) {

        try {
            custoVendasService.alocarDespesaPromotores(dataCompetencia.getValue());
            return ok(PROCESSAMENTO_OK);
        } catch ( Throwable e ) {
            
            return erro(e);
        }
    }


    @Transactional
    public Result alocarDespesaTransportes(final DateBinder dataCompetencia) {

        try {
            custoTransporteService.alocarDespesaTransportes(dataCompetencia.getValue());
            return ok(PROCESSAMENTO_OK);
        } catch ( Throwable e ) {

            return erro(e);
        }
    }

    @Transactional( readOnly = true )
    public Result gerarArquivoBonificacoesDescontosRecebidos( final DateBinder dataCompetencia ) {

        try {
            final Path path = alocacaoCustoService.gerarArquivoBonificacoesDescontosRecebidos( getValue( dataCompetencia ) );
            return ok( new File( path.toUri() ) );
        } catch ( Throwable e ) {
            return erro(e);
        }
    }

    @Transactional( readOnly = true )
    public Result checarPermissaoExecucaoCalculos( final DateBinder dataCompetencia, final ShortBinder fase ) {

        try {
            return ok(alocacaoCustoService.checarPermissaoExecucaoCalculos(dataCompetencia.getValue(),fase.getValue()));
        } catch ( Throwable e ) {
            return erro(e);
        }
    }

    @Transactional
    public Result gerarPlanilhaDebitosAbertos() {

        try {
            return ok( debitoRepository.gerarPlanilhaDebitosAbertos());
        } catch ( Throwable e ) {
            return erro(e);
        }
    }

    @Transactional
    public Result excluirMovimentoEbitda(final ShortBinder idEmpresa, final long idOcorrencia, final ShortBinder idSequencia) {
        try {
            alocacaoCustoService.gerarExclusaoMovimento(idEmpresa.getValue(),idOcorrencia,idSequencia.getValue());
            return ok(PROCESSAMENTO_OK);
        } catch ( Throwable e ) {
            return erro(e);
        }
    }

    @Transactional
    public Result cleber() {

        try {

            final LocalDate dataHoje = sistemaRepository.getDataHoje();

            final LocalDate dataPrimeiroDiaSemana  = UtilDate.getPrimeiroDiaSemana(dataHoje);

            final LocalDateTime dataPrimeiroDiaSemana3  =
                    toLocalDateTime(dataPrimeiroDiaSemana.equals(dataHoje) ? dataPrimeiroDiaSemana.minusDays(7) : dataPrimeiroDiaSemana);

            final LocalDateTime dataUltimoDiaSemana3 = dataHoje.atTime(23,59,59).minusDays(1);

            final LocalDateTime dataPrimeiroDiaSemana2 = dataPrimeiroDiaSemana3.minusDays(7);
            final LocalDateTime dataUltimoDiaSemana2 = dataPrimeiroDiaSemana2.toLocalDate().atTime(23,59,59).plusDays(6);

            final LocalDateTime dataPrimeiroDiaSemana1 = dataPrimeiroDiaSemana2.minusDays(7);
            final LocalDateTime dataUltimoDiaSemana1 = dataPrimeiroDiaSemana1.toLocalDate().atTime(23,59,59).plusDays(6);

            final LocalDateTime datataInicioAnoAtual =
                    toLocalDateTime(Objects.equals(dataHoje.getDayOfMonth(),1) ? dataHoje.minusMonths(1) : UtilDate.getPrimeiroDiaMes(dataHoje));

            final LocalDateTime dataFimAnoAtual = dataUltimoDiaSemana3;

            final LocalDateTime dataInicioAnoAnterior = datataInicioAnoAtual.minusYears(1);

            final LocalDateTime dataFimAnoAnterior = dataFimAnoAtual.minusYears(1);

            final Path nomeDoArquivo = getPastaTemporaria().resolve( "mapex.csv" );

            File file = new File(nomeDoArquivo.toAbsolutePath().toString());
            FileWriter fw = new FileWriter(file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fw);

            bw.write(String.format("Setor MAPEX;Setor Tradicional;QTD Clientes;Estado;Cidade;Faturado (C/IPI) %s a %s;Faturado (C/IPI) %s a %s; " +
                            "Pedidos MAPEX %s a %s;Pedidos MAPEX %s a %s;Pedidos MAPEX %s a %s \n",
                    UtilDate.getDataComoString(dataInicioAnoAnterior),
                    getDataComoString(dataFimAnoAnterior),
                    getDataComoString(datataInicioAnoAtual),
                    getDataComoString(dataFimAnoAtual),
                    getDataComoString(dataPrimeiroDiaSemana1),
                    getDataComoString(dataUltimoDiaSemana1),
                    getDataComoString(dataPrimeiroDiaSemana2),
                    getDataComoString(dataUltimoDiaSemana2),
                    getDataComoString(dataPrimeiroDiaSemana3),
                    getDataComoString(dataUltimoDiaSemana3)));

            List<VendaSetorMapexDto> vendaSetorMapexDtos = setorRepository.buscarVendaSetorMapexDto(ARCOM.getValor(),
                    dataInicioAnoAnterior,dataFimAnoAnterior,datataInicioAnoAtual,dataFimAnoAtual,dataPrimeiroDiaSemana1,dataUltimoDiaSemana1,
                    dataPrimeiroDiaSemana2,dataUltimoDiaSemana2,dataPrimeiroDiaSemana3,dataUltimoDiaSemana3);

            if (vendaSetorMapexDtos.size() > 0) {

                VendaSetorMapexDto.sortPorEstadoSetorMapex(vendaSetorMapexDtos);

                Long setorAnterior = 0L;

                for (VendaSetorMapexDto vendaSetorMapexDto : vendaSetorMapexDtos) {

                    final String setorMapexExibir = Objects.equals(setorAnterior,vendaSetorMapexDto.getSetorMapex()) ? "" :  vendaSetorMapexDto.getSetorMapex().toString();

                    if (Objects.equals("",setorMapexExibir) && vendaSetorMapexDto.getQtdClientes() < 5)  {
                        Logger.info("Descartando mapex {} - tradicional {} qtd cli {}",vendaSetorMapexDto.getSetorMapex(),vendaSetorMapexDto.getSetorTradicional(),
                                vendaSetorMapexDto.getQtdClientes());
                        continue;
                    }

                    setorAnterior = vendaSetorMapexDto.getSetorMapex();

                    bw.write(String.format("%s;%s;%s;%s;%s;%s;%s;%s;%s;%s\n",
                            setorMapexExibir,
                            vendaSetorMapexDto.getSetorTradicional(),
                            vendaSetorMapexDto.getQtdClientes(),
                            setorMapexExibir == "" ? "" : vendaSetorMapexDto.getEstado(),
                            setorMapexExibir == "" ? "" : vendaSetorMapexDto.getDescricao(),
                            UtilNumero.formatarString(vendaSetorMapexDto.getFaturadoMesAnoAnteriorMapex()),
                            setorMapexExibir == "" ? "" : UtilNumero.formatarString(vendaSetorMapexDto.getFaturadoMesAnoAtualMapex()),
                            setorMapexExibir == "" ? "" : UtilNumero.formatarString(vendaSetorMapexDto.getVendaSemana1Mapex()),
                            setorMapexExibir == "" ? "" : UtilNumero.formatarString(vendaSetorMapexDto.getVendaSemana2Mapex()),
                            setorMapexExibir == "" ? "" : UtilNumero.formatarString(vendaSetorMapexDto.getVendaSemanaAtualMapex())));

                }
            }

            bw.close();

            String msg = "Arquivo salvo em " + nomeDoArquivo;
            Logger.info(msg);

            return ok(msg);
        } catch (Throwable e) {

            return erro(e);
        }
    }

    /*
    @Transactional
    public Result gerarTotaisEbitda(final DateBinder dataCompetencia) {

        try {
            custeioClienteService.gerarTotaisPorCdaCdm(dataCompetencia.getValue());
            return ok(PROCESSAMENTO_OK);
        } catch ( Throwable e ) {
            return erro(e);
        }
    }

    @Transactional
    public Result gerarDetalheCustoCda( final ShortBinder idCda,
                                        final DateBinder dataCompetencia) {

        try {
            return ok( alocacaoCustoService.gerarDetalheCustoCda(dataCompetencia.getValue(),idCda.getValue()) );
        } catch ( Throwable e ) {
            return erro(e);
        }

    }
    */

    /**
     *
     * <p>Autor: Cleber</p>
     *
     * @return
     */
    @Transactional
    public  Result gerarArquivoResumoTransportes(final DateBinder dataCompetencia) {

        try {
            return ok( alocarDespesaService.gerarArquivoResumoTransportes(dataCompetencia.getValue()));
        } catch ( Throwable e ) {
            return erro(e);
        }

    }

    /**
     *
     * <p>Autor: Cleber</p>
     *
     * @return
     */
    @Transactional
    public  Result atualizarKmRodadoViagens() {

        try {
            custoTransporteService.atualizarKmRodadoViagens();
            return ok(PROCESSAMENTO_OK);
        } catch ( Throwable e ) {
            return erro(e);
        }
    }


    /**
     *
     * <p>Autor: Cleber</p>
     *
     * @return
     */
    @Transactional
    public  Result alocarCustos(final DateBinder dataCompetencia) {

        try {
            return ok( alocarDespesaService.apropriarCustos(dataCompetencia.getValue()));
        } catch ( Throwable e ) {
            return erro(e);
        }
    }

    /**
     *
     * <p>Autor: Cleber</p>
     *
     * @return
     */
    @Transactional
    public  Result gerarPcpEstoque(final DateBinder dataInicio, final DateBinder dataFim) {

        try {
            return ok( pcpService.gerarPcpEstoque(UtilDate.zerarHoras(dataInicio.getValue()),UtilDate.setarHora_23_59_00(dataFim.getValue()),false));
        } catch ( Throwable e ) {
            return erro(e);
        }
    }

    /**
     *
     * <p>Autor: Cleber</p>
     *
     * @return
     */
    @Transactional
    public  Result gerarDemandaEPanilhaDetalhada(final DateBinder dataInicio, final DateBinder dataFim) {

        try {
            pcpService.gerarDemandaEstoque(UtilDate.zerarHoras(dataInicio.getValue()),UtilDate.setarHora_23_59_00(dataFim.getValue()));
            return ok( pcpService.gerarPlanilhaPcpDetalhado(dataInicio.getValue(),dataFim.getValue()));
        } catch ( Throwable e ) {
            return erro(e);
        }
    }


    /**
     *
     * <p>Autor: Cleber</p>
     *
     * @return
     */
    @Transactional
    public  Result gerarDemandaEPcpPendente(final DateBinder dataInicio, final DateBinder dataFim) {

        try {
            return ok(pcpService.gerarDemandaEPcpEstoquePendente(UtilDate.zerarHoras(dataInicio.getValue()),UtilDate.setarHora_23_59_00(dataFim.getValue())));
        } catch ( Throwable e ) {
            return erro(e);
        }
    }


    /**
     *
     * <p>Autor: Cleber</p>
     *
     * @return
     */
    @Transactional
    public  Result gerarDemandaEPcpEstoque(final DateBinder dataInicio, final DateBinder dataFim) {

        try {
            return ok( pcpService.gerarDemandaEPcpEstoque(UtilDate.zerarHoras(dataInicio.getValue()),UtilDate.setarHora_23_59_00(dataFim.getValue())));
        } catch ( Throwable e ) {
            return erro(e);
        }
    }

    /**
     *
     * <p>Autor: Cleber</p>
     *
     * @return
     */
    @Transactional
    public  Result gerarDemandaEstoque(final DateBinder dataInicio, final DateBinder dataFim) {

        try {
            return ok(pcpService.gerarPcpEstoque(UtilDate.zerarHoras(dataInicio.getValue()),UtilDate.setarHora_23_59_00(dataFim.getValue()),false));
        } catch ( Throwable e ) {
            return erro(e);
        }
    }


    @Transactional
    public Result gerarCadastroCda(final DateBinder dataCompetencia) {
        try {
            custoTransporteService.gerarInformacoesCadastroCda(dataCompetencia.getValue());
            return ok(PROCESSAMENTO_OK);
        } catch ( Throwable e ) {
            return erro(e);
        }

    }
    private Result erro( Throwable throwable ) {

        sistemaRepository.setRollbackOnly();

        String msgErro = getExceptionComoString( throwable );

        try {
            final EnvelopeDto envelopeDto = new EnvelopeDto
                    .Builder( "CLEBER CONTROLLER" )
                    .comMensagem( msgErro )
                    .comDestinatarios( "cleber.silva@arcom.com.br","java@arcom.com.br")
                    .build();
            emailErro.enviar( envelopeDto );
        } catch ( BusinessException e ) {
            msgErro = msgErro + e.getMessage();
        }

        return badRequest( msgErro );
    }

    @Transactional( readOnly = true )
    public Result buscarBoxCargaRecipiente( final String codBarra ) {

        try {
            return ok( pcpService.buscarBoxCargaRecipiente(codBarra) );
        } catch ( Throwable e ) {
            return erro(e);
        }
    }

    @Transactional
    public Result alocarBonificacaoDiretaCliente(final Long idDescontoBonifCmv) {

        try {
            alocacaoReceitaService.alocarBonificacaoDiretaCliente(idDescontoBonifCmv);
            return ok( PROCESSAMENTO_OK );
        } catch ( Throwable e ) {
            return erro(e);
        }
    }

    @Transactional
    public Result enviarEmailMapaVeiculosVendas(final String email) {
        try {

            String destinatario = email;
            if (!email.contains("@arcom.com.br"))
                destinatario = destinatario + "@arcom.com.br";

            String erro = "";
            //final String local = parametroRepository.buscarCaminhoGravarArquivoEmail( ARCOM );

            final String local = "/Users/clebersilva/Desktop/";

            Map<String,String> map = mapaService.getMapaVeiculosVendas();

            final String conteudo = views.html.api.mapa.geral.mapaGeral.render( map.get("assunto"), map.get("mapa") ).body();

            final String arquivoMapa = local + "mapa-veiculos-vendas.html";

            if ( gravarTexto( arquivoMapa, conteudo ) ) {
                /*
                emailService.enviar(
                        new EnvelopeDto.Builder(map.get("assunto"))
                                .comMensagem(map.get("mensagem"))
                                .comArquivos(arquivoMapa)
                                .comDestinatarios(destinatario)
                                .comExclusao()
                                .build());
                                */
            }
            else {
                erro = format("Falhou geração do arquivo: %s\n", arquivoMapa);
            }

            if ( UtilString.isVazia(erro) )
                return ok( PROCESSAMENTO_OK );

            return badRequest( erro );

        } catch ( Throwable e ) {

            sistemaRepository.setRollbackOnly();
            return badRequest( getExceptionComoString(e) );
        }
    }

}
