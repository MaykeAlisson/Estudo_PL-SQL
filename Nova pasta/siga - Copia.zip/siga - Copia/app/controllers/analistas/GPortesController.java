package controllers.analistas;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import controllers.AuthController;
import infra.util.UtilDate;
import models.commons.constantes.Estado;
import models.commons.constantes.OrigemPedidoECommerce;
import models.commons.constantes.SimNao;
import models.commons.constantes.SituacaoPedidoECommerce;
import models.commons.constantes.TipoPessoa;
import models.commons.dtos.DadosECommerceDto;
import models.commons.dtos.EnvelopeDto;
import models.domains.rh.FuncionarioRhId;
import models.domains.vendas.PedidoECommerce;
import models.domains.vendas.PedidoECommerceCorreio;
import models.domains.vendas.PedidoECommerceItem;
import models.repository.rh.FuncionarioRhRepository;
import models.repository.vendas.PedidoECommerceCorreioRepository;
import models.repository.vendas.PedidoECommerceItemRepository;
import models.repository.vendas.PedidoECommerceRepository;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.Result;
import play.mvc.Results;
import services.admin.EmailService;
import services.transporte.GeolocalizacaoService;

import javax.inject.Inject;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import static infra.util.UtilDate.FORMATO_JSON_DATA_HORA_MINUTO;
import static infra.util.UtilException.getException;
import static infra.util.UtilException.getExceptionComoString;
import static infra.util.UtilString.isVazia;
import static infra.util.UtilString.trim;
import static java.lang.String.format;
import static models.commons.constantes.TipoServicoCorreio.PAC_CONTRATO_AGENCIA;

/**
 * Controladora de testes !!
 */
public class GPortesController extends AuthController {

    private final FuncionarioRhRepository funcionarioRhRepository;
    private final EmailService emailService;
    private final GeolocalizacaoService geolocalizacaoService;
    private final PedidoECommerceRepository pedidoECommerceRepository;
    private final PedidoECommerceCorreioRepository pedidoECommerceCorreioRepository;
    private final PedidoECommerceItemRepository pedidoECommerceItemRepository;

    @Inject
    public GPortesController( FuncionarioRhRepository funcionarioRhRepository, EmailService emailService, GeolocalizacaoService geolocalizacaoService, PedidoECommerceRepository pedidoECommerceRepository, PedidoECommerceCorreioRepository pedidoECommerceCorreioRepository, PedidoECommerceItemRepository pedidoECommerceItemRepository ) {
        this.funcionarioRhRepository = funcionarioRhRepository;
        this.emailService = emailService;
        this.geolocalizacaoService = geolocalizacaoService;
        this.pedidoECommerceRepository = pedidoECommerceRepository;
        this.pedidoECommerceCorreioRepository = pedidoECommerceCorreioRepository;
        this.pedidoECommerceItemRepository = pedidoECommerceItemRepository;
    }

    @Transactional
    public Result index() {

        try {

            Map<String,String> map = new HashMap<>();
            map.put( "document","03226355600" );
            map.put("first_name", "");
            map.put("last_name", "");
            map.put("email","");
            map.put("phone","");
            map.put("postal_code","38400372");
            map.put("street","");
            map.put("number","");
            map.put("complement","");
            map.put("reference","");
            map.put("neighborhood","");
            map.put("city","");
            map.put("state","");
            map.put("address","");



            new DadosECommerceDto(
            10L,
            BigDecimal.TEN,
            "confirmed",
            "11",
            LocalDateTime.now(),
            BigDecimal.TEN,
            "PAC",
            null,
                Json.toJson(map)
            );

            return ok(  );

        } catch ( final Throwable e ) {
            return badRequestRollback( e );
        }
    }

    @Transactional
    public Result atualizarCoordenadas() {

        try {
            geolocalizacaoService.atualizarUltimaCoordenadaDeTodosVeiculos( );
            return ok();
        } catch ( Throwable e ) {
            return badRequestRollback(e);
        }
    }

    @Transactional( readOnly = true )
    public Result buscarEndereco( final Long idMatricula ) {

        try {
            if ( idMatricula == null )
                throw new NullPointerException( "Favor informar [ matricula ]" );

            return funcionarioRhRepository
                .findById(new FuncionarioRhId((short) 1, idMatricula ))
                .map(func -> {
                    ObjectNode result = Json.newObject();
                    result.put( "idMatricula", func.getIdFuncionario() );
                    result.put( "nome", func.getNomeCompleto() );
                    result.put( "admissao", UtilDate.toString( func.getAdmissao(), FORMATO_JSON_DATA_HORA_MINUTO ) );
                    result.put( "endereco", format("%s %s %s", func.getLogradouro(), func.getEndereco(), func.getNroEndereco() ) );
                    return result;
                })
                .map( Results::ok )
                .orElse( noContent() );
        } catch ( Throwable e ) {
            return badRequest( getException(e) );
        }
    }

    @Transactional
    public Result enviarEmail() {

        try {
            final String assunto = trim( getString("assunto") );
            if ( isVazia(assunto) )
                throw new NullPointerException( "Obrigatório informar [ assunto ] do email!!" );
            if ( assunto.length() > 60 )
                throw new IllegalArgumentException( "Assunto do email não pode exceder 60 caracteres!!" );

            emailService.enviar(
                new EnvelopeDto
                    .Builder(assunto)
                    .comDestinatarios( "suender@arcom.com.br" )
                    .comMensagem( "Prova de conceito (Proxy reverso) -> nginx -> Play" )
                    .build()
            );
            return ok();
        } catch ( Throwable e ) {
            return badRequestRollback( e );
        }
    }



    public Result testar2() {

        Session session = null;
        Channel channel = null;
        ChannelSftp sftpChannel = null;
        try {
            JSch jsch = new JSch();
            session = jsch.getSession("cleber", "172.30.20.125", 22);
            session.setConfig("StrictHostKeyChecking", "no");
            session.setPassword("arcom2000");
            session.connect();
            channel = session.openChannel("sftp");
            channel.connect();
            sftpChannel = (ChannelSftp) channel;
            sftpChannel.get("//home//cleber//scripts//teste.txt", "e:\\teste.txt");
            return ok( "copiado...");
        } catch (SftpException | JSchException e) {
            return badRequest( getExceptionComoString( e ) );
        } finally {
            if ( sftpChannel != null  ) {
                sftpChannel.exit();
                sftpChannel.disconnect();
            }
            if ( channel != null )
                channel.disconnect();
            if ( session != null )
                session.disconnect();
        }
    }

    private void insert1() {

        PedidoECommerce pedidoECommerce = new PedidoECommerce();
        pedidoECommerce.setId(5L);
        pedidoECommerce.setOrigem(OrigemPedidoECommerce.TELEARCOM);
        pedidoECommerce.setIdPedidoOrigem("NF_14004759");
        pedidoECommerce.setSituacao(SituacaoPedidoECommerce.NAO_PROCESSADO);
        pedidoECommerce.setTipoPessoa(TipoPessoa.FISICA);
        pedidoECommerce.setNroInscricao(2678966119L);
        pedidoECommerce.setNomePessoa( "DIEGO LUIZ LIMA FIDELIS VEIGA" );
        pedidoECommerce.setNomeDestinatarioEntrega( "DIEGO LUIZ LIMA FIDELIS VEIGA" );
        pedidoECommerce.setTelefone(991706996L);
        pedidoECommerce.setCep(79081650L);
        pedidoECommerce.setEmail("diego.veiga@tecsinapse.com.br");
        pedidoECommerce.setBairro("JARDIM PARATI");
        pedidoECommerce.setLogradouro("RUA");
        pedidoECommerce.setEndereco("DA DIVISAO");
        pedidoECommerce.setNroEndereco("975");
        pedidoECommerce.setComplementoEndereco("CASA 336");
        pedidoECommerce.setEnderecoReferencia("VILAGIO PARATI");
        final LocalDateTime agora = LocalDateTime.now();
        pedidoECommerce.setDataEntrada( agora );
        pedidoECommerce.setDataPedido( agora.minusMinutes(1) );
        pedidoECommerce.setDescricaoCidade("CAMPO GRANDE");
        pedidoECommerce.setEstado(Estado.MATO_GROSSO_DO_SUL);
        pedidoECommerce.setValorPedido(new BigDecimal("69.90"));
        pedidoECommerce.setValorFrete(BigDecimal.ZERO);
        pedidoECommerceRepository.save(pedidoECommerce);

        PedidoECommerceCorreio pedidoECommerceCorreio = new PedidoECommerceCorreio();
        pedidoECommerceCorreio.setId(5L);
        pedidoECommerceCorreio.setTipoServicoCorreio(PAC_CONTRATO_AGENCIA);
        pedidoECommerceCorreio.setGerarEtiqueta(SimNao.NAO);
        pedidoECommerceCorreioRepository.save(pedidoECommerceCorreio);

        PedidoECommerceItem item = new PedidoECommerceItem();
        item.setIdPedidoECommerce(5L);
        item.setSku("35664");
        item.setQtdVendida((short) 1);
        item.setPrecoUnitario( new BigDecimal("69.90") );
        pedidoECommerceItemRepository.save(item);
    }

    private void insert2() {
        PedidoECommerce pedidoECommerce = new PedidoECommerce();
        pedidoECommerce.setId(6L);
        pedidoECommerce.setOrigem(OrigemPedidoECommerce.TELEARCOM);
        pedidoECommerce.setIdPedidoOrigem("NF_14059085");
        pedidoECommerce.setSituacao(SituacaoPedidoECommerce.NAO_PROCESSADO);
        pedidoECommerce.setTipoPessoa(TipoPessoa.FISICA);

        pedidoECommerce.setNroInscricao(80415628920L);
        pedidoECommerce.setNomePessoa( "ADRIANA MARTINS MARCONDES" );
        pedidoECommerce.setNomeDestinatarioEntrega( "ADRIANA MARTINS MARCONDES" );
        pedidoECommerce.setTelefone(999929915L);
        pedidoECommerce.setEmail("drikapmarcondes@hotmail.com");

        pedidoECommerce.setLogradouro("RUA");
        pedidoECommerce.setEndereco("DANIEL CLEVE");
        pedidoECommerce.setNroEndereco("510");
        pedidoECommerce.setBairro("BOMSUCESSO");
        pedidoECommerce.setDescricaoCidade("GUARAPUAVA");
        pedidoECommerce.setEstado(Estado.PARANA);
        pedidoECommerce.setCep(85055210L);

        final LocalDateTime agora = LocalDateTime.now();
        pedidoECommerce.setDataEntrada( agora );
        pedidoECommerce.setDataPedido( agora.minusMinutes(1) );
        pedidoECommerce.setValorPedido(new BigDecimal("69.90"));
        pedidoECommerce.setValorFrete(BigDecimal.ZERO);
        pedidoECommerceRepository.save(pedidoECommerce);

        PedidoECommerceCorreio pedidoECommerceCorreio = new PedidoECommerceCorreio();
        pedidoECommerceCorreio.setId(6L);
        pedidoECommerceCorreio.setTipoServicoCorreio(PAC_CONTRATO_AGENCIA);
        pedidoECommerceCorreio.setGerarEtiqueta(SimNao.NAO);
        pedidoECommerceCorreioRepository.save(pedidoECommerceCorreio);

        PedidoECommerceItem item = new PedidoECommerceItem();
        item.setIdPedidoECommerce(6L);
        item.setSku("35664");
        item.setQtdVendida((short) 1);
        item.setPrecoUnitario( new BigDecimal("69.90") );
        pedidoECommerceItemRepository.save(item);

    }
}





/*
    public static <T> void jsonSaveAsPdf(
            final List<T> lista,
            final Path arquivoJasper,
            final Path destino
    ) {

        requiredNonEmpty( lista, "Obrigatório informar [ lista ]" );
        requireNonNull( arquivoJasper, "Obrigatório informar [ nomeArquivoJasper ]" );
        requireNonNull( destino, "Obrigatório informar [ nomeArquivo ]" );

        if ( !exists( arquivoJasper ) )
            throw new InfraException( format( "Não localizou [%s] ", arquivoJasper ) );

        final String jsonString = UtilJson
                .convListToJsonString( lista )
                .orElseThrow(() -> new InfraException("Falha ao ler JSON"));

        final Path saida = getPastaTemporaria().resolve( gerarNomeRandomico("pdf") );

        try ( final InputStream jsonStream = new ByteArrayInputStream( jsonString.getBytes()) ) {

            final JsonDataSource dataSource = new JsonDataSource( jsonStream, "" );
            dataSource.setDatePattern( FORMATO_JSON_DATA );

            final JasperPrint jasperPrint = JasperFillManager.fillReport(
                    arquivoJasper.toString(),
                    null,
                    dataSource
            );

            JasperExportManager.exportReportToPdfFile( jasperPrint, saida.toString() );

            move( saida, destino, REPLACE_EXISTING );

        } catch ( final IOException | JRException e ) {

            throw new InfraException( e );

        } finally {

            excluirArquivo( saida );
        }

    }

*/