package controllers.creceber;

import controllers.AuthController;
import infra.binders.BigDecimalBinder;
import models.commons.dtos.BaixaECommerceDto;
import models.commons.dtos.BaixaPedidoECommerceDto;
import models.repository.vendas.BaixaECommerceRepository;
import play.db.jpa.Transactional;
import play.mvc.Result;
import services.admin.TaxaEcommerceService;
import services.contasReceber.BaixaECommerceService;
import javax.inject.Inject;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilException.getException;
import static infra.util.UtilJson.toList;
import static play.libs.Json.stringify;
import static play.libs.Json.toJson;

public class BaixaECommerceController extends AuthController {

    // Service:
    private final BaixaECommerceService baixaECommerceService;
    private final TaxaEcommerceService taxaEcommerceService;

    // Repository:
    private final BaixaECommerceRepository baixaECommerceRepository;



    @Inject
    public BaixaECommerceController(
            final BaixaECommerceService baixaECommerceService,
            TaxaEcommerceService taxaEcommerceService, final BaixaECommerceRepository baixaECommerceRepository) {

        this.baixaECommerceService = baixaECommerceService;
        this.taxaEcommerceService = taxaEcommerceService;
        this.baixaECommerceRepository = baixaECommerceRepository;

    }

    @Transactional(readOnly = true)
    public Result buscar(
            final String tipo,
            final String nomeArquivo
    ) {
        try {
            if (Objects.equals(tipo, "nomes")) {
                final List<String> nomeArquivos = baixaECommerceRepository.buscarNomeArquivos();
                return isVazia(nomeArquivos)
                        ? noContent()
                        : ok(toJson(nomeArquivos));
            }
            final List<BaixaPedidoECommerceDto> dtos = baixaECommerceRepository.buscarAbertos(nomeArquivo);
            return isVazia(dtos) ? noContent() : ok(toJson(dtos));
        } catch (final Throwable e) {
            return badRequest(getException(e));
        }
    }

    @Transactional
    public Result importarArquivo(final String nomeArquivo) {
        try {
            final Map<String, String[]> valorfile = request().body().asFormUrlEncoded();
            if (isVazia(valorfile))
                return badRequest("Favor informar arquivo");
            final List<BaixaECommerceDto> baixasJaRegistradas = baixaECommerceService.importarDados(
                    nomeArquivo,
                    valorfile.keySet());
            return ok(toJson(baixasJaRegistradas));
        } catch (final Throwable e) {
            return badRequestRollback(e);
        }
    }

    @Transactional
    public Result baixarDocto() {
        try {
            final List<BaixaPedidoECommerceDto> baixas = toList(
                    getJsonBody(),
                    "baixas",
                    BaixaPedidoECommerceDto.class);

            baixaECommerceService.baixarDoctos(baixas, getRequest().getIdUsuario());
            return ok();
        } catch (final Throwable e) {
            return badRequestRollback(e);
        }
    }


    @Transactional
    public Result buscaTaxa() {
        try {
            return ok(toJson(taxaEcommerceService.buscaTaxa()));
        } catch (final Throwable e) {
            return badRequestRollback(e);
        }
    }

    @Transactional
    public Result atualizaTaxa(BigDecimalBinder vlrTaxa) {
        try {
            taxaEcommerceService.atualizaTaxa(vlrTaxa,getRequest().getIdUsuario());
            return ok();
        } catch (final Throwable e) {
            return badRequestRollback(e);
        }
    }

}



