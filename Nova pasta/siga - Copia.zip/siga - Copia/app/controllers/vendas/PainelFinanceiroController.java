package controllers.vendas;

import controllers.AuthController;
import infra.binders.LocalDateBinder;
import infra.binders.ShortBinder;
import infra.exceptions.BusinessException;
import infra.util.UtilDate;
import infra.util.UtilNumero;
import infra.util.UtilString;
import models.commons.dtos.SaldoAppBalancoDto;
import models.commons.dtos.SaldoContaDREDto;
import models.repository.admin.SistemaRepository;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.Result;
import services.vendas.PainelFinanceiroService;

import javax.inject.Inject;
import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import static infra.util.UtilException.getException;

/**
 * Alysson Myller
 * 27/08/2018
 */
public class PainelFinanceiroController extends AuthController {

    private static final int HORA_VIRADA_PAINEL_FINANCEIRO = 12;

    private final PainelFinanceiroService painelFinanceiroService;
    private final SistemaRepository sistemaRepository;

    @Inject
    public PainelFinanceiroController(PainelFinanceiroService painelFinanceiroService, SistemaRepository sistemaRepository) {
        this.painelFinanceiroService = painelFinanceiroService;
        this.sistemaRepository = sistemaRepository;
    }

    /**
     * Alysson Myller
     * 05/09/2018
     *
     * Só criei esse método para ter um link direto do PowerBatch - como o pb não consegue passar parâmetro, tive que
     * criar esse método separado
     *
     * @param idEmpresa
     * @return
     */
    @Transactional
    public Result compoeSaldosDia(ShortBinder idEmpresa) {
        try {
            // Como a composição de saldos mostra do dia anterior (ou de dois dias anteriores),
            // tenho que compor os saldos do dia anterior
            LocalDate localDate = this.getMelhorDataComporSaldosPainel();
            if (Objects.isNull(localDate)) {
                return ok(Json.toJson("OK"));
            }

            this.compoeSaldosDiaPorData(idEmpresa, new LocalDateBinder(localDate));
            return ok(Json.toJson("OK"));
        } catch ( Throwable e){
            return badRequestRollback(e);
        }
    }

    /**
     * Alysson Myller
     *
     * @param idEmpresa
     * @param dateBinder
     * @return
     */
    @Transactional
    public Result compoeSaldosDiaPorData(ShortBinder idEmpresa, LocalDateBinder dateBinder) {
        try {
            this.painelFinanceiroService.compoeSaldosDoDia(idEmpresa.getValue(), dateBinder.getValue());
            return ok(Json.toJson("OK"));
        } catch ( Throwable e ){
            return badRequestRollback(e);
        }
    }

    /**
     *
     * @return
     */
    private LocalDate getMelhorDataComporSaldosPainel() {
        LocalDateTime melhorData = this.sistemaRepository.getDataHojeHora();

        //the day-of-week, from 1 (Monday) to 7 (Sunday)
        DayOfWeek dow = melhorData.getDayOfWeek();
        int dayOfWeek = dow.getValue();

        switch (dow){
            case MONDAY:
                melhorData = UtilDate.adicionarNDias(-3, melhorData);
                break;
            case TUESDAY:
                melhorData = UtilDate.adicionarNDias(-1, melhorData);
                break;
            case WEDNESDAY:
                melhorData = UtilDate.adicionarNDias(-1, melhorData);
                break;
            case THURSDAY:
                melhorData = UtilDate.adicionarNDias(-1, melhorData);
                break;
            case FRIDAY:
                melhorData = UtilDate.adicionarNDias(-1, melhorData);
                break;
            case SATURDAY:
                // NÃO FAZ NADA - RETORNA A DATA DE HOJE PARA TER LANÇAMENTOS NO SÁBADO
                // TEM QUE TER LANÇAMENTO EM SABADO E DOMINGO PQ SE O MES ACABA FDS ELE NÃO MOSTRA O MES FECHADO
                break;
            case SUNDAY:
                // NÃO FAZ NADA - RETORNA A DATA DE HOJE PARA TER LANÇAMENTOS NO SÁBADO
                // TEM QUE TER LANÇAMENTO EM SABADO E DOMINGO PQ SE O MES ACABA FDS ELE NÃO MOSTRA O MES FECHADO
                break;
        }

        return melhorData != null ? melhorData.toLocalDate() : null;
    }

    /**
     * Alysson Myller
     * 10/09/2018
     *
     * @return A melhor data para visualização do painel de acordo com a data de hoje
     */
    private LocalDate getMelhorDataVisualizacaoPainel() {
        LocalDateTime melhorData = this.sistemaRepository.getDataHojeHora();

        // Conversei com o Marco Andrey e ele disse que a Contabilidade faz todo o lançamento
        // do dia anterior até as 12:00, ou seja, se for após as 12:00, podemos mostrar
        // os dados com D-1, se for antes das 12:00, mostramos D-2 - Alysson Myller 18/09/2018
        boolean posMeioDia = melhorData.getHour() > HORA_VIRADA_PAINEL_FINANCEIRO;

        //the day-of-week, from 1 (Monday) to 7 (Sunday)
        DayOfWeek dow = melhorData.getDayOfWeek();
        int dayOfWeek = dow.getValue();

        switch (dow){
            case MONDAY:
                melhorData = UtilDate.adicionarNDias(posMeioDia ? -3 : -4, melhorData);
                break;
            case TUESDAY:
                melhorData = UtilDate.adicionarNDias(posMeioDia ? -1 : -4, melhorData);
                break;
            case WEDNESDAY:
                melhorData = UtilDate.adicionarNDias(posMeioDia ? -1 : -2, melhorData);
                break;
            case THURSDAY:
                melhorData = UtilDate.adicionarNDias(posMeioDia ? -1 : -2, melhorData);
                break;
            case FRIDAY:
                melhorData = UtilDate.adicionarNDias(posMeioDia ? -1 : -2, melhorData);
                break;
            case SATURDAY:
                melhorData = UtilDate.adicionarNDias(-2, melhorData);
                break;
            case SUNDAY:
                melhorData = UtilDate.adicionarNDias(-3, melhorData);
                break;
        }

        return melhorData.toLocalDate();
    }

    /**
     * Alysson Myller
     *
     * @param idEmpresa
     * @return
     */
    @Transactional( readOnly = true )
    public Result buscar(ShortBinder idEmpresa) {
        // A ultima data contabilizada do mes atual
        LocalDate ultimaDataDisponivel = this.getMelhorDataVisualizacaoPainel();

        // A ultima data do mes passado (aqui ele esta sumarizado e mostrando o valor integral - fechado - do ultimo mes)
        LocalDate mesPassado = UtilDate.adicionarNMeses(-1, ultimaDataDisponivel);
        mesPassado = UtilDate.getUltimoDiaMes(mesPassado);

        return buscarPorDatas(idEmpresa, new LocalDateBinder(ultimaDataDisponivel), new LocalDateBinder(mesPassado));
    }

    @Transactional( readOnly = true )
    public Result buscarPorDatas(ShortBinder idEmpresa, LocalDateBinder dataAtual, LocalDateBinder dataAnterior) {
        try {
            if (Objects.isNull(dataAtual) || Objects.isNull(dataAnterior)){
                throw new IllegalStateException("Obrigatório informar as datas dataAtual e dataAnterior");
            }

            /* ==========================================================
             * =============== COMPOE OS SALDOS CONTABEIS ===============
             * ========================================================== */
            List<SaldoAppBalancoDto> saldosAtivo = new ArrayList<>();
            List<SaldoAppBalancoDto> saldosPassivo = new ArrayList<>();
            
            BigDecimal vlrTotalAtivoAtual = BigDecimal.ZERO;
            BigDecimal vlrTotalAtivoAnterior = BigDecimal.ZERO;
            BigDecimal vlrTotalPassivoAtual = BigDecimal.ZERO;
            BigDecimal vlrTotalPassivoAnterior = BigDecimal.ZERO;

            LocalDate mesAtual = dataAtual.getValue();
            mesAtual = UtilDate.getPrimeiroDiaMes(mesAtual);
            LocalDate mesAnterior = UtilDate.adicionarNMeses(-1, mesAtual);

            List<SaldoAppBalancoDto> saldos = this.painelFinanceiroService.buscarSaldosAppBalanco(idEmpresa.getValue(), dataAtual.getValue(), dataAnterior.getValue());

            /* ======================================================================
             * =============== ATUALIZA VALOR PASSIVO COM LUCRO LIQUIDO ===============
             * ====================================================================== */
            BigDecimal vlrLucroLiquidoMesAtual = this.painelFinanceiroService.buscarVlrLucroLiquido(idEmpresa.getValue(), mesAtual);
            BigDecimal vlrLucroLiquidoMesAnterior = this.painelFinanceiroService.buscarVlrLucroLiquido(idEmpresa.getValue(), mesAnterior);

            SaldoAppBalancoDto dtoLucroAcumulado = new SaldoAppBalancoDto();
            dtoLucroAcumulado.setDescricao("LUCRO DO EXERCÍCIO");
            dtoLucroAcumulado.setNivel(new Short("5"));
            dtoLucroAcumulado.setConta("29999");
            dtoLucroAcumulado.setSaldoAtual(vlrLucroLiquidoMesAtual != null ? vlrLucroLiquidoMesAnterior : BigDecimal.ZERO);
            dtoLucroAcumulado.setSaldoAnterior(vlrLucroLiquidoMesAnterior != null ? vlrLucroLiquidoMesAnterior : BigDecimal.ZERO);
            saldos.add(dtoLucroAcumulado);

            /* ======================================================================
             * =============== DIVIDE ENTRE ATIVOS E PASSIVOS ===============
             * ====================================================================== */
            for (SaldoAppBalancoDto saldo : saldos){
                if (possuiValoresZerados(saldo)){
                    continue;
                }
                if (saldo.getConta().startsWith("1")){
                    saldosAtivo.add(saldo);
                    if (new Short("5").equals(saldo.getNivel())) {
                        vlrTotalAtivoAtual = vlrTotalAtivoAtual.add(saldo.getSaldoAtual());
                        vlrTotalAtivoAnterior = vlrTotalAtivoAnterior.add(saldo.getSaldoAnterior());
                    }
                } else if (saldo.getConta().startsWith("2")){
                    saldosPassivo.add(saldo);
                    if (new Short("5").equals(saldo.getNivel())) {
                        vlrTotalPassivoAtual = vlrTotalPassivoAtual.add(saldo.getSaldoAtual());
                        vlrTotalPassivoAnterior = vlrTotalPassivoAnterior.add(saldo.getSaldoAnterior());
                    }
                } else {
                    // Não faz nada - podem ser as contas 3 e 4
                }
            }

            /* =======================================================
             * =============== COMPOE OS SALDOS DE DRE ===============
             * ======================================================= */
            List<SaldoContaDREDto> saldosDRESumarizados = this.getSaldoContaDREDtos(mesAtual, mesAnterior);
            LocalDate ultimaDataDisponivel = this.getMelhorDataVisualizacaoPainel();
            LocalDate ultimaDataDisponivelOntem = UtilDate.adicionarNDias(-1, ultimaDataDisponivel);
            // String descricaoMesAtual = mesAtual.getMonth().getDisplayName(TextStyle.FULL, new Locale("pt", "BR")) + " " + mesAtual.getYear();
            String descricaoMesAnterior = mesAnterior.getMonth().getDisplayName(TextStyle.FULL, new Locale("pt", "BR")) + " " + mesAtual.getYear();
            String descricaoHoje = "Até " + UtilDate.getDataComoString(ultimaDataDisponivel, "dd/MM");
            String descricaoOntem = "Até " + UtilDate.getDataComoString(ultimaDataDisponivelOntem, "dd/MM");

            /* =======================================================
             * =============== MONTA O JSON DE RESULT ================
             * ======================================================= */
            final Map<String, Object> result = new HashMap<>();
            result.put("ativo", saldosAtivo);
            result.put("passivo", saldosPassivo);
            result.put("dataAtual", UtilDate.getDataComoString(dataAtual.getValue(), "dd/MM/yyyy"));
            result.put("dataAnterior", UtilDate.getDataComoString(dataAnterior.getValue(), "dd/MM/yyyy"));
            result.put("vlrTotalAtivoAtual", vlrTotalAtivoAtual);
            result.put("vlrTotalAtivoAnterior", vlrTotalAtivoAnterior);
            result.put("vlrTotalPassivoAtual", vlrTotalPassivoAtual);
            result.put("vlrTotalPassivoAnterior", vlrTotalPassivoAnterior);
            result.put("dre", saldosDRESumarizados);
            result.put("dreMesAtual", descricaoHoje);
            result.put("dreMesAtualOntem", descricaoOntem);
            result.put("dreMesAnterior", descricaoMesAnterior.toUpperCase());

            return ok(Json.toJson(result));
        } catch ( Throwable ex ) {
            return badRequest( getException(ex) );
        }
    }

    /**
     * Alysson Myller
     *
     * @param saldo
     * @return
     */
    private boolean possuiValoresZerados(SaldoAppBalancoDto saldo) {
        if (Objects.isNull(saldo.getSaldoAnterior()) && Objects.isNull(saldo.getSaldoAtual())){
            return true;
        }
        if (BigDecimal.ZERO.compareTo(saldo.getSaldoAnterior()) == 0 && BigDecimal.ZERO.compareTo(saldo.getSaldoAtual()) == 0){
            return true;
        }
        return false;
    }

    /**
     * Alysson Myller
     * 04/09/2018
     *
     * @return
     */
    private List<SaldoContaDREDto> getSaldoContaDREDtos(LocalDate mesAtual, LocalDate mesAnterior) {
        List<SaldoContaDREDto> saldosDRESumarizados = new ArrayList<>();
        List<SaldoContaDREDto> saldosDREDespesas = new ArrayList<>();

        // Mes Atual
        mesAtual = UtilDate.getPrimeiroDiaMes(mesAtual);

        String dataCompetencia = UtilDate.getDataComoString(mesAtual, "yyyy-MM-dd");
        String dataCompetenciaMesPassado = UtilDate.getDataComoString(mesAnterior, "yyyy-MM-dd");
        List<SaldoContaDREDto> saldosDRE = this.painelFinanceiroService.buscarSaldosDRE(dataCompetencia, dataCompetenciaMesPassado);







        //AGRUPANDO
        List<SaldoContaDREDto> saldosSumarizadosParaAgrupar = new ArrayList<>();
        List<SaldoContaDREDto> sublist = new ArrayList<>();
        String ultimoIdentificador = null;
        BigDecimal vlrTotal = BigDecimal.ZERO;
        BigDecimal vlrTotalOntem = BigDecimal.ZERO;
        BigDecimal vlrTotalMesPassado = BigDecimal.ZERO;

        for (SaldoContaDREDto saldo : saldosDRE){
            if (ultimoIdentificador == null){
                vlrTotal = vlrTotal.add(saldo.getValor());
                vlrTotalOntem = vlrTotalOntem.add(saldo.getValorOntem());
                vlrTotalMesPassado = vlrTotalMesPassado.add(saldo.getValorMesPassado());
                ultimoIdentificador = saldo.getIdentificadorDre();
            } else if (saldo.getIdentificadorDre().equalsIgnoreCase(ultimoIdentificador)){
                vlrTotal = vlrTotal.add(saldo.getValor());
                vlrTotalOntem = vlrTotalOntem.add(saldo.getValorOntem());
                vlrTotalMesPassado = vlrTotalMesPassado.add(saldo.getValorMesPassado());

            } else {
                SaldoContaDREDto saldoDto = new SaldoContaDREDto();
                saldoDto.setIdentificadorDre(ultimoIdentificador);
                saldoDto.setValor(vlrTotal);
                saldoDto.setValorOntem(vlrTotalOntem);
                saldoDto.setValorMesPassado(vlrTotalMesPassado);

                List<SaldoContaDREDto> sublistDoSaldoAtual = new ArrayList<>(sublist);
                //Collections.copy(sublistDoSaldoAtual, sublist);
                saldoDto.setSublist(sublistDoSaldoAtual);
                sublist = new ArrayList<>();

                saldosSumarizadosParaAgrupar.add(saldoDto);
                ultimoIdentificador = saldo.getIdentificadorDre();

                vlrTotal = saldo.getValor();
                vlrTotalOntem = saldo.getValorOntem();
                vlrTotalMesPassado = saldo.getValorMesPassado();
            }

            sublist.add(saldo);
        }

        // Adiciona o ultimo lançamento
        SaldoContaDREDto saldoDto = new SaldoContaDREDto();
        saldoDto.setIdentificadorDre(ultimoIdentificador);
        saldoDto.setValor(vlrTotal);
        saldoDto.setValorOntem(vlrTotalOntem);
        saldoDto.setValorMesPassado(vlrTotalMesPassado);

        List<SaldoContaDREDto> sublistDoSaldoAtual = new ArrayList<>(sublist);
        saldoDto.setSublist(sublistDoSaldoAtual);
        saldosSumarizadosParaAgrupar.add(saldoDto);


        saldosDRE = saldosSumarizadosParaAgrupar;









        List<SaldoContaDREDto> dreNivel2s = new ArrayList<>();

        // Esse valor eh o que tiramos da planilha do ebitda. talvez tenha que acessar a ebitda.dbo.movimento_excluir_ebitda...
        LocalDate mesPassado = UtilDate.getPrimeiroDiaMes(mesAnterior);
        BigDecimal vlrExcluirEbitda = this.painelFinanceiroService.buscarVlrExcluirEbitda(UtilDate.toDate(mesPassado));
        SaldoContaDREDto investimentos = new SaldoContaDREDto();
        investimentos.setIdentificadorDre("93 - INVESTIMENTOS");
        investimentos.setDescricao("93 - INVESTIMENTOS");
        investimentos.setValor(new BigDecimal("0"));
        investimentos.setValorMesPassado(vlrExcluirEbitda);
        saldosDRE.add(investimentos);


        for (SaldoContaDREDto saldo : saldosDRE){
            saldo.setValorMesAnoPassado(BigDecimal.ZERO);

            // Sr. Dilson quer ver tudo maiúsculo
            String descConta = saldo.getDescricaoConta();
            String desc = saldo.getDescricao();
            String ide = saldo.getIdentificadorDre();
            saldo.setDescricaoConta(UtilString.isVazia(descConta) ? "" : descConta.toUpperCase());
            saldo.setDescricao(UtilString.isVazia(desc) ? "" : desc.toUpperCase());
            saldo.setIdentificadorDre(UtilString.isVazia(ide) ? "" : ide.toUpperCase());

            if (!UtilString.isVazia(saldo.getIdentificadorDre()) && (saldo.getIdentificadorDre().toLowerCase().contains("despesa") || saldo.getIdentificadorDre().toLowerCase().contains("contas perdida"))) {
                saldo.setDescricaoConta(saldo.getIdentificadorDre());
                saldosDREDespesas.add(saldo);
            } else if (saldo.getIdentificadorDre().toLowerCase().contains("91 -") || saldo.getIdentificadorDre().toLowerCase().contains("92 -") || saldo.getIdentificadorDre().toLowerCase().contains("93 -") || saldo.getIdentificadorDre().toLowerCase().contains("94 -") || saldo.getIdentificadorDre().toLowerCase().contains("95 -")){
                dreNivel2s.add(saldo);
            } else {
                saldosDRESumarizados.add(saldo);
            }
        }

        // Agrupa as despesas em uma unica linha
        BigDecimal vlrTotalDespesas = BigDecimal.ZERO;
        BigDecimal vlrTotalDespesasOntem = BigDecimal.ZERO;
        BigDecimal vlrTotalDespesasMesPassado = BigDecimal.ZERO;
        BigDecimal vlrTotalDespesasMesAnoPassado = BigDecimal.ZERO;

        for (SaldoContaDREDto saldo : saldosDREDespesas){
            vlrTotalDespesas = vlrTotalDespesas.add(saldo.getValor());
            vlrTotalDespesasOntem = vlrTotalDespesasOntem.add(saldo.getValorOntem());
            vlrTotalDespesasMesPassado = vlrTotalDespesasMesPassado.add(saldo.getValorMesPassado());
            vlrTotalDespesasMesAnoPassado = vlrTotalDespesasMesAnoPassado.add(saldo.getValorMesAnoPassado());
        }

        SaldoContaDREDto saldoDespesaAgrupado = new SaldoContaDREDto();
        saldoDespesaAgrupado.setValor(vlrTotalDespesas);
        saldoDespesaAgrupado.setValorOntem(vlrTotalDespesasOntem);
        saldoDespesaAgrupado.setIdentificadorDre("5 - DESPESAS OPERACIONAIS");
        saldoDespesaAgrupado.setSublist(saldosDREDespesas);
        saldoDespesaAgrupado.setValorMesPassado(vlrTotalDespesasMesPassado);
        saldoDespesaAgrupado.setValorMesAnoPassado(vlrTotalDespesasMesAnoPassado);
        saldosDRESumarizados.add(saldoDespesaAgrupado);

        // Cria o saldo total de lucro bruto
        BigDecimal vlrTotalCusto = BigDecimal.ZERO;
        BigDecimal vlrTotalCustoOntem = BigDecimal.ZERO;
        BigDecimal vlrTotalCustoMesPassado = BigDecimal.ZERO;
        BigDecimal vlrTotalCustoMesAnoPassado = BigDecimal.ZERO;

        BigDecimal vlrTotalFaturamento = BigDecimal.ZERO;
        BigDecimal vlrTotalFaturamentoOntem = BigDecimal.ZERO;
        BigDecimal vlrTotalFaturamentoMesPassado = BigDecimal.ZERO;
        BigDecimal vlrTotalFaturamentoMesAnoPassado = BigDecimal.ZERO;

        for (SaldoContaDREDto saldo : saldosDRESumarizados){
            String ident = UtilString.isVazia(saldo.getIdentificadorDre()) ? "" : saldo.getIdentificadorDre().toLowerCase();
            if (ident.contains("devoluc") || ident.contains("imposto") || ident.contains("mercadoria")) {
                vlrTotalCusto = vlrTotalCusto.add(saldo.getValor());
                vlrTotalCustoOntem = vlrTotalCustoOntem.add(saldo.getValorOntem());
                vlrTotalCustoMesPassado = vlrTotalCustoMesPassado.add(saldo.getValorMesPassado());
                vlrTotalCustoMesAnoPassado = vlrTotalCustoMesAnoPassado.add(saldo.getValorMesAnoPassado());
            } else if (ident.contains("faturamento")){
                vlrTotalFaturamento = saldo.getValor();
                vlrTotalFaturamentoOntem = saldo.getValorOntem();
                vlrTotalFaturamentoMesPassado = saldo.getValorMesPassado();
                vlrTotalFaturamentoMesAnoPassado = saldo.getValorMesAnoPassado();
            }
        }

        // Eu faço .add porque o valor do faturamento vem negativo
        BigDecimal vlrLucroBruto = vlrTotalFaturamento.add(vlrTotalCusto);
        BigDecimal vlrLucroBrutoOntem = vlrTotalFaturamentoOntem.add(vlrTotalCustoOntem);
        BigDecimal vlrLucroBrutoMesPassado = vlrTotalFaturamentoMesPassado.add(vlrTotalCustoMesPassado);
        BigDecimal vlrLucroBrutoMesAnoPassado = vlrTotalFaturamentoMesAnoPassado.add(vlrTotalCustoMesAnoPassado);

        SaldoContaDREDto saldoLucroBrutoAgrupado = new SaldoContaDREDto();
        saldoLucroBrutoAgrupado.setIdentificadorDre("4 - LUCRO BRUTO");
        saldoLucroBrutoAgrupado.setValor(vlrLucroBruto);
        saldoLucroBrutoAgrupado.setValorOntem(vlrLucroBrutoOntem);
        saldoLucroBrutoAgrupado.setValorMesPassado(vlrLucroBrutoMesPassado);
        saldoLucroBrutoAgrupado.setValorMesAnoPassado(vlrLucroBrutoMesAnoPassado);
        saldosDRESumarizados.add(saldoLucroBrutoAgrupado);

        // Adiciona a ultima linha (ebitda)
        SaldoContaDREDto saldoEbitda = new SaldoContaDREDto();
        saldoEbitda.setIdentificadorDre("90 - EBITDA");
        saldoEbitda.setValor(vlrLucroBruto.add(vlrTotalDespesas));
        saldoEbitda.setValorOntem(vlrLucroBrutoOntem.add(vlrTotalDespesasOntem));
        saldoEbitda.setValorMesPassado(vlrLucroBrutoMesPassado.add(vlrTotalDespesasMesPassado));
        saldoEbitda.setValorMesAnoPassado(vlrLucroBrutoMesAnoPassado.add(vlrTotalDespesasMesAnoPassado));
        saldosDRESumarizados.add(saldoEbitda);

        // Soma os valores do nivel 2 para subtrair (Valor do ebitda - Valor do nivel 2 = valor do lucro liquido)
        BigDecimal vlrNivel2 = BigDecimal.ZERO;
        BigDecimal vlrNivel2Ontem = BigDecimal.ZERO;
        BigDecimal vlrNivel2MesPassado = BigDecimal.ZERO;
        for (SaldoContaDREDto dto : dreNivel2s){
            vlrNivel2 = vlrNivel2.add(dto.getValor());
            vlrNivel2Ontem = vlrNivel2Ontem.add(dto.getValorOntem() != null ? dto.getValorOntem() : BigDecimal.ZERO);
            vlrNivel2MesPassado = vlrNivel2MesPassado.add(dto.getValorMesPassado());
        }

        SaldoContaDREDto saldoLL = new SaldoContaDREDto();
        saldoLL.setIdentificadorDre("99 - LUCRO LÍQUIDO");
        saldoLL.setValor(saldoEbitda.getValor().add(vlrNivel2));
        saldoLL.setValorOntem(saldoEbitda.getValorOntem().add(vlrNivel2Ontem));
        saldoLL.setValorMesPassado(saldoEbitda.getValorMesPassado().add(vlrNivel2MesPassado));
        saldosDRESumarizados.add(saldoLL);

        saldosDRESumarizados.addAll(dreNivel2s);

        // Calcula o valor do faturamento
        for (SaldoContaDREDto saldo : saldosDRESumarizados){
            saldo.setPercentualFaturamento(UtilNumero.percentual(saldo.getValor(), vlrTotalFaturamento, 2));
            saldo.setPercentualFaturamentoOntem(UtilNumero.percentual(saldo.getValorOntem(), vlrTotalFaturamentoOntem, 2));
            saldo.setPercentualFaturamentoMesPassado(UtilNumero.percentual(saldo.getValorMesPassado(), vlrTotalFaturamentoMesPassado, 2));
            saldo.setPercentualFaturamentoMesAnoPassado(UtilNumero.percentual(saldo.getValorMesAnoPassado(), vlrTotalFaturamentoMesAnoPassado, 2));
        }
        for (SaldoContaDREDto saldo : saldosDREDespesas){
            saldo.setPercentualFaturamento(UtilNumero.percentual(saldo.getValor(), vlrTotalFaturamento, 2));
            saldo.setPercentualFaturamentoOntem(UtilNumero.percentual(saldo.getValorOntem(), vlrTotalFaturamentoOntem, 2));
            saldo.setPercentualFaturamentoMesPassado(UtilNumero.percentual(saldo.getValorMesPassado(), vlrTotalFaturamentoMesPassado, 2));
            saldo.setPercentualFaturamentoMesAnoPassado(UtilNumero.percentual(saldo.getValorMesAnoPassado(), vlrTotalFaturamentoMesAnoPassado, 2));
        }

        Collections.sort(saldosDRESumarizados, new Comparator<SaldoContaDREDto>() {
            @Override
            public int compare(SaldoContaDREDto o1, SaldoContaDREDto o2) {
                return o1.getIdentificadorDre().compareTo(o2.getIdentificadorDre());
            }
        });
        return saldosDRESumarizados;
    }

    private List<SaldoContaDREDto> getSaldoContaDREDtos2(LocalDate mesAtual, LocalDate mesAnterior) {
        List<SaldoContaDREDto> saldosDRESumarizados = new ArrayList<>();
        List<SaldoContaDREDto> saldosDREDespesas = new ArrayList<>();

        // Mes Atual
        mesAtual = UtilDate.getPrimeiroDiaMes(mesAtual);

        String dataCompetencia = UtilDate.getDataComoString(mesAtual, "yyyy-MM-dd");
        String dataCompetenciaMesPassado = UtilDate.getDataComoString(mesAnterior, "yyyy-MM-dd");
        List<SaldoContaDREDto> saldosDRE = this.painelFinanceiroService.buscarSaldosDRE(dataCompetencia, dataCompetenciaMesPassado);

        List<SaldoContaDREDto> saldosSumarizados = new ArrayList<>();

        List<SaldoContaDREDto> sublist = new ArrayList<>();
        String ultimoIdentificador = "";
        BigDecimal vlrTotal = BigDecimal.ZERO;
        BigDecimal vlrTotalMesPassado = BigDecimal.ZERO;

        for (SaldoContaDREDto saldo : saldosDRE){
            if (saldo.getIdentificadorDre().equalsIgnoreCase(ultimoIdentificador)){
                vlrTotal = vlrTotal.add(saldo.getValor());
                vlrTotalMesPassado = vlrTotalMesPassado.add(saldo.getValorMesPassado());
                sublist.add(saldo);
            } else {
                SaldoContaDREDto saldoDto = new SaldoContaDREDto();
                saldoDto.setIdentificadorDre(ultimoIdentificador);
                saldoDto.setValor(vlrTotal);
                saldoDto.setValorMesPassado(vlrTotalMesPassado);
                saldoDto.setSublist(sublist);

                saldosSumarizados.add(saldoDto);
                ultimoIdentificador = saldo.getIdentificadorDre();
            }
        }













        List<SaldoContaDREDto> dreNivel2s = new ArrayList<>();


        // Esse valor eh o que tiramos da planilha do ebitda. talvez tenha que acessar a ebitda.dbo.movimento_excluir_ebitda...
        LocalDate mesPassado = UtilDate.getPrimeiroDiaMes(mesAnterior);
        BigDecimal vlrExcluirEbitda = this.painelFinanceiroService.buscarVlrExcluirEbitda(UtilDate.toDate(mesPassado));
        SaldoContaDREDto investimentos = new SaldoContaDREDto();
        investimentos.setIdentificadorDre("93 - INVESTIMENTOS");
        investimentos.setDescricao("93 - INVESTIMENTOS");
        investimentos.setValor(new BigDecimal("0"));
        investimentos.setValorMesPassado(vlrExcluirEbitda);
        saldosDRE.add(investimentos);


        for (SaldoContaDREDto saldo : saldosDRE){
            saldo.setValorMesAnoPassado(BigDecimal.ZERO);

            // Sr. Dilson quer ver tudo maiúsculo
            String descConta = saldo.getDescricaoConta();
            String desc = saldo.getDescricao();
            String ide = saldo.getIdentificadorDre();
            saldo.setDescricaoConta(UtilString.isVazia(descConta) ? "" : descConta.toUpperCase());
            saldo.setDescricao(UtilString.isVazia(desc) ? "" : desc.toUpperCase());
            saldo.setIdentificadorDre(UtilString.isVazia(ide) ? "" : ide.toUpperCase());

            if (!UtilString.isVazia(saldo.getIdentificadorDre()) && (saldo.getIdentificadorDre().toLowerCase().contains("despesa") || saldo.getIdentificadorDre().toLowerCase().contains("contas perdida"))) {
                saldosDREDespesas.add(saldo);
            } else if (saldo.getIdentificadorDre().toLowerCase().contains("91 -") || saldo.getIdentificadorDre().toLowerCase().contains("92 -") || saldo.getIdentificadorDre().toLowerCase().contains("93 -") || saldo.getIdentificadorDre().toLowerCase().contains("94 -") || saldo.getIdentificadorDre().toLowerCase().contains("95 -")){
                dreNivel2s.add(saldo);
            } else {
                saldosDRESumarizados.add(saldo);
            }
        }

        // Agrupa as despesas em uma unica linha
        BigDecimal vlrTotalDespesas = BigDecimal.ZERO;
        BigDecimal vlrTotalDespesasMesPassado = BigDecimal.ZERO;
        BigDecimal vlrTotalDespesasMesAnoPassado = BigDecimal.ZERO;

        for (SaldoContaDREDto saldo : saldosDREDespesas){
            vlrTotalDespesas = vlrTotalDespesas.add(saldo.getValor());
            vlrTotalDespesasMesPassado = vlrTotalDespesasMesPassado.add(saldo.getValorMesPassado());
            vlrTotalDespesasMesAnoPassado = vlrTotalDespesasMesAnoPassado.add(saldo.getValorMesAnoPassado());
        }

        SaldoContaDREDto saldoDespesaAgrupado = new SaldoContaDREDto();
        saldoDespesaAgrupado.setValor(vlrTotalDespesas);
        saldoDespesaAgrupado.setIdentificadorDre("5 - DESPESAS OPERACIONAIS");
        saldoDespesaAgrupado.setSublist(saldosDREDespesas);
        saldoDespesaAgrupado.setValorMesPassado(vlrTotalDespesasMesPassado);
        saldoDespesaAgrupado.setValorMesAnoPassado(vlrTotalDespesasMesAnoPassado);
        saldosDRESumarizados.add(saldoDespesaAgrupado);

        // Cria o saldo total de lucro bruto
        BigDecimal vlrTotalCusto = BigDecimal.ZERO;
        BigDecimal vlrTotalCustoMesPassado = BigDecimal.ZERO;
        BigDecimal vlrTotalCustoMesAnoPassado = BigDecimal.ZERO;

        BigDecimal vlrTotalFaturamento = BigDecimal.ZERO;
        BigDecimal vlrTotalFaturamentoMesPassado = BigDecimal.ZERO;

        for (SaldoContaDREDto saldo : saldosDRESumarizados){
            String ident = UtilString.isVazia(saldo.getIdentificadorDre()) ? "" : saldo.getIdentificadorDre().toLowerCase();
            if (ident.contains("devoluc") || ident.contains("imposto") || ident.contains("mercadoria")) {
                vlrTotalCusto = vlrTotalCusto.add(saldo.getValor());
                vlrTotalCustoMesPassado = vlrTotalCustoMesPassado.add(saldo.getValorMesPassado());
                vlrTotalCustoMesAnoPassado = vlrTotalCustoMesAnoPassado.add(saldo.getValorMesAnoPassado());
            } else if (ident.contains("faturamento")){
                vlrTotalFaturamento = saldo.getValor();
                vlrTotalFaturamentoMesPassado = saldo.getValorMesPassado();
            }
        }

        // Eu faço .add porque o valor do faturamento vem negativo
        BigDecimal vlrLucroBruto = vlrTotalFaturamento.add(vlrTotalCusto);
        BigDecimal vlrLucroBrutoMesPassado = vlrTotalFaturamentoMesPassado.add(vlrTotalCustoMesPassado);

        SaldoContaDREDto saldoLucroBrutoAgrupado = new SaldoContaDREDto();
        saldoLucroBrutoAgrupado.setIdentificadorDre("4 - LUCRO BRUTO");
        saldoLucroBrutoAgrupado.setValor(vlrLucroBruto);
        saldoLucroBrutoAgrupado.setValorMesPassado(vlrLucroBrutoMesPassado);
        saldosDRESumarizados.add(saldoLucroBrutoAgrupado);

        // Adiciona a ultima linha (ebitda)
        SaldoContaDREDto saldoEbitda = new SaldoContaDREDto();
        saldoEbitda.setIdentificadorDre("90 - EBITDA");
        saldoEbitda.setValor(vlrLucroBruto.add(vlrTotalDespesas));
        saldoEbitda.setValorMesPassado(vlrLucroBrutoMesPassado.add(vlrTotalDespesasMesPassado));
        saldosDRESumarizados.add(saldoEbitda);

        // Soma os valores do nivel 2 para subtrair (Valor do ebitda - Valor do nivel 2 = valor do lucro liquido)
        BigDecimal vlrNivel2 = BigDecimal.ZERO;
        BigDecimal vlrNivel2MesPassado = BigDecimal.ZERO;
        for (SaldoContaDREDto dto : dreNivel2s){
            vlrNivel2 = vlrNivel2.add(dto.getValor());
            vlrNivel2MesPassado = vlrNivel2MesPassado.add(dto.getValorMesPassado());
        }

        SaldoContaDREDto saldoLL = new SaldoContaDREDto();
        saldoLL.setIdentificadorDre("99 - LUCRO LÍQUIDO");
        saldoLL.setValor(saldoEbitda.getValor().add(vlrNivel2));
        saldoLL.setValorMesPassado(saldoEbitda.getValorMesPassado().add(vlrNivel2MesPassado));
        saldosDRESumarizados.add(saldoLL);

        //
        saldosDRESumarizados.addAll(dreNivel2s);

        // Calcula o valor do faturamento
        for (SaldoContaDREDto saldo : saldosDRESumarizados){
            saldo.setPercentualFaturamento(UtilNumero.percentual(saldo.getValor(), vlrTotalFaturamento, 2));
            saldo.setPercentualFaturamentoMesPassado(UtilNumero.percentual(saldo.getValorMesPassado(), vlrTotalFaturamentoMesPassado, 2));
        }
        for (SaldoContaDREDto saldo : saldosDREDespesas){
            saldo.setPercentualFaturamento(UtilNumero.percentual(saldo.getValor(), vlrTotalFaturamento, 2));
            saldo.setPercentualFaturamentoMesPassado(UtilNumero.percentual(saldo.getValorMesPassado(), vlrTotalFaturamentoMesPassado, 2));
        }

        Collections.sort(saldosDRESumarizados, new Comparator<SaldoContaDREDto>() {
            @Override
            public int compare(SaldoContaDREDto o1, SaldoContaDREDto o2) {
                return o1.getIdentificadorDre().compareTo(o2.getIdentificadorDre());
            }
        });
        return saldosDRESumarizados;
    }
//
//    @Transactional( readOnly = true )
//    public Result buscarDetalhado(String contaPai, String dataCompetencia) {
//        try {
//            //List<SaldoContaFinanceiraDto> saldosSumarizadosTotais = getSaldos("app/controllers/vendas/result.json");
//            List<SaldoContaFinanceiraDto> saldosSumarizadosTotais = this.painelFinanceiroService.buscarSaldosDetalhados(dataCompetencia);
//
//            SaldoContaFinanceiraDto contaPaiObj = null;
//
//            List<SaldoContaFinanceiraDto> saldosSumarizados = new ArrayList<>();
//            for (SaldoContaFinanceiraDto dto : saldosSumarizadosTotais){
//                if (contaPaiObj == null && Short.valueOf("5").equals(dto.getNivel()) && contaPai.equals(dto.getConta())) {
//                    contaPaiObj = dto;
//                }
//
//                if (dto.getConta().startsWith(contaPai) && Short.valueOf("8").equals(dto.getNivel())){
//                    // Busca o saldo da conta do mes passado
//                    LocalDate localDate = UtilDate.toLocalDate(dataCompetencia, "yyyy-MM-dd");
//                    LocalDate localDateMesPassado = UtilDate.adicionarNMeses(-1, localDate);
//                    SaldoContaFinanceiraDto saldoDto = this.painelFinanceiroService.buscarSaldosSumarizadosPorConta(UtilDate.getDataComoString(localDateMesPassado, "yyyy-MM-dd"), dto.getConta());
//                    dto.setSaldoMesPassado(saldoDto.getSaldo());
//
//                    // Busca o saldo da conta do mesmo mes do ano passado
//                    LocalDate localDateAnoPassado = UtilDate.toLocalDate(dataCompetencia, "yyyy-MM-dd");
//                    LocalDate localDateMesAnoPassado = UtilDate.adicionarNMeses(-12, localDateAnoPassado);
//                    SaldoContaFinanceiraDto saldoDtoAnoPassado = this.painelFinanceiroService.buscarSaldosSumarizadosPorConta(UtilDate.getDataComoString(localDateMesAnoPassado, "yyyy-MM-dd"), dto.getConta());
//                    dto.setSaldoMesAnoPassado(saldoDtoAnoPassado.getSaldo());
//
//                    saldosSumarizados.add(dto);
//                }
//            }
//
//            final Map<String, Object> result = new HashMap<>();
//            result.put("contaPai", contaPaiObj);
//            result.put("detalhes", saldosSumarizados);
//
//            return ok(Json.toJson(result));
//        } catch ( Throwable ex ) {
//            return badRequest( getException(ex) );
//        }
//    }
//
//    private List<SaldoContaFinanceiraDto> getSaldos(String fileName) throws FileNotFoundException {
//        File file = new File(fileName);
//        FileInputStream is = new FileInputStream(file);
//        final JsonNode node = Json.parse(is);
//
//        List<SaldoContaFinanceiraDto> list = new ArrayList<>();
//
//        if (node.isArray()) {
//            Iterator<JsonNode> elements = node.elements();
//            while (elements.hasNext()) {
//                JsonNode obj = elements.next();
//
//                SaldoContaFinanceiraDto dto = new SaldoContaFinanceiraDto();
//                dto.setConta(UtilJson.toText(obj, "conta"));
//                //dto.setDataCompetencia(UtilJson.toLocalDate(obj, "periodo", "yyyy-MM-dd"));
//                dto.setDescricao(UtilJson.toText(obj, "descricao"));
//                dto.setEmpresa(UtilJson.toShort(obj, "empresa"));
//                dto.setNivel(UtilJson.toShort(obj, "nivel"));
//                dto.setSaldo(obj.get("saldo").decimalValue());
//                list.add(dto);
//            }
//        }
//        return list;
//    }
//
//    private List<SaldoContaDREDto> getSaldosDRE() throws FileNotFoundException {
//        File file = new File("app/controllers/vendas/result_dre.json");
//        FileInputStream is = new FileInputStream(file);
//        final JsonNode node = Json.parse(is);
//
//        List<SaldoContaDREDto> list = new ArrayList<>();
//
//        if (node.isArray()) {
//            Iterator<JsonNode> elements = node.elements();
//            while (elements.hasNext()) {
//                JsonNode obj = elements.next();
//
//                SaldoContaDREDto dto = new SaldoContaDREDto();
//                dto.setCentroCusto(UtilJson.toText(obj, "centroCusto"));
//                dto.setConta(UtilJson.toText(obj, "conta"));
//                dto.setDataMovimento(UtilJson.toText(obj, "dataMovimento"));
//                dto.setDescricao(UtilJson.toText(obj, "descricao"));
//                dto.setDescricaoConta(UtilJson.toText(obj, "descricaoConta"));
//                dto.setIdentificadorDre(UtilJson.toText(obj, "identificadorDre"));
//                dto.setValor(obj.get("valor").decimalValue());
//                list.add(dto);
//            }
//        }
//        return list;
//    }



}
