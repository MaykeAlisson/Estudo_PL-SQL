package controllers.vendas;

import controllers.AuthController;
import infra.util.UtilString;
import models.commons.dtos.CidadeDto;
import models.commons.dtos.VendaCdmLocalizacaoCidadeDto;
import models.repository.vendas.CidadeRepository;
import models.repository.vendas.ClienteRepository;
import models.repository.vendas.NfSaidaRepository;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.Result;

import javax.inject.Inject;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static infra.util.UtilException.getException;

public class DashboardController extends AuthController {

    private final NfSaidaRepository nfSaidaRepository;
    private final ClienteRepository clienteRepository;
    private final CidadeRepository cidadeRepository;

    @Inject
    public DashboardController(NfSaidaRepository nfSaidaRepository, ClienteRepository clienteRepository, CidadeRepository cidadeRepository) {
        this.nfSaidaRepository = nfSaidaRepository;
        this.clienteRepository = clienteRepository;
        this.cidadeRepository = cidadeRepository;
    }

    @Transactional( readOnly = true )
    public Result buscar() {
        try {
            String dtInicio = request().getQueryString("dataInicio");
            String dtFim = request().getQueryString("dataFim");
            String estado = request().getQueryString("uf");
            String cidade = request().getQueryString("cidade");

            if (UtilString.isVazia(dtInicio) || UtilString.isVazia(dtFim)){
                return badRequest( "É necessario informar a data ínicio e a data fim" );
            }

            Date dataInicio = new SimpleDateFormat("yyyy-MM-dd").parse(dtInicio);
            Date dataFim = new SimpleDateFormat("yyyy-MM-dd").parse(dtFim);

            List<VendaCdmLocalizacaoCidadeDto> pontos = this.nfSaidaRepository.buscarClientesComFaturamentoNoPeriodo(dataInicio, dataFim, estado, cidade);
            Integer qtdSetores = this.nfSaidaRepository.buscarQuantidadeSetoresNoPeriodo(dataInicio, dataFim, estado, cidade).orElse(0);
            BigDecimal valorFaturado = this.nfSaidaRepository.buscarValorFaturamentoNoPeriodo(dataInicio, dataFim, estado, cidade).orElse(BigDecimal.ZERO);
            Integer qtdClientes = this.clienteRepository.buscarTotalClientesAtivos(estado, cidade);

            final Map<String, Object> result = new HashMap<>();
            result.put("pontos", pontos);
            result.put("valorFaturado", valorFaturado);
            result.put("setores", qtdSetores);
            result.put("clientesExistentes", qtdClientes);
            result.put("clientesCompraram", pontos.size());

            return ok(Json.toJson(result));
        } catch ( Throwable ex ) {
            return badRequest( getException(ex) );
        }
    }

    /**
     * Alysson Myller
     * 28/06/2018
     * @return
     */
    @Transactional( readOnly = true )
    public Result buscarCidades() {
        try {
            List<CidadeDto> cidades = this.cidadeRepository.buscarTodasCidades();
            return ok(Json.toJson(cidades));
        } catch ( Throwable ex ) {
            return badRequest( getException(ex) );
        }
    }

}
