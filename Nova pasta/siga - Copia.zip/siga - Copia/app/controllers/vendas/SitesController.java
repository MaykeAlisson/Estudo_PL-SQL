package controllers.vendas;

import controllers.AuthController;
import infra.binders.LongBinder;
import infra.binders.ShortBinder;
import infra.util.UtilDate;
import models.commons.constantes.Estado;
import models.commons.dtos.CidadeDto;
import models.commons.dtos.MercadoriaImportacaoSitesDto;
import models.commons.dtos.SituacaoPedidoVendaDto;
import models.domains.admin.Empresa;
import models.domains.estoque.DescargaAgendamento;
import models.domains.estoque.DescargaAgendamentoId;
import models.domains.estoque.Fornecedor;
import models.repository.estoque.DescargaAgendamentoRepository;
import models.repository.estoque.FornecedorRepository;
import models.repository.vendas.CidadeRepository;
import models.repository.vendas.PedidoVendaRepository;
import play.db.jpa.Transactional;
import play.libs.ws.WSClient;
import play.libs.ws.WSResponse;
import play.mvc.Result;
import services.admin.EmailService;

import javax.inject.Inject;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static infra.binders.LongBinder.getValue;
import static infra.binders.ShortBinder.getValue;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilException.getException;
import static infra.util.UtilString.isVazia;
import static play.libs.Json.toJson;

/**
 * Alysson Myller
 * 03/11/2018
 */
public class SitesController extends AuthController {

    private static String xml =
        "<item>" + "\n" +
            "<title>TITULO DO PRODUTO</title>" + "\n" +
            "<link>http://localhost:8888/arcom/product/TITULO-DO-PRODUTO/</link>" + "\n" +
            "<pubDate>Thu, 08 Nov 2018 19:22:01 +0000</pubDate>" + "\n" +
            "<dc:creator><![CDATA[wpadmin]]></dc:creator>" + "\n" +
            "<guid isPermaLink=\"false\">http://www4.arcom.com.br/?post_type=product&#038;p=ADICIONAR_ID_PRODUTO</guid>" + "\n" +
            "<description></description>" + "\n" +
            "<content:encoded><![CDATA[ADICIONAR_CONTEUDO]]></content:encoded>" + "\n" +
            "<excerpt:encoded><![CDATA[]]></excerpt:encoded>" + "\n" +
            "<wp:post_id>ADICIONAR_ID_PRODUTO</wp:post_id>" + "\n" +
            "<wp:post_date><![CDATA[2018-11-08 16:22:01]]></wp:post_date>" + "\n" +
            "<wp:post_date_gmt><![CDATA[2018-11-08 19:22:01]]></wp:post_date_gmt>" + "\n" +
            "<wp:comment_status><![CDATA[closed]]></wp:comment_status>" + "\n" +
            "<wp:ping_status><![CDATA[closed]]></wp:ping_status>" + "\n" +
            "<wp:post_name><![CDATA[TITULO-DO-PRODUTO]]></wp:post_name>" + "\n" +
            "<wp:status><![CDATA[publish]]></wp:status>" + "\n" +
            "<wp:post_parent>0</wp:post_parent>" + "\n" +
            "<wp:menu_order>0</wp:menu_order>" + "\n" +
            "<wp:post_type><![CDATA[product]]></wp:post_type>" + "\n" +
            "<wp:post_password><![CDATA[]]></wp:post_password>" + "\n" +
            "<wp:is_sticky>0</wp:is_sticky>" + "\n" +
            "<category domain=\"product_category\" nicename=\"NOME_CATEGORIA\"><![CDATA[NOME_CATEGORIA]]></category>" + "\n" +
            "<category domain=\"product_category\" nicename=\"NOME_SUB_CATEGORIA\"><![CDATA[NOME_SUB_CATEGORIA]]></category>" + "\n" +
            "<category domain=\"language\" nicename=\"pt\"><![CDATA[Português]]></category>" + "\n" +
            "<wp:postmeta>" + "\n" +
                "<wp:meta_key><![CDATA[_easy_image_gallery_link_images]]></wp:meta_key>" + "\n" +
                "<wp:meta_value><![CDATA[off]]></wp:meta_value>" + "\n" +
            "</wp:postmeta>" + "\n" +
            "<wp:postmeta>" + "\n" +
                "<wp:meta_key><![CDATA[_edit_last]]></wp:meta_key>" + "\n" +
                "<wp:meta_value><![CDATA[11]]></wp:meta_value>" + "\n" +
            "</wp:postmeta>" + "\n" +
            "<wp:postmeta>" + "\n" +
                "<wp:meta_key><![CDATA[_thumbnail_id]]></wp:meta_key>" + "\n" +
                "<wp:meta_value><![CDATA[ID_IMAGEM_PRODUTO]]></wp:meta_value>" + "\n" +
            "</wp:postmeta>" + "\n" +
            "<wp:postmeta>" + "\n" +
                "<wp:meta_key><![CDATA[url]]></wp:meta_key>" + "\n" +
                "<wp:meta_value><![CDATA[URL_SITE_OFICIAL]]></wp:meta_value>" + "\n" +
            "</wp:postmeta>" + "\n" +
            "<wp:postmeta>" + "\n" +
                "<wp:meta_key><![CDATA[_url]]></wp:meta_key>" + "\n" +
                "<wp:meta_value><![CDATA[field_5baab63a87f64]]></wp:meta_value>" + "\n" +
            "</wp:postmeta>" + "\n" +
        "</item>" + "\n";



    String xmlImagem =
        "<item>" + "\n" +
            "<title>NOME_DA_FOTO</title>" + "\n" +
            "<link>http://localhost:8888/arcom/product/TITULO-DO-PRODUTO/attachment/NOME_DA_FOTO/</link>" + "\n" +
            "<pubDate>Sun, 11 Nov 2018 20:27:39 +0000</pubDate>" + "\n" +
            "<dc:creator><![CDATA[]]></dc:creator>" + "\n" +
            "<guid isPermaLink=\"false\">http://localhost:8888/arcom/wp-content/uploads/2018/08/NOME_DA_FOTO.jpg</guid>" + "\n" +
            "<description></description>" + "\n" +
            "<content:encoded><![CDATA[]]></content:encoded>" + "\n" +
            "<excerpt:encoded><![CDATA[]]></excerpt:encoded>" + "\n" +
            "<wp:post_id>AUTOINCREMENT</wp:post_id>" + "\n" +
            "<wp:post_date><![CDATA[2018-11-11 18:27:39]]></wp:post_date>" + "\n" +
            "<wp:post_date_gmt><![CDATA[2018-11-11 20:27:39]]></wp:post_date_gmt>" + "\n" +
            "<wp:comment_status><![CDATA[open]]></wp:comment_status>" + "\n" +
            "<wp:ping_status><![CDATA[closed]]></wp:ping_status>" + "\n" +
            "<wp:post_name><![CDATA[screenshot]]></wp:post_name>" + "\n" +
            "<wp:status><![CDATA[inherit]]></wp:status>" + "\n" +
            "<wp:post_parent>ID_PRODUTO</wp:post_parent>" + "\n" +
            "<wp:menu_order>0</wp:menu_order>" + "\n" +
            "<wp:post_type><![CDATA[attachment]]></wp:post_type>" + "\n" +
            "<wp:post_password><![CDATA[]]></wp:post_password>" + "\n" +
            "<wp:is_sticky>0</wp:is_sticky>" + "\n" +
            "<wp:attachment_url><![CDATA[http://localhost:8888/arcom/wp-content/uploads/2018/08/NOME_DA_FOTO.jpg]]></wp:attachment_url>" + "\n" +
            "<category domain=\"language\" nicename=\"pt\"><![CDATA[Português]]></category>" + "\n" +
            "<wp:postmeta>" + "\n" +
                "<wp:meta_key><![CDATA[_wp_attached_file]]></wp:meta_key>" + "\n" +
                "<wp:meta_value><![CDATA[2018/08/NOME_DA_FOTO.jpg]]></wp:meta_value>" + "\n" +
            "</wp:postmeta>" + "\n" +
            "<wp:postmeta>" + "\n" +
                "<wp:meta_key><![CDATA[_wp_attachment_metadata]]></wp:meta_key>" + "\n" +
            "</wp:postmeta>" + "\n" +
        "</item>" + "\n";


    // Repository:
    private final PedidoVendaRepository pedidoVendaRepository;
    private final CidadeRepository cidadeRepository;
    private final FornecedorRepository fornecedorRepository;
    private final DescargaAgendamentoRepository descargaAgendamentoRepository;
    private final EmailService emailService;

    // Play Ws
    private final WSClient ws;

    @Inject
    public SitesController(
            final PedidoVendaRepository pedidoVendaRepository,
            final CidadeRepository cidadeRepository,
            final FornecedorRepository fornecedorRepository,
            final DescargaAgendamentoRepository descargaAgendamentoRepository,
            final EmailService emailService,
            final WSClient ws
    ) {

        this.pedidoVendaRepository = pedidoVendaRepository;
        this.cidadeRepository = cidadeRepository;
        this.fornecedorRepository = fornecedorRepository;
        this.descargaAgendamentoRepository = descargaAgendamentoRepository;
        this.emailService = emailService;
        this.ws = ws;
    }

    @Transactional( readOnly = true )
    public Result statusPedidos(ShortBinder idEmpresa, LongBinder cnpj) {
        try {
            String linkDownloadXmlPadrao = "https://cdn01.arcom.com.br/frontstack/segunda-via-xml?";
            String linkDownloadBoletoPadrao = "https://cdn01.arcom.com.br/frontstack/segunda-via-boleto?";

            List<SituacaoPedidoVendaDto> ret = this.pedidoVendaRepository.buscarSituacaoTodosPedidosDoCliente(getValue(idEmpresa), getValue(cnpj));

            for (SituacaoPedidoVendaDto sit : ret){
                if (!Objects.isNull(sit.getNotaFiscal())) {
                    String linkXml = linkDownloadXmlPadrao + "idEmpresa=1&cnpj=" + getValue(cnpj) + "&notaFiscal=" + sit.getNotaFiscal();
                    sit.setLinkDownloadXml(linkXml);

                    String linkBoleto = linkDownloadBoletoPadrao + "idEmpresa=1&cnpj=" + getValue(cnpj) + "&notaFiscal=" + sit.getNotaFiscal();
                    sit.setLinkDownloadBoleto(linkBoleto);
                }

                try {
                    String dataUltAtu = sit.getDataUltimaAtualizacao().substring(0, 16);
                    LocalDateTime data = UtilDate.toLocalDateTime(dataUltAtu, "yyyy-MM-dd HH:mm");
                    String dataFormatada = UtilDate.getDataComoString(data, "dd/MM/yyyy HH:mm");
                    if (!isVazia(dataFormatada)) {
                        sit.setDataUltimaAtualizacao(dataFormatada);
                    }
                } catch (Throwable e){
                    //NAO FAZ NADA MESMO
                }
            }

            return ok(toJson(ret));
        } catch ( Throwable e){
            return badRequest( getException(e) );
        }
    }

    @Transactional( readOnly = true )
    public Result segundaViaBoleto(ShortBinder idEmpresa, LongBinder cnpj, LongBinder notaFiscal) {
        try {
            String res = this.pedidoVendaRepository.agendaSolicitacaoSegundaViaBoleto(getValue(cnpj), getValue(idEmpresa), getValue(notaFiscal));
            if ("OK".equalsIgnoreCase(res)){
                return ok(toJson("OK"));
            } else {
                return badRequest( "Não foi possível solicitar a segunda via de email. Erro: " + res);
            }
        } catch ( Throwable e){
            return badRequest( getException(e) );
        }
    }

    @Transactional( readOnly = true )
    public Result segundaViaXml(ShortBinder idEmpresa, LongBinder cnpj, LongBinder notaFiscal) {
        try {
            String res = this.pedidoVendaRepository.agendaSolicitacaoSegundaViaXml(getValue(cnpj), getValue(idEmpresa), getValue(notaFiscal));
            if ("OK".equalsIgnoreCase(res)){
                return ok(toJson("OK"));
            } else {
                return badRequest( "Não foi possível solicitar a segunda via de email. Erro: " + res);
            }
        } catch ( Throwable e){
            return badRequest( getException(e) );
        }
    }

    @Transactional( readOnly = true )
    public Result gerarXmlMercadoriasImportacaoSites() {
        try {
            List<MercadoriaImportacaoSitesDto> ret = this.pedidoVendaRepository.buscarMercadoriasImportacaoSites();

            StringBuilder builder = new StringBuilder();
            for (MercadoriaImportacaoSitesDto dto: ret){
                String xmlAtual = xml;
                xmlAtual = xmlAtual.replace("TITULO DO PRODUTO", dto.getTitulo());
                xmlAtual = xmlAtual.replace("TITULO-DO-PRODUTO", dto.getTitulo().replace(" ", "-").toLowerCase());
                xmlAtual = xmlAtual.replace("ADICIONAR_ID_PRODUTO", String.valueOf(dto.getId()));
                xmlAtual = xmlAtual.replace("ADICIONAR_CONTEUDO", dto.getDica());
                xmlAtual = xmlAtual.replace("NOME_CATEGORIA", dto.getCategoria().toLowerCase());
                xmlAtual = xmlAtual.replace("NOME_SUB_CATEGORIA", dto.getSubCategoria());
                xmlAtual = xmlAtual.replace("ID_IMAGEM_PRODUTO", String.valueOf(dto.getId())  + "10");

                String xmlAtualImagem = xmlImagem;
                xmlAtualImagem = xmlAtualImagem.replace("NOME_DA_FOTO", String.format("%d_t", dto.getCodigoFoto()));
                xmlAtualImagem = xmlAtualImagem.replace("TITULO-DO-PRODUTO", dto.getTitulo().replace(" ", "-").toLowerCase());
                xmlAtualImagem = xmlAtualImagem.replace("AUTOINCREMENT", String.valueOf(dto.getId())  + "10");
                xmlAtualImagem = xmlAtualImagem.replace("ID_PRODUTO", String.valueOf(dto.getId()));

                builder.append(xmlAtual);
                builder.append(xmlAtualImagem);
            }

            return ok(builder.toString());
        } catch ( Throwable e){
            return badRequest( getException(e) );
        }
    }

    @Transactional( readOnly = true )
    public Result buscarCidadesPorEstado(String estado) {
        try {
            Estado enumEstado = getEnum(Estado.class,estado);
            List<CidadeDto> ret = this.cidadeRepository.buscarTodasCidadesPorEstado(enumEstado);
            return ok(toJson(ret));
        } catch ( Throwable e){
            return badRequest( getException(e) );
        }
    }

    @Transactional( readOnly = true )
    public Result buscarBairrosPorCidade(ShortBinder idCidade) {
        try {
            List<CidadeDto> ret = this.cidadeRepository.buscarTodosBairrosPorCidade(getValue(idCidade));
            return ok(toJson(ret));
        } catch ( Throwable e){
            return badRequest( getException(e) );
        }
    }


    @Transactional( readOnly = true )
    public Result buscarLatitudeLongitudePorDescricao(String cidade, String estado, String bairro) {

//        POST
//        http://roteirizador.arcom.com.br:5030/googlemaps/buscarCoordenadaArgs
//        Content-Type: application/json
//        {
//            "cidade" : "Uberlandia",
//                "estado" : "MG",
//                "bairro" : "Custodio Pereira"
//        }

        try {

            if ( isVazia(cidade) || isVazia(estado) || isVazia(bairro) ) {
                return badRequest("Obrigatório informar cidade, estado e bairro");
            }

            Map<String, String> mapJson = new HashMap<>();
            mapJson.put("cidade", cidade);
            mapJson.put("estado", estado);
            mapJson.put("bairro", bairro);

            final WSResponse response = ws
                .url( "http://roteirizador.arcom.com.br:5030/googlemaps/buscarCoordenadaArgs" )
                .post( toJson( mapJson ) )
                .toCompletableFuture()
                .get();

            if ( Objects.equals( response.getStatus(), 200 ) ) {
                return ok( response.getBody() );
            } else {
                return badRequest( response.getStatusText() );
            }

        } catch ( Throwable e){
            return badRequest( getException(e) );
        }
    }

    @Transactional
    public Result agendamentoDeEntrega(String transportador, String fornecedor, String tipoCarga, Long quantidade, String tipoVeiculo, String dataEntrega, String horarioEntrega, String email, String observacao) {
        try {
            if ( isVazia(transportador) || isVazia(fornecedor) || isVazia(tipoCarga) || isVazia(dataEntrega) || isVazia(horarioEntrega) || isVazia(email) || Objects.isNull(quantidade)) {
                return badRequest("Obrigatório informar todos os campos para gravar agendamento de entrega");
            }

            // Valida o fornecedor
            String fornecedorComNumeros = fornecedor.replace(".", "").replace("-", "").replace("/", "");
            Fornecedor forn = fornecedorRepository.buscarPorCnpj((short) 1, Long.valueOf(fornecedorComNumeros));
            if (forn == null){
                return badRequest("Fornecedor com o cnpj " + fornecedor + " não cadastrado! ");
            }

            // Valida a transportadora
            String transportadorComNumeros = transportador.replace(".", "").replace("-", "").replace("/", "");
            Fornecedor transp = fornecedorRepository.buscarPorCnpj((short) 1, Long.valueOf(transportadorComNumeros));
            if (transp == null){
                return badRequest("Transportadora com o cnpj " + fornecedor + " não cadastrado! ");
            }

            // Data e hora que usuario quer agendar no arcom
            LocalDate localDate = UtilDate.toLocalDate(dataEntrega, "dd/MM/yyyy");
            LocalDateTime dataSugestao = LocalDateTime.of(localDate.getYear(), localDate.getMonth(), localDate.getDayOfMonth(), 6, 0); // Esta fixo 06:00 AM

            DescargaAgendamentoId id = new DescargaAgendamentoId();
            id.setDataAgendamento(LocalDateTime.now());
            id.setFornecedor(forn.getIdFornecedor());
            id.setIdEmpresa(Empresa.IdEmpresa.ARCOM.getValor());
            id.setIdFilial((short)0);
            id.setTransportadora(transp.getIdFornecedor());

            DescargaAgendamento descargaAgendamento = new DescargaAgendamento();
            descargaAgendamento.setDataSugestao(dataSugestao);
            descargaAgendamento.setEmail(email);
            descargaAgendamento.setId(id);
            descargaAgendamento.setObservacao(observacao);
            descargaAgendamento.setPeso(BigDecimal.ZERO);
            descargaAgendamento.setQtdPaletes(quantidade != null ? quantidade.shortValue() : (short) 0);
            descargaAgendamento.setSituacao("S");
            descargaAgendamento.setTipoCarga(tipoCarga);
            descargaAgendamento.setTipoVeiculo(tipoVeiculo);

            descargaAgendamentoRepository.save(descargaAgendamento);

            return ok(toJson("Agendado com sucesso"));
        } catch ( Throwable e){
            return badRequest( getException(e) );
        }
    }

    @Transactional( readOnly = true )
    public Result ok7(String transportador, String fornecedor, String tipoCarga, Long quantidade, String tipoVeiculo, String dataEntrega, String horarioEntrega, String email, String observacao) {
        try {
            return ok();
        } catch ( Throwable e){
            return badRequest( getException(e) );
        }
    }

    @Transactional( readOnly = true )
    public Result ok6(String cidade, String estado, String bairro) {
        try {
            return ok();
        } catch ( Throwable e){
            return badRequest( getException(e) );
        }
    }

    @Transactional( readOnly = true )
    public Result ok3(ShortBinder idCidade) {
        try {
            return ok();
        } catch ( Throwable e){
            return badRequest( getException(e) );
        }
    }

    @Transactional( readOnly = true )
    public Result ok2(String estado) {
        try {
            return ok();
        } catch ( Throwable e){
            return badRequest( getException(e) );
        }
    }

    @Transactional( readOnly = true )
    public Result ok(ShortBinder idEmpresa, LongBinder cnpj) {
        try {
            return ok();
        } catch ( Throwable e){
            return badRequest( getException(e) );
        }
    }

    @Transactional( readOnly = true )
    public Result ok4(ShortBinder idEmpresa, LongBinder cnpj, LongBinder notaFiscal) {
        try {
            return ok();
        } catch ( Throwable e){
            return badRequest( getException(e) );
        }
    }

    @Transactional( readOnly = true )
    public Result ok5(ShortBinder idEmpresa, LongBinder cnpj, LongBinder notaFiscal) {
        try {
            return ok();
        } catch ( Throwable e){
            return badRequest( getException(e) );
        }
    }

}
