package controllers.vendas;

import akka.actor.ActorSystem;
import com.fasterxml.jackson.databind.node.ObjectNode;
import controllers.AuthController;
import controllers.binders.SimNaoBinder;
import infra.binders.ArrayLongBinder;
import infra.binders.LongBinder;
import infra.binders.ShortBinder;
import infra.util.UtilDate;
import models.commons.constantes.SimNao;
import models.commons.dtos.ClienteAtivoSetorDto;
import models.commons.dtos.ClienteDebitoNegociadoDto;
import models.repository.admin.ClienteExcluidoRepository;
import models.repository.admin.SistemaRepository;
import models.repository.vendas.ClienteRepository;
import models.repository.vendas.ClienteVdaMonitoradaRepository;
import models.repository.vendas.DebitoRepository;
import play.db.jpa.Transactional;
import play.mvc.Result;
import play.mvc.Results;
import scala.concurrent.ExecutionContextExecutor;
import scala.concurrent.duration.Duration;
import services.admin.EmailService;
import services.admin.PessoaService;
import services.contasReceber.ClienteBloqueadoService;
import services.contasReceber.ClienteCreditoService;
import services.contasReceber.ClienteReativacaoService;
import services.vendas.MidiaClienteService;
import views.xml.api.contasReceber.limiteCredito.exibir_limite_construido;
import views.xml.api.contasReceber.limiteCredito.exibir_limite_credito;

import javax.inject.Inject;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static controllers.binders.SimNaoBinder.getValue;
import static infra.binders.ArrayLongBinder.getValue;
import static infra.binders.LongBinder.getValue;
import static infra.binders.ShortBinder.getValue;
import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilDate.FORMATO_DATA_HORA;
import static infra.util.UtilDate.FORMATO_JSON_DATA_HORA_MINUTO;
import static infra.util.UtilException.getException;
import static infra.util.UtilException.getExceptionComoString;
import static infra.util.UtilString.trim;
import static java.lang.String.format;
import static models.commons.constantes.SimNao.NAO;
import static models.commons.constantes.SimNao.SIM;
import static models.domains.admin.Empresa.IdEmpresa.ARCOM;
import static play.libs.Json.newObject;
import static play.libs.Json.toJson;

public class ClienteController extends AuthController {

    // Play:
    private final ActorSystem actorSystem;
    private final ExecutionContextExecutor exec;

    // Service:
    private final MidiaClienteService midiaClienteService;
    private final ClienteCreditoService clienteCreditoService;
    private final ClienteBloqueadoService clienteBloqueadoService;
    private final ClienteReativacaoService clienteReativacaoService;
    private final PessoaService pessoaService;
    private final EmailService emailService;

    // Repository:
    private final SistemaRepository sistemaRepository;
    private final ClienteRepository clienteRepository;
    private final ClienteVdaMonitoradaRepository clienteVdaMonitoradaRepository;
    private final DebitoRepository debitoRepository;
    // Repository
    private final ClienteExcluidoRepository clienteExcluidoRepository;

    @Inject
    public ClienteController(
            final ActorSystem actorSystem,
            final ExecutionContextExecutor exec,
            final MidiaClienteService midiaClienteService,
            final ClienteCreditoService clienteCreditoService,
            final ClienteBloqueadoService clienteBloqueadoService,
            final ClienteReativacaoService clienteReativacaoService,
            final PessoaService pessoaService,
            final EmailService emailService,
            final SistemaRepository sistemaRepository,
            final ClienteRepository clienteRepository,
            final ClienteVdaMonitoradaRepository clienteVdaMonitoradaRepository,
            final DebitoRepository debitoRepository,
            final ClienteExcluidoRepository clienteExcluidoRepository
    ) {

        this.actorSystem = actorSystem;
        this.exec = exec;
        this.midiaClienteService = midiaClienteService;
        this.clienteCreditoService = clienteCreditoService;
        this.clienteBloqueadoService = clienteBloqueadoService;
        this.clienteReativacaoService = clienteReativacaoService;
        this.pessoaService = pessoaService;
        this.emailService = emailService;
        this.sistemaRepository = sistemaRepository;
        this.clienteRepository = clienteRepository;
        this.clienteVdaMonitoradaRepository = clienteVdaMonitoradaRepository;
        this.debitoRepository = debitoRepository;
        this.clienteExcluidoRepository = clienteExcluidoRepository;
    }

    @Transactional( readOnly = true )
    public Result buscarDataAbertura( final LongBinder cnpjBinder ) {

        try {
            final Long cnpj = getValue(cnpjBinder);

            final boolean permite = clienteExcluidoRepository.permiteReimplantacao( ARCOM, cnpj);
            if (!permite) return ok( newObject().put( "excluido", true ) );

            Optional<LocalDateTime> possivelData = clienteRepository.buscarDataAberturaPorCnpj( ARCOM, cnpj );
            if ( !possivelData.isPresent() )
                possivelData = pessoaService.buscarDataAberturaWS( cnpj );

            return possivelData
                    .map( dataAbertura -> UtilDate.toString( dataAbertura, FORMATO_JSON_DATA_HORA_MINUTO ) )
                    .map( dataAbertura -> ok( newObject().put( "dataAbertura", dataAbertura ) ) )
                    .orElse( noContent() );
        } catch ( final Throwable e ) {
            return badRequest( getException(e) );
        }
    }

    @Transactional
    public Result atualizarDataAbertura(
        final ShortBinder idEmpresa,
        final Long idCliente
    ) {

        try {
            return  clienteCreditoService
                .atualizarDataAbertura( getValue(idEmpresa), idCliente )
                .map( data -> format("Data de Abertura: %s", UtilDate.toString(data, FORMATO_DATA_HORA) ) )
                .map( Results::ok )
                .orElse( noContent() );
        } catch ( final Throwable e ) {
            return badRequestRollback(e);
        }
    }

    @Transactional( readOnly = true )
    public Result buscar(
        final ShortBinder idEmpresa,
        final Long cnpj,
        final String fields
    ) {

        try {
            switch ( fields ) {
                case "razao-social":
                    return clienteRepository
                            .buscarRazaoSocialPorCnpj( getValue(idEmpresa), cnpj )
                            .map( razaoSocial -> ok( newObject().put("razaoSocial", trim(razaoSocial) ) ) )
                            .orElse( noContent() );
            }
            return badRequest( "API não responde ao campo solicitado!" );
        } catch ( final Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }

    @Transactional
    public Result excluirArquivoDeMidia( final Long idMidiaCliente ) {

        try {
            midiaClienteService.excluirIdMidia( idMidiaCliente );
            return ok();
        } catch ( final Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }

    @Transactional
    public Result liberarBloqueado() {

        try {
            clienteBloqueadoService.checkProcessoEmExecucao();
            actorSystem.scheduler().scheduleOnce( Duration.Zero(), liberarBloqueadoTask(), exec );
            return ok( );
        } catch ( final Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }

    private Runnable liberarBloqueadoTask() {

        return () ->
            sistemaRepository.getJPA().withTransaction( () -> {
                try {
                    clienteBloqueadoService.liberarPorLimiteDeCreditoExcedido();
                } catch ( final Throwable e ) {
                    sistemaRepository.setRollbackOnly();
                    emailService.enviarErroAnalistas(
                        "[ SIGA / ClienteController.liberarBloqueadoTask ]",
                        getExceptionComoString( e )
                    );
                }
            });
    }

    @Transactional
    public Result atualizarPeriodoReativacao( final ArrayLongBinder idClientes ) {

        try {
            if ( idClientes == null ) {
                clienteReativacaoService.checkProcessoEmExecucao();
                actorSystem.scheduler().scheduleOnce( Duration.Zero(), atualizarPeriodoReativacaoTask(), exec );
            } else {
                clienteReativacaoService.atualizarClientesComVendasRealizadas( getValue( idClientes ) );
            }
            return ok( );
        } catch ( final Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }

    private Runnable atualizarPeriodoReativacaoTask() {

        return () ->
            sistemaRepository.getJPA().withTransaction( () -> {
                try {
                    clienteReativacaoService.atualizarClientesComVendasRealizadas();
                } catch ( final Throwable e ) {
                    sistemaRepository.setRollbackOnly();
                    emailService.enviarErroAnalistas(
                        "[ SIGA / ClienteController.atualizarPeriodoReativacaoTask ]",
                        getExceptionComoString( e )
                    );
                }
            });
    }

    @Transactional( readOnly = true )
    public Result buscarLimiteCredito(
        final ShortBinder idEmpresa,
        final Long idCliente,
        final SimNaoBinder analitico,
        final SimNaoBinder construido
    ) {

        try {
            final SimNao consultaAnalitica = getValue(analitico);
            final SimNao consultaApenasConstruido = getValue(construido);

            if ( Objects.equals( consultaAnalitica, NAO ) ) {
                if ( Objects.equals( consultaApenasConstruido, SIM ) )
                    return clienteCreditoService
                        .buscarValorConstruido( getValue(idEmpresa), idCliente )
                        .map( valor -> newObject().put("valor", valor ) )
                        .map( Results::ok )
                        .orElse( noContent() );

                return clienteCreditoService
                    .buscarValorFinal( getValue(idEmpresa), idCliente )
                    .map( valor -> newObject().put("valor", valor ) )
                    .map( Results::ok )
                    .orElse( noContent() );
            }

            if ( Objects.equals( consultaApenasConstruido, SIM ) )
                return clienteCreditoService
                    .calcularLimiteConstruido( getValue(idEmpresa), idCliente )
                    .map( exibir_limite_construido::render )
                    .map( Results::ok )
                    .orElse( noContent() );

            return clienteCreditoService
                .calcularLimite( getValue(idEmpresa), idCliente )
                .map( exibir_limite_credito::render )
                .map( Results::ok )
                .orElse( noContent() );

        } catch ( final Throwable ex ) {

            return badRequest( getException( ex ) );
        }
    }

    @Transactional( readOnly = true )
    public Result buscarOcorrenciaIVendas(
        final ShortBinder idEmpresa,
        final LongBinder idCliente
    ) {

        try {
            final Map<Short, String> map = clienteRepository.buscarOcorrenciaIVendas(
                getValue(idEmpresa),
                getValue(idCliente)
            );

            return isVazia( map ) ?
                noContent() :
                map.entrySet().stream().map( item -> {
                    final ObjectNode result = newObject();
                    result.put( "idOcorrencia", item.getKey() );
                    result.put( "descricao", item.getValue() );
                    return result;
                })
                .findFirst()
                .map( Results::ok )
                .orElse( noContent() );

        } catch ( final Throwable e ) {

            return badRequest( getException( e ));
        }
    }

    @Transactional( readOnly = true )
    public Result buscarTodosMonitorados(
        final ShortBinder idEmpresaBinder,
        final LongBinder idSetorBinder
    ) {

        try {

            final List<Long> idClientes = clienteVdaMonitoradaRepository.buscarTodosPorSetor(
                getValue(idEmpresaBinder),
                getValue(idSetorBinder)
            );

            if ( isVazia(idClientes) )
                return noContent();

            Map<String,List<Long>> retorno = new HashMap<>(1);
            retorno.put( "idClientes", idClientes );
            return ok( toJson(retorno) );

        } catch ( final Throwable e ) {

            return badRequest( getException(e) );
        }
    }

    @Transactional
    public Result buscarDebitosNegociados(
        final ShortBinder idEmpresaBinder,
        final LongBinder idSetorBinder
    ) {

        try {
            final List<ClienteDebitoNegociadoDto> dtos = debitoRepository.buscarDebitosNegociados(
                    getValue(idEmpresaBinder),
                    getValue(idSetorBinder)
            );
            return ( isVazia(dtos) ) ? noContent() : ok(toJson(dtos));
        } catch ( final Throwable e ) {
            return badRequest( getException(e) );
        }
    }

    @Transactional( readOnly = true )
    public Result uploadImagem( final LongBinder idCliente ) {

        try {
            return midiaClienteService
                .gravarImagem( getValue(idCliente), getByteArrayBody() )
                .map( p -> {
                    final ObjectNode node = newObject();
                    node.put("caminho", p.getKey() );
                    node.put( "arquivo", p.getValue() );
                    return node;
                })
                .map( Results::ok )
                .orElse( noContent() );
        } catch ( Throwable e ) {
            return badRequest( getException(e) );
        }
    }

    /**
     * Alysson Myller
     *
     * @param idEmpresaBinder
     * @param idSetorBinder
     * @return
     */
    @Transactional( readOnly = true )
    public Result buscarTodosSetor(
            final ShortBinder idEmpresaBinder,
            final LongBinder idSetorBinder
    ) {

        try {

            final List<ClienteAtivoSetorDto> clientes = clienteRepository.buscarAtivosPorSetor(
                    getValue(idEmpresaBinder),
                    getValue(idSetorBinder)
            );

            if ( isVazia(clientes) )
                return noContent();

            return ok( toJson(clientes) );

        } catch ( final Throwable e ) {

            return badRequest( getException(e) );
        }
    }

}
