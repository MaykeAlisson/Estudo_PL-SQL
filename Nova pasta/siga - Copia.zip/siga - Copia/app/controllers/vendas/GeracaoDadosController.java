package controllers.vendas;

import controllers.AuthController;
import infra.binders.LongBinder;
import play.db.jpa.Transactional;
import play.mvc.Result;
import services.vendas.GeracaoDadosService;

import javax.inject.Inject;

import static infra.binders.LongBinder.getValue;
import static infra.util.UtilException.getException;

public class GeracaoDadosController extends AuthController {

    private GeracaoDadosService geracaoDadoService;

    @Inject
    public GeracaoDadosController( final GeracaoDadosService geracaoDadoService ) {

        this.geracaoDadoService = geracaoDadoService;
    }

    @Transactional( readOnly = true )
    public Result buscarArquivoGeracaoDados(
        final LongBinder destinatario,
        final LongBinder registro
    ) {
        try {
            return geracaoDadoService
                .buscarArquivo( getValue(destinatario), getValue(registro) )
                .map( arquivo -> ok(arquivo.toFile()) )
                .orElse( noContent() );
        } catch ( final Throwable e ) {
            return badRequest( getException(e) );
        }
    }
}
