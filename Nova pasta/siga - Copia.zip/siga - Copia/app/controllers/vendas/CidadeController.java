package controllers.vendas;

import com.fasterxml.jackson.databind.node.ObjectNode;
import controllers.AuthController;
import infra.binders.BooleanBinder;
import infra.binders.ShortBinder;
import models.repository.vendas.CidadeRepository;
import models.repository.vendas.impl.ElasticSearchCidadeRepository;
import play.db.jpa.Transactional;
import play.mvc.Result;

import javax.inject.Inject;

import static infra.binders.BooleanBinder.getValue;
import static infra.binders.ShortBinder.getValue;
import static infra.util.UtilException.getException;
import static play.libs.Json.newObject;

public class CidadeController extends AuthController {

    private final CidadeRepository cidadeRepository;
    private final ElasticSearchCidadeRepository searchCidadeRepository;

    @Inject
    public CidadeController(
        final CidadeRepository cidadeRepository,
        final ElasticSearchCidadeRepository searchCidadeRepository
    ) {

        this.cidadeRepository = cidadeRepository;
        this.searchCidadeRepository = searchCidadeRepository;
    }

    @Transactional( readOnly = true )
    public Result buscar(
        final ShortBinder idCidadeBinder,
        final ShortBinder idDistritoBinder,
        final String fields
    ) {

        try {
            switch ( fields ) {
                case "descricao,estado":
                    return cidadeRepository
                        .buscarDescricaoEstadoPor( getValue(idCidadeBinder), getValue(idDistritoBinder) )
                        .map(es -> {
                            final ObjectNode retorno = newObject();
                            retorno.put("descricao", es.getDescricao());
                            retorno.put("estado", es.getEstado().getValor());
                            return ok( retorno );
                        })
                        .orElse( noContent() );
            }
            return badRequest( "Não foi possível atender solicitação de pesquisa por Cidade!" );
        } catch ( final Throwable ex ) {
            return badRequest( getException(ex) );
        }
    }

    @Transactional
    public Result inserir( final BooleanBinder indexar ) {

        try {
            if ( getValue(indexar) )
                searchCidadeRepository.save( getJsonBody() );
            return ok();
        } catch ( final Throwable e ) {
            return badRequestRollback( e );
        }
    }

}
