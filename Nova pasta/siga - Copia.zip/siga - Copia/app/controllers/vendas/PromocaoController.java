package controllers.vendas;

import controllers.AuthController;
import play.db.jpa.Transactional;
import play.mvc.Result;
import services.vendas.PromocaoService;

import javax.inject.Inject;

public class PromocaoController extends AuthController {

    private final PromocaoService promocaoService;

    @Inject
    public PromocaoController( final PromocaoService promocaoService ) {

        this.promocaoService = promocaoService;
    }

    @Transactional
    public Result gerarRelatorioParcial() {

        try {
            promocaoService.enviarRelatorioParcial();
            return ok();
        } catch ( final Throwable e ) {
            return badRequestRollback( e );
        }
    }




}
