package controllers.vendas;

import controllers.AuthController;
import infra.binders.ShortBinder;
import models.repository.vendas.RepresentanteRepository;
import models.repository.vendas.SetorRepository;
import play.db.jpa.Transactional;
import play.mvc.Result;

import javax.inject.Inject;

import static infra.binders.ShortBinder.getValue;
import static infra.util.UtilDate.getDataComoString;
import static infra.util.UtilException.getException;
import static java.lang.String.format;
import static play.libs.Json.newObject;

public class SetorController extends AuthController {

    // Repository:
    private final SetorRepository setorRepository;
    private final RepresentanteRepository representanteRepository;

    @Inject
    public SetorController(
            final SetorRepository setorRepository,
            final RepresentanteRepository representanteRepository
    ) {

        this.setorRepository = setorRepository;
        this.representanteRepository = representanteRepository;
    }

    @Transactional( readOnly = true )
    public Result buscar(
            final ShortBinder idEmpresaBinder,
            final Long idSetor,
            final String fields
    ) {

        try {

            final Short idEmpresa = getValue( idEmpresaBinder );

            switch ( fields ) {
                case "nome-representante":
                    return setorRepository
                            .buscarDataEncerramento( idEmpresa, idSetor )
                            .map( dto ->
                                dto.isEncerrado() ?
                                badRequest( format( "Setor [%s] foi encerrado em [%s] !! ", idSetor, getDataComoString( dto.getDataFim() ) ) ) :
                                ok( newObject()
                                    .put("nomeRepresentante",
                                            representanteRepository
                                            .buscarNomeRepresentantePorSetor( idEmpresa, idSetor )
                                            .orElse( "SETOR VAGO" )
                                            .trim()
                                    )
                                )
                            )
                            .orElse( noContent() );
            }

            return badRequest( "Não foi possível atender solicitação!" );

        } catch ( Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }

}
