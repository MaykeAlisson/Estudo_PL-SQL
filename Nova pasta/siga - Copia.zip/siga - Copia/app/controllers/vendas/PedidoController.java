package controllers.vendas;

import controllers.AuthController;
import controllers.binders.TipoProcPedidoECommerceBinder;
import models.commons.constantes.SituacaoPedidoECommerce;
import models.commons.dtos.PedidoECommerceRastreioDto;
import models.repository.vendas.PedidoECommerceCorreioNfRepository;
import play.db.jpa.Transactional;
import play.mvc.Result;
import services.contasReceber.AnaliseCreditoService;
import services.ecommerce.ECommerceCorreiosService;
import services.ecommerce.ECommerceService;
import services.ecommerce.ECommerceTransportadoraService;

import javax.inject.Inject;
import java.util.List;
import java.util.Objects;

import static controllers.binders.TipoProcPedidoECommerceBinder.Acao;
import static controllers.binders.TipoProcPedidoECommerceBinder.getQueryStringValida;
import static controllers.binders.TipoProcPedidoECommerceBinder.getValue;
import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilEnum.getEnum;
import static java.lang.String.format;
import static play.libs.Json.toJson;

public class PedidoController extends AuthController {

    // Service:
    private final AnaliseCreditoService analiseCreditoService;
    private final ECommerceService eCommerceService;
    private final ECommerceCorreiosService eCommerceCorreiosService;
    private final ECommerceTransportadoraService eCommerceTransportadoraService;

    // Repository:
    private final PedidoECommerceCorreioNfRepository pedidoECommerceCorreioNfRepository;

    @Inject
    public PedidoController(
        final AnaliseCreditoService analiseCreditoService,
        final ECommerceService eCommerceService,
        final ECommerceCorreiosService eCommerceCorreiosService,
        final ECommerceTransportadoraService eCommerceTransportadoraService,
        final PedidoECommerceCorreioNfRepository pedidoECommerceCorreioNfRepository
    ) {

        this.analiseCreditoService = analiseCreditoService;
        this.eCommerceService = eCommerceService;
        this.eCommerceCorreiosService = eCommerceCorreiosService;
        this.eCommerceTransportadoraService = eCommerceTransportadoraService;
        this.pedidoECommerceCorreioNfRepository = pedidoECommerceCorreioNfRepository;
    }

    @Transactional
    public Result aplicarAnaliseCredito() {

        try {
            analiseCreditoService.avaliar(
                getLong( "idTempAnaliseCredito" ),
                getLong( "versionTempAnaliseCredito" )
            );
            return ok();
        } catch ( final Throwable e ) {
            return badRequestRollback( e );
        }
    }

    @Transactional
    public Result baixarPedidosDoECommerce() {

        try {
            eCommerceService.baixarPedidosDoSite();
            return ok();
        } catch ( final Throwable e ) {
            return badRequestRollback( e );
        }
    }

    @Transactional( readOnly = true )
    public Result buscarPedidoDoECommerce( final String codigoRastreamento ){

        try {
            final List<PedidoECommerceRastreioDto> dados = pedidoECommerceCorreioNfRepository
                    .buscarDadosPorCodigoRastreamento( codigoRastreamento );
            return isVazia(dados) ? noContent() : ok( toJson(dados) );
        } catch ( final Throwable e ) {
            return badRequestRollback( e );
        }
    }

    @Transactional
    public Result enviarEmailPedidoDoECommerceAtrasados() {

        try {
            eCommerceService.enviarEmailPedidosEmAtraso();
            return ok();
        } catch ( final Throwable e ) {
            return badRequestRollback( e );
        }
    }

    @Transactional
    public Result processarPedidosDoECommerce( final TipoProcPedidoECommerceBinder binder ) {

        try {
            final Acao acao = getValue( binder );
            if ( acao != null ) {
                switch ( acao ) {
                    case PROCESSAR:
                        eCommerceService.processarPedidos();
                        return ok();
                    case ETIQUETA_CORREIO:
                        eCommerceCorreiosService.gerarEtiqueta( getIdPedidoFromHeader() );
                        return ok();
                    case LIBERAR:
                        if ( isEntregaTransportadora() ) {
                            eCommerceTransportadoraService.liberarPedidoSiteECommerce( getIdPedidoFromHeader() );
                        } else {
                            eCommerceService.liberarPedido( getIdPedidoFromHeader() );
                        }
                        return ok();
                    case ENTREGA_CORREIO:
                        return eCommerceCorreiosService.emitirReciboDeEntregaParaCorreios(
                                getLong("idResponsavelColeta" ),
                                getSet("destinatarios", Long.class ),
                                getRequest().getIdUsuario()
                            )
                            .map( arquivo -> ok( arquivo.toFile() ) )
                            .orElse( noContent() );
                    case CANCELAR:
                        eCommerceService.cancelarPedido(
                            getLong("idPedidoECommerce" ),
                            getEnum( SituacaoPedidoECommerce.class, getShort( "situacaoPedido" ) ),
                            getString("motivoCancelamento" ),
                            getRequest().getIdUsuario()
                        );
                        return ok();
                }
            }
            return forbidden( format( "Serviço indisponível - Valores validos [ %s ] ", getQueryStringValida() ) );
        } catch ( final Throwable e ) {
            return badRequestRollback( e );
        }
    }

    private Long getIdPedidoFromHeader() {

        return getPowerBatchParam()
            .map( param -> param.getLong(1) )
            .orElseThrow( () -> new IllegalArgumentException( "PowerBatch/Requisição sem nro do pedido!" ) );
    }

    private boolean isEntregaTransportadora() {

        return getPowerBatchParam()
            .map( param -> Objects.equals( param.getString(1), "R" ) )
            .orElseThrow( () -> new IllegalArgumentException( "PowerBatch/Requisição sem nro do pedido!" ) );
    }

}