package controllers.credito;

import infra.binders.ShortBinder;
import play.db.jpa.Transactional;
import play.mvc.Controller;
import play.mvc.Result;
import services.contasReceber.ClienteCreditoService;

import javax.inject.Inject;

import static infra.binders.ShortBinder.getValue;
import static infra.util.UtilException.getExceptionComoString;
import static java.lang.String.valueOf;
import static java.math.BigDecimal.ZERO;

public class ApiCreditoController extends Controller {

    // Service:
    private final ClienteCreditoService clienteCreditoService;

    @Inject
    public ApiCreditoController( final ClienteCreditoService clienteCreditoService ) {

        this.clienteCreditoService = clienteCreditoService;
    }

    @Transactional( readOnly = true )
    public Result buscarLimiteDeCreditoDoCliente(
            final ShortBinder idEmpresa,
            final Long idCliente
    ) {

        try {
            // TODO - DE-IMPLEMENTAR - USO NO SIG
            return ok( valueOf( clienteCreditoService.buscarValorFinal( getValue( idEmpresa), idCliente ).orElse( ZERO ) ) );
        } catch ( Throwable e ) {
            return badRequest( getExceptionComoString( e ) );
        }
    }

}
