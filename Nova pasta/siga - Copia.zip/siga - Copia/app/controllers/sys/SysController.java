package controllers.sys;

import infra.controllers.Controller;
import models.repository.admin.SistemaRepository;
import play.db.jpa.Transactional;
import play.mvc.Result;

import javax.inject.Inject;

import static infra.util.UtilDate.getDataComoString;
import static infra.util.UtilException.getExceptionComoString;
import static play.libs.Json.newObject;

public class SysController extends Controller {

    // Repository:
    private final SistemaRepository sistemaRepository;

    @Inject
    public SysController( final SistemaRepository sistemaRepository ) {

        this.sistemaRepository = sistemaRepository;
    }

    @Transactional(readOnly = true)
    public Result buscarHoraSybase() {

        try {
            return ok( newObject().put("data",  getDataComoString( sistemaRepository.getDataHojeHora() ) ) );
        } catch ( Throwable e ) {
            return badRequest( getExceptionComoString(e) );
        }
    }
}
