package controllers.binders;

import play.mvc.PathBindable;
import play.mvc.QueryStringBindable;

import java.util.Map;
import java.util.Optional;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilEnum.getEnum;
import static java.util.Optional.empty;
import static java.util.Optional.of;
import static models.domains.seguranca.Aplicacao.IdAplicacao;

public class AplicacaoBinder implements QueryStringBindable<AplicacaoBinder>, PathBindable<AplicacaoBinder> {

    private IdAplicacao value;

    public AplicacaoBinder() {
    }

    public AplicacaoBinder( final IdAplicacao value ) {

        this.value = value;
    }

    public AplicacaoBinder( final String value ) {

        this.value = getEnum( IdAplicacao.class, value );
    }

    public IdAplicacao getValue() {

        return value;
    }

    @Override
    public AplicacaoBinder bind( final String key,
                                 final String value ) {

        this.value = getEnum( IdAplicacao.class, value );
        return this;
    }

    @Override
    public Optional<AplicacaoBinder> bind( final String key,
                                           final Map<String, String[]> data ) {

        if ( isVazia( data ) || !data.containsKey( key ) || isVazia( data.get( key ) ) )
            return empty();

        return of( new AplicacaoBinder( data.get( key )[0] ) );
    }

    @Override
    public String unbind( String key ) {

        return this.value != null ? this.value.getValor() : null;
    }

    @Override
    public String javascriptUnbind() {

        return null;
    }

    public static IdAplicacao getValue( final AplicacaoBinder binder ) {

        return binder != null ? binder.getValue() : null;
    }
}
