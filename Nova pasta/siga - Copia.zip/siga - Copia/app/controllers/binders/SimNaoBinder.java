package controllers.binders;

import models.commons.constantes.SimNao;
import play.mvc.PathBindable;
import play.mvc.QueryStringBindable;

import java.util.Map;
import java.util.Optional;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilString.isVazia;
import static infra.util.UtilString.trim;
import static java.util.Optional.empty;
import static java.util.Optional.of;
import static models.commons.constantes.SimNao.NAO;
import static models.commons.constantes.SimNao.SIM;

public class SimNaoBinder
    implements QueryStringBindable<SimNaoBinder>,
    PathBindable<SimNaoBinder>
{

    private SimNao value;


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CONSTRUCTOR
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public SimNaoBinder() {

        value = NAO;
    }

    public SimNaoBinder( final SimNao value ) {

        this.value = value;
    }

    public SimNaoBinder( final String value ) {

        if ( !isVazia( value ) )
            switch ( trim( value ).substring(0,1) ) {
                case "s":
                case "S":
                    this.value =  SIM;
                    return;
                case "n":
                case "N":
                    this.value =  NAO;
                    return;
            }

        this.value = getEnum( SimNao.class, value );
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // GETTERS
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public SimNao getValue() {

        return value;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // BINDERS
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public SimNaoBinder bind(
        final String key,
        final String value
    ) {

        this.value = getEnum( SimNao.class, value );
        return this;
    }

    @Override
    public Optional<SimNaoBinder> bind(
        final String key,
        final Map<String, String[]> data
    ) {

        if ( isVazia( data ) || !data.containsKey( key ) || isVazia( data.get( key ) ) )
            return empty();

        return of( new SimNaoBinder( data.get( key )[0] ) );
    }

    @Override
    public String unbind( final String key ) {

        return this.value != null ? this.value.getValor() : null;
    }

    @Override
    public String javascriptUnbind() {

        return null;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public static SimNao getValue( final SimNaoBinder binder ) {

        return binder != null ? binder.getValue() : null;
    }

    public static SimNaoBinder newInstance( final String value ) {

        return new SimNaoBinder( value );
    }

}
