package controllers.binders;

import models.commons.constantes.TransportadoraOrigemECommerce;
import play.mvc.PathBindable;
import play.mvc.QueryStringBindable;

import java.util.Map;
import java.util.Optional;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.convShort;
import static infra.util.UtilString.isVazia;
import static java.util.Optional.empty;
import static java.util.Optional.of;

public class TransportadoraOrigemECommerceBinder implements
    QueryStringBindable<TransportadoraOrigemECommerceBinder>,
    PathBindable<TransportadoraOrigemECommerceBinder>
{

    private TransportadoraOrigemECommerce value;


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CONSTRUCTOR
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public TransportadoraOrigemECommerceBinder() {

        this.value = null;
    }

    public TransportadoraOrigemECommerceBinder( final Short value ) {

        this.value = getEnum( TransportadoraOrigemECommerce.class, value );
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // GETTERS
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public TransportadoraOrigemECommerce getValue() {

        return value;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // BINDERS
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public TransportadoraOrigemECommerceBinder bind(
        final String key,
        final String value
    ) {

        this.value = getEnum(TransportadoraOrigemECommerce.class, convShort(value));
        return this;
    }

    @Override
    public Optional<TransportadoraOrigemECommerceBinder> bind(
        final String key,
        final Map<String, String[]> data
    ) {

        return isVazia( key ) || isVazia( data ) || !data.containsKey(key)
            ? empty()
            : of( new TransportadoraOrigemECommerceBinder(convShort(data.get(key)[0])));
    }

    @Override
    public String unbind( final String key ) {

        return this.value != null
            ? String.valueOf( this.value.getValor() )
            : null;
    }

    @Override
    public String javascriptUnbind() {

        return null;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public static TransportadoraOrigemECommerce getValue( final TransportadoraOrigemECommerceBinder binder ) {

        return binder != null ? binder.getValue() : null;
    }


}
