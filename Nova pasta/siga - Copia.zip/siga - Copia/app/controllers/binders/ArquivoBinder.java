package controllers.binders;

import infra.model.Constante;
import play.mvc.PathBindable;
import play.mvc.QueryStringBindable;

import java.util.Map;
import java.util.Optional;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilString.isVazia;
import static java.lang.String.format;
import static java.util.Arrays.stream;
import static java.util.Optional.empty;
import static java.util.Optional.of;
import static java.util.stream.Collectors.joining;

public class ArquivoBinder implements QueryStringBindable<ArquivoBinder> ,
        PathBindable<ArquivoBinder> {

    public enum Arquivo implements Constante<String> {

        /**
         * lista-cidades
         */
        LISTA_CIDADES( "Lista cidades", "lista-cidades" ),

        /**
         * estatistica-venda
         */
        ESTATISTICA_VENDA( "Estatistica Venda", "estatistica-venda" ),

        /**
         * location
         */
        LOCATION( "Location", "location"),

        /**
         * location-exclusao
         */
        LOCATION_EXCLUSAO( "Location Exclusao", "location-exclusao" )
        ;

        private final String descricao;
        private final String valor;

        Arquivo(
                final String descricao,
                final String valor
        ) {

            this.descricao = descricao;
            this.valor = valor;
        }

        @Override
        public String getDescricao() {

            return descricao;
        }

        @Override
        public String getValor() {

            return valor;
        }
    }

    private Arquivo value;

    public ArquivoBinder() {
    }

    public ArquivoBinder(final Arquivo value ) {

        this.value = value;
    }

    public ArquivoBinder(final String value ) {

        this.value = getEnum( Arquivo.class, value );
    }

    public Arquivo getValue() {

        return value;
    }

    @Override
    public ArquivoBinder bind(
            final String key,
            final String value
    ) {

        this.value = getEnum( Arquivo.class, value );
        return this;
    }

    @Override
    public Optional<ArquivoBinder> bind(
            final String key,
            final Map<String, String[]> data
    ) {

        return ( isVazia( key ) || isVazia(data) || !data.containsKey( key ) )
                ? empty()
                : of( new ArquivoBinder( data.get(key)[0] ) );
    }

    @Override
    public String unbind( final String key ) {

        return this.value != null ? this.value.getValor() : null;
    }

    @Override
    public String javascriptUnbind() {

        return null;
    }

    public static ArquivoBinder.Arquivo getValue(final ArquivoBinder value ) {

        return value != null ? value.getValue() : null;
    }

    public static String getQueryStringValida() {

        return format( "?arquivo=%s",
                stream( Arquivo.values() )
                        .map( Arquivo::getValor )
                        .collect( joining("|") )
        );
    }
}

