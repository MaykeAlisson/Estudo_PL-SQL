package controllers.binders;

import infra.util.UtilEnum;
import models.commons.constantes.AtividadeCusto;
import play.mvc.PathBindable;
import play.mvc.QueryStringBindable;

import java.util.Map;
import java.util.Optional;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilEnum.getEnum;
import static java.util.Optional.empty;
import static java.util.Optional.of;
import static java.util.Optional.ofNullable;

/**
 * Binder para rotas que são compostas por {@link models.commons.constantes.AtividadeCusto}
 *
 * <p>Autor: GPortes</p>
 *
 */
public class AtividadeCustoBinder implements QueryStringBindable<AtividadeCustoBinder>, PathBindable<AtividadeCustoBinder> {

    private AtividadeCusto value;

    public AtividadeCustoBinder( ) {
    }

    public AtividadeCustoBinder( final AtividadeCusto value ) {

        this.value = value;
    }

    public AtividadeCustoBinder( final String value ) {

        this.value = getEnum( AtividadeCusto.class, value );
    }

    public AtividadeCusto getValue( ) {

        return value;
    }

    @Override
    public AtividadeCustoBinder bind( final String key,
                                      final String value ) {

        this.value =  getEnum( AtividadeCusto.class, value );
        return this;
    }

    @Override
    public Optional<AtividadeCustoBinder> bind( final String key,
                                                final Map<String, String[]> data ) {

        if ( isVazia( data ) || !data.containsKey( key ) || isVazia( data.get( key ) ) )
            return empty();

        return of( new AtividadeCustoBinder( data.get( key )[0] ) );
    }

    @Override
    public String unbind( String key ) {

        return this.value != null ? this.value.getValor() : null;
    }

    @Override
    public String javascriptUnbind( ) {

        return null;
    }

    public static AtividadeCusto getValue( AtividadeCustoBinder value ) {

        return value != null ? value.getValue() : null;
    }
}
