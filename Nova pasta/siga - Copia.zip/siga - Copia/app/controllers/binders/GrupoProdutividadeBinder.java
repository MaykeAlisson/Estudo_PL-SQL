package controllers.binders;

import models.domains.move.MovimentacaoPalete.GrupoProdutividade;
import play.mvc.PathBindable;
import play.mvc.QueryStringBindable;

import java.util.Map;
import java.util.Optional;


/**
 * Binder para rotas que são compostas por "MovimentacaoPalete.GrupoProdutividade'
 *
 * <p>Autor: GPortes</p>
 *
 */
public class GrupoProdutividadeBinder implements QueryStringBindable<GrupoProdutividadeBinder>, PathBindable<GrupoProdutividadeBinder> {

    private GrupoProdutividade value;

    public GrupoProdutividadeBinder() {
    }

    public GrupoProdutividadeBinder(GrupoProdutividade value) {
        this.value = value;
    }

    public GrupoProdutividade getValue() {
        return value;
    }

    @Override
    public GrupoProdutividadeBinder bind( String key, String txt) {
        this.value = GrupoProdutividade.valueOf(txt);
        return this;
    }

    @Override
    public Optional<GrupoProdutividadeBinder> bind( String key, Map<String, String[]> map) {
        return null;
    }

    @Override
    public String unbind(String key) {
        return this.value.name();
    }

    @Override
    public String javascriptUnbind() {
        return null;
    }

}
