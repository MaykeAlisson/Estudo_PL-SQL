package controllers.binders;

import infra.model.Constante;
import play.mvc.PathBindable;
import play.mvc.QueryStringBindable;

import java.util.Arrays;
import java.util.Map;
import java.util.Optional;
import java.util.StringJoiner;
import java.util.stream.Collectors;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilString.isVazia;
import static java.lang.String.format;
import static java.util.Arrays.stream;
import static java.util.Optional.empty;
import static java.util.Optional.of;
import static java.util.stream.Collectors.joining;

public class TipoProcPedidoECommerceBinder implements QueryStringBindable<TipoProcPedidoECommerceBinder> ,
                                                      PathBindable<TipoProcPedidoECommerceBinder> {

    public enum Acao implements Constante<String> {

        /**
         * processar
         */
        PROCESSAR( "Processar Pedidos", "processar" ),

        /**
         * etiqueta-correios
         */
        ETIQUETA_CORREIO( "Impressão de etiquetas para os Correios", "etiqueta-correios" ),

        /**
         * liberar
         */
        LIBERAR( "Liberar Pedidos", "liberar"),

        /**
         * entrega-correios
         */
        ENTREGA_CORREIO( "Impressão do recebido de entrega para os Corrêios", "entrega-correios" ),

        /**
         * cancelar
         */
        CANCELAR( "Cancelar pedido", "cancelar")
        ;

        private final String descricao;
        private final String valor;

        Acao(
            final String descricao,
            final String valor
        ) {

            this.descricao = descricao;
            this.valor = valor;
        }

        @Override
        public String getDescricao() {

            return descricao;
        }

        @Override
        public String getValor() {

            return valor;
        }
    }

    private Acao value;

    public TipoProcPedidoECommerceBinder() {
    }

    public TipoProcPedidoECommerceBinder( final Acao value ) {

        this.value = value;
    }

    public TipoProcPedidoECommerceBinder( final String value ) {

        this.value = getEnum( Acao.class, value );
    }

    public Acao getValue() {

        return value;
    }

    @Override
    public TipoProcPedidoECommerceBinder bind(
        final String key,
        final String value
    ) {

        this.value = getEnum( Acao.class, value );
        return this;
    }

    @Override
    public Optional<TipoProcPedidoECommerceBinder> bind(
        final String key,
        final Map<String, String[]> data
    ) {

        return ( isVazia( key ) || isVazia(data) || !data.containsKey( key ) )
                ? empty()
                : of( new TipoProcPedidoECommerceBinder( data.get(key)[0] ) );
    }

    @Override
    public String unbind( final String key ) {

        return this.value != null ? this.value.getValor() : null;
    }

    @Override
    public String javascriptUnbind() {

        return null;
    }

    public static TipoProcPedidoECommerceBinder.Acao getValue( final TipoProcPedidoECommerceBinder value ) {

        return value != null ? value.getValue() : null;
    }

    public static String getQueryStringValida() {

        return format( "?acao=%s",
            stream( Acao.values() )
            .map( Acao::getValor )
            .collect( joining("|") )
        );
    }
}
