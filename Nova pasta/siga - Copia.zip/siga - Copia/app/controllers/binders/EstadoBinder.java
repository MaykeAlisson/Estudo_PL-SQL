package controllers.binders;

import models.commons.constantes.Estado;
import play.mvc.PathBindable;
import play.mvc.QueryStringBindable;

import java.util.Map;
import java.util.Optional;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilString.isVazia;
import static java.util.Optional.empty;
import static java.util.Optional.of;

/**
 * Binder para tratamento de rotas que recebem a constante {@link Estado}
 *
 */

public class EstadoBinder implements
    QueryStringBindable<EstadoBinder>,
    PathBindable<EstadoBinder>
{

    private Estado value;

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CONSTRUCTOR
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public EstadoBinder() {

        this.value = null;
    }

    public EstadoBinder( final String value ) {

        this.value = getEnum( Estado.class, value );
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // GETTERS
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public Estado getValue() {

        return value;
    }



    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // BINDERS
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public EstadoBinder bind(
        final String key,
        final String value
    ) {

        this.value = getEnum( Estado.class, value );
        return this;
    }

    @Override
    public Optional<EstadoBinder> bind(
        final String key,
        final Map<String, String[]> data
    ) {

        return isVazia( key ) || isVazia( data ) || !data.containsKey(key)
            ? empty()
            : of( new EstadoBinder( data.get(key)[0] )  );
    }

    @Override
    public String unbind(String key) {
        return null;
    }

    @Override
    public String javascriptUnbind() {

        return null;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public static Estado getValue( final EstadoBinder binder ) {

        return binder != null ? binder.getValue() : null;
    }

}
