package controllers.transporte;

import controllers.AuthController;
import infra.binders.ShortBinder;
import models.repository.transp.ViagemRepository;
import play.db.jpa.Transactional;
import play.mvc.Result;

import javax.inject.Inject;
import java.util.List;

import static infra.binders.ShortBinder.getValue;
import static infra.util.UtilException.getException;
import static play.libs.Json.toJson;

public class ViagemController extends AuthController {

    private final ViagemRepository viagemRepository;

    @Inject
    public ViagemController( final ViagemRepository viagemRepository ) {

        this.viagemRepository = viagemRepository;
    }

    @Transactional( readOnly = true )
    public Result consultarPesoVeiculos( final ShortBinder idEmpresa,
                                         final List<ShortBinder> idVeiculos ) {

        try {
            return ok( toJson( viagemRepository.buscarPesoDeCargas( getValue(idEmpresa), getValue(idVeiculos) ) ) );
        } catch ( Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }
}
