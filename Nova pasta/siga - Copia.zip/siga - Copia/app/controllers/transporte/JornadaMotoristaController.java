package controllers.transporte;

import controllers.AuthController;
import infra.binders.BooleanBinder;
import infra.binders.ShortBinder;
import play.db.jpa.Transactional;
import play.mvc.Result;
import services.transporte.JornadaMotoristaService;

import javax.inject.Inject;

import static infra.binders.BooleanBinder.getValue;
import static infra.binders.ShortBinder.getValue;

/**
 * Victor Serafim
 * 11/12/2018
 */

public class JornadaMotoristaController extends AuthController {

    private final JornadaMotoristaService jornadaMotoristaService;

    @Inject
    public JornadaMotoristaController( final JornadaMotoristaService jornadaMotoristaService ) {

        this.jornadaMotoristaService = jornadaMotoristaService;
    }

    @Transactional
    public Result estendeJornadaTrabalho(
        final String solicitante,
        final ShortBinder frota,
        final BooleanBinder enviarEmail
    ) {

        try {
            jornadaMotoristaService.estendeJornadaTrabalho(
                solicitante,
                getValue(frota),
                getRequest().getIdUsuario(),
                getValue(enviarEmail)
            );
            return ok();
        } catch ( final Throwable e ) {
            return badRequestRollback( e );
        }
    }
}
