package controllers.transporte;

import controllers.AuthController;
import infra.binders.ShortBinder;
import play.db.jpa.Transactional;
import play.mvc.Result;
import services.transporte.ZonaRoteirizacaoService;

import javax.inject.Inject;

import static infra.binders.ShortBinder.getValue;
import static infra.util.UtilException.getException;
import static play.libs.Json.toJson;

public class ZonaRoteirizacaoController extends AuthController {

    private final ZonaRoteirizacaoService zonaRoteirizacaoService;

    @Inject
    public ZonaRoteirizacaoController(final ZonaRoteirizacaoService zonaRoteirizacaoService ) {
        this.zonaRoteirizacaoService = zonaRoteirizacaoService;
    }

    @Transactional( readOnly = true )
    public Result buscarZonasRoteirizacao(final ShortBinder idEmpresa,
                                          final String idGrupoCidade) {
        try {
            return ok( toJson( zonaRoteirizacaoService.buscarZonasRoteirizacaoPorIdGrupoCidade(idGrupoCidade, getValue(idEmpresa))));
        } catch ( Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }
}
