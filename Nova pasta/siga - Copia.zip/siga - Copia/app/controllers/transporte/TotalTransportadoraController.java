package controllers.transporte;

import controllers.AuthController;
import infra.binders.LongBinder;
import infra.powerbatch.PBatchParam;
import play.db.jpa.Transactional;
import play.mvc.Result;
import play.mvc.Results;
import services.ecommerce.ECommerceTransportadoraService;

import javax.inject.Inject;
import java.util.Optional;

import static infra.binders.LongBinder.getValue;

public class TotalTransportadoraController extends AuthController {

    // Service:
    private final ECommerceTransportadoraService eCommerceTransportadoraService;

    @Inject
    public TotalTransportadoraController( final ECommerceTransportadoraService eCommerceTransportadoraService ) {

        this.eCommerceTransportadoraService = eCommerceTransportadoraService;
    }

    @Transactional
    public Result criarRemessa() {

        try {
            return eCommerceTransportadoraService
                .criarRemessa()
                .map( String::valueOf )
                .map( Results::ok )
                .orElse( noContent() );
        } catch ( final Throwable e ) {
            return badRequestRollback( e );
        }
    }

    @Transactional
    public Result excluirRemessa( final LongBinder idRemessaBinder ) {

        try {
            eCommerceTransportadoraService.excluirRemessa( getValue(idRemessaBinder) );
            return ok();
        } catch ( final Throwable e ) {
            return badRequestRollback( e );
        }
    }

    @Transactional
    public Result enviarEncomenda() {

        try {
            final Optional<PBatchParam> param = getPowerBatchParam();
            if ( param.isPresent() ) {
                eCommerceTransportadoraService.enviarRemessa( param.get().getLong(1) );
                return ok();
            }
            return badRequest( "Argumento PowerBatch [Id da Remessa] não esta presente no header da requisição!" );
        } catch ( final Throwable e ) {
            return badRequestRollback( e );
        }
    }
}
