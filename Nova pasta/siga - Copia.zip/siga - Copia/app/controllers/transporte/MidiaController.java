package controllers.transporte;

import akka.NotUsed;
import akka.actor.Status;
import akka.stream.OverflowStrategy;
import akka.stream.javadsl.Source;
import akka.util.ByteString;
import controllers.AuthController;
import play.db.jpa.Transactional;
import play.mvc.Result;
import services.transporte.AtomFotoService;

import javax.inject.Inject;
import java.util.Optional;

import static infra.util.UtilException.getExceptionComoString;
import static java.lang.String.format;

public class MidiaController extends AuthController {

    // Service:
    private final AtomFotoService atomFotoService;

    @Inject
    public MidiaController( final AtomFotoService atomFotoService ) {

        this.atomFotoService = atomFotoService;
    }

    @Transactional( readOnly = true )
    public Result buscarFotoAbastecimento( final Long idAbastecimento ) {

        try {

            Optional<String> possivelStringBase64  = atomFotoService.buscarFotoAbastecimentoBase64( idAbastecimento );
            if ( !possivelStringBase64.isPresent() )
                return badRequest( format( "FOTO NAO LOCALIZADA DO ABASTECIMENTO - ID_ABASTECIMENTO: %s", idAbastecimento ));

            // Prepare a chunked text stream
            Source<ByteString, ?> source = Source.<ByteString>actorRef(256, OverflowStrategy.dropNew())
                    .mapMaterializedValue(sourceActor -> {
                        sourceActor.tell(ByteString.fromString( possivelStringBase64.get() ), null);
                        sourceActor.tell(new Status.Success(NotUsed.getInstance()), null);
                        return NotUsed.getInstance();
                    });

            return ok().chunked(source);

        } catch ( Throwable e ) {
            return badRequest( getExceptionComoString( e ) );
        }
    }

    @Transactional( readOnly = true )
    public Result buscarFotoDespesa( final Long idDespesa ) {

        try {

            Optional<String> possivelStringBase64  = atomFotoService.buscarFotoDespesaBase64( idDespesa );
            if ( !possivelStringBase64.isPresent() )
                return badRequest( format( "FOTO NAO LOCALIZADA DA DESPESA - ID_DESPESA: %s", idDespesa ));

            // Prepare a chunked text stream
            Source<ByteString, ?> source = Source.<ByteString>actorRef(256, OverflowStrategy.dropNew())
                    .mapMaterializedValue(sourceActor -> {
                        sourceActor.tell(ByteString.fromString( possivelStringBase64.get() ), null);
                        sourceActor.tell(new Status.Success(NotUsed.getInstance()), null);
                        return NotUsed.getInstance();
                    });

            return ok().chunked(source);

        } catch ( Throwable e ) {
            return badRequest( getExceptionComoString( e ) );
        }
    }
}
