package controllers.transporte;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import controllers.AuthController;
import controllers.binders.TransportadoraOrigemECommerceBinder;
import infra.binders.LongBinder;
import models.commons.constantes.TransportadoraOrigemECommerce;
import models.domains.transp.TransportadoraECommerce;
import models.repository.transp.TransportadoraECommerceRepository;
import models.repository.transp.impl.ElasticSeachTransportadoraECommerceRepository;
import models.repository.vendas.CidadeRepository;
import play.db.jpa.Transactional;
import play.mvc.Result;
import play.mvc.Results;

import javax.inject.Inject;
import java.util.Arrays;

import static controllers.binders.TransportadoraOrigemECommerceBinder.getValue;
import static infra.binders.LongBinder.getValue;
import static infra.util.UtilConstante.getValor;
import static play.libs.Json.fromJson;
import static play.libs.Json.newArray;
import static play.libs.Json.newObject;
import static play.libs.Json.toJson;

public class TransportadoraECommerceController extends AuthController {

    // Repository:
    private final TransportadoraECommerceRepository transportadoraECommerceRepository;
    private final ElasticSeachTransportadoraECommerceRepository elasticSeach;
    private final CidadeRepository cidadeRepository;

    @Inject
    public TransportadoraECommerceController(
        final TransportadoraECommerceRepository transportadoraECommerceRepository,
        final ElasticSeachTransportadoraECommerceRepository elasticSeach,
        final CidadeRepository cidadeRepository
    ) {

        this.transportadoraECommerceRepository = transportadoraECommerceRepository;
        this.elasticSeach = elasticSeach;
        this.cidadeRepository = cidadeRepository;
    }

    private TransportadoraECommerce getTranspFromBody() {

        return fromJson( getJsonBody(), TransportadoraECommerce.class );
    }

    @Transactional
    public Result inserir() {

        try {
            final TransportadoraECommerce transportadoraECommerce = getTranspFromBody();
            transportadoraECommerceRepository.save(transportadoraECommerce);
            return ok( toJson(transportadoraECommerce)  );
        } catch ( final Throwable e ) {
            return badRequestRollback( e );
        }
    }

    @Transactional
    public Result atualizar() {

        try {
            return ok( toJson(transportadoraECommerceRepository.update(getTranspFromBody()))  );
        } catch ( final Throwable e ) {
            return badRequestRollback( e );
        }
    }

    @Transactional
    public Result excluir(
        final LongBinder idTransportadoraECommerce,
        final LongBinder version
    ) {

        try {
            return transportadoraECommerceRepository.deleteByIdVersion(
                getValue(idTransportadoraECommerce),
                getValue(version)
            ) > 0 ? ok() : noContent();
        } catch ( final Throwable e ) {
            return badRequestRollback( e );
        }
    }

    @Transactional( readOnly = true )
    public Result buscar(
        final TransportadoraOrigemECommerceBinder transportadoraOrigemECommerceBinder,
        final LongBinder idCodigoFrenet
    ) {

        return transportadoraECommerceRepository
            .buscarPor(
                getValue( transportadoraOrigemECommerceBinder ),
                getValue( idCodigoFrenet )
            )
            .map( transportadora -> {
                final JsonNode jsonNode = toJson( transportadora );
                final ObjectNode node = (ObjectNode) jsonNode; // Complementa com informações da cidade.
                node.putNull("descricaoCidade");
                node.putNull("estado");
                cidadeRepository.buscarDescricaoEstadoPor(
                    transportadora.getIdCidade(),
                    transportadora.getIdDistrito()
                ).ifPresent( descricaoEstado -> {
                    node.put("descricaoCidade", descricaoEstado.getDescricao());
                    node.put("estado", getValor(descricaoEstado.getEstado()) );
                });
                return jsonNode;
            })
            .map( Results::ok )
            .orElse( noContent() );
    }

    public Result buscarTodasOrigens() {

        final ArrayNode arrayNode = newArray();

        Arrays
        .stream( TransportadoraOrigemECommerce.values() )
        .map( origem -> newObject()
            .put("origem",origem.getValor())
            .put( "descricao", origem.getDescricao())
        ).forEach( arrayNode::add );

        return ok( arrayNode );
    }

    @Transactional( readOnly = true )
    public Result atualizarSearch( final LongBinder idTransportadoraECommerceBinder ) {

        try {
            final Long id = getPowerBatchParam()
                .map( param -> param.getLong(1) )
                .orElse( getValue(idTransportadoraECommerceBinder) );
            transportadoraECommerceRepository.buscarDadosIndexar( id ).ifPresent( elasticSeach::save );
            return ok();
        } catch ( final Throwable e ) {
            return badRequestRollback( e );
        }
    }

}
