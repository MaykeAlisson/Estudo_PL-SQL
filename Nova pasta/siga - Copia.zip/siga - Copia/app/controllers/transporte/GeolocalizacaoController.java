package controllers.transporte;

import akka.NotUsed;
import akka.actor.Status;
import akka.stream.OverflowStrategy;
import akka.stream.javadsl.Source;
import akka.util.ByteString;
import controllers.AuthController;
import infra.binders.LocalDateBinder;
import infra.exceptions.BusinessException;
import infra.util.UtilArquivo;
import models.commons.dtos.EnvelopeDto;
import models.commons.dtos.GerenteMapaGeolocalizacaoDto;
import models.repository.admin.ParametroRepository;
import models.repository.seguranca.UsuarioRepository;
import play.db.jpa.Transactional;
import play.mvc.Result;
import services.admin.EmailService;
import services.custos.CustoTransporteService;
import services.mapas.MapaService;
import services.transporte.GeolocalizacaoService;
import views.html.api.transporte.geolocalizacao.localVeiculo;

import javax.inject.Inject;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.StringJoiner;

import static infra.binders.LocalDateBinder.getValue;
import static infra.util.UtilArquivo.gerarNomeRandomico;
import static infra.util.UtilArquivo.gravarTexto;
import static infra.util.UtilCollections.getFirstKey;
import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilDate.isDomingo;
import static infra.util.UtilDate.isSegundaFeira;
import static infra.util.UtilDate.isValida;
import static infra.util.UtilException.getExceptionComoString;
import static infra.util.UtilRandom.getRandom;
import static infra.util.UtilString.isVazia;
import static java.lang.String.format;
import static models.domains.admin.Empresa.IdEmpresa.ARCOM;
import static models.domains.admin.Parametro.IdParametro.ARQUIVO_MAPA_PERNOITE_VENDAS;

public class GeolocalizacaoController extends AuthController {

    // Service:
    private final GeolocalizacaoService geolocalizacaoService;
    private final MapaService mapaService;
    private final EmailService emailService;
    private final CustoTransporteService custoTransporteService;

    // Repository:
    private final UsuarioRepository usuarioRepository;
    private final ParametroRepository parametroRepository;

    @Inject
    public GeolocalizacaoController(
        final GeolocalizacaoService geolocalizacaoService,
        final MapaService mapaService,
        final EmailService emailService,
        final CustoTransporteService custoTransporteService,
        final UsuarioRepository usuarioRepository,
        final ParametroRepository parametroRepository
    ) {

        this.geolocalizacaoService = geolocalizacaoService;
        this.mapaService = mapaService;
        this.emailService = emailService;
        this.custoTransporteService = custoTransporteService;
        this.usuarioRepository = usuarioRepository;
        this.parametroRepository = parametroRepository;
    }

    @Transactional( readOnly = true )
    public Result buscarConteudoDoArquivoRotaRealizada() {

        try {

            final String conteudoArquivo = geolocalizacaoService.getConteudoDoArquivoRotaRealizada();

            // Prepare a chunked text stream
            Source<ByteString, ?> source = Source.<ByteString>actorRef(256, OverflowStrategy.dropNew())
                .mapMaterializedValue(sourceActor -> {
                    sourceActor.tell(ByteString.fromString( conteudoArquivo ), null);
                    sourceActor.tell(new Status.Success( NotUsed.getInstance()), null);
                    return NotUsed.getInstance();
                });

            return ok().chunked(source);

        } catch ( Throwable e ) {

            return badRequest( getExceptionComoString( e ) );
        }
    }

    @Transactional
    public Result enviarEmailMapaVendaCdm(
        final String idGrupoCidade,
        final LocalDateBinder dataInicioBinder,
        final LocalDateBinder dataFimBinder
    ) {

        try {

            final LocalDate dataInicio = getValue(dataInicioBinder);
            final LocalDate dataFim = getValue(dataFimBinder);

            if ( ! isSegundaFeira( dataInicio ) )
                throw new BusinessException("data inicio deve ser sempre uma segunda (inicio da semana)");

            if ( ! isDomingo( dataFim) )
                throw new BusinessException("data fim deve ser sempre um domingo (fim da semana)");

            final Long idUsuario = getRequest().getIdUsuario();
            final Map<String, LocalDateTime> emailFuncionario = usuarioRepository.buscarEmailDoFuncionario( idUsuario );
            final Optional<String> possivelEmail = getFirstKey( emailFuncionario );

            if ( possivelEmail.isPresent() ) {
                final String email = possivelEmail.get();
                if ( isVazia(email) )
                    throw new BusinessException( format( "Não localizou email do usuario %s !!", idUsuario) );
                if ( isValida( emailFuncionario.get( email ) ) )
                    throw new BusinessException( format( "Usuario %s consta como DEMITIDO", idUsuario ) );
            } else {
                throw new BusinessException( "Não localizou usuario !!" );
            }

            final Map<String,String> map = mapaService.getMapaVendaCidadeCdm( idGrupoCidade, dataInicio, dataFim );

            final String conteudo = views.html.api.mapa.geral.mapaGeral.render( map.get("assunto"), map.get("mapa") ).body();

            final Path arquivoMapa = parametroRepository
                .buscarCaminhoGravarArquivoEmail(ARCOM)
                .resolve( format("mapa-grupo-%s-%s", idGrupoCidade, gerarNomeRandomico("html")) );

            if ( gravarTexto( arquivoMapa, conteudo ) ) {
                emailService.enviar(
                    new EnvelopeDto.Builder( map.get( "assunto" ) )
                        .comMensagem( map.get( "mensagem" ) )
                        .comArquivos( arquivoMapa.toString() )
                        .comDestinatarios( possivelEmail.get() )
                        .comExclusao()
                        .build()
                );
                return ok( format( "Email enviado para [ %s ]", possivelEmail.get() ) );
            }

            return badRequest( format("Falhou geração do arquivo: %s\n", arquivoMapa) );

        } catch ( Throwable e ) {

            return badRequestRollback( e );
        }
    }

    @Transactional
    public Result enviarEmailMapaDeLocalizacaoVeiculo() {

        try {

            final Path local = parametroRepository.buscarCaminhoGravarArquivoEmail(ARCOM);
            final List<GerenteMapaGeolocalizacaoDto> dtos = custoTransporteService.gerarMapaLocalizacaoTodosVeiculos();
            final List<EnvelopeDto> envelopes = new ArrayList<>( dtos.size() );
            final StringJoiner erros = new StringJoiner("\n");

            for ( GerenteMapaGeolocalizacaoDto dto : dtos ) {

                final String conteudo = localVeiculo.render( dto.getMapa() ).body();

                final Path arquivoGerTrans = local.resolve(format("mapa-gerente-%s-%s.html", dto.getIdGerente(), getRandom()));

                if ( gravarTexto( arquivoGerTrans, conteudo ) )
                    envelopes.add(
                        new EnvelopeDto
                        .Builder( "Mapa de localização de veiculo" )
                        .comMensagem( "Segue anexo o mapa com as localizacoes dos veiculos \n" + custoTransporteService.getLegendaCoresMapaLocalizacao() )
                        .comArquivos( arquivoGerTrans.toString() )
                        .comDestinatarios( custoTransporteService.getEmailGerenteTransporte(dto.getIdGerente()), "regis@arcom.com.br" )
                        .comExclusao()
                        .build()
                    );
                else
                    erros.add( format( "Gerente [ %s ]  Falhou geração do arquivo: %s\n", dto.getIdGerente(), arquivoGerTrans ) );
            }

            if ( erros.length() > 1 )
                throw new BusinessException( erros.toString() );

            if ( !isVazia(envelopes) )
                for ( EnvelopeDto envelope : envelopes )
                    emailService.enviar(envelope);

            return ok();

        } catch ( final Throwable e ) {

            return badRequestRollback( e );
        }
    }

    @Transactional( readOnly = true )
    public Result buscarMapaPernoiteVendas() {

        try {
            Source<ByteString, ?> source = parametroRepository
                    .buscarPath( ARCOM, ARQUIVO_MAPA_PERNOITE_VENDAS )
                    .flatMap( UtilArquivo::getConteudoDoArquivo )
                    .map( this::getChuncked )
                    .orElseThrow( () -> new BusinessException( "Não foi possivel ler o conteudo do arquivo de mapa" ) );
            return ok().chunked( source );
        } catch ( Throwable e ) {
            return badRequest( getExceptionComoString( e ) );
        }
    }

    /**
     * Prepare a chunked text stream
     *
     * @param dados String de dados p/ aplicar chuncked.
     *
     * @return Chuncked
     */
    private Source<ByteString, ?> getChuncked( final String dados ) {

        return Source.<ByteString>actorRef(256, OverflowStrategy.dropNew() )
            .mapMaterializedValue( sourceActor -> {
                sourceActor.tell( ByteString.fromString( dados ), null );
                sourceActor.tell( new Status.Success( NotUsed.getInstance()), null );
                return NotUsed.getInstance();
            });
    }

}
