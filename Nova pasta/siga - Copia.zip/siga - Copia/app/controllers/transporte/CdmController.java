package controllers.transporte;

import controllers.AuthController;
import infra.binders.ShortBinder;
import models.repository.vendas.CdaRepository;
import play.db.jpa.Transactional;
import play.mvc.Result;

import javax.inject.Inject;

import static infra.binders.ShortBinder.getValue;
import static infra.util.UtilException.getException;
import static play.libs.Json.newObject;

public class CdmController extends AuthController {

    private final CdaRepository cdaRepository;

    @Inject
    public CdmController( final CdaRepository cdaRepository ) {

        this.cdaRepository = cdaRepository;
    }

    @Transactional( readOnly = true )
    public Result buscarDescricao(
        final ShortBinder idEmpresa,
        final ShortBinder idCdm,
        final String fields
    ) {

        try {
            switch ( fields ) {
                case "descricao":
                    return cdaRepository
                            .buscarDescricaoPor( getValue(idEmpresa), getValue(idCdm) )
                            .map( descricao -> ok( newObject().put("descricao", descricao.trim()) ) )
                            .orElse( noContent() );
            }
            return badRequest( "Não foi possível atender solicitação!" );
        } catch ( Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }
}
