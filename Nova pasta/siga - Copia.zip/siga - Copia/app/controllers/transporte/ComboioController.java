package controllers.transporte;

import controllers.AuthController;
import infra.util.UtilDate;
import models.commons.dtos.AgrupamentoComboioVeiculoDto;
import models.commons.dtos.ComboioVeiculoDto;
import models.repository.admin.SistemaRepository;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.Result;
import services.transporte.ComboioService;

import javax.inject.Inject;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static infra.util.UtilException.getException;

public class ComboioController extends AuthController {

    private final ComboioService comboioService;

    @Inject
    public ComboioController(ComboioService comboioService) {
        this.comboioService = comboioService;
    }

    /**
     * Alysson Myller
     * 26/07/2018
     *
     * @return
     */
    @Transactional
    public Result buscarComboiosEmAndamento() {
        try {
            Map<Long, List<ComboioVeiculoDto>> mapComboioXVeiculosDoComboio = this.comboioService.buscarAgrupamentoComboiosEmAndamento(new Short("1"));

            List<AgrupamentoComboioVeiculoDto> veiculos = new ArrayList<>();
            for (Long idComboio : mapComboioXVeiculosDoComboio.keySet()){
                Long maiorDistancia = 0L;
                String situacaoVeiculo = "";
                List<ComboioVeiculoDto> veiculosComboios = mapComboioXVeiculosDoComboio.get(idComboio);
                for (ComboioVeiculoDto c : veiculosComboios){
                    if (c.getDistanciaMetros() != null && c.getDistanciaMetros() > maiorDistancia){
                        situacaoVeiculo = c.getSituacaoVeiculo();
                        maiorDistancia = c.getDistanciaMetros();
                    }
                }

                AgrupamentoComboioVeiculoDto dto = new AgrupamentoComboioVeiculoDto();
                dto.setIdComboio(idComboio);
                dto.setSituacaoComboioVeiculo(situacaoVeiculo);
                dto.setDistanciaMetros(maiorDistancia);
                dto.setDistanciaKm(String.valueOf(maiorDistancia / 1000L));
                dto.setVeiculos(veiculosComboios);
                veiculos.add(dto);
            }

            Comparator<AgrupamentoComboioVeiculoDto> orderBySituacaoEDistanciaDoComboio = new Comparator<AgrupamentoComboioVeiculoDto>() {
                @Override
                public int compare(AgrupamentoComboioVeiculoDto o1, AgrupamentoComboioVeiculoDto o2) {
                    Long distancia1 = o1.getDistanciaMetros() == null ? 0L : o1.getDistanciaMetros();
                    Long distancia2 = o2.getDistanciaMetros() == null ? 0L : o2.getDistanciaMetros();
                    return distancia2.compareTo(distancia1);
                }
            };
            Collections.sort(veiculos, orderBySituacaoEDistanciaDoComboio);

            Map<String, Object> mapRes = new HashMap<>();
            mapRes.put("dataUltimaAtualizacao", UtilDate.getDataComoString(this.comboioService.getDataHoraAgora(), UtilDate.FORMATO_DATA_HORA_MINUTO));
            mapRes.put("veiculos", veiculos);
            return ok(Json.toJson(mapRes));
        } catch ( Throwable ex ) {
            return badRequestRollback( ex );
        }
    }

    /**
     * Alysson Myller
     * 27/07/2018
     *
     * @param idEmpresa
     * @param idComboio
     * @param idVeiculo
     * @return
     */
    @Transactional
    public Result removerVeiculoComboio(final Long idEmpresa, final Long idComboio, final Long idVeiculo) {
        try {
            this.comboioService.removerVeiculoComboio(idEmpresa, idComboio, idVeiculo, getRequest().getIdUsuario());
            return ok();
        } catch ( Throwable ex ) {
            return badRequestRollback( ex );
        }
    }

}
