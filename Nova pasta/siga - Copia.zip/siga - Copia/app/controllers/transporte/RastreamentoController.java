package controllers.transporte;

import controllers.AuthController;
import play.db.jpa.Transactional;
import play.mvc.Result;
import services.transporte.RastreadorService;
import javax.inject.Inject;

public class RastreamentoController extends AuthController {

    private final RastreadorService rastreadorService;

    @Inject
    public RastreamentoController(RastreadorService rastreadorService) {

        this.rastreadorService = rastreadorService;
    }

    @Transactional
    public Result enviarEmailChecagemAberturaPortas() {

        try {
            rastreadorService.enviarEmailChecagemAberturaPortas();
            return ok();
        } catch (Throwable e) {
            return badRequestRollback(e);
        }
    }
}
