package controllers.transporte;

import akka.NotUsed;
import akka.actor.Status;
import akka.stream.OverflowStrategy;
import akka.stream.javadsl.Source;
import akka.util.ByteString;
import infra.binders.DateBinder;
import infra.binders.LocalDateBinder;
import infra.binders.ShortBinder;
import infra.controllers.Controller;
import models.commons.dtos.HistoricoCoordenadaDto;
import models.repository.admin.SistemaRepository;
import models.repository.transp.HistoricoCoordenadaRepository;
import play.db.jpa.Transactional;
import play.mvc.Result;
import services.custos.CustoTransporteService;
import services.transporte.AtomFotoService;
import services.transporte.GeolocalizacaoService;
import views.xml.api.transporte.geolocalizacao.index;

import javax.inject.Inject;
import java.util.List;
import java.util.Optional;

import static infra.binders.LocalDateBinder.getValue;
import static infra.binders.ShortBinder.getValue;
import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilException.getExceptionComoString;
import static java.lang.String.format;
import static play.libs.Json.toJson;

public class PublicController extends Controller {

    // Service:
    private final GeolocalizacaoService geolocalizacaoService;
    private final AtomFotoService atomFotoService;

    // Repository:
    private final HistoricoCoordenadaRepository historicoCoordenadaRepository;
    private final SistemaRepository sistemaRepository;
    private final CustoTransporteService custoTransporteService;

    @Inject
    public PublicController(
        final GeolocalizacaoService geolocalizacaoService,
        final AtomFotoService atomFotoService,
        final HistoricoCoordenadaRepository historicoCoordenadaRepository,
        final SistemaRepository sistemaRepository,
        final CustoTransporteService custoTransporteService
    ) {

        this.geolocalizacaoService = geolocalizacaoService;
        this.atomFotoService = atomFotoService;
        this.historicoCoordenadaRepository = historicoCoordenadaRepository;
        this.sistemaRepository = sistemaRepository;
        this.custoTransporteService = custoTransporteService;
    }

    @Transactional( readOnly = true )
    public Result buscarCoordenadasKml(
        final ShortBinder idEmpresa,
        final Long idViagem
    ) {

        try {
            final List<HistoricoCoordenadaDto> coordenadas =
                    historicoCoordenadaRepository.buscarCoordenadasDaViagem( getValue(idEmpresa), idViagem );

            if ( isVazia( coordenadas ) )
                return noContent();

            response().setHeader( "Access-Control-Allow-Origin", "*" );

            return HistoricoCoordenadaDto
                    .getInfoViagem( coordenadas )
                    .map( infoViagem -> ok( index.render( infoViagem, coordenadas ) ) )
                    .orElse( noContent() );

        } catch ( Throwable e ) {

            return badRequest( getExceptionComoString( e ) );
        }
    }

    @Transactional( readOnly = true )
    public Result checkImportacaoCoordenadaRastreador() {

        return ok ( toJson( geolocalizacaoService.buscarUltimaImportacaoDeCoordenada() ) );
    }

    @Transactional( readOnly = true )
    public Result buscarImagemAceiteAtom( final Long idAtomEntrega ) {

        try {

            Optional<String> possivelStringBase64  = atomFotoService.buscarFotoAceiteBase64( idAtomEntrega );
            if ( !possivelStringBase64.isPresent() )
                return badRequest( format( "FOTO NAO LOCALIZADA DO ACEITE - ID_ATOM_ENTREGA: %s", idAtomEntrega ));

            // Prepare a chunked text stream
            Source<ByteString, ?> source = Source.<ByteString>actorRef(256, OverflowStrategy.dropNew())
                    .mapMaterializedValue(sourceActor -> {
                        sourceActor.tell(ByteString.fromString( possivelStringBase64.get() ), null);
                        sourceActor.tell(new Status.Success(NotUsed.getInstance()), null);
                        return NotUsed.getInstance();
                    });

            return ok().chunked(source);

        } catch ( Throwable e ) {
            return badRequest( getExceptionComoString( e ) );
        }
    }

    @Transactional
    public Result agendarEntrega(
        final Long idCliente,
        final DateBinder data
    ) {

        try {
            if ( custoTransporteService.agendarEntrega(idCliente,DateBinder.getValue(data) ) ) return ok();
            return noContent();
        } catch ( Throwable e ) {
            sistemaRepository.setRollbackOnly();
            return badRequest(getExceptionComoString(e));
        }
    }

    @Transactional( readOnly = true )
    public Result buscarRotaMapaPernoiteVendas(
        final ShortBinder idEmpresa,
        final Long idRepresentante,
        final LocalDateBinder dia
    ) {

        try {

            response().setHeader( "Access-Control-Allow-Origin", "*" );

            final List<HistoricoCoordenadaDto> coordenadas = historicoCoordenadaRepository
                    .buscarCoordenadasDoRepresentante(
                        getValue( idEmpresa ),
                        idRepresentante,
                        getValue( dia )
            ) ;

            return HistoricoCoordenadaDto
                    .getInfoViagem( coordenadas )
                    .map( infoViagem -> ok( index.render( infoViagem, coordenadas ) ) )
                    .orElse( noContent() );

        } catch ( Throwable e ) {

            return badRequest( getExceptionComoString( e ) );
        }
    }

}
