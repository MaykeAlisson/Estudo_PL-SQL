package controllers;

import authenticator.AcessoAutenticadoApi;
import infra.controllers.Controller;
import play.mvc.Security.Authenticated;

import static infra.jwt.Token.INFO_TOKEN;
import static infra.jwt.Token.Value;

/**
 * Controladora base para requisições autenticadas.
 */
@Authenticated( AcessoAutenticadoApi.class )
public class AuthController extends Controller {

    /**
     * Retorna valores armazenados no token do usuário.
     *
     * <p>Autor: GPortes</p>
     *
     * @return Valores do token
     */
    protected Value getRequest() {

        if( ctx().args.containsKey( INFO_TOKEN ) )
            return (Value) ctx().args.get( INFO_TOKEN );

        return null;
    }
}
