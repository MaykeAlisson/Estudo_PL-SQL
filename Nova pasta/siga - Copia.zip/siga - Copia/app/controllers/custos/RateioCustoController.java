package controllers.custos;

import controllers.AuthController;
import infra.binders.ShortBinder;
import models.commons.constantes.AtividadeCusto;
import models.commons.constantes.SubGrupoCusto;
import models.commons.dtos.DestinoRateioCustoDto;
import play.db.jpa.Transactional;
import play.mvc.Result;
import play.mvc.Results;
import services.custos.MovimentoDespesaService;

import javax.inject.Inject;

import static infra.binders.ShortBinder.getValue;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilException.getException;
import static play.libs.Json.newObject;

/**
 * Controller ref. ao rateio de custos.
 *
 * @author GPortes
 * @since 07/03/2017
 *
 */
public class RateioCustoController extends AuthController {

    // Service:
    private final MovimentoDespesaService movimentoDespesaService;

    @Inject
    public RateioCustoController( final MovimentoDespesaService movimentoDespesaService ) {

        this.movimentoDespesaService = movimentoDespesaService;
    }

    @Transactional( readOnly = true )
    public Result buscarDespesas(
        final ShortBinder idEmpresa,
        final Long ocorrencia,
        final ShortBinder sequencia
    ) {

        try {
            return movimentoDespesaService.buscarDespesas(
                    getValue( idEmpresa ),
                    ocorrencia,
                    getValue( sequencia )
                )
                .map( valor -> newObject().put("vlrCusto", valor ) )
                .map( Results::ok )
                .orElse( noContent() );
        } catch ( final Throwable e ) {
            return badRequest( getException(e) );
        }
    }

    @Transactional
    public Result gravar( ) {

        try {
            movimentoDespesaService.alocarDespesa(
                getShort( "idEmpresa" ),
                getLong( "ocorrencia" ),
                getShort( "sequencia" ),
                getEnum( AtividadeCusto.class, getString( "atividadeCusto" ) ),
                getEnum( SubGrupoCusto.class, getString( "subGrupoCusto" ) ),
                getList( "destinos", DestinoRateioCustoDto.class )
            );
            return ok();
        } catch ( final Throwable e ) {
            return badRequestRollback( e );
        }
    }
}
