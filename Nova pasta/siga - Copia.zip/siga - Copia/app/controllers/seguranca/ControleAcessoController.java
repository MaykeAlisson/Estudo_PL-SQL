package controllers.seguranca;

import infra.binders.LocalDateBinder;
import infra.controllers.Controller;
import infra.exceptions.BusinessException;
import models.commons.dtos.UsuarioAcessoDto;
import models.repository.seguranca.SolicitacaoUsuarioPerfilRespository;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Result;
import play.mvc.Results;
import services.seguranca.ControleAcessoService;

import javax.inject.Inject;
import java.util.List;
import java.util.Objects;

import static infra.binders.LocalDateBinder.getValue;
import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilException.getException;
import static java.util.stream.Collectors.joining;
import static models.domains.admin.Empresa.IdEmpresa.ARCOM;

public class ControleAcessoController extends Controller {

    // Service:
    private final ControleAcessoService controleAcessoService;
    private final SolicitacaoUsuarioPerfilRespository solicitacaoUsuarioPerfilRespository;

    @Inject
    public ControleAcessoController(
            final ControleAcessoService controleAcessoService,
            final SolicitacaoUsuarioPerfilRespository solicitacaoUsuarioPerfilRespository
    ) {

        this.controleAcessoService = controleAcessoService;
        this.solicitacaoUsuarioPerfilRespository = solicitacaoUsuarioPerfilRespository;
    }

    @BodyParser.Of( BodyParser.Json.class )
    @Transactional
    public Result fazLogin() {

        try {
            return controleAcessoService
                .validarCredenciais(
                    getLong( "idUsuario" ),
                    getString( "senha" ),
                    false
                )
                .map( Json::toJson )
                .map( Results::ok )
                .orElse( unauthorized() );
        } catch ( BusinessException e ) {
            setRollbackOnly();
            return unauthorized( getException(e) );
        } catch ( Throwable e ) {
            return badRequestRollback( e );
        }
    }

    @BodyParser.Of( BodyParser.Json.class )
    @Transactional
    public Result buscarToken() {

        try {
            return controleAcessoService
                .validarCredenciais(
                    getLong( "idUsuario" ),
                    getString( "senha" ),
                    true
                )
                .map( UsuarioAcessoDto::getToken )
                .map( Results::ok )
                .orElse( unauthorized() );
        } catch ( BusinessException e ) {
            setRollbackOnly();
            return unauthorized( getException(e) );
        } catch ( Throwable e ) {
            return badRequestRollback( e );
        }
    }

    @Transactional( readOnly = true )
    public Result buscarUsuariosTrocaPerfil(
            final LocalDateBinder dataAlteracaoPerfil,
            final String formatoTexto
    ) {

        if ( dataAlteracaoPerfil == null )
            return badRequest( "Obrigatório informar a data para pesquisa" );

        try {
            final List<Long> idUsuarios = solicitacaoUsuarioPerfilRespository.buscarUsuariosTrocaPerfil(
                ARCOM,
                getValue(dataAlteracaoPerfil)
            );

            if ( isVazia(idUsuarios) )
                return noContent();

            final String retorno = idUsuarios
                .stream()
                .map(String::valueOf)
                .collect(joining(","));

            return  Objects.equals(formatoTexto,"texto")
                    ? ok( retorno )
                    : ok( Json.newObject().put("idUsuarios", retorno) );

        } catch ( Throwable e ) {
            return badRequest( getException(e) );
        }
    }

}
