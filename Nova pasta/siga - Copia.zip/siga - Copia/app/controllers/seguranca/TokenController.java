package controllers.seguranca;

import controllers.AuthController;
import infra.binders.LocalDateTimeBinder;
import infra.binders.LongBinder;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.Result;
import play.mvc.Results;
import services.seguranca.ControleAcessoService;

import javax.inject.Inject;

import static infra.binders.LocalDateTimeBinder.getValue;
import static infra.binders.LongBinder.getValue;
import static infra.util.UtilException.getException;

public class TokenController extends AuthController {

    private final ControleAcessoService controleAcessoService;

    @Inject
    public TokenController( final ControleAcessoService controleAcessoService ) {

        this.controleAcessoService = controleAcessoService;
    }

    @Transactional(readOnly = true)
    public Result gerarToken(
        final LongBinder idUsuarioBinder,
        final LocalDateTimeBinder dataExpiracaoBinder
    ) {

        try {
            return controleAcessoService
                .gerarToken(
                    getValue(idUsuarioBinder),
                    getValue(dataExpiracaoBinder)
                )
                .map( token -> Json.newObject().put("token", token) )
                .map( Results::ok )
                .orElse( noContent() );
        } catch ( Throwable e ) {
            return badRequest( getException(e) );
        }
    }

    @Transactional
    public Result gravarLogAcessoSiga() {

        try {
            controleAcessoService.gravarLogAcessoSIGA(
                getLong("idMenu" ),
                getLocalDateTime("versao" ),
                getRequest().getIdUsuario(),
                getUserAgent()
            );
            return ok();
        } catch ( final Throwable e ) {
            return badRequestRollback( e );
        }
    }
}
