package controllers.reinf;

import controllers.AuthController;
import models.commons.constantes.ESocialConstantes;
import models.commons.constantes.ReinfConstantes;
import models.commons.dtos.EmpregadoresESocialDto;
import models.eSocial.Processo;
import models.repository.admin.SistemaRepository;
import models.repository.fisco.ProcessoRepository;
import play.db.jpa.Transactional;
import play.mvc.Controller;
import play.mvc.Result;
import services.eSocial.impl.ESocialUtil;
import services.reinf.eventos.ConsultaInformacoesConsolidadasService;
import services.reinf.eventos.EnviaConsultaLoteService;
import services.reinf.eventos.R1000Service;
import services.reinf.eventos.R1070Service;
import services.reinf.eventos.R2010Service;
import services.reinf.eventos.R2020Service;
import services.reinf.eventos.R2070Service;
import services.reinf.eventos.R2098Service;
import services.reinf.eventos.R2099Service;
import services.reinf.eventos.R5001Service;
import services.reinf.eventos.R9000Service;

import javax.inject.Inject;
import java.util.Arrays;
import java.util.List;

import static infra.util.UtilException.getExceptionComoString;

/**
 * Controller responsável por centralizar requisições externas do eSocial.
 *
 * <p>
 * Autor: Fernando Vicente
 * </p>
 *
 * @since 21/08/2017
 */
public class ReinfController extends AuthController {

	// Service:
	private final R1000Service r1000Service;
	private final R1070Service r1070Service;
	private final R2010Service r2010Service;
	private final R2020Service r2020Service;
	private final R2070Service r2070Service;
	private final R2098Service r2098Service;
	private final R2099Service r2099Service;
	private final R5001Service r5001Service;
	private final R9000Service r9000Service;
	private final EnviaConsultaLoteService enviaConsultaLoteService;
	private final ConsultaInformacoesConsolidadasService consultaInformacoesConsolidadasService;
	private final ProcessoRepository processoRepository;
	private final SistemaRepository sistemaRepository;

	@Inject
	public ReinfController(
			final R1000Service r1000Service,
			final R1070Service r1070Service,
			final R2010Service r2010Service,
			final R2020Service r2020Service,
			final R2070Service r2070Service,
			final R2098Service r2098Service,
			final R2099Service r2099Service,
			final R5001Service r5001Service,
			final R9000Service r9000Service,
			final EnviaConsultaLoteService enviaConsultaLoteService,
			final ConsultaInformacoesConsolidadasService consultaInformacoesConsolidadasService,
			final ProcessoRepository processoRepository,
			final SistemaRepository sistemaRepository
	) {

		this.r1000Service = r1000Service;
		this.r1070Service = r1070Service;
		this.r2010Service = r2010Service;
		this.r2020Service = r2020Service;
		this.r2070Service = r2070Service;
		this.r2098Service = r2098Service;
		this.r2099Service = r2099Service;
		this.r5001Service = r5001Service;
		this.r9000Service = r9000Service;
		this.enviaConsultaLoteService = enviaConsultaLoteService;
		this.consultaInformacoesConsolidadasService = consultaInformacoesConsolidadasService;
		this.processoRepository = processoRepository;
		this.sistemaRepository = sistemaRepository;
	}

	/**
	 * Serviço responsavel por orquestrar chamada de eventos.
	 *
	 * <p>
	 * Autor: Fernando Vicente
	 * </p>
	 *
	 *
	 * @return OK se processo ocorreu sem problemas.
	 */
	@Transactional
	public Result gerarEvento(String evento) {

		Processo processo = new Processo();
		List<EmpregadoresESocialDto> empregadoresList = processoRepository.buscarEmpregadoresESocial();
		for (EmpregadoresESocialDto empregador : empregadoresList){
			if (empregador.getEmpresa() != 1) { continue; }
			processo.setIdEmpresa(empregador.getEmpresa());
			processo.setCnpj(empregador.getCnpj());
		}
		String retorno = "";
		processo.setIdSistema(2L);
		processo.setDataInicio(sistemaRepository.getHoje());
		processo.setIdEventoCatalogo(1L);
		processo.setVersaoProcessamento(ESocialConstantes.VERSAO_PROCESSO);
		processo.setQtdEventos(0l);
		processoRepository.save(processo);

		try {
			switch (evento.toUpperCase()) {
				case ReinfConstantes.R1000:
					retorno += r1000Service.informacoesContribuinte(processo);
					break;
				case ReinfConstantes.R1070:
					retorno += r1070Service.tabProcAdministrativosJudiciais(processo);
					break;
				case ReinfConstantes.R2010:
					retorno += r2010Service.retContribPrevServicosTomados(processo);
					break;
				case ReinfConstantes.R2020:
					retorno += r2020Service.retContribPrevServicosPrestados(processo);
					break;
				case ReinfConstantes.R2070:
					retorno += r2070Service.rentencaoFonte(processo);
					break;
				case ReinfConstantes.R2098:
					retorno += r2098Service.reaberturaEventosPeriodicos(processo,"2018-07-01");
					break;
				case ReinfConstantes.R2099:
					retorno += r2099Service.fechamentoEventosPeriodicos(processo, "2018-08-01");
					break;
				case ReinfConstantes.R5001:
					retorno += r5001Service.informacoesBasesTributosPorEvento(processo);
					break;
				case ReinfConstantes.R5011:
					retorno += consultaInformacoesConsolidadasService.enviarConsulta(
							ESocialUtil.getNrInsc(Long.valueOf(ESocialConstantes.CNPJ)).toString(),
							"1",
							"16849-2099-1809-16849" );
					break;
				case ReinfConstantes.R9000:
					List<String> recibos =
							Arrays.asList("5369-2099-1804-5369");
					String dataBase = "2018-04";
					Integer count = 0;
					for (String recibo : recibos){
						count++;
						retorno += r9000Service.exclusaoEventos(processo, recibo, dataBase, count);
					}
					break;

				default:
					retorno = "Evento " + evento + " não configurado.";
					break;
			}
			retorno = "----------------------------------------------------------------------------------------------------------------------\n"
					+ "Gerar Evento - " + evento.toUpperCase() +"\n"
					+ "----------------------------------------------------------------------------------------------------------------------\n"
					+ retorno;
			return ok(retorno);
		} catch (Throwable e) {
			return badRequest(getExceptionComoString(e));
		}
	}

	/**
	 * Expõe serviço para geração de lotes de envio
	 *
	 * <p>
	 * Autor: Fernando Vicente
	 * </p>
	 *
	 *
	 * @return OK se processo ocorreu sem problemas.
	 */
	@Transactional
	public Result enviaConsultaLote() {

		try {
			String retorno = "";

			retorno += enviaConsultaLoteService.buscaEventosEnvio(ESocialConstantes.TipoEvento.EDF_REINF.getId());

			return ok(retorno);
		} catch (Throwable e) {
			return badRequest(getExceptionComoString(e));
		}
	}



}
