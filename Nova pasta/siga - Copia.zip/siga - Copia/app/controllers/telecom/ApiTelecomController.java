package controllers.telecom;

import com.fasterxml.jackson.databind.JsonNode;
import infra.binders.ShortBinder;
import models.commons.dtos.GestorFuncionarioDto;
import models.repository.rh.FuncionarioRhRepository;
import play.db.jpa.Transactional;
import play.mvc.Controller;
import play.mvc.Result;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import static infra.binders.ShortBinder.getValue;
import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilException.getExceptionComoString;
import static infra.util.UtilNumero.asListLong;
import static infra.util.UtilNumero.ehNulo;
import static infra.util.UtilString.isVazia;
import static java.lang.Short.valueOf;
import static java.util.Collections.singletonList;
import static java.util.stream.Collectors.joining;

public class ApiTelecomController extends Controller {

    private final FuncionarioRhRepository funcionarioRhRepository;

    @Inject
    public ApiTelecomController( final FuncionarioRhRepository funcionarioRhRepository ) {

        this.funcionarioRhRepository = funcionarioRhRepository;
    }

    @Transactional( readOnly = true )
    public Result buscarGestorDeptoPorMatricula(
        final ShortBinder idEmpresa,
        final String idFuncionarios
    ) {

        try {
            final List<GestorFuncionarioDto> getores = funcionarioRhRepository.buscarGestorDoFuncionario(
                    getValue(idEmpresa),
                    asListLong(idFuncionarios)
            );

            if ( isVazia(getores) )
                return noContent();

            final String retorno =
                    getores.stream()
                            .map( GestorFuncionarioDto::getInfoTelecom )
                            .collect( joining("\n") );
            return ok( retorno );

        } catch ( Throwable e ) {
            return badRequest( getExceptionComoString( e ) );
        }

    }

    @Transactional( readOnly = true )
    public Result buscarGestorDepto( final ShortBinder idEmpresaBinder,
                                     final Long idFuncionario ) {

        StringBuilder msg = new StringBuilder();

        if ( ehNulo( idEmpresaBinder ) )
            msg.append( " [ empresa ] " );

        if ( idFuncionario == null )
            msg.append( " [ funcionario ] ");

        if ( !isVazia(msg) )
            return badRequest( "Faltou informar argumento(s): " + msg.toString() );

        try {

            final List<GestorFuncionarioDto> getores = funcionarioRhRepository.buscarGestorDoFuncionario(
                idEmpresaBinder.getValue(),
                singletonList( idFuncionario )
            );

            if ( isVazia(getores) )
                return noContent();

            final String retorno = getores.stream()
                                          .map( GestorFuncionarioDto::getInfoTelecom )
                                          .collect( joining() );

            if ( isVazia(retorno) )
                return noContent();

            return ok( retorno );

        } catch ( Throwable e ) {

            return badRequest( getExceptionComoString(e) );
        }
    }

    @Transactional( readOnly = true )
    public Result buscarGestoresDepto() {

        if ( !request().hasBody() )
            return badRequest( "Faltou definir argumentos" );

        final JsonNode json = request().body().asJson();
        if ( json == null )
            return badRequest( "Faltou definir argumentos" );

        final List<GestorFuncionarioDto> dados = new ArrayList<>();

        final Iterator<Map.Entry<String, JsonNode>> fields = json.fields();

        while ( fields.hasNext() ) {

            final Map.Entry<String, JsonNode> idEmpresaFuncionarios = fields.next();
            final Short idEmpresa = valueOf( idEmpresaFuncionarios.getKey() );
            final List<Long> idFuncionarios = new ArrayList<>();

            for ( JsonNode idFuncionario : idEmpresaFuncionarios.getValue() )
                if ( idFuncionario.isNumber() ) idFuncionarios.add( idFuncionario.asLong() );

            dados.addAll( funcionarioRhRepository.buscarGestorDoFuncionario( idEmpresa, idFuncionarios ) );
        }

        if ( isVazia( dados ) )
            return noContent();

        final String retorno =
            dados.stream()
                 .map( GestorFuncionarioDto::getInfoTelecom )
                 .collect( joining("\n") );

        return ok( retorno );
    }

}
