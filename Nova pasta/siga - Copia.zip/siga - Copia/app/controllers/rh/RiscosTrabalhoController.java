package controllers.rh;

import controllers.AuthController;
import infra.binders.ShortBinder;
import models.domains.rh.RiscoFuncaoDepto;
import models.domains.rh.RiscoTrabalho;
import play.db.jpa.Transactional;
import play.mvc.Result;
import services.rh.RiscoTrabalhoService;

import javax.inject.Inject;

import static infra.binders.ShortBinder.getValue;
import static infra.util.UtilException.getException;
import static play.libs.Json.toJson;

/**
 * Created by alysson on 25/04/2018.
 */
public class RiscosTrabalhoController extends AuthController {

    // Service
    private final RiscoTrabalhoService riscoTrabalhoService;

    @Inject
    public RiscosTrabalhoController( final RiscoTrabalhoService riscoTrabalhoService ) {

        this.riscoTrabalhoService = riscoTrabalhoService;
    }

    @Transactional(readOnly = true)
    public Result buscarTodosRiscos() {

        return ok( toJson( riscoTrabalhoService.buscarTodos() ) );
    }

    @Transactional
    public Result salvar() {

        try {
            final RiscoTrabalho risco = new RiscoTrabalho();
            risco.setRiscoTrabalho( getString("riscoTrabalho") );
            risco.setDescRiscoTrabalho( getString("descRiscoTrabalho") );
            riscoTrabalhoService.salvar( risco );
            return ok();
        } catch ( Throwable e ) {
            return badRequestRollback( e );
        }
    }

    @Transactional
    public Result excluir() {

        try {
            riscoTrabalhoService.excluir( getString("riscoTrabalho") );
            return ok();
        } catch ( Throwable e ) {
            return badRequestRollback( e );
        }
    }

    @Transactional(readOnly = true)
    public Result buscarDepartamentosFuncoes( final ShortBinder idEmpresa ) {

        try {
            return ok( toJson( riscoTrabalhoService.buscarDepartamentoFuncoes( getValue(idEmpresa) ) ) );
        } catch ( Throwable e ) {
            return badRequest( getException(e) );
        }
    }

    @Transactional
    public Result gravarRelacionamentos() {

        try {
            riscoTrabalhoService.gravarRelacionamentos( getList("relacionamentos", RiscoFuncaoDepto.class) );
            return ok();
        } catch ( Throwable e ) {
            return badRequestRollback( e );
        }
    }

    @Transactional(readOnly = true)
    public Result buscarRelacionamentos(
        final ShortBinder idEmpresa,
        final String tipoBusca,
        final String valor
    ) {

        try {
            return ok( toJson( riscoTrabalhoService.buscarRelacionamentos( getValue(idEmpresa), tipoBusca, valor ) ) );
        } catch ( Throwable e ) {
            return badRequest( getException(e) );
        }
    }

    @Transactional(readOnly = true)
    public Result buscarTodosRelacionamentos( final ShortBinder idEmpresa )  {

        try {
            return ok(toJson(riscoTrabalhoService.buscarTodosRelacionamentos(getValue(idEmpresa))));
        } catch ( Throwable e ) {
            return badRequest( getException(e) );
        }
    }

    @Transactional
    public Result removerRelacionamentos()  {

        try {
            riscoTrabalhoService.removerRelacionamentos(
                getList("idsRelacionamentos",Long.class ),
                getLocalDateTime( "dataFim" )
            );
            return ok();
        } catch ( Throwable e ) {
            return badRequestRollback( e );
        }
    }
}
