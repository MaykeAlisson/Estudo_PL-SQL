package controllers.rh;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import controllers.AuthController;
import infra.binders.ShortBinder;
import infra.exceptions.BusinessException;
import infra.model.Model;
import models.commons.dtos.CatalogoCatDto;
import models.commons.dtos.GestorFuncionarioDto;
import models.commons.dtos.PcmsoDto;
import models.domains.rh.AgentesCausadoresCat;
import models.domains.rh.ComunicadoAcidenteTrabalho;
import models.domains.rh.FichaMedica;
import models.domains.rh.FichaMedicaId;
import models.domains.rh.MonitoramentoSaudeTrabalho;
import models.domains.rh.PartesAtingidasCat;
import models.repository.admin.EmpresaRepository;
import models.repository.fisco.ComunicadoAcidenteTrabalhoRepository;
import models.repository.fisco.MonitoramentoSaudeTrabalhoRepository;
import models.repository.rh.FuncionarioRhRepository;
import play.Logger;
import play.db.jpa.Transactional;
import play.mvc.Result;
import play.mvc.Results;
import services.rh.FuncionarioPontoService;

import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.StringJoiner;

import static infra.binders.ShortBinder.getValue;
import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilException.getException;
import static infra.util.UtilException.getExceptionComoString;
import static infra.util.UtilNumero.toLong;
import static infra.util.UtilNumero.toShort;
import static infra.util.UtilSistema.logaSeDesenvolvimento;
import static java.util.Collections.singletonList;
import static java.util.Objects.requireNonNull;
import static junit.framework.Assert.assertEquals;
import static play.Logger.info;
import static play.libs.Json.fromJson;
import static play.libs.Json.mapper;
import static play.libs.Json.toJson;

public class FuncionarioController extends AuthController {

    private final FuncionarioRhRepository funcionarioRhRepository;
    private final FuncionarioPontoService funcionarioPontoService;
    private final ComunicadoAcidenteTrabalhoRepository comunicadoAcidenteTrabalhoRepository;
    private final MonitoramentoSaudeTrabalhoRepository monitoramentoSaudeTrabalhoRepository;
    private final EmpresaRepository empresaRepository;
    private Validator validator;

    @Inject
    public FuncionarioController(
            final FuncionarioRhRepository funcionarioRhRepository,
            final FuncionarioPontoService funcionarioPontoService,
            final ComunicadoAcidenteTrabalhoRepository comunicadoAcidenteTrabalhoRepository,
            final MonitoramentoSaudeTrabalhoRepository monitoramentoSaudeTrabalhoRepository,
            final EmpresaRepository empresaRepository,
            Validator validator) {

        this.funcionarioRhRepository = funcionarioRhRepository;
        this.funcionarioPontoService = funcionarioPontoService;
        this.comunicadoAcidenteTrabalhoRepository = comunicadoAcidenteTrabalhoRepository;
        this.monitoramentoSaudeTrabalhoRepository = monitoramentoSaudeTrabalhoRepository;
        this.empresaRepository = empresaRepository;
        this.validator = validator;
    }

    @Transactional
    public Result inserirMarcacaoPonto() {

        final String email = getString("email");
        final LocalDateTime dataEntrada = getLocalDateTime("dataEntrada");
        final LocalDateTime dataSaida = getLocalDateTime("dataSaida");
        final Long relogio = getLong("relogio");

        info( "[ FuncionarioController.inserirMarcacaoPonto ] {} [ {} - {} ]: {}", email, dataEntrada, dataSaida, relogio );

        try {
            funcionarioPontoService.inserirMarcacaoPonto( email, dataEntrada, dataSaida, new BigDecimal( relogio ) );
            return ok();
        } catch ( Throwable ex ) {
            return badRequestRollback( ex );
        }
    }

    @Transactional( readOnly = true )
    public Result buscarGestorDoFuncionario(
        final Optional<ShortBinder> possivelEmpresa,
        final Optional<Long> possivelIdFuncionario,
        final Optional<String> possivelEmail
    ) {

        try {
            if ( possivelIdFuncionario.isPresent() )
                return  buscarGestor( getValue( possivelEmpresa ), possivelIdFuncionario.get() )
                        .map( Results::ok )
                        .orElse( noContent() );

            if ( possivelEmail.isPresent() ) {
                final List<Map<String, Object>> dados =
                        funcionarioRhRepository.buscarMatriculasDoEmail( possivelEmail.get() );

                final StringJoiner info = new StringJoiner("\n" );
                for ( Map<String, Object> map : dados )
                    buscarGestor(toShort(map.get("ID_EMPRESA")), toLong(map.get("ID_FUNCIONARIO")))
                            .map( info::add );

                return info.length() > 0 ? ok( info.toString() ) : noContent();
            }

            return noContent();

        } catch ( Throwable e ) {
            return badRequest( getExceptionComoString(e) );
        }
    }

    private Optional<String> buscarGestor(
        final Short idEmpresa,
        final Long idFuncionario
    ) {
        return
            funcionarioRhRepository.buscarGestorDoFuncionario( idEmpresa, singletonList( idFuncionario ) )
                .stream()
                .map( GestorFuncionarioDto::getInfoTelecom )
                .reduce( ( gestor1, gestor2 ) -> gestor1 + "\n" + gestor2 );
    }

    @Transactional( readOnly = true )
    public Result buscarDadosFuncionario(
            final Optional<ShortBinder> possivelEmpresa,
            final Optional<Long> possivelIdFuncionario
    ) {

        if (possivelIdFuncionario.isPresent()) {
            try {
                return ok(toJson(funcionarioRhRepository.buscarFuncionarioSiga(getValue(possivelEmpresa), possivelIdFuncionario.get())));
            } catch (Throwable ex) {
                return badRequest(getException(ex));
            }
        } else {
            return noContent();
        }
    }

    @Transactional( readOnly = true )
    public Result buscarDadosCat(
        final ShortBinder idEmpresa,
        final Long idFuncionario
    ) {

        try {
            List<ComunicadoAcidenteTrabalho> lista = comunicadoAcidenteTrabalhoRepository.buscarPorMatricula(getValue(idEmpresa), idFuncionario);
            if (isVazia(lista))
                return noContent();
            return ok(toJson(lista));
        } catch (Throwable ex) {
            return badRequest(getException(ex));
        }
    }

    @Transactional( readOnly = true )
    public Result buscarAcidenteTipo() {
        try {
            List<CatalogoCatDto> catalogoCatDtoList = funcionarioRhRepository.buscarAcidenteTipo();
            return ok(toJson(catalogoCatDtoList));
        } catch ( Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }

    @Transactional( readOnly = true )
    public Result buscarAcidenteSituacaoGeradora() {
        try {
            List<CatalogoCatDto> catalogoCatDtoList= funcionarioRhRepository.buscarAcidenteSituacaoGeradora();
            return ok(toJson(catalogoCatDtoList));
        } catch ( Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }

    @Transactional( readOnly = true )
    public Result buscarAcidentePaises() {
        try {
            List<CatalogoCatDto> catalogoCatDtoList= funcionarioRhRepository.buscarAcidentePaises();
            return ok(toJson(catalogoCatDtoList));
        } catch ( Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }

    @Transactional( readOnly = true )
    public Result buscarAcidenteParteCorpoAtingida() {
        try {
            List<CatalogoCatDto> catalogoCatDtoList= funcionarioRhRepository.buscarAcidenteParteCorpoAtingida();
            return ok(toJson(catalogoCatDtoList));
        } catch ( Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }

    @Transactional( readOnly = true )
    public Result buscarAcidenteAgenteCausador() {
        try {
            List<CatalogoCatDto> catalogoCatDtoList= funcionarioRhRepository.buscarAcidenteAgenteCausador();
            return ok(toJson(catalogoCatDtoList));
        } catch ( Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }

    @Transactional( readOnly = true )
    public Result buscarAcidenteLesao() {
        try {
            List<CatalogoCatDto> catalogoCatDtoList= funcionarioRhRepository.buscarAcidenteLesao();
            return ok(toJson(catalogoCatDtoList));
        } catch ( Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }

    @Transactional( readOnly = true )
    public Result buscarCodigosCid() {
        try {
            List<CatalogoCatDto> catalogoCatDtoList= funcionarioRhRepository.buscarCodigosCid();
            return ok(toJson(catalogoCatDtoList));
        } catch ( Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }

    @Transactional( readOnly = true )
    public Result buscarMunicipiosIbge() {
        try {
            List<CatalogoCatDto> catalogoCatDtoList= funcionarioRhRepository.buscarMunicipiosIbge();
            return ok(toJson(catalogoCatDtoList));
        } catch ( Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }

    @Transactional( readOnly = true )
    public Result buscarExamesCatalogo() {
        try {
            List<CatalogoCatDto> catalogoCatDtoList= funcionarioRhRepository.buscarExamesCatalogo();
            return ok(toJson(catalogoCatDtoList));
        } catch ( Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }

    @Transactional( readOnly = true )
    public Result buscarPcmso(final ShortBinder empresa) {
        try {
            Optional<PcmsoDto> pcmsoDto = empresaRepository.buscarPcmso(getValue(empresa));
            return ok(toJson(pcmsoDto));
        } catch ( Throwable ex ) {
            return badRequest( getException( ex ) );
        }
    }

    @Transactional
    public Result inserirNovoCat() {

        final ComunicadoAcidenteTrabalho model = fromJson( getJsonBody(), ComunicadoAcidenteTrabalho.class );
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
        Set<ConstraintViolation<Model>> constraintViolations = validator.validate( model );
        try {

            final PartesAtingidasCat partesAtingidasCat = fromJson( getJsonBody(), PartesAtingidasCat.class );
            constraintViolations = constraintViolations.size() == 0 ? validator.validate( partesAtingidasCat ) : constraintViolations;
            model.getPartesAtingidas().add(partesAtingidasCat);

            final AgentesCausadoresCat agentesCausadoresCat = fromJson( getJsonBody(), AgentesCausadoresCat.class );
            constraintViolations = constraintViolations.size() == 0 ? validator.validate( agentesCausadoresCat ) : constraintViolations;
            model.getAgentesCausadores().add(agentesCausadoresCat);

            comunicadoAcidenteTrabalhoRepository.save(model);

        } catch ( ConstraintViolationException ex ) {
            return badRequest( "O Campo " +
                    constraintViolations.iterator().next().getPropertyPath().toString() + " " +
                    constraintViolations.iterator().next().getMessage() + "!"
                    );
        } catch ( Throwable ex ) {
            logaSeDesenvolvimento( "" , getExceptionComoString(ex)  );
            return badRequest( getException( ex ) );
        }
        return ok();
    }

    @Transactional
    public Result alterarCat() {

        final ComunicadoAcidenteTrabalho model = fromJson( getJsonBody(), ComunicadoAcidenteTrabalho.class );
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
        Set<ConstraintViolation<Model>> constraintViolations = validator.validate( model );
        try {

            final PartesAtingidasCat partesAtingidasCat = fromJson( getJsonBody(), PartesAtingidasCat.class );
            constraintViolations = constraintViolations.size() == 0 ? validator.validate( partesAtingidasCat ) : constraintViolations;
            model.getPartesAtingidas().add(partesAtingidasCat);

            final AgentesCausadoresCat agentesCausadoresCat = fromJson( getJsonBody(), AgentesCausadoresCat.class );
            constraintViolations = constraintViolations.size() == 0 ? validator.validate( agentesCausadoresCat ) : constraintViolations;
            model.getAgentesCausadores().add(agentesCausadoresCat);

            comunicadoAcidenteTrabalhoRepository.update(model);

        } catch ( ConstraintViolationException ex ) {
            return badRequest( "O Campo " +
                    constraintViolations.iterator().next().getPropertyPath().toString() + " " +
                    constraintViolations.iterator().next().getMessage() + "!"
            );
        } catch ( Throwable ex ) {
            logaSeDesenvolvimento( "" , getExceptionComoString(ex)  );
            return badRequest( getException( ex ) );
        }
        return ok();
    }

    @Transactional
    public Result excluirCat( final Long cat) {

        try {
            comunicadoAcidenteTrabalhoRepository.excluirCat(cat);
        } catch (BusinessException e) {
            return badRequest( getException( e ) );
        }
        return ok();

    }

    @Transactional( readOnly = true )
    public Result buscarDadosAso(
            final ShortBinder idEmpresa,
            final Long idFuncionario
    ) {

        try {
            List<MonitoramentoSaudeTrabalho> lista = monitoramentoSaudeTrabalhoRepository.buscarPorMatricula(getValue(idEmpresa), idFuncionario);
            if (isVazia(lista))
                return noContent();
            return ok(toJson(lista));
        } catch (Throwable ex) {
            return badRequest(getException(ex));
        }
    }

    @Transactional
    public Result inserirNovoAso() {

        final MonitoramentoSaudeTrabalho model = fromJson( getJsonBody(), MonitoramentoSaudeTrabalho.class );
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
        Set<ConstraintViolation<Model>> constraintViolations = validator.validate( model );
        try {

            List<ObjectNode> examesNode = new ArrayList<>();

            Iterator<Map.Entry<String, JsonNode>> it = getJsonBody().fields();
            while (it.hasNext()) {
                Map.Entry<String, JsonNode> entry = it.next();
                int i;
                if (entry.getValue().getNodeType().toString().equals("ARRAY")) {
                    i = 0;
                    for (JsonNode e : entry.getValue()) {
                        ObjectNode obj = new ObjectNode(null);
                        if (examesNode.size() > i) {
                            examesNode.get(i).set(entry.getKey(), e);
                        } else {
                            obj.set(entry.getKey(), e);
                            examesNode.add(obj);
                        }
                        i++;
                    }
                }
            }
            it = getJsonBody().fields();
            while (it.hasNext()) {
                Map.Entry<String, JsonNode> entry = it.next();
                if (!entry.getValue().getNodeType().toString().equals("ARRAY")) {
                    if (examesNode.isEmpty()) {
                        ObjectNode obj = new ObjectNode(null);
                        examesNode.add(obj);
                    }
                    for (ObjectNode e : examesNode) {
                        e.set(entry.getKey(), entry.getValue());
                    }
                }
            }

            FichaMedica fichaMedica = new FichaMedica();
            FichaMedicaId fichaMedicaId;
            for (ObjectNode exames : examesNode) {
                fichaMedica = fromJson( exames , FichaMedica.class);
                fichaMedicaId = fromJson( exames , FichaMedicaId.class);
                fichaMedica.setId(fichaMedicaId);
                model.getFichasMedicas().add(fichaMedica);
            }

            constraintViolations = constraintViolations.size() == 0 ? validator.validate( fichaMedica) : constraintViolations;

            monitoramentoSaudeTrabalhoRepository.save(model);

        } catch ( ConstraintViolationException ex ) {
            return badRequest( "O Campo " +
                    constraintViolations.iterator().next().getPropertyPath().toString() + " " +
                    constraintViolations.iterator().next().getMessage() + "!"
            );
        } catch ( Throwable ex ) {
            logaSeDesenvolvimento( "" , getExceptionComoString(ex)  );
            return badRequest( getException( ex ) );
        }
        return ok();
    }

    @Transactional
    public Result excluirAso( final Long aso) {

        try {
            monitoramentoSaudeTrabalhoRepository.excluirAso(aso);
        } catch (BusinessException e) {
            return badRequest( getException( e ) );
        }
        return ok();

    }


    @Transactional( readOnly = true )
    public Result buscarExamesFuncao(
            final ShortBinder possivelEmpresa,
            final Long possivelFuncao
    ) {

        try {
            return ok(toJson(funcionarioRhRepository.buscarExamesFuncao(getValue(possivelEmpresa), possivelFuncao)));
        } catch (Throwable ex) {
            return badRequest(getException(ex));
        }
    }

    @Transactional( readOnly = true )
    public Result buscarExamesHistorico(
            final ShortBinder possivelEmpresa,
            final Long possivelMatricula
    ) {

        try {
            return ok(toJson(funcionarioRhRepository.buscarExamesHistorico(getValue(possivelEmpresa), possivelMatricula)));
        } catch (Throwable ex) {
            return badRequest(getException(ex));
        }
    }

    @Transactional( readOnly = true )
    public Result buscarExamesLocais(
    ) {

        try {
            return ok(toJson(funcionarioRhRepository.buscarExamesLocais()));
        } catch (Throwable ex) {
            return badRequest(getException(ex));
        }
    }

}
