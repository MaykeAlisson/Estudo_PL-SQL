package controllers.rh;

import infra.binders.ShortBinder;
import infra.controllers.Controller;
import play.db.jpa.Transactional;
import play.mvc.Result;
import services.rh.ObrigacaoService;

import javax.inject.Inject;

import static infra.binders.ShortBinder.getValue;
import static infra.util.UtilEnum.getEnum;
import static models.domains.admin.Empresa.IdEmpresa;

public class ApiRhController extends Controller {

    // Service:
    private final ObrigacaoService obrigacaoService;

    @Inject
    public ApiRhController( final ObrigacaoService obrigacaoService ) {

        this.obrigacaoService = obrigacaoService;
    }

    @Transactional
    public Result criarObrigacao(
        final ShortBinder idEmpresa,
        final String titulo,
        final String descricao,
        final ShortBinder idEquipe
    )  {

        try {
            obrigacaoService.gravarObrigacaoSimples(
                titulo,
                descricao,
                getValue(idEquipe),
                getEnum( IdEmpresa.class, getValue(idEmpresa) )
            );
            return ok();
        } catch ( Throwable e ) {
            return badRequestRollback( e );
        }
    }

    @Transactional
    public Result inserirPendenciaRetornoTablet() {
        try {
            obrigacaoService.inserirCobrancaRetornoEqpto();
            return ok();
        } catch ( Throwable e ) {
            return badRequestRollback( e );
        }
    }
}
