package controllers.rh;

import controllers.AuthController;
import models.repository.rh.ObrigacaoRepository;
import play.mvc.Result;

import javax.inject.Inject;
import java.util.concurrent.CompletionStage;

import static java.lang.String.valueOf;
import static java.util.concurrent.CompletableFuture.supplyAsync;

public class ObrigacaoController extends AuthController {

    private final ObrigacaoRepository obrigacaoRepository;

    @Inject
    public ObrigacaoController( final ObrigacaoRepository obrigacaoRepository ) {

        this.obrigacaoRepository = obrigacaoRepository;
    }

    public CompletionStage<Result> buscarQtdeDeTarefasImediatas( final Long idUsuario ) {

        return supplyAsync( () -> obrigacaoRepository.buscarQtdeDeTarefasImediatasPorUsuario( idUsuario ) )
                .thenApply( qtde -> ok( valueOf( qtde ) ) );
    }
}
