package controllers.admin;

import com.fasterxml.jackson.databind.node.ArrayNode;
import controllers.AuthController;
import models.commons.constantes.Estado;
import play.mvc.Result;

import java.util.Arrays;

import static play.libs.Json.newArray;
import static play.libs.Json.newObject;

public class EstadosFederecaoController extends AuthController {

    public Result buscarTodos() {

        final ArrayNode array = newArray();

        Arrays
        .stream( Estado.values() )
        .forEach( estado -> array.add(
            newObject()
            .put("estado", estado.getValor())
            .put("descricao", estado.getDescricao())
        ));

        return ok( array );

    }
}
