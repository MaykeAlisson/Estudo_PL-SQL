package controllers.admin;

import controllers.AuthController;
import infra.util.UtilArquivo;
import play.libs.Json;
import play.mvc.Result;
import play.mvc.Results;

public class PathController extends AuthController {

    public Result converterPathServidor( final String path ) {

        return UtilArquivo
            .toPath( path )
            .map( p -> Json.newObject().put("path", p.toString() ) )
            .map( Results::ok )
            .orElse( noContent() );
    }
}
