package controllers.admin;

import controllers.AuthController;
import models.commons.constantes.TipoModeloEquipamento;
import models.domains.admin.EquipamentosMobile;
import play.db.jpa.Transactional;
import play.mvc.Result;
import services.admin.EquipamentosMobileService;

import javax.inject.Inject;

import static infra.util.UtilEnum.getEnum;
import static play.libs.Json.fromJson;

public class EquipamentoController extends AuthController {

    // Service:
    private final EquipamentosMobileService equipamentosMobileService;

    // Construtor class Controller
    @Inject
    public EquipamentoController(EquipamentosMobileService equipamentosMobileService) {

        this.equipamentosMobileService = equipamentosMobileService;
    }


    @Transactional
    public Result inserir() {

        try {
            return equipamentosMobileService.liberarEquipamento(
                getEnum(TipoModeloEquipamento.class,getShort("tipoModelo")),
                getString("modeloDevice"),
                getLong("setor"),
                fromJson(getJsonBody(), EquipamentosMobile.class),
                getRequest().getIdUsuario()
            )
            ? created()
            : noContent();
        } catch ( final Throwable e ) {
            return badRequestRollback( e );
        }
    }
}
