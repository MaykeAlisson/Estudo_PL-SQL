package controllers.admin;

import controllers.AuthController;
import models.commons.annotations.AltRua;
import models.commons.constantes.TipoXref;
import models.commons.dtos.ReferenciaCruzadaDto;
import play.db.jpa.Transactional;
import play.mvc.Result;
import services.admin.XRefService;

import javax.inject.Inject;
import java.util.List;
import java.util.Objects;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilException.getExceptionComoString;
import static java.lang.String.format;
import static java.util.stream.Collectors.joining;
import static models.commons.constantes.TipoXref.ALT_RUA;
import static models.commons.constantes.TipoXref.PROJETOS_JAVA;

public class XrefController extends AuthController {

    // Service:
    private final XRefService xRefAltRuaService;
    private final XRefService xRefProjetosJavaService;

    @Inject
    public XrefController(
        @AltRua final XRefService xRefAltRuaService,
        final XRefService xRefProjetosJavaService
    ) {

        this.xRefAltRuaService = xRefAltRuaService;
        this.xRefProjetosJavaService = xRefProjetosJavaService;
    }

    @Transactional( readOnly = true )
    public Result executarXref( ) {

        try {
            final TipoXref tipoXref = getEnum( TipoXref.class, getString("tipo") );
            final List<String> palavrasChave = getList("chaves", String.class );

            List<ReferenciaCruzadaDto> xrefs;

            if ( Objects.equals(ALT_RUA, tipoXref) )
                xrefs = xRefAltRuaService.exec( palavrasChave );
            else if ( Objects.equals(PROJETOS_JAVA, tipoXref) )
                xrefs = xRefProjetosJavaService.exec( palavrasChave );
            else
                return badRequest( format( "Não existe serviço para tratar xRef de: %s", tipoXref ) );

            if ( isVazia(xrefs) )
                return noContent();

            return ok(
                xrefs
                .stream()
                .map(dto -> format("%s>%s",  dto.getQtdeOcorrencias(), dto.getArquivo()))
                .collect(joining("|"))
            );

        } catch ( Throwable e ) {

            return badRequest( getExceptionComoString( e ) );
        }
    }
}