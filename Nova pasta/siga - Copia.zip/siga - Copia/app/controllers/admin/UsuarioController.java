package controllers.admin;

import controllers.AuthController;
import controllers.binders.AplicacaoBinder;
import models.commons.dtos.EmpresaUsuarioDto;
import models.repository.rh.UsuarioAcessoRepository;
import models.repository.seguranca.UsuarioEmpresaRepository;
import play.db.jpa.Transactional;
import play.mvc.Result;

import javax.inject.Inject;
import java.util.List;

import static controllers.binders.AplicacaoBinder.getValue;
import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilException.getException;
import static play.libs.Json.toJson;

public class UsuarioController extends AuthController {

    // Repository:
    private final UsuarioEmpresaRepository usuarioEmpresaRepository;
    private final UsuarioAcessoRepository usuarioAcessoRepository;


    @Inject
    public UsuarioController(
        final UsuarioEmpresaRepository usuarioEmpresaRepository,
        final UsuarioAcessoRepository usuarioAcessoRepository
    ) {

        this.usuarioEmpresaRepository = usuarioEmpresaRepository;
        this.usuarioAcessoRepository = usuarioAcessoRepository;
    }

    @Transactional( readOnly = true )
    public Result buscarEmpresas( final AplicacaoBinder aplicacao ) {

        try {
            final List<EmpresaUsuarioDto> dtos =
                    usuarioEmpresaRepository.buscarEmpresasDoUsuario( getValue(aplicacao), getRequest().getIdUsuario() );
            return isVazia( dtos ) ? noContent() : ok( toJson( dtos ) );
        } catch ( Throwable e ) {
            return badRequest( getException(e)  );
        }
    }

    @Transactional( readOnly = true )
    public Result buscarEmpresasUsuarioAcesso( ) {

        try {
            final List<EmpresaUsuarioDto> dtos =
                    usuarioAcessoRepository.buscarEmpresasDoUsuario( getRequest().getIdUsuario() );
            return isVazia( dtos ) ? noContent() : ok( toJson( dtos ) );
        } catch ( Throwable e ) {
            return badRequest( getException(e)  );
        }
    }

}
