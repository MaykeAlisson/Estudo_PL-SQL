package controllers.admin;

import com.fasterxml.jackson.databind.node.ArrayNode;
import controllers.AuthController;
import play.mvc.Result;

import java.util.Arrays;

import static models.domains.admin.Logradouro.IdLogradouro.values;
import static play.libs.Json.newArray;
import static play.libs.Json.newObject;

public class LogradouroController extends AuthController {

    public Result buscarTodos() {

        final ArrayNode arrayNode = newArray();

        Arrays
        .stream( values() )
        .map( idLogradouro -> newObject()
            .put("logradouro",idLogradouro.getValor())
            .put( "descricao", idLogradouro.getDescricao())
        ).forEach( arrayNode::add );

        return ok(arrayNode);
    }
}
