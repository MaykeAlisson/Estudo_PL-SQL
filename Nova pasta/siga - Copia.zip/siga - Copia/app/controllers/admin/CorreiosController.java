package controllers.admin;

import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import controllers.AuthController;
import infra.binders.LongBinder;
import models.commons.constantes.TipoServicoCorreio;
import models.repository.admin.ResponsavelColetaCorreioRepository;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.Result;
import play.mvc.Results;

import javax.inject.Inject;
import java.util.Arrays;

import static infra.binders.LongBinder.getValue;
import static infra.util.UtilString.toUpperCase;
import static play.libs.Json.newObject;

public class CorreiosController extends AuthController {

    // Repository:
    private final ResponsavelColetaCorreioRepository responsavelColetaCorreioRepository;

    @Inject
    public CorreiosController( final ResponsavelColetaCorreioRepository responsavelColetaCorreioRepository ) {

        this.responsavelColetaCorreioRepository = responsavelColetaCorreioRepository;
    }

    @Transactional
    public Result buscarReponsavelColetaPorCpf( final LongBinder cpf ) {

        try {
            return responsavelColetaCorreioRepository.buscarPorCpf( getValue(cpf) )
                .map( Json::toJson )
                .map( Results::ok )
                .orElse( noContent() );
        } catch ( final Throwable e ) {
            return badRequestRollback( e );
        }
    }

    @Transactional
    public Result gravarResponsavelColeta() {

        try {
            return responsavelColetaCorreioRepository.atualizar(
                    getLong("cpf"),
                    toUpperCase( getString("nomeResponsavel") )
                )
                .map( idResponsavelColeta -> newObject().put( "idResponsavelColeta", idResponsavelColeta ) )
                .map( Results::ok )
                .orElse( noContent() );
        } catch ( final Throwable e ) {
            return badRequestRollback( e );
        }
    }

    public Result buscarServicosDisponiveis() {

        final ObjectNode servicos = newObject();
        final ArrayNode tipos = servicos.putArray("servicos" );

        Arrays
        .stream( TipoServicoCorreio.values() )
        .forEach( tipoServicoCorreio -> {
            final ObjectNode node = newObject();
            node.put("tipo", tipoServicoCorreio.getValor());
            node.put("descricao", tipoServicoCorreio.getDescricao());
            tipos.add( node );
        });

        return ok( servicos );
    }

}
