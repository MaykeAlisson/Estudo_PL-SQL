package controllers.admin;

import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import controllers.AuthController;
import infra.binders.ArrayStringBinder;
import infra.util.UtilArquivo;
import play.db.jpa.Transactional;
import play.mvc.Result;
import play.mvc.Results;
import services.vendas.MensagemService;

import javax.inject.Inject;

import java.nio.file.Files;

import static infra.binders.ArrayStringBinder.getValue;
import static infra.util.UtilArquivo.getBase64;
import static infra.util.UtilArquivo.tamanhoDoArquivo;
import static infra.util.UtilArquivo.toPath;
import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilException.getException;
import static play.libs.Json.newArray;
import static play.libs.Json.newObject;

public class ImagemController extends AuthController {

    private final MensagemService mensagemService;

    @Inject
    public ImagemController( final MensagemService mensagemService ) {

        this.mensagemService = mensagemService;
    }

    public Result converterBase64( final String arquivo ) {

        try {
            return toPath( arquivo )
                .flatMap( UtilArquivo::getBase64 )
                .map( base64 -> ok( newObject().put("imagem", base64 ) ) )
                .orElse( noContent() );
        } catch ( final Throwable e ) {
            return badRequest( getException(e) );
        }
    }

    public Result converterBase64v2( final String arquivo ) {

        try {
            return toPath( arquivo )
            .filter( Files::exists )
            .map( path -> {
                final ObjectNode json = newObject();
                json.put( "imagem", getBase64(path).orElse(null) );
                json.put( "tamanho", tamanhoDoArquivo( path ) );
                return json;
            })
            .map( Results::ok )
            .orElse( noContent() );
        } catch ( final Throwable e ) {
            return badRequest( getException(e) );
        }
    }

    @Transactional( readOnly = true )
    public Result listarArquivosFotosMensagens() {

        try {
            return mensagemService
                .listarArquivosDeImagens()
                .map( values -> {
                    final ArrayNode arrayNode = newArray();
                    if ( !isVazia(values.getValue()) )
                        values.getValue().forEach( arrayNode::add );

                    final ObjectNode json = newObject();
                    json.put( "path", values.getKey() );
                    json.putArray( "arquivos" ).addAll( arrayNode );
                    return json;
                })
                .map( Results::ok )
                .orElse( noContent() );
        } catch ( final Throwable e ) {
            return badRequest( getException(e) );
        }
    }

    @Transactional
    public Result excluirArquivosFotosMensagens( final ArrayStringBinder arquivos ) {

        try {
            mensagemService.excluirImagens( getRequest().getIdPerfil(), getValue(arquivos) );
            return ok();
        } catch ( final Throwable e ) {
            return badRequest( getException(e) );
        }
    }

    @Transactional( readOnly = true )
    public Result uploadFotoMensagem( final String nomeArquivo ) {

        try {
            mensagemService.gravarArquivoImagem( nomeArquivo, getByteArrayBody() );
            return ok();
        } catch ( Throwable e ) {
            return badRequest( getException(e) );
        }
    }

}
