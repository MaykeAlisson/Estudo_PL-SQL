package controllers.admin;

import controllers.AuthController;
import play.db.jpa.Transactional;
import play.mvc.Result;
import services.admin.FornecedorService;
import javax.inject.Inject;
import static infra.util.UtilException.getException;
import static play.libs.Json.toJson;

public class FornecedorController extends AuthController {

    private final FornecedorService fornecedorService;

    @Inject
    public FornecedorController(FornecedorService fornecedorService) {

        this.fornecedorService = fornecedorService;
    }

    @Transactional
    public Result buscarFornecedorWs(String cnpj) {

        try {
            return ok( toJson( fornecedorService.buscarFornecedorWs(cnpj) ) );
        } catch ( Throwable e ) {
            return badRequest( getException(e) );
        }
    }
}
