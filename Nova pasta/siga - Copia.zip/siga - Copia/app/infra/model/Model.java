package infra.model;

import java.io.Serializable;


/**
 * Classe base para mapeamentos JPA.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 02/09/2014
 *
 */
public abstract class Model implements Serializable {

    private static final long serialVersionUID = -5298400824207534965L;
}
