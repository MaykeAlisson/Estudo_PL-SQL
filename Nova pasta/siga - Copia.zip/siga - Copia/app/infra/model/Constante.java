package infra.model;

/**
 * Inteface default para definição de constantes.
 *
 * <p>Autor: GPortes</p>
 *
 */
public interface Constante<T> {

    String getDescricao();

    T getValor();

}
