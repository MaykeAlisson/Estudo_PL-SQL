package infra.interceptors;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

import java.util.Collection;
import java.util.Objects;
import java.util.StringJoiner;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilString.isVazia;
import static java.lang.String.format;

/**
 * Classe utilizada para validação de argumentos em métodos de negócio.
 *
 * @author GPortes
 * @since 27/03/2019
 */
public class CheckArgsInterceptor implements MethodInterceptor {

    @Override
    public Object invoke( final MethodInvocation invocation ) throws Throwable {

        final Object[] args = invocation.getArguments();
        final StringJoiner msg = new StringJoiner(",");

        for (int i = 0; i < args.length; i++) {

            final Class<?> clazzType = invocation.getMethod().getParameterTypes()[i];

            if ( Objects.equals(clazzType, String.class) ) {
                if (isVazia((String) args[i])) msg.add(getNomeArgumento(invocation, i));
                continue;
            }

            if ( Objects.equals(clazzType, Collection.class) ) {
                if (isVazia((Collection) args[i])) msg.add(getNomeArgumento(invocation, i));
                continue;
            }

            if (args[i] == null) msg.add(getNomeArgumento(invocation, i));
        }

        if ( msg.length() > 0 )
            throw new IllegalArgumentException(format(
                "[%s.%s] Obrigatório informar arg(s) [%s]",
                invocation.getMethod().getDeclaringClass().getSimpleName(),
                invocation.getMethod().getName(),
                msg.toString()
            ));

        return invocation.proceed();
    }

    private String getNomeArgumento(
        final MethodInvocation invocation,
        int index
    ) {

        return ( invocation.getMethod().getParameters()[index] ).getName();
    }
}