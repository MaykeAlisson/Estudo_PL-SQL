package infra.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import java.sql.Timestamp;
import java.time.LocalDateTime;

/**
 * Classe converter para compatibilidade de datas entre JPA2.1 e LocalDate (Java8)
 *
 * <p>Autor: GPortes</p>
 */
@Converter( autoApply = true )
public class LocalDateTimeConverter implements AttributeConverter<LocalDateTime, Timestamp> {

    @Override
    public Timestamp convertToDatabaseColumn( final LocalDateTime localDateTime ) {

        return ( localDateTime == null ? null : Timestamp.valueOf(localDateTime) );
    }

    @Override
    public LocalDateTime convertToEntityAttribute( final Timestamp sqlTimestamp ) {

        return ( sqlTimestamp == null ? null : sqlTimestamp.toLocalDateTime() );
    }
}