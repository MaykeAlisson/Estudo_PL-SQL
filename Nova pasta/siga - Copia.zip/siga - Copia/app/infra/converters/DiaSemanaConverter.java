package infra.converters;

import infra.commons.constantes.DiaSemana;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import static infra.util.UtilConstante.getValor;
import static infra.util.UtilEnum.getEnum;
import static infra.util.UtilNumero.toShort;

/**
 * Classe converter para constante DiaSemana
 *
 * <p>Autor: Guilherme</p>
 *
 * @since 16/07/2018
 *
 * @see infra.commons.constantes.DiaSemana
 */
@Converter
public class DiaSemanaConverter implements AttributeConverter<DiaSemana,Object> {

    @Override
    public Short convertToDatabaseColumn( final DiaSemana diaSemana ) {

        return getValor( diaSemana );
    }

    @Override
    public DiaSemana convertToEntityAttribute( final Object diaSemana ) {

        return getEnum( DiaSemana.class, toShort(diaSemana) );
    }
}
