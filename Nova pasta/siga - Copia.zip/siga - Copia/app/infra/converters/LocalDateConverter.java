package infra.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import java.sql.Date;
import java.time.LocalDate;

/**
 * Classe converter para compatibilidade de datas entre JPA2.1 e LocalDate (Java8)
 *
 * <p>Autor: GPortes</p>
 */
@Converter( autoApply = true )
public class LocalDateConverter implements AttributeConverter<LocalDate, Date> {

    @Override
    public Date convertToDatabaseColumn( final LocalDate localDate ) {

        return ( localDate == null ? null : Date.valueOf(localDate) );
    }

    @Override
    public LocalDate convertToEntityAttribute( final Date sqlDate ) {

        return ( sqlDate == null ? null : sqlDate.toLocalDate() );
    }
}
