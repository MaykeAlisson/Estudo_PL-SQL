package infra.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import java.sql.Time;
import java.time.LocalTime;

/**
 * Classe converter para compatibilidade de hora entre JPA2.1 e LocalTime (Java8)
 *
 * <p>Autor: GPortes</p>
 */
@Converter( autoApply = true )
public class LocalTimeConverter implements AttributeConverter<LocalTime, Time> {

    @Override
    public Time convertToDatabaseColumn( final LocalTime localTime ) {

        return localTime == null ? null : Time.valueOf(localTime);
    }

    @Override
    public LocalTime convertToEntityAttribute( final Time sqlTime ) {

        return sqlTime == null ? null : sqlTime.toLocalTime();
    }
}
