package infra.exceptions;

/**
 * Exception a ser lançada em logicas de negócio.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 10/09/2014
 */
public class BusinessException extends Exception {

    public BusinessException( final String message ) {

        super(message);
    }

    public BusinessException( final Throwable cause ) {

        super( cause );
    }
}
