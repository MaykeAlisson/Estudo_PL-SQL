package infra.exceptions;

/**
 * Exception a ser lançada em logicas de infra.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 30/01/2019
 */
public class InfraException extends RuntimeException {

    public InfraException( final String message ) {

        super( message );
    }

    public InfraException( final Throwable cause ) {

        super( cause );
    }
}
