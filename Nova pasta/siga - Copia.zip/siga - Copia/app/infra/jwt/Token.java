package infra.jwt;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.UnsupportedJwtException;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Optional;
import java.util.StringJoiner;

import static infra.jwt.Token.Value.newInstance;
import static infra.util.UtilCollections.getTamanho;
import static infra.util.UtilDate.isValida;
import static infra.util.UtilDate.toDate;
import static infra.util.UtilRandom.getRandom;
import static infra.util.UtilString.isVazia;
import static io.jsonwebtoken.SignatureAlgorithm.HS256;
import static java.lang.String.format;
import static java.lang.String.valueOf;
import static java.time.LocalDate.now;
import static java.util.Optional.empty;
import static java.util.Optional.of;
import static java.util.Optional.ofNullable;

/**
 * Classe reponsável pela geração e leitura do Token de acesso das APIs.
 *
 * <p>Autor: GPortes</p>
 */
public final class Token {

    public static String INFO_TOKEN = "INFO_TOKEN";
    private static String KEY = "Tuy=jiyjeuxP09Lhx_pbHSFn:u5YX8s484cko<jgXhT8SXArinOl`c@MqTRPWtM[";


    /**
     * @see #checkGerar(Long, Long, LocalDateTime)
     */
    private static void checkGerar(
        final Long idUsuario,
        final Long idPerfil,
        final LocalDateTime dataExpiracao
    ) {

        final StringJoiner check = new StringJoiner(" ");
        if ( idUsuario == null ) check.add( "[ idUsuario ]" );
        if ( idPerfil == null ) check.add( "[ idPerfil ]" );
        if ( !isValida(dataExpiracao) ) check.add( "[ dataExpiracao ]" );
        if ( check.length() > 0 )
            throw new IllegalArgumentException( format( "Faltou definir arg(s): %s para gerar Token", check ) );
    }

    /**
     * Gera token do usuario.
     *
     * <p>Autor: GPortes</p>
     *
     * @param idUsuario Código do usuario
     *
     * @return Token
     */
    public static Optional<String> gerar(
        final Long idUsuario,
        final Long idPerfil,
        final LocalDateTime dataExpiracao
    ) {

        checkGerar( idUsuario, idPerfil, dataExpiracao );

        return ofNullable(
            Jwts
            .builder()
            .setSubject( createSubject( idUsuario, idPerfil ) )
            .setExpiration( toDate( dataExpiracao ) )
            .signWith( HS256, KEY )
            .compact()
        );
    }

    public static Optional<String> gerar(
        final Long idUsuario,
        final Long idPerfil,
        final LocalDate dataExpiracao
    ) {

        return gerar(
            idUsuario,
            idPerfil,
            LocalDateTime.of(dataExpiracao, LocalTime.of(23,59,58))
        );
    }

    private static String createSubject(
        final Long idUsuario,
        final Long idPerfil
    ) {

        return format( "%s;%s;%s;%s", valueOf(idUsuario), valueOf(idPerfil), now(), getRandom() );
    }

    /**
     * Retorna o código do usuario.
     *
     * <p>Autor: GPortes</p>
     *
     * @param token Token
     *
     * @return Código do usuário.
     */
    public static Optional<Value> decode( final String token ) {

        if ( isVazia( token ) )
            return empty();

        try {

            final String subject = Jwts.parser()
                                    .setSigningKey( KEY )
                                    .parseClaimsJws( token )
                                    .getBody()
                                    .getSubject();

            if ( isVazia(subject) )
                return empty();

            final String[] decode = subject.split(";");

            if ( getTamanho( decode ) != 4 )
                return empty();

            return of( newInstance( Long.valueOf( decode[0] ), Long.valueOf( decode[1] ) ) );

        } catch ( ExpiredJwtException e ) {

            return of( newInstance( "ACESSO EXPIROU - NECESSARIO NOVA AUTENTICACAO") );

        } catch ( UnsupportedJwtException e ) {

            return empty();

        } catch ( MalformedJwtException | SignatureException | IllegalArgumentException e ) {

            return of( newInstance( "TOKEN INVALIDO - CONTATE O DEPTO DE TI") );

        }
    }

    /**
     * Valores do token
     */
    public interface Value {

        Long getIdUsuario();
        Long getIdPerfil();
        String getMsgInconsistencia();

        static Value newInstance(
            final Long idUsuario,
            final Long idPerfil,
            final String msgInconsistencia
        ) {
            return new Value() {
                @Override
                public Long getIdUsuario() {
                    return idUsuario;
                }

                @Override
                public Long getIdPerfil() {
                    return idPerfil;
                }

                @Override
                public String getMsgInconsistencia() {
                    return msgInconsistencia;
                }
            };
        }

        static Value newInstance(
            final Long idUsuario,
            final Long idPerfil
        ) {
            return newInstance( idUsuario, idPerfil, null );
        }

        static Value newInstance( final String mensagem ) {

            return newInstance( null, null, mensagem );
        }
    }

}
