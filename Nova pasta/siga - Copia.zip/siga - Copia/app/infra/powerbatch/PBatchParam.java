package infra.powerbatch;

import infra.util.UtilDate;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Objects;
import java.util.StringJoiner;

import static infra.powerbatch.PBatchParam.TipoJava.BIGDECIMAL;
import static infra.powerbatch.PBatchParam.TipoJava.BOOLEAN;
import static infra.powerbatch.PBatchParam.TipoJava.INTEGER;
import static infra.powerbatch.PBatchParam.TipoJava.LOCAL_DATE;
import static infra.powerbatch.PBatchParam.TipoJava.LOCAL_DATETIME;
import static infra.powerbatch.PBatchParam.TipoJava.LOCAL_TIME;
import static infra.powerbatch.PBatchParam.TipoJava.LONG;
import static infra.powerbatch.PBatchParam.TipoJava.SHORT;
import static infra.powerbatch.PBatchParam.TipoJava.STRING;
import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilDate.toLocalDate;
import static infra.util.UtilDate.toLocalTime;
import static infra.util.UtilNumero.formatarString;
import static infra.util.UtilNumero.toBigDecimal;
import static infra.util.UtilNumero.toInteger;
import static infra.util.UtilNumero.toLong;
import static infra.util.UtilNumero.toShort;
import static infra.util.UtilString.isEmptyGet;
import static infra.util.UtilString.isVazia;
import static infra.util.UtilString.preencherZerosDireita;
import static infra.util.UtilString.requireNonEmpty;
import static java.lang.Integer.valueOf;
import static java.lang.String.format;
import static java.util.Map.Entry;
import static java.util.Objects.isNull;
import static java.util.Objects.requireNonNull;
import static java.util.regex.Pattern.compile;
import static java.util.stream.Collectors.toMap;

/**
 * Classe suporte para tratamento de passagem de argumentos para PowerBatch.
 *
 * <p>Autor: GPortes</p>
 */
public final class PBatchParam {

    private HashMap<TipoJava, LinkedList<?>> valuesDecode;
    private String argumentos;

    /**
     * Builder para construção de um objeto {@code PBatchParam}
     *
     * <blockquote><pre>
     *   PBatchParam param = new PBatchParam
     *      .Builder()
     *      .comString( 1, "ABCD" )
     *      .comString( 2, "XYZ" )
     *      .comDecimal( 1, new BigDecimal( "12" ) )
     *      .build();
     * </pre></blockquote>
     *
     */
    public static class Builder {

        private Map<String,Object> values;

        public Builder( ) {

            this.values = new HashMap<>(5 );
        }

        public Builder comBoolean(
            final int posicao,
            final Boolean value
        ) {

            checkArgumentoPosicao( posicao );
            this.values.put( getKey(PB_LOGICO, posicao), value );
            return this;
        }

        public Builder comString(
            final int posicao,
            final String value
        ) {

            checkArgumentoPosicao( posicao );
            this.values.put( getKey(PB_ALFA, posicao), value );
            return this;
        }

        public Builder comDateTime(
            final int posicao,
            final LocalDateTime value
        ) {

            checkArgumentoPosicao( posicao );
            this.values.put( getKey(PB_DATETIME, posicao), value );
            return this;
        }

        public Builder comDate(
            final int posicao,
            final LocalDate value
        ) {

            checkArgumentoPosicao( posicao );
            this.values.put( getKey(PB_DATE, posicao), value );
            return this;
        }

        public Builder comTime(
            final int posicao,
            final LocalTime value
        ) {

            checkArgumentoPosicao( posicao );
            this.values.put( getKey(PB_TIME, posicao), value );
            return this;
        }

        public Builder comLong(
            final int posicao,
            final Long value
        ) {

            checkArgumentoPosicao( posicao );
            this.values.put( getKey(PB_NUMBER_LONG, posicao), value );
            return this;
        }

        public Builder comInteger(
            final int posicao,
            final Integer value
        ) {

            checkArgumentoPosicao( posicao );
            this.values.put( getKey(PB_NUMBER_LONG, posicao), value );
            return this;
        }

        public Builder comShort(
            final int posicao,
            final Short value
        ) {

            checkArgumentoPosicao( posicao );
            this.values.put( getKey(PB_NUMBER_INTEGER, posicao), value );
            return this;
        }

        public Builder comBigDecimal(
            final int posicao,
            final BigDecimal value
        ) {

            checkArgumentoPosicao( posicao );
            this.values.put( getKey(PB_NUMBER_DECIMAL, posicao), value );
            return this;
        }

        public PBatchParam build() {

            return new PBatchParam( this );
        }
    }

    private String convMapToPbString( final Map<String,Object> values ) {

        if ( isVazia(values) )
            return null;

        final String[] pbTipos = {
            PB_LOGICO,
            PB_ALFA,
            PB_DATETIME,
            PB_DATE,
            PB_TIME,
            PB_NUMBER_LONG,
            PB_NUMBER_INTEGER,
            PB_NUMBER_DECIMAL,
            PB_NUMBER_REAL
        };

        final StringJoiner argDrComplServicoBatch = new StringJoiner( "#" );

        for ( final String pbTipo : pbTipos ) {

            final String regex = format("(%s)|\\*", pbTipo);

            final Map<String,Object> valuesPb =
                values
                .entrySet()
                .stream()
                .filter( value -> compile(regex).matcher(value.getKey()).find() )
                .collect( toMap( Entry::getKey, Entry::getValue, (oldValue, newValue) -> oldValue, LinkedHashMap::new ) );

            final int tam = valuesPb.size();

            if ( tam > 0 ) {

                int qtLeitura = 0;

                for ( int posicao = 1; true; posicao++ ) {

                    final String key = format("%s|%s", pbTipo, posicao);
                    String argumento = "";
                    if ( valuesPb.containsKey(key) ) {
                        argumento = convObjToPbString(pbTipo, valuesPb.get(key));
                        qtLeitura++;
                    } else {
                        argumento = PB_NULO;
                    }

                    argDrComplServicoBatch.add(pbTipo).add(argumento);

                    if ( qtLeitura == tam )
                        break;
                }

            }
        }

        return isVazia( argDrComplServicoBatch ) ? "" : argDrComplServicoBatch.toString().concat("#");
    }

    private String convObjToPbString(
        final String pbTipo,
        final Object obj
    ) {

        requireNonEmpty(pbTipo, "(PowerBatch) Obrigatório informar o tipo" );
        requireNonNull( obj, "(PowerBatch) Obrigatório informar o dado" );

        String pbString = "";

        switch ( pbTipo ) {
            case PB_ALFA:
            case PB_NUMBER_LONG:
            case PB_NUMBER_INTEGER:
                pbString = obj.toString();
                break;
            case PB_DATETIME:
                final LocalDateTime dataHoje = (LocalDateTime) obj;
                pbString = String.valueOf( dataHoje.getNano() );
                pbString = format("%s:%s", UtilDate.toString(dataHoje, "dd/MM/yyyy HH:mm:ss"),
                        pbString.substring(0,6) );
                break;
            case PB_DATE:
                pbString = UtilDate.toString( (LocalDate) obj, "dd/MM/yyyy" );
                break;
            case PB_TIME:
                pbString = UtilDate.toString( (LocalTime) obj, "HH:mm:ss" );
                break;
            case PB_NUMBER_DECIMAL:
                pbString = formatarString( (BigDecimal) obj );
                break;
            case PB_LOGICO:
                pbString = ( (Boolean) obj ) ? "T" : "F";
                break;
            default:
                throw new IllegalArgumentException( format( "(PowerBatch) Falha ao montar " +
                        "argumento - Tipo [%s] inválido!", pbTipo) );
        }

        return pbString;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CONSTRUCTOR
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    private PBatchParam( final Builder builder ) {

        this.argumentos = ( builder != null && builder.values != null ) ?
                convMapToPbString( builder.values ) : null;
    }

    private PBatchParam(
        final String argumentos,
        final HashMap<TipoJava, LinkedList<?>> valuesDecode
    ) {

        this.argumentos = argumentos;
        this.valuesDecode = valuesDecode;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // GETTERS
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    private boolean existeDado( final TipoJava tipoJava ) {

        return valuesDecode != null && valuesDecode.get(tipoJava) != null;
    }

    public String getString( final int posicao ) {

        try {
            return existeDado( STRING ) ? (String) valuesDecode.get(STRING).get(posicao - 1) : null;
        } catch ( IndexOutOfBoundsException e ) {
            return null;
        }
    }

    public Boolean getBoolean( final int posicao ) {

        try {
            return existeDado( BOOLEAN ) ? (Boolean) valuesDecode.get(BOOLEAN).get(posicao - 1) : null;
        } catch ( IndexOutOfBoundsException e ) {
            return null;
        }
    }

    public LocalDateTime getDateTime( final int posicao ) {

        try {
            return existeDado( LOCAL_DATETIME ) ? (LocalDateTime) valuesDecode.get(LOCAL_DATETIME).get(posicao - 1) : null;
        } catch ( IndexOutOfBoundsException e ) {
            return null;
        }
    }

    public LocalDate getDate( final int posicao ) {

        try {
            return existeDado( LOCAL_DATE ) ? (LocalDate) valuesDecode.get(LOCAL_DATE).get(posicao - 1) : null;
        } catch ( IndexOutOfBoundsException e ) {
            return null;
        }
    }

    public LocalTime getTime( final int posicao ) {

        try {
            return existeDado( LOCAL_TIME ) ? (LocalTime) valuesDecode.get(LOCAL_TIME).get(posicao - 1) : null;
        } catch ( IndexOutOfBoundsException e ) {
            return null;
        }
    }

    public Short getShort( final int posicao ) {

        try {
            return existeDado( SHORT ) ? (Short) valuesDecode.get(SHORT).get(posicao - 1) : null;
        } catch ( IndexOutOfBoundsException e ) {
            return null;
        }
    }

    public Long getLong( final int posicao ) {

        try {
            return existeDado( LONG ) ? (Long) valuesDecode.get(LONG).get(posicao - 1) : null;
        } catch ( IndexOutOfBoundsException e ) {
            return null;
        }
    }

    public Integer getInteger( final int posicao ) {

        try {
            return existeDado( INTEGER ) ? (Integer) valuesDecode.get(INTEGER).get(posicao - 1) : null;
        } catch ( IndexOutOfBoundsException e ) {
            return null;
        }
    }

    public BigDecimal getDecimal( final int posicao ) {

        try {
            return existeDado( BIGDECIMAL ) ? (BigDecimal) valuesDecode.get(BIGDECIMAL).get(posicao - 1) : null;
        } catch ( IndexOutOfBoundsException e ) {
            return null;
        }
    }

    public String getArgumentos() {

        return this.argumentos;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CONSTANTES
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    private static final String PB_LOGICO = "B";
    private static final String PB_ALFA = "S";
    private static final String PB_DATETIME = "A";
    private static final String PB_DATE = "D";
    private static final String PB_TIME = "T";
    private static final String PB_NUMBER_LONG = "L";
    private static final String PB_NUMBER_INTEGER = "I";
    private static final String PB_NUMBER_DECIMAL = "C";
    private static final String PB_NUMBER_REAL = "R";
    private static final String PB_NULO = "(null)";

    protected enum TipoJava {
        BOOLEAN,
        STRING,
        LOCAL_DATETIME,
        LOCAL_DATE,
        LOCAL_TIME,
        INTEGER,
        LONG,
        SHORT,
        BIGDECIMAL
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EQUALS & HASCODE & TO_STRING
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean equals( Object o ) {

        if ( this == o ) return true;
        if ( !(o instanceof PBatchParam) ) return false;
        final PBatchParam that = (PBatchParam) o;
        return Objects.equals(getArgumentos(), that.getArgumentos());
    }

    @Override
    public int hashCode() {

        return Objects.hash( getArgumentos() );
    }

    @Override
    public String toString() {

        return "PBatchParam{" +
                "argumentos='" + argumentos + '\'' +
                '}';
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // METODOS AUXILIARES.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Retorna um objeto {@code PBatchParam} a partir de uma string.
     *
     * <blockquote><pre>
     *   PBatchParam param = PBatchParam.decode( "S#B#L#1#I#15#I#16#" );
     *   param.getString(0); // "B"
     *   param.getLong(0); // 1
     *   param.getInteger(0); // 15
     *   param.getInteger(1); // 16
     * </pre></blockquote>
     *
     * @param texto String ref. dr_compl_servico_batch
     *
     * @return Objeto PBatchParam
     */
    public static PBatchParam decode( final String texto ) {

        final String[] argumentos = texto.split("#" );

        if ( argumentos.length % 2 != 0 )
            throw new IllegalArgumentException( "Argumento em [ dr_compl_servico_batch ] esta quebrado! Contate o Analista Responsável!" );

        LinkedList<String> listString = null;
        LinkedList<Boolean> listBoolean = null;
        LinkedList<LocalDateTime> listLocalDateTime = null;
        LinkedList<LocalDate> listLocalDate = null;
        LinkedList<LocalTime> listLocalTime = null;
        LinkedList<BigDecimal> listBigDecimal = null;
        LinkedList<Long> listLong = null;
        LinkedList<Integer> listInteger = null;
        LinkedList<Short> listShort = null;

        for ( int i = 0; i < argumentos.length; i+=2 ) {

            final String tipo = argumentos[i];
            final String value = Objects.equals( isEmptyGet(argumentos[i+1], PB_NULO), PB_NULO) ? null : argumentos[i+1];

            switch ( tipo ) {

                case PB_LOGICO:
                    if ( listBoolean == null ) listBoolean = new LinkedList<>();
                    listBoolean.add( isNull(value) ? null : Objects.equals( value, "T" ) );
                    break;

                case PB_ALFA:
                    if ( listString == null ) listString = new LinkedList<>();
                    listString.add( value );
                    break;

                case PB_DATETIME:
                    final LocalDateTime dataHora = isNull(value) ? null :
                        LocalDateTime.of(
                                valueOf(value.substring(6, 10)),
                                valueOf(value.substring(3, 5)),
                                valueOf(value.substring(0, 2)),
                                valueOf(value.substring(11, 13)),
                                valueOf(value.substring(14, 16)),
                                valueOf(value.substring(17, 19)),
                                valueOf( preencherZerosDireita( valueOf(value.substring(20, 26)), 6 ) )
                        );
                    if ( listLocalDateTime == null ) listLocalDateTime = new LinkedList<>();
                    listLocalDateTime.add( dataHora );
                    break;

                case PB_DATE:
                    if ( listLocalDate == null ) listLocalDate = new LinkedList<>();
                    listLocalDate.add( toLocalDate( value, "dd/MM/yyyy" ) );
                    break;

                case PB_TIME:
                    if ( listLocalTime == null ) listLocalTime = new LinkedList<>();
                    listLocalTime.add( toLocalTime( value, "HH:mm:ss" ) );
                    break;

                case PB_NUMBER_DECIMAL:
                case PB_NUMBER_REAL:
                    if ( listBigDecimal == null ) listBigDecimal = new LinkedList<>();
                    listBigDecimal.add( toBigDecimal( value ).orElse( null ) );
                    break;

                case PB_NUMBER_LONG:
                    if ( listLong == null ) {
                        listLong = new LinkedList<>();
                        listInteger = new LinkedList<>();
                    }
                    listLong.add( toLong(value).orElse(null) );
                    listInteger.add( toInteger(value).orElse(null) );
                    break;

                case PB_NUMBER_INTEGER:
                    if ( listShort == null ) listShort = new LinkedList<>();
                    listShort.add( toShort(value).orElse(null) );
                    break;

                default:
                    throw new IllegalArgumentException( format( "(PowerBatch) Falha ao decodificar Argumento - Tipo [%s] inválido!", tipo) );
            }
        }

        final HashMap<TipoJava, LinkedList<?>> values = new HashMap<>(argumentos.length / 2);
        values.put( STRING, listString );
        values.put( BOOLEAN, listBoolean );
        values.put( LOCAL_DATETIME, listLocalDateTime );
        values.put( LOCAL_DATE, listLocalDate );
        values.put( LOCAL_TIME, listLocalTime );
        values.put( BIGDECIMAL, listBigDecimal );
        values.put( LONG, listLong );
        values.put( INTEGER, listInteger );
        values.put( SHORT, listShort );

        return new PBatchParam( texto, values );
    }

    private static String getKey(
        final String tipo,
        final int posicao
    ) {

        return format( "%s|%s", tipo, valueOf(posicao) );
    }

    private static void checkArgumentoPosicao( final int posicao ) {

        if ( posicao <=0 )
            throw new IllegalArgumentException( format( "(PowerBach) Posição de leitura " +
                    "deve ser > 0 - Valor informado [%s]", posicao ) );
    }

}
