package infra.controllers;

import akka.util.ByteString;
import com.fasterxml.jackson.databind.JsonNode;
import infra.powerbatch.PBatchParam;
import infra.util.UtilJson;
import play.db.jpa.JPAApi;
import play.mvc.Http;
import play.mvc.Result;

import javax.inject.Inject;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static infra.util.UtilDate.toLocalDateTime;
import static infra.util.UtilException.getException;
import static infra.util.UtilJson.toBigDecimal;
import static infra.util.UtilJson.toBoolean;
import static infra.util.UtilJson.toList;
import static infra.util.UtilJson.toLocalDate;
import static infra.util.UtilJson.toLong;
import static infra.util.UtilJson.toSet;
import static infra.util.UtilJson.toShort;
import static infra.util.UtilJson.toText;
import static infra.util.UtilString.isVazia;
import static play.mvc.Http.RequestBody;

/**
 * Controladora com metodos utilitarios para uso geral.
 *
 */
public class Controller extends play.mvc.Controller {

    @Inject
    private JPAApi jpaApi;

    private RequestBody getBody() {

        return request().body();
    }

    /**
     * Retorna corpo da requisição no formato JSON.
     *
     * @return Objeto Json
     */
    protected JsonNode getJsonBody() {

        final RequestBody body = getBody();
        return body != null ? body.asJson() : null;
    }

    /**
     * Retorna corpo da requisição no formato Text.
     *
     * @return String.
     */
    protected String getTextBody() {

        final RequestBody body = getBody();
        return body != null ? body.asText() : null;
    }

    /**
     * Retorna array de bytes de uma requisição.
     *
     * @return Array de bytes
     */
    protected byte[] getByteArrayBody() {

        final RequestBody body = getBody();
        if ( body != null ) {
            final ByteString byteString = body.asBytes();
            if ( byteString != null )
                return byteString.toArray();
        }

        return new byte[0];
    }

    /**
     * @see UtilJson#toList(JsonNode, String, Class)
     */
    protected <T> List<T> getList(
        final String fieldName,
        final Class<T> clazz
    ) {

        try {
            return toList( getJsonBody(), fieldName, clazz );
        } catch ( final IOException e ) {
            throw new IllegalStateException( "Falha ao aplicar parse em json" );
        }
    }

    /**
     * @since UtilJson#toSet(JsonNode, String, Class)
     */
    protected <T> Set<T> getSet(
        final String fieldName,
        final Class<T> clazz
    ) {

        try {
            return toSet( getJsonBody(), fieldName, clazz );
        } catch ( final IOException e ) {
            throw new IllegalStateException( "Falha ao aplicar parse em json" );
        }
    }

    /**
     * @see UtilJson#toShort(JsonNode, String)
     */
    protected Short getShort( final String fieldName ) {

        return toShort( getJsonBody(), fieldName );
    }

    /**
     * @see UtilJson#toLong(JsonNode, String)
     */
    protected Long getLong( final String fieldName ) {

        return toLong( getJsonBody(), fieldName );
    }

    /**
     * @see UtilJson#toText(JsonNode, String)
     */
    protected String getString( final String fieldName ) {

        return toText( getJsonBody(), fieldName );
    }

    /**
     * @see UtilJson#toBigDecimal(JsonNode, String)
     */
    protected BigDecimal getBigDecimal( final String fieldName ) {

        return toBigDecimal( getJsonBody(), fieldName );
    }

    /**
     * (Json) Obtem valor data => formato: dd-MM-yyyy
     *
     * @see UtilJson#toLocalDate(JsonNode, String, String)
     */
    protected LocalDate getLocalDate( final String fieldName ) {

        final String value = getString( fieldName );

        if ( isVazia(value) ) return null;

        return toLocalDate( getJsonBody(), fieldName, "dd-MM-yyyy" );
    }

    /**
     * (Json) Obtem valor data/hora
     *
     * <p>Separadores:  '-' ou '/' </p>
     *
     * <ul>
     *     <li>dd-MM-yyyy</li>
     *     <li>dd-MM-yyyy HH:mm</li>
     *     <li>dd-MM-yyyy HH:mm:ss</li>
     * </ul>
     */
    protected LocalDateTime getLocalDateTime( final String fieldName ) {

        final String value = getString( fieldName );

        if ( isVazia(value) ) return null;

        switch ( value.length() ) {
            case 10:
                return toLocalDateTime( value, value.contains("/") ? "dd/MM/yyyy" : "dd-MM-yyyy");
            case 16:
                return toLocalDateTime( value, value.contains("/") ? "dd/MM/yyyy HH:mm" : "dd-MM-yyyy HH:mm");
            case 19:
                return toLocalDateTime( value, value.contains("/") ? "dd/MM/yyyy HH:mm:ss" : "dd-MM-yyyy HH:mm:ss");
        }

        return null;
    }

    /**
     * Formato boolean
     *
     * @see UtilJson#toBoolean(JsonNode, String)
     */
    protected Boolean getBoolean( final String fieldName ) {

        return toBoolean( getJsonBody(), fieldName );
    }

    /**
     * Aplicar rollback.
     */
    protected void setRollbackOnly() {

        if ( jpaApi.em().getTransaction().isActive() )
            jpaApi.em().getTransaction().setRollbackOnly();
    }

    /**
     * Retorna badRequest aplicando rollback.
     *
     * <p>Autor: GPortes</p>
     *
     * @param throwable Erro
     *
     * @return Status de retorno da requisição.
     */
    protected Result badRequestRollback( final Throwable throwable ) {

        setRollbackOnly();
        return badRequest( getException(throwable) );
    }

    /**
     * Parametros enviados pelo PowerBatch.
     *
     * <p>Autor: GPortes</p>
     *
     * @return Possivel valores.
     *
     * <pre>{@code
     *   // Exemplo:
     *   final Optional<PBatchParam> possivelParam = getPowerBatchParam();
     *   if ( possivelParam.isPresent() ) {
     *      PBatchParam param = possivelParam.get();
     *      String texto1 = param.getString(1);
     *      ..
     *      ..
     *      Long valor1 = param.getLong(1);
     *   }
     * }</pre>
     *
     */
    protected Optional<PBatchParam> getPowerBatchParam() {

        return request()
            .header( "powerbatch-param" )
            .map( PBatchParam::decode );
    }

    /**
     * Retorna User-Agent.
     *
     * @return User-Agent
     */
    protected String getUserAgent() {

        return request().getHeaders().get(Http.HeaderNames.USER_AGENT).orElse( "" );
    }
}
