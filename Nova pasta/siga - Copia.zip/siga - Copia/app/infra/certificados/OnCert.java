package infra.certificados;

import infra.exceptions.InfraException;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Enumeration;

import static infra.util.UtilSistema.OSType.LINUX;
import static infra.util.UtilSistema.OSType.WINDOWS;
import static infra.util.UtilSistema.SO_CORRENTE;
import static infra.util.UtilString.isVazia;
import static java.lang.String.format;

/**
 * Classe que encapsula metodos para busca utilização de certificados instalados na maquina
 * ou em keystores.
 *
 * @author fernandopti
 *
 */
public class OnCert {

    public static final String CAMINHO_KEYSTORE_LINUX = "/play/apps/siga/wallet.jks";
    public static final String SENHA_CERTIFICADO = "ArC0mNf3!@#$%6&*9";

    /**
     * Procedimento que retorna o Keystore
     *
     * @param strAliasTokenCert
     * @return
     * @throws Exception
     */
    public static KeyStore funcKeyStore(String strAliasTokenCert) throws Exception {

        String strResult = "";

        // Busca Keystore conforme SO.
        KeyStore ks = buscarKeystoreSO();

        Enumeration<String> aliasEnum = ks.aliases();
        while (aliasEnum.hasMoreElements()) {
            String aliasKey = aliasEnum.nextElement();
            if (ks.isKeyEntry(aliasKey)) {
                strResult = aliasKey;
            }
            if (ks.getCertificateAlias(ks.getCertificate(strResult)).equals(strAliasTokenCert)) {
                break;
            }
        }

        return ks;
    }

    /**
     * Procedimento de listagem dos certificados digitais
     *
     * @param booCertValido
     * @return
     * @throws Exception
     */
    public static String[] funcListaCertificados(boolean booCertValido)	throws Exception {

        // 50 certificados no maximo
        String strResult[] = new String[50];
        Integer intCnt = 0;


        // Busca Keystore conforme SO.
        KeyStore ks = buscarKeystoreSO();

        Enumeration<String> aliasEnum = ks.aliases();
        while (aliasEnum.hasMoreElements()) {
            String aliasKey = aliasEnum.nextElement();
            if (!booCertValido) {
                strResult[intCnt] = aliasKey;
            } else if (ks.isKeyEntry(aliasKey)) {
                strResult[intCnt] = aliasKey;
            }
            if (strResult[intCnt] != null) {
                intCnt = intCnt + 1;
            }
        }

        return strResult;
    }

    /**
     * Procedimento que retorna a chave privada de um certificado Digital
     *
     * @param strAliasTokenCert
     * @param strAliasCertificado
     * @param strArquivoCertificado
     * @param strSenhaCertificado
     * @return
     * @throws Exception
     */
    public static PrivateKey funcChavePrivada(
        String strAliasTokenCert,
        String strAliasCertificado,
        String strArquivoCertificado,
        String strSenhaCertificado
    ) throws Exception {

        KeyStore ks;
        PrivateKey privateKey;

        if ( isVazia(strAliasTokenCert) ) {
            ks = KeyStore.getInstance("PKCS12");
            FileInputStream fis = new FileInputStream(strArquivoCertificado);
            ks.load(fis, strSenhaCertificado.toCharArray());
            privateKey = (PrivateKey) ks.getKey(strAliasCertificado, strSenhaCertificado.toCharArray());
        } else {
            if ( isVazia(strSenhaCertificado) ) {
                strSenhaCertificado = "Senha";
            }
            // Procedimento para a captura da chave privada do token/cert
            privateKey = (PrivateKey) funcKeyStore(strAliasTokenCert).getKey(
                strAliasTokenCert,
                strSenhaCertificado.toCharArray()
            );
        }

        return privateKey;
    }

    /**
     * Procedimento que retorna o certificado selecionado
     *
     * @param strAliasTokenCert
     * @param strAliasCertificado
     * @param strArquivoCertificado
     * @param strSenhaCertificado
     * @return
     * @throws Exception
     */
    public static X509Certificate funcCertificadoSelecionado(
        String strAliasTokenCert,
        String strAliasCertificado,
        String strArquivoCertificado,
        String strSenhaCertificado
    ) throws Exception {

        X509Certificate crtCertificado;
        KeyStore ks;
        if ( isVazia(strAliasTokenCert) ) {
            // Procedimento de captura do certificao arquivo passado como parametro
            InputStream dado = new FileInputStream(strArquivoCertificado);
            ks = KeyStore.getInstance("PKCS12");
            ks.load(dado, strSenhaCertificado.toCharArray());
            crtCertificado = (X509Certificate) ks.getCertificate(strAliasCertificado);
        } else {
            // Procedimento de captura do certificao token passado como parametro
            KeyStore.PrivateKeyEntry keyEntry;
            keyEntry = (KeyStore.PrivateKeyEntry) funcKeyStore(strAliasTokenCert).getEntry(
                strAliasTokenCert,
                new KeyStore.PasswordProtection(strSenhaCertificado.toCharArray()
            ));
            crtCertificado = (X509Certificate) keyEntry.getCertificate();
        }
        return crtCertificado;
    }


    /**
     * Buscar keyStore conforme sistema operacional.

     * @return
     */
    private static KeyStore buscarKeystoreSO() {

        try {
            KeyStore ks;

            if ( SO_CORRENTE == WINDOWS ){
                ks = KeyStore.getInstance("Windows-MY", "SunMSCAPI");
                ks.load(null, null);
            } else if ( SO_CORRENTE == LINUX ){
                File file = new File( CAMINHO_KEYSTORE_LINUX );
                FileInputStream is = new FileInputStream(file);
                ks = KeyStore.getInstance(KeyStore.getDefaultType());
                ks.load(is, SENHA_CERTIFICADO.toCharArray());
            } else {
                throw new InfraException( format(
                    "Não foi implementado uma busca de KeyStore para o SO [%s]" , SO_CORRENTE
                ));
            }

            return ks;

        } catch ( KeyStoreException
                | NoSuchProviderException
                | IOException
                | NoSuchAlgorithmException
                | CertificateException  e
        ) {
            throw new InfraException( "Falha ao buscar KeyStore " + e.getMessage() );
        }
    }

    /**
     * Classe para amazenar parametros da assinatura
     */
    public static class TAssinaXML {
        public String strAliasTokenCert = null;
        public String strAliasCertificado = null;
        public String strArquivoCertificado = null;
        public String strSenhaCertificado = null;
        public String strArquivoXML = null;
        public String C14N_TRANSFORM_METHOD = "http://www.w3.org/TR/2001/REC-xml-c14n-20010315";
    }
}