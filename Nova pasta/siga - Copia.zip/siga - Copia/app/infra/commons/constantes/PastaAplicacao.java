package infra.commons.constantes;

import infra.model.Constante;


/**
 * Constante ref. a valores das pastas de implantação do aplicação.
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 23/05/2017
 */
public enum PastaAplicacao implements Constante<Integer> {


    /**
     * 0
     */
    NAO_IDENTIFICADO( "NAO IDENTIFICADO", 0 ),

    /**
     * 1
     */
    SIGA_1( "SIGA 1", 1 ),

    /**
     * 2
     */
    SIGA_2( "SIGA 2", 2 )
    ;

    private final String descricao;
    private final Integer valor;


    PastaAplicacao( final String descricao,
                    final Integer valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public Integer getValor() {

        return valor;
    }
}
