package infra.commons.constantes;

import infra.model.Constante;
import infra.util.UtilDate;

import java.util.Date;

/**
 * Constante ref. ao conjunto de valores dos dias da semana.
 *
 * <p>Autor: Clebersilva</p>
 *
 * @since 23/05/2017
 */
public enum DiaSemana implements Constante<Short> {

    /**
     * 1
     */
    DOMINGO( "DOMINGO", (short) 1 ),

    /**
     * 2
     */
    SEGUNDA( "SEGUNDA", (short) 2 ),

    /**
     * 3
     */
    TERCA( "TERCA", (short) 3 ),

    /**
     * 4
     */
    QUARTA( "QUARTA", (short) 4 ),

    /**
     * 5
     */
    QUINTA( "QUINTA", (short) 5 ),

    /**
     * 6
     */
    SEXTA( "SEXTA", (short) 6 ),

    /**
     * 7
     */
    SABADO( "SABADO", (short) 7 )
    ;

    private final String descricao;
    private final Short valor;

    DiaSemana(
        final String descricao,
        final Short valor
    ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return descricao;
    }

    @Override
    public Short getValor() {

        return valor;
    }

    public static DiaSemana getDiaSemana(final Date dataBase) {

        int dia = UtilDate.getDiaSemana(dataBase);

        switch (dia) {
            case 1 : return DOMINGO;
            case 2 : return SEGUNDA;
            case 3 : return TERCA;
            case 4 : return QUARTA;
            case 5 : return QUINTA;
            case 6 : return SEXTA;
            case 7 : return SABADO;
        }

        throw new IllegalArgumentException( "[DiaSemana] Data base invalida: " + dataBase );
    }

}
