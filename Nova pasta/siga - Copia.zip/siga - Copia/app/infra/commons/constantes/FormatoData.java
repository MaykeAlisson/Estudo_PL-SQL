package infra.commons.constantes;

import infra.model.Constante;

public enum FormatoData implements Constante<String> {

    /**
     * dd/MM/yyyy HH:mm:ss
     */
    DATA_HORA( "DATA/HORA (dd/mm/yyyy hh:mm:ss)", "dd/MM/yyyy HH:mm:ss" ),

    /**
     * dd/MM/yyyy HH:mm
     */
    DATA_HORA_MINUTO( "DATA/HORA (dd/mm/yyyy hh:mm)","dd/MM/yyyy HH:mm" ),

    /**
     * HH:mm
     */
    HORA_MINUTO( "HORA (hh:mm)", "HH:mm" )
    ;

    private String descricao;
    private String valor;

    FormatoData( final String descricao,
                 final String valor ) {

        this.descricao = descricao;
        this.valor = valor;
    }

    @Override
    public String getDescricao() {

        return this.descricao;
    }

    @Override
    public String getValor() {

        return this.valor;
    }
}
