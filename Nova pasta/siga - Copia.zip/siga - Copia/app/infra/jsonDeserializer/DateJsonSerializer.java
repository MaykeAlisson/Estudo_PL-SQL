package infra.jsonDeserializer;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import infra.util.UtilDate;

import java.io.IOException;
import java.util.Date;

import static infra.util.UtilDate.FORMATO_JSON_DATA;
import static infra.util.UtilDate.getDataComoString;

/**
 * Serializer - LocalDate.
 *
 * <p>Autor: Alysson</p>
 */
public class DateJsonSerializer extends StdSerializer<Date> {

    public DateJsonSerializer(){

        super( Date.class );
    }

    @Override
    public void serialize(
        final Date value,
        final JsonGenerator gen,
        final SerializerProvider sp
    ) throws IOException {

        gen.writeString( getDataComoString( value, FORMATO_JSON_DATA ) );
    }
}