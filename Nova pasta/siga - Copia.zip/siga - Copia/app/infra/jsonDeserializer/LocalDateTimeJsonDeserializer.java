package infra.jsonDeserializer;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

import static infra.util.UtilDate.getStringComoDate;
import static infra.util.UtilDate.toLocalDate;
import static infra.util.UtilDate.toLocalDateTime;
import static infra.util.UtilString.isVazia;

/**
 * <p>Autor: tiagopti</p>
 */
public class LocalDateTimeJsonDeserializer extends JsonDeserializer<LocalDateTime> {

    @Override
    public LocalDateTime deserialize(JsonParser jsonParser,
                                     DeserializationContext deserializationContext ) throws IOException {

        if ( jsonParser == null )
            return null;

        final String texto = jsonParser.getText();

        if ( isVazia( texto ) )
            return null;

        return toLocalDateTime( texto, "yyyy-MM-dd HH:mm" );
    }
}
