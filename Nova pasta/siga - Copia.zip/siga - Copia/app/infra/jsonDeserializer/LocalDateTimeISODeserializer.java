package infra.jsonDeserializer;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static infra.util.UtilString.isVazia;

public class LocalDateTimeISODeserializer extends StdDeserializer<LocalDateTime> {

    public LocalDateTimeISODeserializer() {

        this(null );
    }

    private LocalDateTimeISODeserializer( final Class<LocalDateTime> vc ) {

        super(vc);
    }

    @Override
    public LocalDateTime deserialize(
        final JsonParser jsonParser,
        final DeserializationContext ctxt
    ) throws IOException {

        if ( jsonParser != null && !isVazia( jsonParser.getText() ) )
            return LocalDateTime.parse( jsonParser.getText(), DateTimeFormatter.ISO_DATE_TIME );

        return null;
    }
}
