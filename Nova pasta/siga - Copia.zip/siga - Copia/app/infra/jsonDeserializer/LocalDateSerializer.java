package infra.jsonDeserializer;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import infra.util.UtilDate;

import java.io.IOException;
import java.time.LocalDate;

import static infra.util.UtilDate.FORMATO_JSON_DATA;

/**
 * Serializer - LocalDate.
 *
 * <p>Autor: Alysson</p>
 */
public class LocalDateSerializer extends StdSerializer<LocalDate> {

    public LocalDateSerializer(){

        super( LocalDate.class );
    }

    @Override
    public void serialize(
        final LocalDate value,
        final JsonGenerator gen,
        final SerializerProvider sp
    ) throws IOException {

        gen.writeString( UtilDate.toString( value, FORMATO_JSON_DATA ) );
    }
}