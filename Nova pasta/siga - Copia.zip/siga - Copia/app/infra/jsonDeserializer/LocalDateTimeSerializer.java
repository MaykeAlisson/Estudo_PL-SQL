package infra.jsonDeserializer;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import infra.util.UtilDate;

import java.io.IOException;
import java.time.LocalDateTime;

import static infra.util.UtilDate.FORMATO_JSON_DATA_HORA_MINUTO;

/**
 * Serializer - LocalDatetime.
 *
 * <p>Autor: GPortes</p>
 */
public class LocalDateTimeSerializer extends StdSerializer<LocalDateTime> {

    public LocalDateTimeSerializer() {

        super( LocalDateTime.class );
    }

    @Override
    public void serialize(
        final LocalDateTime value,
        final JsonGenerator gen,
        final SerializerProvider provider
    ) throws IOException {

        gen.writeString( UtilDate.toString( value, FORMATO_JSON_DATA_HORA_MINUTO ) );
    }
}
