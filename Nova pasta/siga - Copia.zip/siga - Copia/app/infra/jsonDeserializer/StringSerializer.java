package infra.jsonDeserializer;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by tiagopti on 17/10/2018.
 */
public class StringSerializer extends StdSerializer<String> {

    private static final long serialVersionUID = 1L;

    public StringSerializer(){
        super(String.class);
    }

    @Override
    public void serialize(String value, JsonGenerator gen, SerializerProvider sp) throws IOException, JsonProcessingException {
        gen.writeString(value.trim());
    }
}