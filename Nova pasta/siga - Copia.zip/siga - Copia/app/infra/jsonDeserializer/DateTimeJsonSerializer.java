package infra.jsonDeserializer;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;
import java.util.Date;

import static infra.util.UtilDate.FORMATO_JSON_DATA_HORA_MINUTO;
import static infra.util.UtilDate.getDataComoString;

/**
 * Serializer - LocalDate.
 *
 * <p>Autor: Alysson</p>
 */
public class DateTimeJsonSerializer extends StdSerializer<Date> {

    public DateTimeJsonSerializer(){

        super( Date.class );
    }

    @Override
    public void serialize(
            final Date value,
            final JsonGenerator gen,
            final SerializerProvider sp
    ) throws IOException {

        gen.writeString( getDataComoString( value, FORMATO_JSON_DATA_HORA_MINUTO ) );
    }

}
