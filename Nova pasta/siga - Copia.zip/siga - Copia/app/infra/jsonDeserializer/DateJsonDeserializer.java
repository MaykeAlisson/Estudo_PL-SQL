package infra.jsonDeserializer;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

import java.io.IOException;
import java.util.Date;

import static infra.util.UtilDate.getStringComoDate;
import static infra.util.UtilString.isVazia;

/**
 * <p>Autor: GPortes</p>
 */
public class DateJsonDeserializer extends JsonDeserializer<Date> {

    @Override
    public Date deserialize( JsonParser jsonParser,
                             DeserializationContext deserializationContext ) throws IOException {

        if ( jsonParser == null )
            return null;

        final String texto = jsonParser.getText();

        if ( isVazia( texto ) )
            return null;

        return getStringComoDate( texto, "yyyy-MM-dd HH:mm:ss" );
    }
}
