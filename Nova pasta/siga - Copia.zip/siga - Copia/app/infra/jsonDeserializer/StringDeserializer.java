package infra.jsonDeserializer;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

import java.io.IOException;
import java.time.LocalDateTime;

import static infra.util.UtilDate.toLocalDateTime;
import static infra.util.UtilString.isVazia;

/**
 * <p>Autor: tiagopti</p>
 */
public class StringDeserializer extends JsonDeserializer<String> {

    @Override
    public String deserialize(JsonParser jsonParser,
                                     DeserializationContext deserializationContext ) throws IOException {

        if ( jsonParser == null )
            return null;

        final String texto = jsonParser.getText();

        if ( isVazia( texto ) )
            return null;

        return texto;
    }
}
