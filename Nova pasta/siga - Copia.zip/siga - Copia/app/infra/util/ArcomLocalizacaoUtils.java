package infra.util;

import java.math.BigDecimal;
import java.util.List;

public final class ArcomLocalizacaoUtils {

	private ArcomLocalizacaoUtils() {
	}

	public static long calcularDistanciaCoordenadasEmMetros(BigDecimal latitude1,
															BigDecimal longitude1, BigDecimal latitude2, BigDecimal longitude2) {
		return calcularDistanciaCoordenadasEmMetros(latitude1.doubleValue(), longitude1.doubleValue(), latitude2.doubleValue(), longitude2.doubleValue());
	}

	public static long calcularDistanciaCoordenadasEmMetros(double latitude1,
															double longitude1, double latitude2, double longitude2) {
		double theta = longitude1 - longitude2;
		double dist = Math.sin(deg2rad(latitude1))
				* Math.sin(deg2rad(latitude2)) + Math.cos(deg2rad(latitude1))
				* Math.cos(deg2rad(latitude2)) * Math.cos(deg2rad(theta));
		dist = Math.acos(dist);
		dist = rad2deg(dist);
		dist = dist * 60 * 1.1515 * 1609.0;
		return Double.valueOf(dist).longValue();
	}

	public static boolean validarLocalizacao(double latitude, double longitude) {
		return latitude != 0d && longitude != 0d && Math.abs(latitude) <= 90
				&& Math.abs(longitude) <= 180;
	}

	private static double deg2rad(double deg) {
		return (deg * Math.PI / 180.0);
	}

	private static double rad2deg(double rad) {
		return (rad * 180 / Math.PI);
	}

	/**
	 * @param latitude
	 * @param longitude
	 * @param coordenadas
	 * @return <p><b>Autoria: </b>Maycon César - 27/07/2017</p>
	 */
	public static <T> T getCoordenadaMenorDistancia(double latitude, double longitude, List<ArcomCoordenadaDoubleWrapper<T>> coordenadas) {
		ArcomCoordenadaDoubleWrapper<T> melhorLocation = null;
		if (coordenadas != null && !coordenadas.isEmpty()) {
			long menorDist = -1;
			for (ArcomCoordenadaDoubleWrapper<T> loc : coordenadas) {
				long dist = ArcomLocalizacaoUtils.calcularDistanciaCoordenadasEmMetros(latitude, longitude, loc.getLatitude(), loc.getLongitude());
				if (dist < 0) {
					continue;
				}
				if (menorDist == -1) {
					melhorLocation = loc;
					menorDist = dist;

				} else if (dist < menorDist) {
					melhorLocation = loc;
					menorDist = dist;
				}
			}
		}
		return melhorLocation == null ? null : melhorLocation.getObject();
	}

	/**
	 * @param coordenadas
	 * @return <p><b>Autoria: </b>Maycon César - 27/07/2017</p>
	 */
	public static <T> T getCoordenadaMenorDistancia(List<ArcomCoordenadaDoubleWrapper<T>> coordenadas) {
		return new ArcomCoordenadaBestMatch<T>(coordenadas).get();
	}

}
