package infra.util;

import play.Logger;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Path;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import static infra.util.UtilCollections.isVazia;
import static java.util.Objects.requireNonNull;

/**
 * Utilitario para compactação de arquivos.
 */
public class UtilZip {

    /**
     * Compactar arquivos.
     *
     * <p>Autor: GPortes</p>
     *
     * @param arquivoDestinoZip Arquivo ZIP
     * @param arquivosCompactar Arquivo(s) a serem compactado(s).
     *
     * @return (true) se ok e (false) o contrário.
     *
     * <pre>{@code
     *
     *  // Exemplo
     *
     *  final Path saida = Paths.get("D:\\temp\\imagem\\comp\\teste.zip");
     *  final Path arq1 = Paths.get("D:\\temp\\imagem\\teste1.txt");
     *  final Path arq2 = Paths.get("D:\\temp\\imagem\\teste2.txt");
     *
     *  UtilArquivo.compactar(saida, arq1, arq2);
     *
     * }</pre>
     *
     */
    public static boolean compactar(
        final Path arquivoDestinoZip,
        final Path ...arquivosCompactar
    ) {

        requireNonNull(arquivoDestinoZip, "Arquivo Zip destino não informado");

        if ( isVazia(arquivosCompactar) )
            return false;

        try ( ZipOutputStream zipOut = new ZipOutputStream(new FileOutputStream(arquivoDestinoZip.toFile())))  {
            for ( Path arquivo : arquivosCompactar ) {
                try ( FileInputStream fis = new FileInputStream(arquivo.toFile()) ){
                    final ZipEntry zipEntry = new ZipEntry(arquivo.toFile().getName());
                    zipOut.putNextEntry(zipEntry);
                    byte[] bytes = new byte[1024];
                    int length;
                    while((length = fis.read(bytes)) >= 0) {
                        zipOut.write(bytes, 0, length);
                    }
                } catch ( final FileNotFoundException e ) {
                    Logger.error("Arquivo {}", arquivo.toAbsolutePath());
                    throw new UncheckedIOException(e);
                }
            }
            return true;
        } catch ( final IOException e ) {
            throw new UncheckedIOException(e);
        }
    }


}
