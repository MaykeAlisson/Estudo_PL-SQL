package infra.util;

import infra.model.Constante;

import static infra.util.UtilString.isVazia;

/**
 * Classe utilitária para tratamento de Enums.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 03/09/2014
 *
 */
public final class UtilEnum {

    /**
     * Retorna se um Enum não esta contido num array de Enums
     *
     * <p>Autor: GPortes</p>
     *
     * @param find  Enumerado a ser pesquisado.
     * @param dados Array de Enum
     *
     * @return boolean
     */
    public static boolean notIn(
        final Enum find,
        final Enum... dados
    ) {

        for ( final Enum e : dados )
            if ( e.equals( find ) )
                return false;

        return true;
    }


    /**
     * Retorna Enum com base no valor passado como argumento.
     *
     * <p>Autor: GPortes</p>
     *
     * @param enumClass Enum Class
     * @param value     Valor a pesquisar no Enum
     *
     * @return Enum
     */
    @SuppressWarnings( "unchecked" )
    public static <T extends Enum & Constante<S>, S> T getEnum(
        final Class<T> enumClass,
        final S value
    ) {

        if ( enumClass == null || value == null )
            return null;

        for ( final Enum obj : enumClass.getEnumConstants() )
            if ( ((Constante) obj).getValor().equals(value) )
                return (T) obj;

        return null;
    }

    /**
     * Retorna enum a partir de um texto
     *
     * <p>Autor: GPortes</p>
     *
     * @param enumClass Enum class
     * @param texto     Texto a ser localizado.
     *
     * @return Enumerado.
     */
    public static <T extends Enum<T>> T getEnumFromString(
        final Class<T> enumClass,
        final String texto
    ) {

        if ( enumClass == null || texto == null )
            return null;

        for ( final T enumValue : enumClass.getEnumConstants() )
            if ( enumValue.name().equalsIgnoreCase(texto) )
                return enumValue;

        return null;
    }

}
