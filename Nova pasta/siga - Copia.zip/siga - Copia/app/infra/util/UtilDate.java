package infra.util;

import infra.binders.DateBinder;
import infra.binders.LocalDateBinder;
import infra.commons.constantes.DiaSemana;
import infra.commons.constantes.FormatoData;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilString.ehHoraValida;
import static infra.util.UtilString.isVazia;
import static java.lang.String.format;
import static java.time.format.DateTimeFormatter.ofPattern;
import static java.time.temporal.ChronoUnit.DAYS;
import static java.time.temporal.TemporalAdjusters.lastDayOfMonth;
import static java.util.Calendar.AM_PM;
import static java.util.Calendar.DAY_OF_MONTH;
import static java.util.Calendar.DAY_OF_WEEK;
import static java.util.Calendar.DAY_OF_YEAR;
import static java.util.Calendar.HOUR_OF_DAY;
import static java.util.Calendar.MILLISECOND;
import static java.util.Calendar.MINUTE;
import static java.util.Calendar.MONTH;
import static java.util.Calendar.SATURDAY;
import static java.util.Calendar.SECOND;
import static java.util.Calendar.SUNDAY;
import static java.util.Calendar.YEAR;
import static java.util.Collections.sort;
import static java.util.Optional.empty;
import static java.util.Optional.of;


/**
 * Classe utilitária para tratamento de Datas.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 03/09/2014
 *
 */
public final class UtilDate {

    public static final String FORMATO_DATA_HORA = "dd/MM/yyyy HH:mm:ss";
    public static final String FORMATO_DATA_HORA_MINUTO = "dd/MM/yyyy HH:mm";
    public static final String FORMATO_HORA_MINUTO = "HH:mm";
    public static final String FORMATO_JSON_DATA_HORA_MINUTO = "dd-MM-yyyy HH:mm:ss";
    public static final String FORMATO_JSON_DATA = "dd-MM-yyyy";
    private static final String FORMATO_DATA_PADRAO = "dd/MM/yyyy";
    private static final String FORMATO_DATA_XSD = "yyyy-MM-dd";
    private static final Date[] ARRAY_VAZIO = {};


    /**
     * Verifica se objeto não é {@code null} ou {@code empty}. Este método é projetado principalmente
     * para fazer a validação de parâmetros em métodos e construtores, como demonstrado abaixo:
     *
     * <blockquote><pre>
     * public Foo(String bar) {
     *     this.bar = UtilDate.requireNonEmpty(bar);
     * }
     * </pre></blockquote>
     *
     * @param obj       the object reference to check for nullity
     * @param message   the type of the reference
     *
     * @return {@code obj} if not {@code null}
     *
     * @throws IllegalArgumentException if {@code obj} is {@code empty}
     *
     * <p>Autor: GPortes</p>
     */
    public static LocalDateTime requireNonEmpty(
            final LocalDateTime obj,
            final String message
    ) {

        if ( isValida(obj) )
            return obj;

        if ( isVazia( message ) )
            throw new IllegalArgumentException( "Data invalida!!" );

        throw new IllegalArgumentException( message );
    }

    /**
     * Verifica se objeto não é {@code null} ou {@code empty}. Este método é projetado principalmente
     * para fazer a validação de parâmetros em métodos e construtores, como demonstrado abaixo:
     *
     * <blockquote><pre>
     * public Foo(String bar) {
     *     this.bar = UtilDate.requireNonEmpty(bar);
     * }
     * </pre></blockquote>
     *
     * @param obj       the object reference to check for nullity
     * @param message   the type of the reference
     *
     * @return {@code obj} if not {@code null}
     *
     * @throws IllegalArgumentException if {@code obj} is {@code empty}
     *
     * <p>Autor: GPortes</p>
     */
    public static LocalDate requireNonEmpty(
            final LocalDate obj,
            final String message
    ) {

        if ( isValida(obj) )
            return obj;

        if ( isVazia( message ) )
            throw new IllegalArgumentException( "Data invalida!!" );

        throw new IllegalArgumentException( message );
    }


    /**
     * Verifica se data é valida.
     *
     * @param value Data a ser validada.
     *
     * @return (true) e válida e (false) o contrário.
     */
    public static boolean isValida( final Date value ) {

        return value != null;
    }

    /**
     * Verifica se data é valida.
     *
     * @param value Data a ser validada.
     *
     * @return (true) e válida e (false) o contrário.
     */
    public static boolean isValida( final LocalDateTime value ) {

        return  value != null;
    }

    /**
     * Verifica se data é valida.
     *
     * @param value Data a ser validada.
     *
     * @return (true) e válida e (false) o contrário.
     */
    public static boolean isValida( final LocalDate value ) {

        return  value != null;
    }

    /**
     * Verifica se data é valida.
     *
     * @param value Data a ser validada.
     *
     * @return (true) e válida e (false) o contrário.
     */
    public static boolean isValida( final DateBinder value ) {

        return value != null && isValida( value.getValue() );
    }

    /**
     * Verifica se data é valida.
     *
     * @param value Data a ser validada.
     *
     * @return (true) e válida e (false) o contrário.
     */
    public static boolean isValida( final LocalDateBinder value ) {

        return value != null && isValida( value.getValue() );
    }

    /**
     *
     * @param dataBase
     * @param diaSemana
     * @return
     */
    public static Date getProximoDia( final Date dataBase,
                                      final DiaSemana diaSemana ) {

        if ( !isValida(dataBase) )
            throw new IllegalArgumentException( "Faltou definir argumento [ dataBase ] " );

        if ( diaSemana == null )
            throw new IllegalArgumentException( "Faltou definir argumento [ diaSemana ] " );

        Date data = dataBase;
        do {
            data = adicionarNDias(1,data);
            if ( getDiaSemana(data) == diaSemana.getValor() )  return data;
        } while (true);
    }

    /**
     * Retorna data/hora no formato especificado.
     *
     * <p>Autor: GPortes</p>
     *
     * @param locDateTime   Data/hora a ser formatada.
     * @param formato       Padrão a ser formatado.
     *
     * @return Data no padrão especificado.
     */
    public static String getDataComoString( final LocalDateTime locDateTime,
                                            final String formato ) {

        if ( locDateTime == null )
            return "";

        return locDateTime.format( ofPattern( formato ) );
    }

    /**
     * Retorna representação em String no formato DD/MM/YYYY.
     *
     * <p>Autor: GPortes</p>
     *
     * @param locDateTime   Data/hora a ser formatada.
     *
     */
    public static String getDataComoString( final LocalDateTime locDateTime ) {

        if ( locDateTime == null )
            return "";

        return locDateTime.format( ofPattern( FORMATO_DATA_PADRAO ) );
    }

    /**
     * Retorna data/hora no formato especificado.
     *
     * <p>Autor: GPortes</p>
     *
     * @param locDateTime   Data/hora a ser formatada.
     * @param formato       Padrão a ser formatado.
     *
     * @return Data no padrão especificado.
     */
    public static String getDataComoString( final LocalDate locDateTime,
                                            final String formato ) {

        if ( locDateTime == null )
            return "";

        return locDateTime.format( ofPattern( formato ) );
    }

    /**
     * Retorna representação em String no formato DD/MM/YYYY.
     *
     * <p>Autor: GPortes</p>
     *
     * @param locDateTime   Data/hora a ser formatada.
     *
     */
    public static String getDataComoString( final LocalDate locDateTime ) {

        if ( locDateTime == null )
            return "";

        return locDateTime.format( ofPattern( FORMATO_DATA_PADRAO ) );
    }

    /**
     * Retorna data/hora no formato especificado.
     *
     * <p>Autor: GPortes</p>
     *
     * @param localDate   Data/hora a ser formatada.
     * @param formato     Padrão a ser formatado.
     *
     * @return Data no padrão especificado.
     */
    public static String toString(
        final LocalDate localDate,
        final String formato ) {

        if ( localDate == null )
            return "";

        return localDate.format( ofPattern( formato ) );
    }

    /**
     * Converte data para String no formato DD/MM/YYYY.
     *
     * <p>Autor: GPortes</p>
     *
     * @param localDate Data a ser convertida.
     *
     * @return String formatada.
     */
    public static String toString( final LocalDate localDate ) {

        return toString( localDate, FORMATO_DATA_PADRAO );
    }

    /**
     * Retorna data/hora no formato especificado.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value     Data/hora a ser formatada.
     * @param formato   Padrão a ser formatado.
     *
     * @return  Data/Hora no padrão especificado.
     */
    public static String toString(
        final LocalDateTime value,
        final String formato
    ) {

        if ( value == null ) return "";

        return value.format(  ofPattern( formato ) );
    }

    /**
     * Retorna data/hora no formato especificado.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value     Hora a ser formatada em String.
     * @param formato   Padrão a ser formatado.
     *
     * @return Hora no padrão especificado.
     */
    public static String toString(
        final LocalTime value,
        final String formato
    ) {

        if ( value == null ) return "";

        return value.format( ofPattern( formato ) );
    }

    /**
     * Retorna representação em String / XSD.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value Data a ser convertida
     *
     * @return Data no formato XSD.
     */
    public static String toStringXSD( final LocalDateTime value ) {

        return value == null ? "" : value.format( ofPattern( FORMATO_DATA_XSD ) );
    }

    /**
     * Retorna representação em String no formato DD/MM/YYYY.
     *
     * @param dataBase
     *
     * @return String formatada.
     */
    public static String getDataComoString( final Date dataBase ) {

        return getDataComoString( dataBase, FORMATO_DATA_PADRAO );
    }

    /**
     * Retorna representação em String da data informada.
     *
     * @param dataBase
     * @param formato
     *
     * @return {@link String}
     */
    public static String getDataComoString( final Date dataBase,
                                            final String formato ) {

        if ( !isValida(dataBase) )
            return "";

        if ( isVazia(formato) )
            return new SimpleDateFormat(formato).format(FORMATO_DATA_PADRAO);

        return new SimpleDateFormat(formato).format(dataBase);
    }

    /**
     * Retorna representação em String de uma lista de datas. No formato DD/MM/YYYY
     *
     * @param datas Lista de datas
     *
     * @return Lista de datas no formato String.
     */
    public static String getDataComoString( final List<Date> datas ) {

        return getDataComoString( datas, " " );
    }

    /**
     * Retorna representação em String de uma lista de datas. No formato DD/MM/YYYY
     *
     * @param datas     Listas de datas
     * @param separador Separador entre as datas.
     *
     * @return Lista de datas no formato String.
     */
    public static String getDataComoString( final List<Date> datas,
                                            final String separador ) {

        if ( isVazia( datas ) ) return "";

        StringBuilder builder = new StringBuilder(  );
        for ( Date aux : datas )
            builder.append( getDataComoString( aux ) ).append( separador == null ? " " : separador );

        return builder.toString();
    }

    /**
     * Converte uma String para Date, de acordo com o formato passado. Se o
     * formato especificado for nulo, é assumido como padrão "dd/MM/yyyy".
     *
     * @param dataBase A data no formato String a ser convertida.
     * @param formatoDaData O formato da data.
     *
     * @return {@link Date} Valor nulo "null" se a data for nula, ou se ocorrer problemas na conversão.
     *                                Caso contrário, a data de acordo com o formato.
     *
     */
    public static Date getStringComoDate( final String dataBase,
                                          final String formatoDaData) {

        if ( isVazia(dataBase) )
            return null;

        String formato = formatoDaData;

        if ( isVazia(formato) )
            formato = FORMATO_DATA_PADRAO;

        SimpleDateFormat dateFormat = new SimpleDateFormat(formato);
        try {
            return dateFormat.parse(dataBase);
        } catch ( ParseException e ) {
            return null;
        }
    }

    /**
     * Converte uma String para Date, de acordo com o formato "dd/MM/yyyy".
     *
     * @param dataBase A data no formato "dd/MM/yyyy" a ser convertida.
     *
     * @return {@link Date}   Valor nulo "null" se a data for nula, ou se ocorrer problemas na
     *                                  conversão. Caso contrário, a data de acordo com o formato.
     */
    public static Date getStringComoDate( final String dataBase ) {

        return getStringComoDate(dataBase, null);
    }

    /**
     * Retorna um objeto {@link Date} a partir do dia, mes e ano informados como
     * parametros.
     *
     * @param dia
     * @param mes
     * @param ano
     *
     * @return {@link Date}
     */
    public static Date getData( final Integer dia,
                                final Integer mes,
                                final Integer ano) {

        return getStringComoDate(dia + "/" + mes + "/" + ano);
    }

    /**
     * Retorna objeto LocalDateTime ( zero hora )
     * 
     * <p>Autor: GPortes</p>
     *
     * @param dia   Dia do ano
     * @param mes   Mes
     * @param ano   Ano.
     *
     * @return Data
     */
    public static LocalDateTime getLocalDateTime(
        final Integer dia,
        final Integer mes,
        final Integer ano
    ) {

        return LocalDateTime.of( ano, mes, dia, 0, 0 );
    }

    /**
     * Retorna data.
     *
     * @param dia
     * @param mes
     * @param ano
     * @param hora
     * @param minutos
     * @param segundos
     *
     * @return Retorna data.
     */
    public static Date getData( final Integer dia,
                                final Integer mes,
                                final Integer ano,
                                final Integer hora,
                                final Integer minutos,
                                final Integer segundos ) {

        return getStringComoDate( dia + "/" + mes + "/" + ano + " " + hora + ":" + minutos + ":" + segundos, FORMATO_DATA_HORA );
    }

    /**
     * Retorna um Calendar a partir de um Date.
     *
     * @param dataBase
     *
     * @return {@link Calendar}
     */
    public static Calendar getCalendar( final Date dataBase ) {

        if ( ! isValida(dataBase) )
            return null;

        Calendar cal = Calendar.getInstance();
        cal.setTime( dataBase );
        return cal;
    }


    /**
     * Retorna o mes do calendario informado.
     *
     * @param calendario
     *
     * @return int
     */
    public static int getMes( final Calendar calendario ) {

        return calendario.get(MONTH) + 1;
    }

    /**
     * Retorna o mes da data informada.
     *
     * @param dataBase
     * @return int
     */
    public static int getMes( final Date dataBase ) {

        return getMes( getCalendar(dataBase) );
    }

    /**
     * Retorna o ano do calendario informado.
     *
     * @param calendario
     *
     * @return int
     */
    public static int getAno( final Calendar calendario ) {

        return calendario.get(YEAR);
    }


    /**
     * Retorna o ano da data informada.
     *
     * @param dataBase
     *
     * @return {@link Date}
     */
    public static int getAno( final Date dataBase ) {

        if ( ! isValida(dataBase) )
            return 0;

        Calendar calendario = new GregorianCalendar();
        calendario.setTime( dataBase );
        return getAno(calendario);
    }


    /**
     * Retorno o dia
     *
     * <p>Autor: Cleber</p>
     *
     * @param calendario
     *
     * @return int
     */
    public static int getDia( final Calendar calendario ) {

        return calendario.get(DAY_OF_MONTH);
    }

    /**
     * Retorna o dia
     *
     * <p>Autor: Cleber</p>
     *
     * @param dataBase
     *
     * @return int
     */
    public static int getDia( final Date dataBase ) {

        if (!isValida(dataBase))
            return 0;

        Calendar calendario = new GregorianCalendar();
        calendario.setTime( dataBase );
        return getDia(calendario);
    }


    /**
     * Retorna o dia da Semana
     *
     * <p>Autor: Cleber</p>
     *
     * @param dataBase
     *
     * @return int
     */
    public static int getDiaSemana( final Date dataBase ) {

        if (!isValida(dataBase))
            return 0;

        Calendar calendario = new GregorianCalendar();
        calendario.setTime( dataBase );
        return getDiaSemana(calendario);
    }

    /**
     * Retorno o dia da Semana
     *
     * <p>Autor: Cleber</p>
     *
     * @param calendario
     *
     * @return int
     */
    public static int getDiaSemana( final Calendar calendario ) {

        return calendario.get(DAY_OF_WEEK);
    }

    /**
     * Retorna a hora
     *
     * <p>Autor: Cleber</p>
     *
     * @param dataBase
     *
     * @return int
     */
    public static int getHora( final Date dataBase ) {

        if ( ! isValida(dataBase) )
            return 0;

        Calendar calendario = new GregorianCalendar();
        calendario.setTime( dataBase );
        return getHora(calendario);
    }

    /**
     * Retorna a hora,
     *
     * <p>Autor: Cleber</p>
     *
     * @param calendario
     * @return int
     */
    public static int getHora( final Calendar calendario ) {

        return calendario.get(HOUR_OF_DAY);
    }

    /**
     * Extrai apenas hora de um LocalTime.
     *
     * <p>Autor: GPortes</p>
     *
     * @param hora  Hora/Minuto
     *
     * @return Apenas hora.
     */
    public static Integer getHora( final LocalTime hora ) {

        return hora != null ? hora.getHour() : null;
    }

    /**
     * Retorna o minuto
     *
     * <p>Autor: Cleber</p>
     *
     * @param dataBase
     *
     * @return int
     */
    public static int getMinuto( final Date dataBase ) {

        if ( ! isValida(dataBase) )
            return 0;

        Calendar calendario = new GregorianCalendar();
        calendario.setTime( dataBase );
        return getMinuto(calendario);
    }

    /**
     * Retorna a hora,
     *
     * <p>Autor: Cleber</p>
     *
     * @param calendario
     * @return int
     */
    public static int getMinuto( final Calendar calendario ) {

        return calendario.get(Calendar.MINUTE);
    }

    /**
     * Extrai apenas minuto de um LocalTime.
     *
     * <p>Autor: GPortes</p>
     *
     * @param hora  Hora/Minuto
     *
     * @return Apenas minuto.
     */
    public static Integer getMinuto( final LocalTime hora ) {

        return hora != null ? hora.getMinute() : null;
    }

    /**
     * Retorna o primeiro dia do mês, adicionando N meses.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataBase          Data a ser alterada.
     * @param adicionarMeses    Nro de meses para adicionar.
     *
     * @return
     */
    public static Date getPrimeiroDiaMes( final Date dataBase,
                                          final int adicionarMeses ) {

        if ( !isValida(dataBase) )
            return null;

        Calendar calendar = Calendar.getInstance();
        calendar.setTime( dataBase );
        calendar.set( DAY_OF_MONTH, 1 );
        if ( adicionarMeses != 0 )
            calendar.add( MONTH, adicionarMeses );

        return calendar.getTime();
    }

    public static Date getUltimoDiaMes (final Date dataBase) {

        if (!isValida(dataBase))
            return null;

        Date data = adicionarNMeses(1,dataBase);
        data = setarHora_23_59_59(adicionarNDias(-1,data));

        return data;
    }

    /**
     * Passando como parametro um LocalDate, será retornado ultimo dia do mês
     *
     * <p>Autor: Fernando Vicente </p>
     *
     * @param dataBase
     *
     * @return
     */
    public static LocalDate getUltimoDiaMes( LocalDate dataBase ){

        return dataBase != null ? dataBase.withDayOfMonth(dataBase.lengthOfMonth()) : null;
    }

    /**
     * Retorna ultima data do mes.
     *
     * <p>Autor: GPortes </p>
     *
     * @param dataBase
     *
     * @return
     */
    public static LocalDateTime getUltimoDiaMes( final LocalDateTime dataBase ){

        return dataBase != null ? dataBase.with( lastDayOfMonth() ) : null;
    }

    /**
     * Retorna primeiro da do mês.
     *
     * @param dataBase
     *
     * @return {@link Date}
     */
    public static Date getPrimeiroDiaMes( final Date dataBase ) {

        return getPrimeiroDiaMes(dataBase, 0);
    }

    /**
     * Retorna primeiro da do mês.
     *
     * @param dataBase
     *
     * @return {@link Date}
     */
    public static LocalDateTime getPrimeiroDiaMes( final LocalDateTime dataBase ) {

        return isValida(dataBase) ? dataBase.withDayOfMonth(1) : null;
    }

    /**
     * Retorna primeiro da do mês.
     *
     * @param dataBase
     *
     * @return {@link Date}
     */
    public static LocalDate getPrimeiroDiaMes( final LocalDate dataBase ) {

        return isValida(dataBase) ? dataBase.withDayOfMonth(1) : null;
    }

    /**
     * Retorna todos os primeiros dia do mês.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataBase
     * @param nroDeMeses
     *
     * @return Períodos.
     */
    public static Date[] getTodosPrimeiroDiaMes( final Date dataBase,
                                                 final int nroDeMeses ) {

        if ( !isValida( dataBase ) || nroDeMeses == 0 )
            return ARRAY_VAZIO;

        Date dataFim = null;
        Date dataInicio = null;

        if ( nroDeMeses < 0 ) {
            dataFim = getPrimeiroDiaMes( dataBase, 0 );
            dataInicio = getPrimeiroDiaMes( dataFim, nroDeMeses );
        } else {
            dataInicio = getPrimeiroDiaMes( dataBase, 0 );
            dataFim = getPrimeiroDiaMes( dataInicio, nroDeMeses );
        }

        long meses = diferencaEmMeses(dataInicio, dataFim);

        Date[] periodo = new Date[ (int) meses ];
        int index = 0;

        while ( ehMenor( dataInicio, dataFim ) ) {
            periodo[index] = dataInicio;
            dataInicio = adicionarNMeses( 1, dataInicio );
            index ++;
        }

        return periodo;
    }

    /**
     * Altera data para N meses.
     *
     * <p>Autor: GPortes</p>
     *
     * @param meses     Qtde de meses a ser adicionado a data informada.
     * @param dataBase  Data a ser alterada.
     *
     * @return Nova data calculada.
     */
    public static Date adicionarNMeses( final int meses,
                                        final Date dataBase ) {

        if ( ! isValida( dataBase ) )
            return null;

        Calendar cal = getCalendar( dataBase );
        cal.add( MONTH, meses );
        return cal.getTime();
    }

    /**
     * Altera data para N meses.
     *
     * <p>Autor: GPortes</p>
     *
     * @param meses     Qtde de meses a ser adicionado a data informada.
     * @param dataBase  Data a ser alterada.
     *
     * @return Nova data calculada.
     */
    public static LocalDate adicionarNMeses(
        final long meses,
        final LocalDate dataBase
    ) {

        return isValida(dataBase) ? dataBase.plusMonths(meses) : null;
    }

    /**
     * Altera data para N meses.
     *
     * <p>Autor: GPortes</p>
     *
     * @param meses     Qtde de meses a ser adicionado a data informada.
     * @param dataBase  Data a ser alterada.
     *
     * @return Nova data calculada.
     */
    public static LocalDateTime adicionarNMeses(
            final long meses,
            final LocalDateTime dataBase
    ) {

        return isValida(dataBase) ? dataBase.plusMonths(meses) : null;
    }

    /**
     * Adiciona N dias a data informada.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dias      Qtde de dias a ser adicionada a data informada.
     * @param dataBase  Data a ser alterada.
     *
     * @return Nova data calculada.
     */
    public static Date adicionarNDias( final int dias,
                                       final Date dataBase ) {

        if ( ! isValida( dataBase ) )
            return dataBase;

        Calendar cal = getCalendar( dataBase );
        cal.add( GregorianCalendar.DAY_OF_MONTH, dias );
        return cal.getTime();
    }

    /**
     * Adiciona N dias a data informada.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dias       Qtde de dias a ser adicionada a data informada.
     * @param localDate  Data a ser incluida N dias.
     *
     * @return Nova data calculada.
     */
    public static LocalDate adicionarNDias(
        final int dias,
        final LocalDate localDate
    ) {

        return localDate != null ? localDate.plusDays( dias ) : null;
    }

    /**
     * Adiciona N dias a data informada.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dias       Qtde de dias a ser adicionada a data informada.
     * @param dataHora  Data a ser incluida N dias.
     *
     * @return Nova data calculada.
     */
    public static LocalDateTime adicionarNDias(
        final int dias,
        final LocalDateTime dataHora
    ) {

        return dataHora != null ? dataHora.plusDays( dias ) : null;
    }

    /**
     * Adiciona N minutos a data informada.
     *
     * <p>Autor: GPortes</p>
     *
     * @param minutos   Qtde de minutos a ser adicionado a data informada.
     * @param dataBase  Data a ser manipulada.
     *
     * @return Nova data calculada.
     */
    public static Date adicionarNMinutos( final int minutos,
                                          final Date dataBase ) {

        if ( ! isValida( dataBase ) )
            return dataBase;

        Calendar cal = getCalendar( dataBase );
        cal.add( Calendar.MINUTE, minutos );
        return cal.getTime();
    }

    /**
     * Adiciona N minutos a data informada.
     *
     * <p>Autor: GPortes</p>
     *
     * @param minutos   Qtde de minutos a ser adicionado a data informada.
     * @param dataBase  Data a ser manipulada.
     *
     * @return Nova data calculada.
     */
    public static Date adicionarNMinutos( final long minutos,
                                          final Date dataBase ) {

        if ( minutos > Integer.MAX_VALUE )
            throw new IllegalArgumentException( format( "Valor %s muito grande para conversão", minutos ) );

        return adicionarNMinutos( (int) minutos, dataBase );
    }

    /**
     * Adiciona N minutos a data informada.
     *
     * <p>Autor: GPortes</p>
     *
     * @param minutos   Qtde de minutos a ser adicionado a data informada.
     * @param dataBase  Data a ser manipulada.
     *
     * @return Nova data calculada.
     */
    public static LocalDateTime adicionarNMinutos( final long minutos,
                                                   final LocalDateTime dataBase ) {

        return dataBase != null ? dataBase.plusMinutes( minutos ) : dataBase;
    }

    /**
     * Retorna quantidade de dias entre 2 datas
     *
     * @param dataA
     * @param dataB
     * @return long
     */
    public static long diferencaEmDias( final Date dataA,
                                        final Date dataB ) {

        if ( !isValida(dataA) || !isValida(dataB) )
            return 0;

        int diferencaTemporaria = 0;
        int diferencaEmDias = 0;
        Calendar menorData = Calendar.getInstance();
        Calendar maiorData = Calendar.getInstance();

        if ( dataA.compareTo( dataB ) < 0) {
            menorData.setTime(dataA);
            maiorData.setTime(dataB);
        } else {
            menorData.setTime(dataB);
            maiorData.setTime(dataA);
        }

        while ( menorData.get(YEAR) != maiorData.get(YEAR ) ) {
            diferencaTemporaria = 365 * (maiorData.get(YEAR) - menorData.get(YEAR));
            diferencaEmDias += diferencaTemporaria;
            menorData.add(DAY_OF_YEAR, diferencaTemporaria);
        }

        if ( menorData.get(DAY_OF_YEAR) != maiorData.get(DAY_OF_YEAR) ) {
            diferencaTemporaria = maiorData.get(DAY_OF_YEAR)- menorData.get(DAY_OF_YEAR);
            diferencaEmDias += diferencaTemporaria;
            menorData.add(DAY_OF_YEAR, diferencaTemporaria);
        }

        return diferencaEmDias;
    }

    /**
     * Retorna a diferenca
     *
     * @param firstDate
     * @param secondDate
     * @return
     */
    public static long diferencaEmDias(
        final LocalDate firstDate,
        final LocalDate secondDate
    ) {

        return firstDate != null && secondDate != null ? DAYS.between(firstDate, secondDate) : 0L;
    }

    /**
     * Retorna a diferenca
     *
     * @param firstDate
     * @param secondDate
     * @return
     */
    public static long diferencaEmDias(
        final LocalDateTime firstDate,
        final LocalDateTime secondDate
    ) {

        return firstDate != null && secondDate != null ? DAYS.between(firstDate, secondDate) : 0L;
    }

    /**
     * Retorna quantidade de meses entre 2 datas.
     *
     * @param dataA
     * @param dataB
     * @return int Qtde de meses entre as datas.
     */
    public static long diferencaEmMeses( final Date dataA,
                                         final Date dataB ) {

        if ( !isValida(dataA) || !isValida(dataB) )
            return 0;

        return diferencaEmMeses(
            LocalDate.of( getAno(dataA), getMes(dataA), getDia(dataA) ),
            LocalDate.of( getAno(dataB), getMes(dataB), getDia(dataB) )
        );
    }

    public static long diferencaEmMeses( final LocalDate dataInicio,
                                         final LocalDate dataFim ) {

        if ( dataInicio == null || dataFim == null )
            return 0;

        return ChronoUnit.MONTHS.between( dataInicio, dataFim );
    }

    /**
     * Retorna quantidade de Segundos entre 2 datas.
     *
     * @param dataA
     * @param dataB
     * @return int Qtde de segundos entre as datas.
     */
    public static long diferencaEmSegundos( final Date dataA,
                                            final Date dataB ) {

        if ( !isValida(dataA) || !isValida(dataB) )
            return 0;

        return ChronoUnit.SECONDS.between( toLocalDateTime(dataA), toLocalDateTime(dataB) );
    }

    /**
     * Retorna quantidade de Segundos entre duas horas.
     *
     * <p>Autor: GPortes</p>
     *
     * @param horaA
     * @param horaB
     *
     * @return int Qtde de segundos entre as horas.
     */
    public static long diferencaEmSegundos(
        final LocalTime horaA,
        final LocalTime horaB
    ) {

        return horaA != null && horaB != null ? ChronoUnit.SECONDS.between( horaA, horaB ) : 0;
    }

    /**
     * Retorna a quantidade de minutos entre duas datas.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataA
     * @param dataB
     *
     * @return Qtde de minutos entre duas datas.
     */
    public static long diferencaEmMinutos(
            final Date dataA,
            final Date dataB
    ) {

        if ( !isValida( dataA ) || !isValida( dataB ) )
            return 0L;

        return diferencaEmMinutos( toLocalDateTime(dataA), toLocalDateTime(dataB));
    }

    /**
     * Retorna a quantidade de minutos entre duas datas.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dateValue1
     * @param dateValue2
     *
     * @return Qtde de minutos entre duas datas.
     */
    public static long diferencaEmMinutos(
        final LocalDateTime dateValue1,
        final LocalDateTime dateValue2
    ) {

        if ( dateValue1 == null || dateValue2 == null )
            return 0L;

        return Duration.between(dateValue1, dateValue2).toMinutes();
    }


    /**
     * Retorna a data informada com um dia a menos.
     *
     * @param dataBase Data base
     * @return {@link Date}
     */
    public static Date getDiaAnterior( final Date dataBase ) {

        return adicionarNDias(-1, dataBase);
    }


    /**
     * Retorna se uma data está entre duas datas.
     *
     * <p>Autor: Cleber</p>
     *
     * @param dataBase      Data a ser avaliada.
     * @param dataInicio    Data inicio.
     * @param dataFim       Data fim
     *
     * @return (true) se estiver entre intervalo de dados e (false) o contrário.
     */

    public static boolean ehBetween ( final Date dataBase,
                                      final Date dataInicio,
                                      final Date dataFim) {

        return ehMaiorIgual( dataBase, dataInicio ) && ehMenorIgual( dataBase, dataFim );
    }


    /**
     * Retorna se uma data é superior a outra.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataA
     * @param dataB
     *
     * @return (true) se positivo e (false) o contrario
     */
    public static boolean ehMaior( final Date dataA,
                                   final Date dataB ) {

        return isValida(dataA) && isValida(dataB) && dataA.after(dataB);
    }

    /**
     * Retorna se uma data é superior a outra.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataA
     * @param dataB
     *
     * @return (true) se positivo e (false) o contrario
     */
    public static boolean ehMaior(
        final LocalDateTime dataA,
        final LocalDateTime dataB
    ) {

        return dataA != null && dataB != null && dataA.isAfter( dataB );
    }

    /**
     * Retorna se uma data é superior a outra.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataA
     * @param dataB
     *
     * @return (true) se positivo e (false) o contrario
     */
    public static boolean ehMaior(
            final LocalDate dataA,
            final LocalDate dataB
    ) {

        return dataA != null && dataB != null && dataA.isAfter( dataB );
    }

    /**
     * Compara se uma data é maior ou igual a outra.
     *
     * <p>Autor: GPortes</p>
     *
     *
     * @param dataA Data avaliada.
     * @param dataB Data a ser comparada.
     *
     * @return (true) se maior ou (false) o contrario.
     */
    public static boolean ehMaiorIgual(
        final Date dataA,
        final Date dataB
    ) {

        return isValida(dataA) && isValida(dataB) && ( dataA.after( dataB ) || dataA.compareTo( dataB ) == 0 );
    }

    /**
     * Compara se uma data é maior ou igual a outra.
     *
     * <p>Autor: GPortes</p>
     *
     *
     * @param dataA Data avaliada.
     * @param dataB Data a ser comparada.
     *
     * @return (true) se maior ou (false) o contrario.
     */
    public static boolean ehMaiorIgual(
        final LocalDate dataA,
        final LocalDate dataB
    ) {

        return isValida(dataA) && isValida(dataB) && ( dataA.isAfter(dataB) || dataA.isEqual( dataB ) );
    }

    public static boolean ehMaiorIgual(
            final LocalDateTime dataA,
            final LocalDate dataB
    ) {

        return isValida(dataA) && isValida(dataB) && ( dataA.toLocalDate().isAfter(dataB) || dataA.toLocalDate().isEqual( dataB ) );
    }


    /**
     * Retorna se uma data é inferior a outra.
     *
     * <p>Autor: GPortes</p>
     *
     * <pre>{@code
     *
     *      // Exemplo:
     *      Date dateA = UtilDate.getData( 1,1,2014 );       // 01/01/2014
     *      Date dateB = UtilDate.getData( 2,1,2014 );       // 02/01/2014
     *      boolean res = UtilDate.ehMenor( dateA, dateB );  // true
     *
     *      dateA = UtilDate.getData( 2,1,2014 );            // 02/01/2014
     *      res = UtilDate.ehMenor( dateA, dateB );          // false
     *
     *      dateA = UtilDate.getData( 3,1,2014 );            // 03/01/2014
     *      res = UtilDate.ehMenor( dateA, dateB );          // false
     *
     * }</pre>
     *
     * @param dataA Data avaliada.
     * @param dataB Data a ser comparada.
     *
     * @return (true) se é menor e (false) o contrário.
     *
     */
    public static boolean ehMenor( final Date dataA,
                                   final Date dataB ) {

        return isValida(dataA) && isValida(dataB) && dataA.before( dataB );
    }

    public static boolean ehMenor( final LocalDate dataA,
                                   final LocalDate dataB ) {

        return dataA != null && dataB != null && dataA.isBefore( dataB );
    }

    /**
     * Alysson Myller
     * 03/05/2018
     *
     * @param dataA
     * @param dataB
     * @return
     */
    public static boolean ehMenor(LocalDateTime dataA, LocalDateTime dataB) {
        return dataA != null && dataB != null && dataA.isBefore(dataB);
    }

    /**
     * Retorna se uma data é inferior a outra.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataA Data avaliada.
     * @param dataB Data a ser comparada.
     *
     * @return (true) se é menor ou igual e (false) o contrário.
     */
    public static boolean ehMenorIgual( final Date dataA,
                                        final Date dataB ) {

        return  isValida(dataA) && isValida(dataB) && ( dataA.before( dataB ) || ehIgual( dataA, dataB ) );
    }

    /**
     * Retorna se duas datas são iguais.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataA Data a ser avaliada.
     * @param dataB Data a ser avaliada.
     *
     * @return (true) se são iguais e (false) o contrário. Se as duas datas são <b>nulas</b> retorna (true)
     */
    public static boolean ehIgual( final Date dataA,
                                   final Date dataB) {

        if ( !isValida( dataA ) && !isValida( dataB ) )
            return true;

        return isValida(dataA) && isValida(dataB) && dataA.compareTo(dataB) == 0;
    }

    /**
     * Retorna se duas datas são iguais.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataA Data a ser avaliada.
     * @param dataB Data a ser avaliada.
     *
     * @return (true) se são iguais e (false) o contrário. Se as duas datas são <b>nulas</b> retorna (true)
     */
    public static boolean ehIgual(
        final LocalDateTime dataA,
        final LocalDateTime dataB
    ) {
        if ( !isValida( dataA ) && !isValida( dataB ) )
            return true;

        return isValida( dataA ) && isValida( dataB ) && dataA.compareTo(dataB) == 0;
    }

    /**
     * Retorna se duas datas são diferentes.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataA Data a ser avaliada.
     * @param dataB Data a ser avaliada.
     *
     * @return (true) se são diferentes e (false) o contrário. Se as duas datas são <b>nulas</b> retorna (false)
     */
    public static boolean ehDiferente( final Date dataA,
                                       final Date dataB ) {

        return !ehIgual( dataA, dataB );
    }

    /**
     * Retorna se duas datas são diferentes.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataA Data a ser avaliada.
     * @param dataB Data a ser avaliada.
     *
     * @return (true) se são diferentes e (false) o contrário. Se as duas datas são <b>nulas</b> retorna (false)
     */
    public static boolean ehDiferente(
            final LocalDateTime dataA,
            final LocalDateTime dataB ) {

        return !ehIgual( dataA, dataB );
    }


    /**
     * Retorna se duas datas pertencem ao mesmo período de mês e ano.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataA Data a ser avaliada.
     * @param dataB Data a ser avaliada.
     *
     * @return (true) se são estão no mesmo período e (false) o contrário.
     */
    public static boolean mesmoMesAno( final Date dataA,
                                       final Date dataB ) {

        return isValida( dataA )
                && isValida( dataB )
                && getMes( dataA ) == getMes( dataB )
                && getAno( dataA ) == getAno( dataB );
    }


    /**
     * <p>Autor: Gportes</p>
     *
     * @see UtilDate#mesmoMesAno(Date, Date)
     */
    public static boolean mesmoMesAno( final Date dataA,
                                       final Optional<Date> optDataB ) {

        return mesmoMesAno( dataA, optDataB.orElse( null ) );
    }


    /**
     * API - Calculo do intervalo de várias datas.
     */
    public interface IntervaloDeDatas {

        Date getDataInicial();
        Date getDataFinal();
        Long getIntervalo();
    }

    /**
     * Retorna objeto que implementa a interface IntervaloDeDatas
     *
     * @param dataInicial
     * @param dataFinal
     * @param intervalo
     *
     * @return
     */
    private static IntervaloDeDatas getIntervaloDeDatas( final Date dataInicial,
                                                         final Date dataFinal,
                                                         final Long intervalo ) {

        return new IntervaloDeDatas() {
            @Override
            public Date getDataInicial() {
                return dataInicial;
            }

            @Override
            public Date getDataFinal() {
                return dataFinal;
            }

            @Override
            public Long getIntervalo() {
                return intervalo;
            }
        };
    }


    /**
     * Retorna o intervalo de datas mais recente que seja superior ou igual a N meses.
     *
     * <p>Autor: GPortes</p>
     *
     * @param datas             Lista de datas.
     * @param nroMesesAAvaliar  A partir de N meses.
     *
     * @return Maior intervalo
     *
     */
    public static Optional<IntervaloDeDatas> maiorIntervaloMaisRecente( List<Date> datas,
                                                                        final int nroMesesAAvaliar ) {


        if ( isVazia( datas ) || datas.size() <= 1 || nroMesesAAvaliar <= 0 )
            return empty();

        sort( datas );

        long meses;
        int tamanhoLista = datas.size();
        long intervalo = 0;
        Date dataInicial = null;
        Date dataFinal = null;

        for ( int i=0; i < tamanhoLista; i++ ) {

            if ( i + 1  == tamanhoLista  )
                break;

            meses = diferencaEmMeses( datas.get(i), datas.get(i + 1) );

            if ( meses >= nroMesesAAvaliar ) {
                dataInicial = datas.get(i);
                dataFinal = datas.get(i+1);
                intervalo = meses;
            }

        }

        if ( dataInicial == null )
            return empty();

        return of( getIntervaloDeDatas( dataInicial, dataFinal, intervalo ) );
    }


    /**
     * Retorna TRUE se a hora atual esta contida nos intervalos: 08:00 - 18:00 ( Segunda a Sexta ) e 08:00 - 12:00 ( Sábado )
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataBase Data base
     *
     * @return boolean
     */
    public static boolean ehHorarioAdministracao( final Date dataBase ) {

        Calendar cal = getCalendar( dataBase );

        switch ( cal.get(DAY_OF_WEEK) ) {

            case SUNDAY:
                return false;

            case SATURDAY:

                if ( cal.get(HOUR_OF_DAY) == 12 && cal.get(MINUTE) != 0 )
                    return false;

                return cal.get(HOUR_OF_DAY) >= 8 && cal.get(HOUR_OF_DAY) <= 12;
        }

        if ( cal.get(HOUR_OF_DAY) == 18 && cal.get(MINUTE) != 0 )
            return false;

        return cal.get(HOUR_OF_DAY) >= 8 && cal.get(HOUR_OF_DAY) <= 18;
    }


    /**
     * Retorna Dia Da semana
     *
     * <p>Autor: Cleber</p>
     *
     * @param dataBase Data base
     *
     * @return int (1=domingo 2=segunda 3=terça... ... ...Parece que seria bom criar constantes....
     */


    public static int diaDaSemana (final Date dataBase) {

        if (dataBase == null )  return 0;

        Calendar cal  = getCalendar(dataBase);

        return cal.get(Calendar.DAY_OF_WEEK);
    }

    /**
     * Retorna segundo argumento caso o primeiro não seja valido.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataA
     * @param dataB
     *
     * @return Data
     *
     */
    public static Date getOrElse( final Date dataA,
                                  final Date dataB ) {

        return isValida( dataA ) ? dataA : dataB;
    }

    /**
     * Retorna segundo argumento caso o primeiro não seja valido.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataA
     * @param dataB
     *
     * @return Data
     *
     */
    public static LocalDateTime getOrElse(
        final LocalDateTime dataA,
        final LocalDateTime dataB
    ) {

        return isValida(dataA) ? dataA : dataB;
    }

    /**
     * Ajusta hora de uma data.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataBase  Data base.
     * @param hora      Hora.
     * @param minuto    Minuto.
     * @param segundo   Segundo.
     *
     * @return Nova data.
     *
     */
    public static Date setarHora( final Date dataBase,
                                  final int hora,
                                  final int minuto,
                                  final int segundo) {

        if ( isValida( dataBase ) ) {
            Calendar cal = getCalendar( dataBase );
            cal.set( AM_PM, 1 );
            cal.set( HOUR_OF_DAY, hora );
            cal.set( MINUTE, minuto );
            cal.set( SECOND, segundo );
            cal.set( MILLISECOND, 0 );
            return cal.getTime();
        }

        return dataBase;
    }

    /**
     * Ajusta hora de uma data.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataBase  Data base.
     * @param hora      Hora.
     * @param minuto    Minuto.
     *
     * @return Nova data.
     *
     */
    public static Date setarHora( final Date dataBase,
                                  final int hora,
                                  final int minuto ) {

       return setarHora( dataBase, hora, minuto, 0 );
    }

    /**
     * Ajusta hora de uma data.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataBase      Data Base
     * @param horaMinuto    Hora no formato HH:MM
     *
     * @return  Nova data com a hora informada.
     *
     * <pre>{@code
     *
     *      // Exemplo: Fixando a hora para 23:00
     *      Date hoje = new Date( System.currentTimeMillis() );
     *      hoje = UtilDate.setarHora( hoje, "23:00");
     *
     *      // Exemplo: Fixando a hora para 06:10
     *      Date hoje = new Date( System.currentTimeMillis() );
     *      hoje = UtilDate.setarHora( hoje, "06:10");
     *
     * }</pre>
     *
     */
    public static Date setarHora( final Date dataBase,
                                  final String horaMinuto ) {

        if ( !isValida( dataBase ) )
            throw new IllegalArgumentException( "dataBase não é válida" );

        if ( !ehHoraValida( horaMinuto ) )
            throw new IllegalArgumentException(format("horaMinuto %s não é válido",horaMinuto ));

        return setarHora( dataBase,
                          Integer.valueOf( horaMinuto.substring( 0, 2 ) ),
                          Integer.valueOf( horaMinuto.substring( 3, 5 ) ) );
    }

    /**
     * Retorna data sem horas.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataBase Data a ser alterada.
     *
     * @return Nova data sem horas.
     */
    public static Date zerarHoras( final Date dataBase ) {

        return setarHora( dataBase, 0, 0 , 0 );
    }

    /**
     * Retorna data na zero hora.
     *
     * @param dataBase  Data a ser alterada.
     *
     * @return Retorna data/hora
     */
    public static LocalDateTime zerarHoras( final LocalDateTime dataBase ) {

        return dataBase != null ?
            LocalDateTime.of( dataBase.getYear(), dataBase.getMonth(), dataBase.getDayOfMonth(), 0 , 0 ):
            dataBase;
    }

    /**
     * Seta a hora da data para 23:59:00
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataBase Data a ser alterada.
     *
     * @return Data com a hora 23:59:00
     *
     */
    public static Date setarHora_23_59_00( final Date dataBase ) {

        return setarHora( dataBase, 23, 59, 0 );
    }


    /**
     * Seta a hora da data para 23:59:00
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataBase Data a ser alterada.
     *
     * @return Data com a hora 23:59:59
     *
     */
    public static Date setarHora_23_59_59( final Date dataBase ) {

        return setarHora( dataBase, 23, 59, 59 );
    }

    /**
     * Busca hora atual da servidor java corrente.
     *
     * <p>Autor: GPortes</p>
     *
     * @return
     */
    public static Date getAgora() {

        return new Date( System.currentTimeMillis() );
    }

    /**
     *
     * @param dataCalculo
     * @param diaSemana
     * @return
     */
    public static Date getProximaData( final Date dataCalculo,
                                       final int diaSemana ) {

        if (!isValida(dataCalculo))
            throw new IllegalArgumentException( "data de calculo não é válida" );

        Date dataCalculada = adicionarNDias(0,dataCalculo);

        do {
            if (getDiaSemana(dataCalculada) == diaSemana) break;
            dataCalculada = adicionarNDias(1,dataCalculada);
        } while ( true );

        return dataCalculada;
    }

    /**
     * Retorna a data de um DateBinder.
     *
     * @param   value
     *          Data a ser lida
     *
     * @return  Data contida dentro do DateBinder.
     */
    public static Date getValue( final DateBinder value ) {

        if ( value == null )
            return null;

        return value.getValue();
    }

    /**
     * Retorna uma data a partir de um valor em milisegundos.
     *
     * <p>Autor: GPortes</p>
     *
     * @param milliseconds  Valor em milisegundos.
     * @param formatoData   Formato de data.
     *
     * @return  Data
     */
    public static Date getValue( final Long milliseconds,
                                 final FormatoData formatoData ) {

        if ( milliseconds == null )
            throw new IllegalArgumentException( "Faltou definir argumento [ milliseconds ]" );

        if ( formatoData == null )
            throw new IllegalArgumentException( "Faltou definir argumento [ formatoData ]" );

        try {
            DateFormat format = new SimpleDateFormat( formatoData.getValor() );
            return format.parse( format.format( milliseconds ) );
        } catch ( ParseException e ) {
            throw new IllegalArgumentException( "Formato inválido de data !" );
        }
    }

    /**
     * Retorna o primeiro dia da semana.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataBase  Data base
     *
     * @return Primeiro dia da semana.
     */
    public static LocalDate getPrimeiroDiaSemana( final LocalDate dataBase ) {

        return dataBase != null ?
            dataBase.minusDays( dataBase.getDayOfWeek().getValue() - DayOfWeek.MONDAY.getValue() ) : dataBase;
    }

    /**
     * Retorna o domingo da semana.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataBase Data base
     *
     * @return Domingo.
     */
    public static LocalDate getDomingo( final LocalDate dataBase ) {

        return dataBase != null ?
            dataBase.minusDays( dataBase.getDayOfWeek().getValue() - DayOfWeek.SUNDAY.getValue() ) : dataBase;
    }

    /**
     * Retorna o sábado da semana.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataBase Data base
     *
     * @return Sábado.
     */
    public static LocalDate getSabado( final LocalDate dataBase ) {

        return dataBase != null ?
            dataBase.minusDays( dataBase.getDayOfWeek().getValue() - DayOfWeek.SATURDAY.getValue() ) : dataBase;
    }

    /**
     * Retorna o sábado da semana anterior.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataBase Data base
     *
     * @return Sábado
     */
    public static LocalDate getSabadoSemanaAnterior( final LocalDate dataBase ) {

        return dataBase != null ? getSabado( dataBase.minusDays(7) ) : null ;
    }


    /**
     * Retorna o ultimo dia da semana.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataBase  Data base
     *
     * @return Ultimo dia da semana.
     */
    public static LocalDate getUltimoDiaSemana( final LocalDate dataBase ) {

        return dataBase != null ?
            dataBase.plusDays( DayOfWeek.SUNDAY.getValue() - dataBase.getDayOfWeek().getValue() ) : dataBase;
    }

    /**
     * Convert java.time.LocalDateTime para java.util.Date.
     *
     * <p>Autor: GPortes</p>
     *
     * @param localDateTime Data a ser convertida.
     *
     * @return Data
     */
    public static Date toDate( final LocalDateTime localDateTime ) {

        return localDateTime != null ?
                Date.from( localDateTime.atZone( ZoneId.systemDefault() ).toInstant() ) :
                null;
    }

    /**
     * Convert java.time.LocalDate para java.util.Date.
     *
     * <p>Autor: Fernando Vicente </p>
     *
     * @param localDate Data a ser convertida.
     *
     * @return Data
     */
    public static Date toDate( final LocalDate localDate ) {

        return localDate != null ? Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant()): null;
    }

    /**
     * Converte LocalDateTime para LocalDate.
     *
     * <p>Autor: GPortes</p>
     *
     * @param localDateTime Data/Hora
     *
     * @return Data
     */
    public static LocalDate toLocalDate( final LocalDateTime localDateTime ) {

        return localDateTime != null ? localDateTime.toLocalDate() : null;
    }

    /**
     * Convert String em LocalTime.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value     Valor a ser convertido em hora.
     * @param formato   Fomato da hora
     * @return
     */
    public static LocalTime toLocalTime(
        final String value,
        final String formato
    ) {

        if ( isVazia(value) ) return null;

        if ( isVazia(formato) )
            return LocalTime.parse(value);

        return LocalTime.parse(value, ofPattern( formato ) );
    }

    /**
     * Convert Date para LocalTime.
     *
     * <p>Autor: GPortes</p>
     *
     * @param date Data a ser convertida
     *
     * @return LocalDate
     */
    public static LocalTime toLocalTime( final Date date ) {

        return date != null
            ? date.toInstant().atZone( ZoneId.systemDefault() ).toLocalTime()
            : null;

    }

    /**
     * Convert Date para LocalDate.
     *
     * <p>Autor: GPortes</p>
     *
     * @param date Data a ser convertida
     *
     * @return LocalDate
     */
    public static LocalDate toLocalDate( final Date date ) {

        return date != null ? new java.sql.Date( date.getTime() ).toLocalDate() : null;
    }

    /**
     * Convert String em LocalDate.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value     Data a ser convertida.
     * @param formato   Formato da string
     *
     * @return LocalDate
     */
    public static LocalDate toLocalDate(
        final String value,
        final String formato
    ) {

        if ( isVazia(value) ) return null;

        if ( isVazia(formato) )
            return LocalDate.parse(value);

        return LocalDate.parse(value, ofPattern( formato ) );
    }

    /**
     * Convert java.time.LocalDate para java.sql.Timestamp.
     *
     * <p>Autor: GPortes</p>
     *
     * @param localDate Data a ser convertida.
     *
     * @return Data/Hora
     */
    public static Timestamp toTimestamp( final LocalDate localDate ) {

        return localDate != null ?
                Timestamp.valueOf( LocalDateTime.of( localDate.getYear(), localDate.getMonth(), localDate.getDayOfMonth(), 0 ,0 ) ) :
                null;
    }

    /**
     * Convert java.time.LocalDate para java.sql.Timestamp.
     *
     * <p>Autor: GPortes</p>
     *
     * @param localDate Data a ser convertida.
     * @param horas     Horas
     * @param minutos   Minutos
     * @param segundos  Segundos.
     *
     * @return Data/Hora
     */
    public static Timestamp toTimestamp(
        final LocalDate localDate,
        int horas,
        int minutos,
        int segundos
    ) {

        return Timestamp.valueOf( toLocalDateTime( localDate, horas, minutos, segundos ) );
    }

    /**
     * Convert java.time.LocalDate para java.sql.Timestamp.
     *
     * <p>Autor: GPortes</p>
     *
     * @param localDate Data a ser convertida.
     * @param horas     Horas
     * @param minutos   Minutos
     *
     * @return Data/Hora
     */
    public static Timestamp toTimestamp(
        final LocalDate localDate,
        int horas,
        int minutos
    ) {

        return toTimestamp( localDate, horas, minutos, 0 );
    }

    /**
     * Convert "LocalDateTime" para "java.time.LocalDate para java.sql.Timestamp."
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataHora Data/hora a ser convertida.
     *
     * @return Timestamp
     */
    public static Timestamp toTimestamp( final LocalDateTime dataHora ) {

        return dataHora != null ? Timestamp.valueOf( dataHora ) : null;
    }

    /**
     * Converte data para tipo apropriado a ser usada pelo jdbc.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataBase  Data a ser convertida.
     *
     * @return Data convertida.
     */
    public static java.sql.Date toDateSql( final LocalDateTime dataBase ) {

        return dataBase != null ?
                new java.sql.Date( dataBase.atZone( ZoneId.systemDefault() ).toInstant().toEpochMilli() ) :
                null;
    }

    /**
     * Convert Date para LocalDateTime
     *
     * @param date Data a ser convertida
     *
     * @return LocalDateTime
     */
    public static LocalDateTime toLocalDateTime( final Date date ) {

        return date != null ?
                date.toInstant().atZone( ZoneId.systemDefault() ).toLocalDateTime() : null;
    }

    /**
     * Converte LocalDate para LocalDateTime.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataBase  Data a ser convertida.
     *
     * @return  Data convertida.
     */
    public static LocalDateTime toLocalDateTime( final LocalDate dataBase ) {

        return toLocalDateTime( dataBase, 0, 0, 0, 0 );
    }

    /**
     * Converte LocalDate para LocalDateTime.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataBase      Data a ser convertida.
     * @param hora          Hora
     * @param minuto        Minuto
     * @param segundos      Segundos
     * @param milesimos     Milésimos
     *
     * @return  Data convertida.
     */
    public static LocalDateTime toLocalDateTime(
        final LocalDate dataBase,
        int hora,
        int minuto,
        int segundos,
        int milesimos
    ) {

        return dataBase != null
            ? dataBase.atTime(hora,minuto,segundos,milesimos) :
            null;
    }

    /**
     * Converte LocalDate para LocalDateTime.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataBase      Data a ser convertida.
     * @param hora          Hora
     * @param minuto        Minuto
     * @param segundos      Segundos
     *
     * @return  Data convertida.
     */
    public static LocalDateTime toLocalDateTime(
        final LocalDate dataBase,
        int hora,
        int minuto,
        int segundos ) {

        return toLocalDateTime( dataBase, hora, minuto, segundos, 0 );
    }

    /**
     * Converte Timestamp (sql) para LocalDateTime.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataSql   Timestamp a ser convertido.
     *
     * @return  LocalDateTime
     */
    public static LocalDateTime toLocalDateTime( final Timestamp dataSql  ) {

        return dataSql == null ? null : dataSql.toLocalDateTime();
    }

    /**
     * Converte String para LocalDatetime
     *
     * <p>Autor: GPortes</p>
     *
     * @param value     String a ser convertida.
     * @param formato   Formato da String.
     *
     * @return LocalDatetime.
     */
    public static LocalDateTime toLocalDateTime(
        final String value,
        final String formato
    ) {

        try {
            if ( isVazia(value) ) return null;
            if ( isVazia(formato) ) return LocalDateTime.parse( value );
            return LocalDateTime.parse(value, ofPattern( formato ) );
        } catch ( DateTimeParseException e ) {
            return null;
        }
    }

    /**
     * Retorna se data é uma segunda feira.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataBase Data a ser avaliada.
     *
     * @return
     */
    public static boolean isSegundaFeira( final LocalDate dataBase ) {

        return dataBase != null && Objects.equals( dataBase.getDayOfWeek(), DayOfWeek.MONDAY );
    }

    /**
     * Retorna se data é um domingo.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataBase Data a ser avaliada.
     *
     * @return
     */
    public static boolean isDomingo( final LocalDate dataBase ) {

        return dataBase != null && Objects.equals( dataBase.getDayOfWeek(), DayOfWeek.SUNDAY );
    }

    /**
     * Retorna se data é um domingo.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataBase Data a ser avalida.
     *
     * @return
     */
    public static boolean isDomingo( final LocalDateTime dataBase ) {

        return dataBase != null && Objects.equals( dataBase.getDayOfWeek(), DayOfWeek.SUNDAY );
    }

    /**
     * Retorna se data é um sábado.
     *
     * <p>Autor: Jander Dutra</p>
     *
     * @param dataBase Data a ser avaliada.
     *
     * @return
     */
    public static boolean isSabado( final LocalDate dataBase ) {

        return dataBase != null && Objects.equals( dataBase.getDayOfWeek(), DayOfWeek.SATURDAY );
    }

}
