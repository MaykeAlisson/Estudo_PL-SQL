package infra.util;

import infra.exceptions.InfraException;

import javax.swing.text.MaskFormatter;
import java.sql.Blob;
import java.sql.SQLException;
import java.text.Normalizer;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.Objects;
import java.util.StringJoiner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static infra.util.UtilBlob.isVazio;
import static java.lang.String.format;
import static java.nio.charset.StandardCharsets.ISO_8859_1;
import static java.util.Collections.emptyList;
import static java.util.Objects.requireNonNull;

/**
 * Classe com métodos utilitários ref. ao tratamento de cadeias de caracteres.
 *
 * <p>Autor: GPortes</p>
 *
 * @since  02/09/2014.
 *
 */
public final class UtilString {

    /**
     * Verifica se objeto não é {@code null} ou {@code empty}. Este método é projetado principalmente
     * para fazer a validação de parâmetros em métodos e construtores, como demonstrado abaixo:
     *
     * <blockquote><pre>
     * public Foo(String bar) {
     *     this.bar = UtilString.requireNonEmpty(bar);
     * }
     * </pre></blockquote>
     *
     * @param obj       the object reference to check for nullity
     * @param message   the type of the reference
     *
     * @return {@code obj} if not {@code null}
     *
     * @see java.util.Objects#requireNonNull(Object, String)
     *
     * @throws NullPointerException if {@code obj} is {@code null}
     * @throws IllegalArgumentException if {@code obj} is {@code empty}
     *
     * <p>Autor: GPortes</p>
     */
    public static String requireNonEmpty(
        final String obj,
        final String message
    ) {
        if ( isVazia( message ) ) {
            requireNonNull( obj );
            if ( obj.trim().length() == 0 )
                throw new IllegalArgumentException( "String vazia não permitido!!" );
            return obj;
        }

        requireNonNull( obj, message );
        if ( obj.trim().length() == 0 )
            throw new IllegalArgumentException( message );
        return obj;
    }

    /**
     * Verifica se a String está null ou vazia.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value String a ser validada
     *
     * @return boolean
     */
    public static boolean isVazia( final String value ) {

        return value == null || value.trim().length() == 0;
    }

    /**
     * Verifica se conteúdo de um StringBuilder esta vazio ou nulo.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value StringBuilder a ser verificado.
     *
     * @return (true) se esta vazio/nulo e (false) o contrário.
     */
    public static boolean isVazia ( final StringBuilder value ) {

        return value == null || value.length() == 0 || value.toString().trim().length() == 0;
    }

    /**
     * Verifica se conteúdo de uma StringJoiner esta vazio ou nulo.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value StringJoiner a ser verificado.
     *
     * @return (true) se esta vazio/nulo e (false) o contrário.
     */
    public static boolean isVazia( final StringJoiner value ) {

        return value == null || isVazia( value.toString() );
    }

    /**
     * Se {@code String} vazia ( nula ou espacos ) retorna valor a direira.
     *
     * <p>Autor: GPortes</p>
     *
     * <pre>{@code
     *
     *     // Exemplo:
     *
     *     String val1 = "";
     *
     *     UtilString.isEmptyGet( va1, "ABC" );      // "ABC"
     *     UtilString.isEmptyGet( "cde", "ABC" );    // "cde"
     *
     *
     * }</pre>
     *
     * @param valueA    Valor a ser avaliado.
     * @param valueB    Valor retornado, caso {@code valueA} estiver vazio.
     *
     * @return String
     */
    public static String isEmptyGet(
        final String valueA,
        final String valueB
    ) {

        return isVazia( valueA ) ? valueB : valueA;
    }

    /**
     * Verifica se String contem apenas numeros.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value String a ser validada
     *
     * @return boolean
     */
    public static boolean apenasNumero( final String value ) {

        return !isVazia( value ) && value.matches("^[0-9]*$");
    }

    /**
     * Converte Blob em String - Enconding: ISO-8859-1
     *
     * <p>Autor: Gportes</p>
     *
     * @param value Valor a ser convertido
     *
     * @return {@link String}
     */
    public static String converterString( final Blob value ) {

        if ( isVazio(value) )
            return "";

        try {
            return new String( value.getBytes(1, (int) value.length()), ISO_8859_1  ).trim();
        } catch ( final SQLException  e) {
            throw new InfraException( format( "[ UtilString.converterString ] %s", e.getMessage() ) );
        }
    }

    /**
     * Indica posição de preenchimento de uma string.
     *
     */
    public enum Posicao { DIREITA, ESQUERDA }

    /**
     * Retorna string acrescida de um caracter, ate que o valor tenha o tamanho informado.
     *
     * <p>Autor: GPortes</p>
     *
     * <pre></pre>
     *
     * @param valorAPreencher   String a preencher.
     * @param tamanho           Qtde de caracteres.
     * @param caracter          Caracter a ser preenchido no espaço.
     * @param posicao           Preencher a direita ou esquerda.
     *
     * @return String preenchida.
     */
    public static String preencherCom( final String valorAPreencher,
                                       final String caracter,
                                       final int tamanho,
                                       final Posicao posicao ) {

        if (tamanho <= 0) {
            throw  new IllegalArgumentException("Tamanho a ser preenchido deve ser maior que zero");
        }

        if (posicao == null) {
            throw  new IllegalArgumentException("Argumento POSICAO eh obrigatorio");
        }

        if ( caracter == null ) {
            throw  new IllegalArgumentException("Caracter a ser preenchido deve ser informado");
        }

        String valor = getOrElse(valorAPreencher,"");
        if (valor.length() > tamanho)  return valor.substring(0,tamanho);

        Boolean negativo = valor.length() > 0 && valor.substring(0,1).equals("-");

        if (negativo) {
            valor = valor.substring(1);
        }

        int restante = tamanho - valor.length();
        
        StringBuilder temp = new StringBuilder();
        while ( temp.length() < restante )
            temp.append( caracter );

        if (negativo) {
            temp.replace(0,1,"-");
        }

        if ( Posicao.ESQUERDA.equals( posicao ) ) {
            temp.append( valor );
            return temp.toString();
        }

        valor = valor + temp.toString();

        return valor;
    }

    public static String preencherNumeroCom(
        final String valorAPreencher,
        final String caracter,
        final int tamanho,
        final Posicao posicao
    ) {

        if (tamanho <= 0) {
            throw  new IllegalArgumentException("Tamanho a ser preenchido deve ser maior que zero");
        }

        if (posicao == null) {
            throw  new IllegalArgumentException("Argumento POSICAO eh obrigatorio");
        }

        if ( caracter == null ) {
            throw  new IllegalArgumentException("Caracter a ser preenchido deve ser informado");
        }

        String valor = getOrElse(valorAPreencher,"");

        int restante = tamanho - valor.length();

        StringBuilder temp = new StringBuilder();
        while ( temp.length() < restante )
            temp.append( caracter );

        if ( Posicao.ESQUERDA.equals( posicao ) ) {
            temp.append( valor );
            return temp.toString();
        }

        valor = valor + temp.toString();

        return valor;
    }

    /**
     * Preenche string com espaços a direita.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valorAPreencher
     * @param tamanho
     *
     * @return
     */
    public static String preencherComEspacosADireita( final String valorAPreencher,
                                                      final int tamanho ) {


        return preencherCom( valorAPreencher, " ", tamanho, Posicao.DIREITA );
    }

    /**
     * Preenche string com espaços a direita.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valorAPreencher
     * @param tamanho
     *
     * @return
     */
    public static String preencherComEspacosAEsquerda( final String valorAPreencher,
                                                      final int tamanho ) {


        return preencherCom( valorAPreencher, " ", tamanho, Posicao.ESQUERDA );
    }

    /**
     * Preenche string com espaços a direita.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valorAPreencher
     * @param tamanho
     *
     * @return
     */
    public static String preencherNumeroComEspacosADireita( final String valorAPreencher,
                                                      final int tamanho ) {

        return preencherNumeroCom( valorAPreencher, " ", tamanho, Posicao.DIREITA );
    }

    /**
     * Preenche string com espaços a esquerda.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valorAPreencher
     * @param tamanho
     *
     * @return
     */
    public static String preencherNumeroComEspacosAEsquerda( final String valorAPreencher,
                                                            final int tamanho ) {

        return preencherNumeroCom( valorAPreencher, " ", tamanho, Posicao.ESQUERDA );
    }

    /**
     * Preenche string com zeros a esquerda.
     *
     * <p>Autor: Cleber</p>
     *
     * @param valor String a ser convertida
     * @param qtdeZeros Qtde de zeros a esquerda
     *
     * @return {@link String}
     */
    public static String preencheZeroEsquerda( final String valor,
                                               final int qtdeZeros ) {

        return preencherCom( valor, "0", qtdeZeros, Posicao.ESQUERDA );
    }

    /**
     * Preenche string com zeros a esquerda.
     *
     * <p>Autor: Cleber</p>
     *
     * @param valor String a ser convertida
     * @param qtdeZeros Qtde de zeros a esquerda
     *
     * @return {@link String}
     */
    public static String preencheZeroDireita( final String valor,
                                               final int qtdeZeros ) {

        return preencherCom( valor, "0", qtdeZeros, Posicao.DIREITA );
    }

    /**
     * <p>Autor: Cleber</p>
     *
     * {@link UtilString#preencheZeroEsquerda(String, int)}
     */
    public static String preencheZeroEsquerda( final Short value,
                                               final int qtdeZeros ) {

        return preencheZeroEsquerda( String.valueOf( value ), qtdeZeros );
    }

    /**
     * <p>Autor: Cleber</p>
     *
     * {@link UtilString#preencheZeroEsquerda(String, int)}
     */
    public static String preencheZeroEsquerda( final Long value,
                                               final int qtdeZeros ) {

        return preencheZeroEsquerda( String.valueOf(value), qtdeZeros );
    }

    /**
     * <p>Autor: Cleber</p>
     *
     * {@link UtilString#preencheZeroEsquerda(Integer, int)}
     */
    public static String preencheZeroEsquerda( final Integer value,
                                               final int qtdeZeros ) {

        return preencheZeroEsquerda( String.valueOf(value), qtdeZeros );
    }

    /**
     * Converte String no formato CamelCase
     *
     * <p>Autor: Gportes</p>
     *
     * @param value                     String a ser convertida
     * @param primeiraLetraMaiuscula    Indica se a primeira letra deve ser convertida para Maiuscula
     *
     * @return {@link String}
     *
     * <pre>{@code
     *
     *     Exemplo:
     *
     *     converterCamelCase( "pedido_vendas",false );      // "pedidoVendas"
     *     converterCamelCase( "acertos",true );             // "Acertos"
     *     converterCamelCase( "pagto_antecipado",true );    // "PagtoAntecipado"
     *
     * }</pre>
     *
     */
    public static String converterCamelCase( final String value,
                                             final boolean primeiraLetraMaiuscula ) {

        if ( isVazia(value) )
            return value;

        if ( value.contains("_") ) {

            boolean upper = false;
            char[] old = value.toCharArray();
            StringBuilder novaString = new StringBuilder();

            for ( int i = 0; i < old.length; i++ ) {

                if ( upper ) {
                    novaString.append(String.valueOf(old[i]).toUpperCase());
                    upper = false;
                    continue;
                }

                if ( old[i] == '_' ) {
                    upper = true;
                } else {
                    novaString.append(  ( primeiraLetraMaiuscula && i == 0 ? String.valueOf(old[i]).toUpperCase() : String.valueOf(old[i]) ) ) ;
                }

            }

            return novaString.toString();

        }

        if ( primeiraLetraMaiuscula )
            return value.substring(0,1).toUpperCase().concat(value.substring(1));

        return value;
    }

    /**
     * Converte String no formato CamelCase.
     *
     * <p>Autor: Gportes</p>
     *
     * @param value String a ser convertida
     *
     * @return {@link String}
     *
     * <pre>{@code
     *
     *     // Exemplo:
     *
     *     converterCamelCase( "pedido_vendas" );       // "pedidoVendas"
     *     converterCamelCase( "acertos" );             // "acertos"
     *     converterCamelCase( "pagto_antecipado" );    // "pagtoAntecipado"
     *
     * }</pre>
     *
     */
    public static String converterCamelCase( String value ) {

        return converterCamelCase(value, false);
    }

    /**
     * Retorna se strings são iguais.
     *
     * <p>Autor: GPortes</p>
     *
     * <pre>{@code
     *
     *     // Exemplo:
     *
     *     ehIgual( "123", "456" );        // false
     *     ehIgual( "123", null );         // false
     *     ehIgual( null, "456" );         // false
     *     ehIgual( null, null );          // true
     *     ehIgual( "123", " 123   " );    // true
     *
     *
     * }</pre>
     *
     * @param value1 String a ser avaliada.
     * @param value2 String a ser avaliada.
     *
     * @return boolean - true: são iguais e false: o contrário.
     */
    public static boolean ehIgual( final String value1,
                                   final String value2 ) {

        return ( isVazia( value1 ) && isVazia( value2 ) )
                || ! ( value1 == null || value2 == null )
                && ( value1.trim().equals( value2.trim() ) );
    }

    /**
     * Retorna se strings são iguais.
     *
     * <p>Autor: GPortes</p>
     *
     * <pre>{@code
     *
     *     UtilString.ehIgual( "abc", "ABC", true );        // false
     *     UtilString.ehIgual( "abc", "ABC", false );       // true
     *
     * }</pre>
     *
     * @param value1    String a ser avaliada.
     * @param value2    String a ser avaliada.
     * @param flag      Considerar case-insensitive
     *
     * @return boolean - true: são iguais e false: o contrário.
     */
    public static boolean ehIgual( final String value1,
                                   final String value2,
                                   final boolean flag ) {

        if ( !flag && ( value1 != null && value2 != null ) )
            return value1.matches( "(?i:" + value2 + ")" );

        return ehIgual( value1, value2 );
    }

    /**
     * Remove acentos e caracteres especiais da string.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value String a ser convertida
     *
     * @return String convertida
     */
    public static String removerAcentosECaracteresEspeciais( String value ) {

        if ( isVazia(value) )
            return value;

        return Normalizer.normalize(value, Normalizer.Form.NFD).replaceAll("[^\\p{ASCII}]", "");
    }

    /**
     * Converte string em uma lsta
     *
     * <p>Autor: GPortes</p>
     *
     * @param values    String a ser convertida
     * @param token     Critério de separação.
     *
     * @return {@link List} Lista de Strings
     */
    public static List<String> asList( final String values,
                                       final String token ) {

        if ( isVazia(values) || isVazia(token) )
            return emptyList();

        return Arrays.asList( values.split( token ) );
    }

    /**
     * Retorna valor não nulo, caso algum dos argumentos não seja nulo.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value1
     * @param value2
     *
     * @return String
     */
    public static String getOrElse( final String value1,
                                    final String value2 ) {

        if ( value2 == null )
            throw new IllegalArgumentException("Segundo argumento na chamada de UtilString.getOrElse não pode ser nulo !!");

        return value1  == null ? value2 : value1;
    }

    /**
     * Verifque se uma string contem partes em outra string.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value     Valor a ser consultado.
     * @param values    Base de consulta.
     *
     * @return (true) positivo ou (false) o contrário.
     *
     * <pre>{@code
     *
     *      // Exemplo.
     *      String temp = "&$#%abc0912";
     *
     *      UtilString.contem( temp, "abc" );    // true
     *      UtilString.contem( temp, "xxx" );    // false
     *      UtilString.contem( temp, "$","12" ); // true
     *      UtilString.contem( temp, "092" );    // false
     *
     *
     * }</pre>
     */
    public static boolean contem(
        final String value,
        final String... values
    ) {

        return value != null
            && values != null
            && Arrays.stream( values ).anyMatch( v -> v != null && value.contains(v) );
    }

    /**
     * Retorna uma string a partir de um inicio de string.
     *
     * <p>Autor: GPortes</p>
     *
     * <pre>{@code
     *
     *     Exemplo:
     *
     *     getAPartirDe( "ABCD_EFG", "ABCD_" ); // "EFG"
     *     getAPartirDe( "01245678", "01" );    // "245678"
     *
     * }</pre>
     *
     * @param value1    String a ser avaliada.
     * @param value2    String a ser pesquisada.
     *
     * @return String.
     *
     */
    public static String getAPartirDe( String value1,
                                       String value2 ) {

        if ( isVazia(value1) || isVazia(value2) )
            return "";

        int index = value1.indexOf( value2 );

        if ( index > -1 )
            return value1.substring( index + value2.length()  );

        return null;
    }

    /**
     * Retorna se String é numerica.
     *
     * @param value
     *
     * @return (true) se String numerica e (false) o contrário.
     */
    public static boolean ehNumero( final String value ) {

        return Pattern.compile( "[0-9]+" ).matcher( value ).matches();
    }

    /**
     * Retorna se a string esta no formato HH:MM.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value String
     *
     * @return (true) se String valida e (false) o contrário.
     */
    public static boolean ehHoraValida( final String value ) {

        return  !isVazia( value ) && value.matches( "^([0-1]\\d|2[0-3]):([0-5]\\d)$" );
    }

    /**
     * Soma 2 Strings considerando se ambas são valores numéricos inteiros.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value1
     * @param value2
     *
     * @return
     */
    public static String somar( final String value1,
                                final String value2 ) {

        if ( ehNumero( value1 ) || ehNumero( value2 ) ) {
            try {
                return String.valueOf( Long.parseLong( value1 ) + Long.valueOf( value2 ) );
            } catch ( NumberFormatException e ) {
                throw new IllegalArgumentException( "Valore(s) muito grande(s) para serem convertidos para Long !" );
            }
        }

        throw new IllegalArgumentException( "Argumento(s) deve(m) ser do tipo inteiro !" );
    }

    /**
     * Soma String com valor numerico informado.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value1
     * @param value2
     *
     * @return String com valor somado.
     */
    public static String somar( final String value1,
                                final short value2 ) {

        if ( ehNumero( value1 ) )
            return String.valueOf( Long.parseLong( value1 ) + value2 );

        throw new IllegalArgumentException( "Argumento inválido - Deve ser numero" );
    }

    /**
     * Converte lista em String.
     *
     * <p>Autor: GPortes</p>
     *
     * @param lista     Lista a ser convertida.
     * @param separador Separador entre os elementos da lista.
     *
     * @return Representação em String da lista informada.
     *
     * <pre>{@code
     *
     *      // Exemplo:
     *
     *      List<Integer> list = new ArrayList<Integer>();
     *      list.add(10);
     *      list.add(20);
     *      list.add(30);
     *
     *      String saida = converterString( list, ";" );   //  10;20;30
     *
     * }</pre>
     *
     */
    public static <T> String converterString(
        final List<T> lista,
        final String separador
    ) {

        if ( UtilCollections.isVazia( lista ) )
            return "";

        StringBuilder temp = new StringBuilder(  );

        for ( T elem : lista )
            temp.append( elem ).append( separador );

        return temp.deleteCharAt( temp.length() - 1 ).toString();
    }

    /**
     * Retorna toString de um StringBuilder.
     *
     * <p>Autor: GPortes</p>
     *
     * @param builder
     *
     * @return String
     */
    public static String converterString( final StringBuilder builder ) {

        return builder != null ? builder.toString() : null;
    }

    /**
     * Retorna toString do objeto.
     *
     * <p>Autor: GPortes</p>
     *
     * @param object Objeto a ser lido.
     *
     * @return String
     */
    public static String converterString( final Object object ) {

        return Objects.isNull(object) ? null : object.toString();
    }

    /**
     * Extrai lista de Strings.
     *
     * <p>Autor: GPortes</p>
     *
     * @param elementos String
     *
     * @return Lista de String
     *
     * <pre>{@code
     *
     *      // Exemplo:
     *
     *      List<String> lista = UtilString.asListNumero( "12,45,67,89" );
     *
     *      // lista.get(0) -> 12
     *      // lista.get(1) -> 12
     *      // lista.get(2) -> 12
     *      // lista.get(3) -> 12
     *
     * }</pre>
     *
     */
    public static List<String> asListNumero( final String elementos ) {

        if ( isVazia( elementos ) )
            return emptyList();

        Matcher matcher = Pattern.compile( "[^0-9]" ).matcher( elementos );

        if ( matcher.find() ) {

            List<String> retorno = new ArrayList<String>();

            for ( String elemento : elementos.split( Character.toString( elementos.charAt( matcher.start() ) ) ) ) {
                elemento = elemento.trim();
                if ( apenasNumero( elemento ) )
                    retorno.add( elemento );
            }

            if ( retorno.isEmpty() )
                return  emptyList();

            return retorno;
        }

        if ( apenasNumero( elementos ) ) {
            List<String> retorno = new ArrayList<String>( 1 );
            retorno.add( elementos );
            return retorno;
        }

        return emptyList();
    }

    /**
     * Converte um caracter de uma String para minusculo.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value String a ser convertida.
     * @param pos   Posição do caracter na String.
     *
     * @return String.
     *
     * <pre>{@code
     *
     *      // Exemplo:
     *
     *      UtilString.toLowerCase( "ABCD", 0 );  // aBCD
     *      UtilString.toLowerCase( "ABCD", 1 );  // AbCD
     *      UtilString.toLowerCase( "ABCD", 2 );  // ABcD
     *
     * }</pre>
     *
     */
    public static String toLowerCase( final String value,
                                      final int pos ) {

        if ( isVazia( value ) )
            return "";

        final int length = value.length();

        if ( pos < 0 || pos > length )
            return value;

        StringBuilder builder = new StringBuilder( value.length() );

        for ( int i = 0 ; i < length; i++ )
            builder.append( ( i == pos ) ? value.substring( i, i + 1 ).toLowerCase() : value.substring( i, i + 1 ) );

        return builder.toString();
    }

    /**
     * Converte um caracter de uma String para maiusculo.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value String a ser convertida.
     * @param pos   Posição do caracter na String.
     *
     * @return String.
     *
     * <pre>{@code
     *
     *      // Exemplo:
     *
     *      UtilString.toLowerCase( "abcd", 0 );  // Abcd
     *      UtilString.toLowerCase( "abcd", 1 );  // aBcd
     *      UtilString.toLowerCase( "abcd", 2 );  // abCd
     *
     * }</pre>
     *
     */
    public static String toUpperCase( final String value,
                                      final int pos ) {

        if ( isVazia( value ) )
            return "";

        final int length = value.length();

        if ( pos < 0 || pos > length )
            return value;

        StringBuilder builder = new StringBuilder( value.length() );

        for ( int i = 0 ; i < length; i++ )
            builder.append( ( i == pos ) ? value.substring( i, i + 1 ).toUpperCase() : value.substring( i, i + 1 ) );

        return builder.toString();
    }

    /**
     * Converte string para maiusculo
     *
     * <p>Autor: GPortes</p>
     *
     * @param value String a ser convertida.
     *
     * @return String convertida para maiusculo
     */
    public static String toUpperCase( final String value ) {

        return value != null ? value.toUpperCase() : value;
    }


    /**
     * Duplica String n vezes.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value String a ser duplicada.
     * @param qtde  Qtde de vezes.
     *
     * @return String duplicada.
     *
     * <pre>{@code
     *
     *      // Exemplo:
     *
     *      UtilString.duplicar( "a", 2 );  // aa
     *      UtilString.duplicar( "ab", 5 ); // ababababab
     *
     * }</pre>
     */
    public static String duplicar( final String value,
                                   final int qtde ) {
        if ( qtde <= 1 )
            return value;

        return value + duplicar( value, ( qtde - 1 ) );
    }

    /**
     * Cria String com N zeros a sua direita.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value     Valor a ser convertido.
     * @param tamanho   Qtde de zeros a ser preenchido.
     *
     * @return String formatada.
     */
    public static String preencherZerosDireita(
        final Long value,
        final int tamanho
    ) {

        return preencherCom( String.valueOf( value ), "0", tamanho, Posicao.DIREITA  );
    }

    /**
     * Cria String com N zeros a sua direita.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value     Valor a ser convertido.
     * @param tamanho   Qtde de zeros a ser preenchido.
     *
     * @return String formatada.
     */
    public static String preencherZerosDireita(
        final Integer value,
        final int tamanho
    ) {

        return preencherCom( String.valueOf( value ), "0", tamanho, Posicao.DIREITA  );
    }

    /**
     * Quebra string em n partes.
     *
     * <p>Autor: GPortes</p>
     *
     * @param text  String a ser avaliada.
     * @param size  Tamanho.
     *
     * @return  Array com partes da string.
     */
    public static List<String> quebrarString(
        final String text,
        final int size
    ) {

        if ( isVazia( text ) || size <= 0 )
            return emptyList();

        List<String> parts = new ArrayList<>();
        int length = text.length();
        for (int i = 0; i < length; i += size) {
            parts.add(text.substring(i, Math.min(length, i + size)));
        }
        return parts;
    }

    /**
     * Formata string para uma mascara padrão de telefone.
     *
     * <p>Autor: GPortes</p>
     *
     * @param fone
     *
     * @return
     */
    public static String formatarFone( final String fone ) {

        if ( isVazia(fone) )
            return "";

        try {
            String mask = "";
            switch ( fone.length() ) {
                case 8:
                    mask = "####-####";
                    break;
                case 9:
                    mask = "#####-####";
                    break;
                case 10:
                    mask = "##-####-####";
                    break;
                case 11:
                    mask = "##-#####-####";
                    break;
                default:
                    return fone;
            }
            MaskFormatter maskFormatter = new MaskFormatter( mask );
            maskFormatter.setValueContainsLiteralCharacters( false );
            return maskFormatter.valueToString( fone );
        } catch ( ParseException e ) {
            return "????";
        }
    }

    /**
     * Concatena strings. Faz o tratamento p/ não exibir a string "null", qdo um dos argumentos é nulo!
     *
     * <p>Autor: GPortes</p>
     *
     * @param valueA    String A
     * @param valueB    String B
     *
     * @return Strings concatenadas.
     */
    public static String concat( final String valueA,
                                 final String valueB ) {

        return new StringJoiner("")
                .add( valueA == null ? "" : valueA )
                .add( valueB == null ? "" : valueB ).toString();
    }

    /**
     * Aplica trim na string.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value String a ser aplicada o trim
     *
     * @return Nova string.
     */
    public static String trim( final String value ) {

        return value != null ? value.trim() : value;
    }

    /**
     * Remove os ultimos caracteres de uma string.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value String a ser avaliada.
     * @param qtde  Qtde de caracteres a ser retirado.
     *
     * @return String.
     */
    public static String removerUltimosCaracteres( final String value,
                                                   final int qtde ) {

        return value != null
                && !value.isEmpty()
                && qtde > 0
                && value.length() > qtde ? value.substring(0, value.length() - qtde ) : value;
    }

    /**
     * Retorna a primeira palavra de uma string.
     *
     * <p>Autor: GPortes</p>
     *
     * @param text  Texto a ser processado.
     *
     * @return Primeira palavra do texto.
     *
     * <pre>{@code
     *
     *      // Exemplo:
     *
     *      UtilString.primeiraPalavra( "ANEL VIARIO AYRTON SENNA" );  // ANEL
     *      UtilString.primeiraPalavra( "ARCOM" );  // ARCOM
     *      UtilString.primeiraPalavra( null );  // null
     *      UtilString.primeiraPalavra( " Texto com espaço no inicio" );  // ""
     *
     * }</pre>
     */
    public static String primeiraPalavra( final String text ) {

        if ( text != null ) {
            int index = text.indexOf(' ');
            if ( index > -1 )
                return text.substring(0, index);
        }

        return text;
    }

    /**
     * Exclui a primeira palavra de uma string.
     *
     * <p>Autor: GPortes</p>
     *
     * @param text Texto a ser processado.
     *
     * @return String.
     *
     * <pre>{@code
     *
     *      // Exemplo:
     *
     *      UtilString.excluirPrimeiraPalavra( "ANEL VIARIO AYRTON SENNA" );  // VIARIO AYRTON SENNA
     *      UtilString.excluirPrimeiraPalavra( "ARCOM" );  // ARCOM
     *      UtilString.excluirPrimeiraPalavra( null );  // null
     *      UtilString.excluirPrimeiraPalavra( " Texto com espaço no inicio" );  // "Texto com espaço no inicio"
     *
     * }</pre>
     *
     */
    public static String excluirPrimeiraPalavra( final String text ) {

        if ( text != null ) {
            int index = text.indexOf(' ');
            if ( index > -1 )
                return text.substring(index);
        }

        return text;
    }

    /**
     * Verifica se string inicializa com valor.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valueA
     * @param valueB
     *
     * @return (true) se positivo e (false) o contrário.
     *
     * <pre>{@code
     *
     *      // Exemplo:
     *
     *      UtilString.inicializaCom( "TESTE MAIS","TES" ); // true
     *      UtilString.inicializaCom( "TESTE MAIS","ABC" ); // false
     * }</pre>
     *
     */
    public static boolean inicializaCom(
        final String valueA ,
        final String valueB
    ) {
        return ( valueA != null && valueB != null ) && valueA.startsWith( valueB );
    }

    /**
     * Monta uma String com valores repetidos.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value         String a ser repetida.
     * @param repeticoes    Nro de repetições.
     *
     * @return String
     *
     * <pre>{@code
     *
     *      // Exemplo:
     *      UtilString.fill("-",5);     // -----
     *      UtilString.fill("ABC",3)    // ABCABCABC
     *
     * }</pre>
     *
     */
    public static String fill(
        final String value,
        final int repeticoes
    ) {
        return value != null
            ? format("%" + repeticoes + "s", " ").replaceAll(" ",value)
            : value;
    }

    /**
     * Retorna String em Base64.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value String a ser convertida
     *
     * @return String em Base64.
     */
    public static String converterBase64( final String value) {

        return isVazia(value) ? value : Base64.getEncoder().encodeToString(value.getBytes());
    }

}
