package infra.util;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

/**
 * @author Maycon César
 * @since 27/07/2017
 *
 * @param <T>
 */
class ArcomCoordenadaBestMatch<T>{

	private final List<ParObjectCoordenadas<T>> paresCoordenadas;
	
	public ArcomCoordenadaBestMatch(Collection<ArcomCoordenadaDoubleWrapper<T>> coordenadas){
		this.paresCoordenadas = new ArrayList<ParObjectCoordenadas<T>>(coordenadas.size() ^ 2);
		for (ArcomCoordenadaDoubleWrapper<T> c1 : coordenadas){
			for (ArcomCoordenadaDoubleWrapper<T> c2 : coordenadas){
				if (c1.getLatitude() == c2.getLatitude() && c1.getLongitude() == c2.getLongitude()){
					continue;
				}
				long distanciaMetros = ArcomLocalizacaoUtils.calcularDistanciaCoordenadasEmMetros(c1.getLatitude(), c1.getLongitude(), c2.getLatitude(), c2.getLongitude());
				
				
				ParObjectCoordenadas<T> par = new ParObjectCoordenadas<T>(
						  c1.getObject()
						, c2.getObject()
						, distanciaMetros);
				this.paresCoordenadas.add(par);
			}
		}
	}
	
	/**
	 * Entre as combinaçoes possíveis obtém a que apresenta menor distancia entre dois pontos
	 * é retornado o objeto de somente um dos pontos (qualquer)
	 * 
	 * <pre>
	 * 	A -> B = {5mts}
	 *  B -> C = {2mts}
	 *  C -> A = {7mts}
	 *  
	 *  Retornaria: B ou C
	 * </pre>
	 * 
	 * @return
	 * <p><b>Autoria: </b>Maycon César - 27/07/2017</p>
	 */
	public T get(){
		if (this.paresCoordenadas == null || this.paresCoordenadas.isEmpty()){
			return null;
		}
		Collections.sort(this.paresCoordenadas);
		return this.paresCoordenadas.get(0).getAny(); // Tanto faz o 1 ou 2
	}


	private static class ParObjectCoordenadas<T> implements Serializable, Comparable<ParObjectCoordenadas<T>>{

		private static final long serialVersionUID = 1L;
		private final T obj1;
		private final T obj2;
		private final long distanciaMetros;
		
		public ParObjectCoordenadas(
				  T obj1
				, T obj2
				, long distanciaMetros
				) {
			super();
			this.obj1 = obj1;
			this.obj2 = obj2;
			this.distanciaMetros = distanciaMetros; 
		}
		public T getAny() {
			return obj1;
		}

		public long getDistanciaMetros() {
			return distanciaMetros;
		}
		
		@Override
		public String toString() {
			return "ParCoordenadas [obj1=" + obj1 + ", obj2=" + obj2
					+ ", distanciaMetros=" + distanciaMetros + "]";
		}
		@Override
		public int compareTo(ParObjectCoordenadas<T> o) {
			long thisVal = this.distanciaMetros;
			long anotherVal = o.getDistanciaMetros();
			return (thisVal<anotherVal ? -1 : (thisVal==anotherVal ? 0 : 1));
		}
	}


	@Override
	public String toString() {
		return "ArcomCoordenadaBestMatch [paresCoordenadas=" + paresCoordenadas	+ "]";
	}
}