package infra.util;

import infra.annotations.NaoVazio;

import javax.persistence.OptimisticLockException;
import javax.persistence.PersistenceException;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.lang.annotation.Annotation;
import java.sql.SQLException;
import java.util.Objects;
import java.util.Set;
import java.util.StringJoiner;

import static infra.util.UtilSqlException.Erro.newInstance;
import static infra.util.UtilString.isVazia;
import static java.lang.String.format;

/**
 * Classe utilitária para tratamento de exceções de banco de dados.
 *
 * <p>Autor: GPortes</p>
 *
 */
public final class UtilSqlException {

    /**
     * Traduz mensagem de erro.
     *
     * @param root Exception ref. ao erro.
     *
     * @return Informação do erro.
     */
    public static Erro traduzErro( final Throwable root ) {

        if ( root instanceof ConstraintViolationException )
            return extrairDeConstraintViolationException((ConstraintViolationException) root);

        if ( root instanceof OptimisticLockException )
            return newInstance( root.getMessage(), OPTIMISTIC_LOCK );

        if ( root instanceof PersistenceException )
            return extrairDePersistenceException((PersistenceException) root);

        if ( isVazia(root.getMessage()) )
            return newInstance(root.toString());

        return newInstance(root.getMessage());
    }

    private static Erro extrairDePersistenceException( final PersistenceException ex ) {

        Throwable sqlException = ex.getCause();

        if ( sqlException != null ) {
            int qtLoopSeguranca = 0;
            while ( qtLoopSeguranca < 10 ) {
                if ( sqlException instanceof SQLException ) {
                    final SQLException erro = (SQLException) sqlException;
                    return newInstance(
                        format("SQL Error [%s] %s", erro.getErrorCode(), erro.getMessage()),
                        erro.getErrorCode()
                    );
                }
                sqlException = sqlException.getCause();
                qtLoopSeguranca++;
            }
        }

        return newInstance(format( "Erro [%s]", ex.toString() ),null);
    }

    private static Erro extrairDeConstraintViolationException( final ConstraintViolationException ex ) {

        final Set<ConstraintViolation<?>> violations = ex.getConstraintViolations();
        final StringJoiner campoVazio = new StringJoiner(",");
        final StringJoiner campoSemValidacao = new StringJoiner(",");

        for ( final ConstraintViolation<?> item : violations ) {
            if ( ehVazio( item.getConstraintDescriptor().getAnnotation() ) ) {
                final String erro = item.getMessageTemplate().startsWith("{javax.validation.constraints")
                    ? item.getPropertyPath().toString()
                    : item.getMessage();
                campoVazio.add( erro );
            } else {
                campoSemValidacao.add( item.getMessage() );
            }
        }

        if ( !isVazia(campoVazio) )
            return newInstance( format("Obrigatório informar [%s]", campoVazio) );

        return newInstance( format("Validação falhou para [%s]", campoSemValidacao) );
    }

    private static boolean ehVazio( final Annotation annotation ) {

        return annotation instanceof NotNull
            || annotation instanceof NotEmpty
            || annotation instanceof NaoVazio;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // Interface para erros.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    private static final int OPTIMISTIC_LOCK  = -10;
    private static final int SYBASE_ERROR_CODE_DUPLICATE = 2601;

    public interface Erro {

        String getMensagem();
        boolean isRegistroDuplicado();
        boolean isRegistroAlterado();

        static Erro newInstance(
            final String mensagem,
            final Integer code
        ) {

            boolean isRegistroDuplicado =  Objects.equals( code, SYBASE_ERROR_CODE_DUPLICATE );
            boolean isRegistroAlterado = Objects.equals( code, OPTIMISTIC_LOCK );

            return new Erro() {
                @Override
                public String getMensagem() {
                    return mensagem;
                }
                @Override
                public boolean isRegistroDuplicado() {
                    return isRegistroDuplicado;
                }
                @Override
                public boolean isRegistroAlterado() {
                    return isRegistroAlterado;
                }
            };
        }

        static Erro newInstance( final String mensagem ) {
            return new Erro() {
                @Override
                public String getMensagem() {
                    return mensagem;
                }
                @Override
                public boolean isRegistroDuplicado() {
                    return false;
                }
                @Override
                public boolean isRegistroAlterado() {
                    return false;
                }
            };
        }
    }
}
