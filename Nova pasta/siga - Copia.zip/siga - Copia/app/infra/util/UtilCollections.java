package infra.util;

import infra.binders.ArrayLongBinder;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static java.util.Optional.empty;

/**
 * Classe utilitária para manipulação de coleções.
 *
 * <p>Autor: GPortes</p>
 *
 *
 * @since 03/09/2014
 *
 */
public final class UtilCollections {

    /**
     * Verifica se colecao não é {@code null} ou {code empty} Este método é projetado principalmente
     * para fazer a validação de parâmetros em métodos e construtores, como demonstrado abaixo:
     *
     * <blockquote><pre>
     * public Pessoa( List<TipoPessoa> pessoas ) {
     *     this.pessoas = UtilCollections.requireNonEmpty(pessoas,"Não pode ser vazio");
     * }
     * </pre></blockquote>
     *
     * @param colecao   the collection reference to check for nullity or empty
     * @param message   the type of the reference
     *
     * @return {@code obj} if not {@code null}
     *
     * @throws IllegalArgumentException if {@code obj} is {@code null}
     *
     * <p>Autor: GPortes</p>
     */
    public static <T> Collection requiredNonEmpty(
        final Collection<T> colecao,
        final String message
    ) {
        if ( isVazia( colecao ) )
            throw new IllegalArgumentException( UtilString.isVazia( message) ?  "Collection não pode ser vazia" : message );

        return colecao;
    }

    /**
     * @see UtilCollections#requiredNonEmpty(Collection, String)
     */
    public static <T> T[] requiredNonEmpty(
        final T[] array,
        final String message
    ) {
        if ( isVazia( array ) )
            throw new IllegalArgumentException( UtilString.isVazia( message) ?  "Array não pode ser vazia" : message );

        return array;
    }

    /**
     * Verifica se a lista esta vazia.
     *
     * <p>Autor: Cleber</p>
     *
     * @param colecao Coleção a ser avaliada.
     *
     * @return boolean
     */
    public static boolean isVazia( final Collection colecao ) {

        return colecao == null || colecao.isEmpty();
    }

    /**
     * Verifica se map esta vazio.
     *
     * <p>Autor: GPortes</p>
     *
     * @param map Mapa a ser avaliado.
     *
     * @return boolean
     */
    public static <T,E> boolean isVazia( final Map<T, E> map ) {

        return map == null || map.isEmpty();
    }

    /**
     * Verifica se array esta vazio.
     *
     * <p>Autor: GPortes</p>
     *
     * @param array Array a ser avaliado.
     *
     * @return (true) se esta vazio e (false) o contrário.
     */
    public static <T> boolean isVazia( final T[] array ) {

        return array == null || array.length == 0;
    }

    /**
     * Verifica se array esta vazio.
     *
     * <p>Autor: GPortes</p>
     *
     * @param array Array a ser avaliado.
     *
     * @return (true) se esta vazio e (false) o contrário.
     */
    public static boolean isVazia( final ArrayLongBinder array ) {

        return array == null || isVazia( array.getValue() );
    }

    /**
     * Retorna o qtde de elementos de uma coleção. Se coleção vazia ou nula retorna 0 (zero).
     *
     * <p>Autor: GPortes</p>
     *
     * @param colecao Coleção a ser avaliada.
     *
     * @return Qtde de elementos.
     */
    public static <T> int getTamanho( final Collection<T> colecao ) {

        return isVazia( colecao ) ? 0 : colecao.size();
    }

    /**
     * Retorna a qtde de elementos de um array.
     *
     * <p>Autor: GPortes</p>
     *
     * @param array Array a ser avaliado.
     *
     * @return Qtde de elementos.
     */
    public static <T> int getTamanho( final T[] array ) {

        return isVazia( array ) ? 0 : array.length;
    }

    /**
     * Quebra lista em listas menores.
     *
     * <p>Autor: GPortes</p>
     *
     * @param lista     Lista original.
     * @param quebra    Qtde de partes a dividir a lista.
     *
     * @return Coleções de listas.
     */
    public static <T> List<List<T>> quebrarLista( List<T> lista,
                                                  final short quebra ) {

        if ( quebra <= 0 )
            throw new IllegalArgumentException("Argumento [ partes ] inválido !");

        if ( isVazia(lista) )
            throw new IllegalArgumentException("Argumento [ lista ] inválido !");

        int tamanhoLista = lista.size();

        List<List<T>> nova = new ArrayList<>(quebra);

        if ( tamanhoLista < quebra ) {
            nova.add( lista );
            return nova;
        }

        int indexIni = -quebra;
        int indexFim = 0;

        do {

            indexIni += quebra;
            indexFim += quebra;

            if ( indexIni >= tamanhoLista )
                break;

            if ( indexFim > tamanhoLista )
                indexFim = tamanhoLista;

            nova.add( lista.subList(indexIni,indexFim) );

        } while ( indexFim % quebra == 0 );

        return nova;
    }

    /**
     * Quebra lista em listas menores.
     *
     * <p>Autor: GPortes</p>
     *
     * @param lista     Lista original.
     * @param quebra     Qtde de partes a dividir a lista.
     *
     * @return  Coleções de listas.
     */
    public static <T> Set<Set<T>> quebrarLista( Set<T> lista,
                                                final short quebra ) {

        if ( quebra <= 0 )
            throw new IllegalArgumentException("Argumento [ partes ] inválido !");

        if ( isVazia( lista ) )
            throw new IllegalArgumentException("Argumento [ lista ] inválido !");

        final int tamanhoLista = lista.size();

        if ( tamanhoLista <= quebra ) {
            Set<Set<T>> subListas = new LinkedHashSet<>( tamanhoLista );
            subListas.add( lista );
            return subListas;
        }

        Set<Set<T>> subListas = new LinkedHashSet<>( quebra );
        Set<T> listaTemp = new LinkedHashSet<>();
        short count = 0;

        for ( T elemento : lista ) {

            listaTemp.add( elemento );
            count ++;

            if ( count == quebra ) {
                subListas.add( listaTemp );
                listaTemp = new LinkedHashSet<>();
                count = 0;
            }
        }

        if ( count > 0 )
            subListas.add( listaTemp );

        return subListas;
    }

    /**
     * Verifica se existe o elemento chave no mapa de valores.
     *
     * <p>Autor: GPortes</p>
     *
     * @param map
     * @param key
     *
     * @return boolean
     */
    public static <T,E> boolean containsKey( final Map<T,E> map,
                                             final T key ) {

        return !isVazia( map ) && map.containsKey( key );
    }

    /**
     * Verifica se uma lista contém todos os elementos de outra lista.
     *
     * <p>Autor: GPortes</p>
     *
     * @param listA Lista de elementos A
     * @param listB Lista de elementos A
     *
     * @return boolean
     */
    public static <T> boolean contem( final List<T> listA,
                                      final List<T> listB ) {

        if ( ( isVazia(listA) && !isVazia(listB) )
             || ( !isVazia(listA) && isVazia(listB) )
             || ( listA.size() > listB.size() ) )
            return false;

        for ( T element : listA )
            if ( !listB.contains(element) )
                return false;

        return true;
    }

    /**
     * Retorna uma lista do valor informado.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value Valor a ser inserido numa lista.
     *
     * @return Lista com valor informado.
     */
    public static <T> List<T> asList( final T value ) {

        List<T> values = new ArrayList<T>(  );
        values.add( value );
        return values;
    }

    /**
     * Retorna nova lista acrescida do elemento informado. Se elemento null retorna a própria lista.
     *
     * <p>Autor: GPortes</p>
     *
     * <pre>{@code
     *
     *      // Exemplo:
     *
     *      List<String> ex01 = Arrays.asList("a","b");
     *      ex01 = UtilCollections.adicionarSeNaoExistir( valores, "b" );   // "a","b"
     *      ex01 = UtilCollections.adicionarSeNaoExistir( valores, "z" );   // "a","b","z"
     *
     *      List<String> ex02 = Collections.emptyList();
     *      ex02 = UtilCollections.adicionarSeNaoExistir( valores, "b" )    // "b"
     *
     * }</pre>
     *
     * @param lista     Lista a manipulada.
     * @param elemento  Elemento a ser adicionado.
     *
     * @return (true) se o elemento foi inserido e (false) o contrário.
     */
    public static <T> List<T> adicionarSeNaoExistir( final List<T> lista,
                                                     final T elemento ) {

        if ( elemento == null )
            return lista;

        if ( isVazia( lista ) ) {
            List<T> novaLista = new ArrayList<>();
            novaLista.add( elemento );
            return novaLista;
        }

        if ( lista.contains( elemento ) )
            return lista;

        List<T> novaLista = new ArrayList<>( lista );
        novaLista.add( elemento );
        return novaLista;
    }

    /**
     * Retorna ultimo elemento de uma lista.
     *
     * <p>Autor: GPortes</p>
     *
     * @param lista  Lista de elementos.
     *
     * @return Ultimo elemento.
     */
    public static <T> T getLast( List<T> lista ) {

        return isVazia( lista ) ? null : lista.get( lista.size() - 1 );
    }

    /**
     * Convert lista em sequencia de String.
     *
     * <p>Autor: GPortes</p>
     *
     * <pre>{@code
     *
     *      // Exemplo:
     *
     *      List<Integer> lista = Arrays.asList(1,2,3,4,5);
     *      UtilCollections.convertString( lista, ";" );  // 1;2;3;4;5
     *      UtilCollections.convertString( lista, "-" );  // 1-2-3-4-5
     *      UtilCollections.convertString( lista, " " );  // 1 2 3 4 5
     *
     * }</pre>
     *
     * @param lista     Lista para converter.
     * @param separador Separador p/ incluir entre as linhas.
     *
     * @return String
     */
    public static <T> String convertString( final List<T> lista,
                                            final String separador ) {

        if ( isVazia( lista ) )
            return "";

        if ( separador == null )
            throw new IllegalArgumentException( "Faltou definir argumento [ separador ]" );

        StringBuilder builder = new StringBuilder(  );

        for ( T t : lista )
            builder.append( t ).append( separador );

        int pos = builder.lastIndexOf( separador );

        if ( pos > 0 )
            return builder.substring( 0, pos );

        return builder.toString();
    }

    /**
     * Retorna a primeira (key) de um mapa de valores.
     *
     * <p>Autor:GPortes</p>
     *
     * <pre>{@code
     *
     *      // Exemplo:
     *
     *      Map<String,LocalDate> map = new HashMap<>();
     *      map.put("ABC", LocalDate.of(2000,1,1));
     *
     *      Optional<String> chave = UtilCollections.getFirstKey( map ) // "ABC"
     *
     * }</pre>
     *
     * @param map Mapa de valores.
     *
     * @return A key de um mapa de valores.
     */
    public static <K,V> Optional<K> getFirstKey( final Map<K,V> map ) {

        if ( isVazia(map) )
            return empty();

        return map.entrySet().stream().map( Map.Entry::getKey ).findFirst();
    }

    /**
     * Converte Set para List.
     *
     * <p>Autor: GPortes</p>
     *
     * @param lista Lista de valores.
     *
     * @return Lista
     */
    public static <T> List<T> convertToList( final Set<T> lista ) {

        return isVazia(lista) ? lista.stream().collect(Collectors.toList()) : Collections.emptyList();
    }

    /**
     * Critério para aplicar distinct a uma lista por alguma propriedade.
     *
     * <p>Autor: GPortes</p>
     *
     * @param keyExtractor
     *
     * @return Predicate
     *
     *
     * <pre>{@code
     *
     *      // Ex:
     *      List<Cliente> clientes = ....
     *
     *      List<Long> idClientesRede = clientes
     *          .stream
     *          .filter( distinctByKey(Cliente::getIdRede) )
     *          .forEach( System.out::println )
     *
     * }</pre>
     */
    public static <T> Predicate<T> distinctByKey( final Function<? super T,Object> keyExtractor) {

        Map<Object,String> seen = new ConcurrentHashMap<>();
        return t -> seen.put(keyExtractor.apply(t), "") == null;
    }

}