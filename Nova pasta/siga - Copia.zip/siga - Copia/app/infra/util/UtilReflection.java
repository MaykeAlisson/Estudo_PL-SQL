package infra.util;

import infra.model.Model;

import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Version;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Arrays;

import static infra.util.UtilException.getExceptionComoString;

/**
 * Classe utilitaria ref. a reflexão de classes.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 05/06/2014
 *
 */
public final class UtilReflection {

    /**
     * Verifica através de reflexão se um objeto é equivalente ao outro.
     *
     * <p>Autor: GPortes</p>
     *
     * @param modelA                Classe A
     * @param modelB                Classe B
     * @param desconsiderarFields   Não considerar atributos.
     *
     * @return (true) se são equivalentes ou (false) o contrário.
     */
    public static <T extends Model> boolean ehIgual( T modelA, T modelB, String... desconsiderarFields ) {

        if ( modelA.getClass() != modelB.getClass() )
            return false;

        Arrays.sort(desconsiderarFields);

        for ( Field field : modelA.getClass().getFields() ) {

            if ( Arrays.binarySearch(desconsiderarFields, field.getName()) > -1 )
                continue;

            boolean bypass = false;

            for ( Annotation annotation : field.getDeclaredAnnotations() ){
                if ( ( annotation.annotationType() == Version.class ) ||
                     ( annotation.annotationType() == IdClass.class ) ||
                     ( annotation.annotationType() == Id.class ) ) {
                    bypass = true;
                    break;
                }
            }

            if ( bypass )
                continue;

            int mod = field.getModifiers();

            if ( Modifier.isStatic(mod) || Modifier.isPrivate(mod) || Modifier.isProtected(mod) )
                continue;

            try {

                if ( field.get(modelA) == null && field.get(modelB) == null )
                    continue;

                if ( ( field.get(modelA) == null && field.get(modelB) != null ) ||
                     ( field.get(modelA) != null && field.get(modelB) == null ) ||
                     ( ! field.get(modelA).equals(field.get(modelB))          )  )
                    return false;

            } catch ( IllegalAccessException ex ) {

                throw new RuntimeException(getExceptionComoString(ex));

            }
        }

        return true;

    }


    /**
     * Retorna valor de um atributo de nome (id) que existe em uma classe.
     *
     * <p>Autor: GPortes</p>
     *
     * @param obj   Instância de um objeto.
     *
     * @return Valor ref. em String.
     *
     */
    public static <T> String getValorAtributoId( T obj ) {

        return getValorAtributo(obj, "id");

    }


    public static <T> String getValorAtributo( T obj, String name ) {

        try {
            return obj.getClass().getDeclaredField(name).get(obj).toString();
        } catch ( Throwable t ) {
            return "??";
        }

    }

}
