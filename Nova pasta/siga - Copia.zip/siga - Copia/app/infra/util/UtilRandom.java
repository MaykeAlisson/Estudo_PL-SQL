package infra.util;

import infra.exceptions.InfraException;

import java.util.Random;
import java.util.UUID;

import static infra.util.UtilString.isVazia;
import static java.lang.String.format;

/**
 * Classe utilitaria para geração de dados Randômicos.
 *
 * <p>Autor: GPortes</p>
 * @since 05/06/2014
 *
 */
public final class UtilRandom {

    public static String getRandom( final String value ) {

        return ( isVazia( value ) ? "" : value ) + getRandom();
    }

    public static String getRandom() {

        return UUID.randomUUID().toString();
    }

    /**
     * Retorna um nro randômico.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valorInicial  Valor inicial
     * @param valorFinal    Valor final
     *
     * @return Nro randômico.
     */
    public static Long getRandom(
        final long valorInicial,
        final long valorFinal
    ) {

        return new Random()
            .longs(valorInicial,valorFinal)
            .findFirst()
            .orElseThrow(() -> new InfraException( format(
                "Falhou busca de valor randômico na faixa %s a %s ", valorInicial, valorFinal
            )));
    }
}
