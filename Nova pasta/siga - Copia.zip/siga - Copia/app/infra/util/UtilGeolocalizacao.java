package infra.util;

//import play.libs.F;
//import play.libs.ws.WS;
//import play.libs.ws.WSResponse;
//import scala.concurrent.Await;
//import scala.concurrent.duration.Duration;

import java.math.BigDecimal;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.concurrent.TimeUnit;

/**
 * Created by clebersilva on 02/05/17.
 */
public class UtilGeolocalizacao {

    public static final int RAIO_PLANETA_TERRA = 6371;

    /**
     * @param latitudeOrigem
     * @param latitudeAtual
     * @param longitudeOrigem
     * @param longitudeAtual
     * @return
     * <p><b>Autoria: </b>Samuel Policeno - 30/03/2017</p>
     */


    public static BigDecimal obtemDistanciaEmMetros(BigDecimal latitudeOrigem, BigDecimal latitudeAtual, BigDecimal longitudeOrigem, BigDecimal longitudeAtual) {

        return new BigDecimal(obtemDistanciaEmMetros(latitudeOrigem.doubleValue(),latitudeAtual.doubleValue(),longitudeOrigem.doubleValue(),longitudeAtual.doubleValue()));
    }

    public static double obtemDistanciaEmMetros(double latitudeOrigem, double latitudeAtual, double longitudeOrigem, double longitudeAtual) {

        Double distanciaLatitude = converterGrauDecimalParaRadiano(latitudeAtual - latitudeOrigem);
        Double distanciaLongitude = converterGrauDecimalParaRadiano(longitudeAtual- longitudeOrigem);
        Double raio = Math.sin(distanciaLatitude / 2) * Math.sin(distanciaLatitude / 2)
                + Math.cos(converterGrauDecimalParaRadiano(latitudeOrigem)) * Math.cos(converterGrauDecimalParaRadiano(latitudeAtual))
                * Math.sin(distanciaLongitude / 2) * Math.sin(distanciaLongitude / 2);
        Double circunferencia = 2 * Math.atan2(Math.sqrt(raio), Math.sqrt(1 - raio));
        double distanciaEmMetroEntreOsPontos = RAIO_PLANETA_TERRA * circunferencia * 1000;

        distanciaEmMetroEntreOsPontos = Math.pow(distanciaEmMetroEntreOsPontos, 2);
        return Math.sqrt(distanciaEmMetroEntreOsPontos);
    }

    /**
     * @param deg
     * @return
     * <p><b>Autoria: </b>Samuel Policeno - 30/03/2017</p>
     */
    private static double converterGrauDecimalParaRadiano(Double deg) {
        return deg * Math.PI / 180.0;
    }


//    public static Map<String,BigDecimal> consultaPosicaoVeiculo(final long idVeiculo) throws Exception {
//
//            final F.Promise<String> resultPromise = WS.url("http://siajob.arcom.com.br/arcom/rest/sys/oficina/consultarPosicaoVeiculo?idVeiculo=" + idVeiculo).get().map(
//                    new F.Function<WSResponse, String>() {
//                        public String apply(WSResponse response) {
//                            return response.getBody();
//                        }
//                    }
//            );
//        String resultado =  Await.result(resultPromise.wrapped(), Duration.apply(60, TimeUnit.SECONDS));
//
//        if (resultado.contains("OK#")) {
//            resultado = resultado.split("OK#")[1];
//            Map<String, BigDecimal> mapLatitudeLongitude = new HashMap<String, BigDecimal>();
//
//            mapLatitudeLongitude.put("latitude", new BigDecimal(resultado.split(",")[0]));
//            mapLatitudeLongitude.put("longitude", new BigDecimal(resultado.split(",")[1]));
//            return mapLatitudeLongitude;
//        }
//        return null;
//    }

}
