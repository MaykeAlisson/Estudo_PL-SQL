package infra.util;

import infra.exceptions.InfraException;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JRPrintServiceExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimplePrintServiceExporterConfiguration;

import javax.print.PrintService;
import javax.print.attribute.HashPrintServiceAttributeSet;
import javax.print.attribute.PrintServiceAttributeSet;
import javax.print.attribute.standard.PrinterName;
import java.util.Arrays;
import java.util.Objects;
import java.util.Optional;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilString.requireNonEmpty;
import static java.lang.String.format;
import static java.util.Objects.requireNonNull;
import static java.util.Optional.empty;
import static javax.print.PrintServiceLookup.lookupPrintServices;

/**
 * Classe utilitária para tratamento de acesso a impressoras.
 */
public final class UtilImpressora {

    /**
     * Retorna impressora pelo nome.
     *
     * <p>Autor: GPortes</p>
     *
     * @param nomeImpressora Nome da impressora
     *
     * @return Possivel impressora
     */
    public static Optional<PrintService> getImpressora( final String nomeImpressora ) {

        final PrintService[] printServices = lookupPrintServices(null, null );

        return isVazia( printServices )
                ? empty()
                : Arrays
                    .stream( printServices )
                    .filter( printService -> Objects.equals(printService.getName(), nomeImpressora ) )
                    .findFirst();
    }

    /**
     * Imprime relatório Jasper
     *
     * <p>Autor: GPortes</p>
     *
     * @param jasperPrint       Relatório Jasper.
     * @param nomeImpressora    Nome da impressora.
     */
    public static void imprimirRelatorio(
        final JasperPrint jasperPrint,
        final String nomeImpressora
    ) {

        requireNonNull( jasperPrint, "Obrigatório informar [ jasperPrint ]" );
        requireNonEmpty( nomeImpressora, "Obrigatório informar [ nomeImpressora ]" );

        final PrintService impressora =
            getImpressora( nomeImpressora )
            .orElseThrow( () -> new InfraException( format("Não localizou impressora [%s]", nomeImpressora) ) );

        final PrintServiceAttributeSet printServiceAttributeSet = new HashPrintServiceAttributeSet();
        printServiceAttributeSet.add( new PrinterName(impressora.getName(), null) );

        final SimplePrintServiceExporterConfiguration configuration = new SimplePrintServiceExporterConfiguration();
        configuration.setPrintServiceAttributeSet(printServiceAttributeSet);
        configuration.setDisplayPageDialog(false);
        configuration.setDisplayPrintDialog(false);

        try {
            final JRPrintServiceExporter exporter = new JRPrintServiceExporter();
            exporter.setExporterInput( new SimpleExporterInput( jasperPrint ) );
            exporter.exportReport();
        } catch ( final JRException e ) {
            throw new InfraException( e );
        }
    }
}
