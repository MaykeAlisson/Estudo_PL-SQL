package infra.util;

import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.CustomClassLoaderConstructor;
import play.Environment;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.io.InputStream;
import java.util.Optional;

import static java.util.Optional.empty;
import static java.util.Optional.ofNullable;

/**
 * Classe utilitaria para leitura de arquivos no formato YAML
 *
 * https://bitbucket.org/asomov/snakeyaml/wiki/Documentation
 *
 * <p>Autor: GPortes</p>
 *
 */
@Singleton
public class UtilYaml {

    private final Environment environment;

    @Inject
    public UtilYaml( final Environment environment ) {

        this.environment = environment;
    }

    /**
     * Leitura do arquivo na pasta conf da aplicação.
     *
     * <p>Autor: GPortes</p>
     *
     */
    public Optional<Object> load( final String resourceName ) {

        try {
            return ofNullable( load(
                environment.resourceAsStream(resourceName),
                environment.classLoader()
            ));
        } catch ( Throwable e ) {
            return empty();
        }
    }

    /**
     * Load the specified InputStream as Yaml.
     *
     * @param classloader The classloader to use to instantiate Java objects.
     */
    public Optional<Object> load(
        final InputStream is,
        final ClassLoader classloader
    ) {

        try {
            Yaml yaml = new Yaml( new CustomClassLoaderConstructor( classloader ) );
            return ofNullable( yaml.load(is) );
        } catch ( Throwable e ) {
            return empty();
        }
    }

}