package infra.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.JsonNodeType;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.type.TypeFactory;
import infra.exceptions.InfraException;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilString.isVazia;
import static java.util.Collections.emptyList;
import static java.util.Collections.emptySet;
import static java.util.Optional.empty;
import static java.util.Optional.ofNullable;
import static play.libs.Json.newObject;

/**
 * Classe utilitária para tratamento JSON.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 18/12/2017
 */
public final class UtilJson {

    public static ObjectNode mensagemErro( final String texto ) {

        return newObject().put( "erro", texto );
    }

    private static boolean isStringType( final JsonNode node ) {

        return node.getNodeType() != null
            && Objects.equals( node.getNodeType(), JsonNodeType.STRING );
    }

    /**
     * Retorna valor convertido em Long.
     *
     * <pre>{@code
     *
     *  Exemplo:
     *
     *  json -> { "idCarga": 15, "idCliente": "ABC" }
     *
     *  Long idCarga = UtilJson.toLong( json, "idCarga" );
     *   // retorna 15.
     *
     *  Long idNota = UtilJson.toLong( json, "idNota" );
     *   // retorna null, pois não existe a chave "idNota".
     *
     *  Long idCliente = UtilJson.toLong( json, "idCliente" );
     *   // retorna null, pois o valor e texto.
     *
     * }</pre>
     *
     * <p>Autor: GPortes</p>
     *
     * @param node
     * @param fieldName
     *
     * @return Valor (Long)
     */
    public static Long toLong(
        final JsonNode node,
        final String fieldName
    ) {

        if ( node != null && !isVazia( fieldName ) && node.has( fieldName ) ) {
            final JsonNode jsonNode = node.get( fieldName );
            return jsonNode.canConvertToLong() ? jsonNode.asLong() : null;
        }

        return null;
    }

    /**
     * Retorna valor convertido em Short.
     *
     * <pre>{@code
     *
     *  Exemplo:
     *
     *  json -> { "idEmpresa": 1, "idFilial": "ABC" }
     *
     *  Short idEmpresa = UtilJson.toShort( json, "idEmpresa" );
     *   // retorna 1.
     *
     *  Short idCidade = UtilJson.toShort( json, "idCidade" );
     *   // retorna null, pois não existe a chave "idCidade".
     *
     *  Short idFilial = UtilJson.toShort( json, "idFilial" );
     *   // retorna null, pois o valor e texto.
     *
     * }</pre>
     *
     * <p>Autor: GPortes</p>
     *
     * @param node
     * @param fieldName
     *
     * @return Valor(Short)
     */
    public static Short toShort(
            final JsonNode node,
            final String fieldName
    ) {

        return node != null
            && !isVazia( fieldName )
            && node.has( fieldName )
            && node.get( fieldName ).canConvertToInt()
            ? UtilNumero.toShort( node.get( fieldName ).asInt() )
            : null;
    }

    /**
     * Retorna valor convertido em BigDecimal.
     *
     * <p>Autor: GPortes</p>
     *
     * @param node
     * @param fieldName
     *
     * @return Valor(BigDecimal)
     */
    public static BigDecimal toBigDecimal(
        final JsonNode node,
        final String fieldName
    ) {

        try {
            return ( node != null && !isVazia( fieldName ) && node.has( fieldName ) )
                ?  isStringType( node.get( fieldName ) )
                   ? new BigDecimal( node.get( fieldName ).textValue() )
                   : node.get( fieldName ).decimalValue()
                : null;
        } catch ( final NumberFormatException e ) {
            return null;
        }
    }

    /**
     * Retorna valor convertido em Texto.
     *
     * <pre>{@code
     *
     *  Exemplo:
     *
     *  json -> { "razaoSocial": "ABC" }
     *
     *  String razaoSocial = UtilJson.toText( json, "razaoSocial" );
     *    // Retorna "ABC"
     *
     *  String fantasia = UtilJson.toText( json, "fantasia" );
     *    // Retorna null pois não existe a chave "fantasia"
     *
     * }</pre>
     *
     * <p>Autor: GPortes</p>
     *
     * @param node
     * @param fieldName
     *
     * @return Valor(String)
     */
    public static String toText(
        final JsonNode node,
        final String fieldName
    ) {

        return node != null
            && !isVazia( fieldName )
            && node.has( fieldName )
            && node.get( fieldName ).isTextual()
            ? node.get( fieldName ).asText()
            : null;
    }

    /**
     * Retorna valor convertido em LocalDate.
     *
     * <pre>{@code
     *
     *  json -> { "dataFim": "01-02-2020" }
     *
     *  LocalDate dataFim = UtilJson.toLocalDate( json, "dataFim", "dd-MM-yyyy" );
     *      // Retorna  "01-02-2020"
     *
     *  LocalDate dataFim = UtilJson.toLocalDate( json, "dataInicio", "dd-MM-yyyy" );
     *      // Retorna  null pois não existe a chave "dataInicio"
     *
     * }</pre>
     *
     * @param node
     * @param fieldName
     * @param formato
     *
     * @return Valor(LocalDate)
     */
    public static LocalDate toLocalDate(
        final JsonNode node,
        final String fieldName,
        final String formato
    ) {

        final String value = toText(node, fieldName);

        return value != null ? UtilDate.toLocalDate( value, formato ) : null;
    }

    /**
     * Retorna valor convertido em LocalDate.
     *
     * <pre>{@code
     *
     *  json -> { "dataFim": "01-02-2020 12:00:00" }
     *
     *  LocalDateTime dataFim = UtilJson.toLocalDate( json, "dataFim", "dd-MM-yyyy HH:mm:ss" );
     *      // Retorna  "01-02-2020 12:00:00"
     *
     *  LocalDate dataFim = UtilJson.toLocalDate( json, "dataInicio", "dd-MM-yyyy HH:mm:ss" );
     *      // Retorna  null pois não existe a chave "dataInicio"
     *
     * }</pre>
     *
     * @param node
     * @param fieldName
     * @param formato
     *
     * @return Valor(LocalDateTime)
     */
    public static LocalDateTime toLocalDateTime(
        final JsonNode node,
        final String fieldName,
        final String formato
    ) {

        final String value = toText(node, fieldName);

        return value != null ? UtilDate.toLocalDateTime( value, formato ) : null;
    }

    /**
     * Retorna valor convertido em Boolean.
     *
     * <pre>{@code
     *
     *  Exemplo:
     *
     *  json -> { "permiteBloqueio": true }
     *
     *  Boolean permiteBloqueio = UtilJson.toBoolean( json, "permiteBloqueio" );
     *    // Retorna true
     *
     *  String permiteCarga = UtilJson.toBoolean( json, "permiteCarga" );
     *    // Retorna null pois não existe a chave "permiteCarga"
     *
     * }</pre>
     *
     * <p>Autor: GPortes</p>
     *
     * @param node
     * @param fieldName
     *
     * @return Valor(Boolean)
     */
    public static Boolean toBoolean(
        final JsonNode node,
        final String fieldName
    ) {

        return node != null
                && !isVazia( fieldName )
                && node.has( fieldName )
                ? node.get( fieldName ).asBoolean()
                : null;
    }

    /**
     * Retorna valor convertido em List.
     *
     * <p>Autor: GPortes</p>
     *
     * @param node          Json node.
     * @param fieldName     Nome do atributo
     * @param clazz         Classe destino.
     *
     * @return Valores(List)
     *
     * <pre>{@code
     *
     *  Exemplo:
     *
     *  json -> { "dados": [
     *                  { empresa: 1, razaoSocial: "ABC" },
     *                  { empresa: 2, razaoSocial: "DEF" },
     *                  { empresa: 3, razaoSocial: "GHI" }
     *              ]
     *          }
     *
     *  List<Empresa> empresas = UtilJson.toList( json, "dados", Empresa.class );
     *
     * }</pre>
     */
    public static <T> List<T> toList(
        final JsonNode node,
        final String fieldName,
        final Class<T> clazz
    ) throws IOException {

        if ( node == null || isVazia(fieldName) || clazz == null )
            return emptyList();

        final ObjectMapper objectMapper = new ObjectMapper();
        final TypeFactory typeFactory = objectMapper.getTypeFactory();

        return
        objectMapper
        .readValue(
            node.get( fieldName ).traverse(),
            typeFactory.constructCollectionType( List.class, clazz )
        );
    }

    /**
     * Retorna valor convertido em Set.
     *
     * <p>Autor: GPortes</p>
     *
     * @param node          Json node.
     * @param fieldName     Nome do atributo
     * @param clazz         Classe destino.
     *
     * @return Valores(List)
     *
     * <pre>{@code
     *
     *  Exemplo:
     *
     *  json -> { "dados": [
     *                  { empresa: 1, razaoSocial: "ABC" },
     *                  { empresa: 2, razaoSocial: "DEF" },
     *                  { empresa: 3, razaoSocial: "GHI" }
     *              ]
     *          }
     *
     *  Set<Empresa> empresas = UtilJson.toSet( json, "dados", Empresa.class );
     *
     * }</pre>
     */
    public static <T> Set<T> toSet(
        final JsonNode node,
        final String fieldName,
        final Class<T> clazz
    ) throws IOException {

        if ( node == null || isVazia(fieldName) || clazz == null )
            return emptySet();

        final ObjectMapper objectMapper = new ObjectMapper();
        final TypeFactory typeFactory = objectMapper.getTypeFactory();

        return
        objectMapper
        .readValue(
            node.get( fieldName ).traverse(),
            typeFactory.constructCollectionType( Set.class, clazz )
        );
    }

    /**
     * Convert coleção em uma String de Json
     *
     * <p>Autor: GPortes</p>
     *
     * @param lista Coleção a ser convertida.
     *
     * @return Possível json.
     */
    public static <T> Optional<String> convListToJsonString( final List<T> lista ) {

        try {
            if ( isVazia(lista) )
                return empty();
            final ObjectMapper objectMapper = new ObjectMapper();
            return ofNullable( objectMapper.writeValueAsString(lista) );
        } catch ( final JsonProcessingException e ) {
            throw new InfraException( e );
        }
    }
}
