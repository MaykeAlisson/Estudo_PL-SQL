package infra.util;

import javax.sql.rowset.serial.SerialBlob;
import java.sql.Blob;
import java.sql.SQLException;

/**
 * Classe com método utilitários referentes a binary large object.
 *
 * @author GPortes
 *
 * @since  02/09/2014.
 *
 */
public final class UtilBlob {

    /**
     * Verifica se Blob esta vazio.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value Blob
     *
     * @return
     */
    public static boolean isVazio(Blob value) {

        try {
            return value == null || value.length() == 0;
        } catch (SQLException e) {
            return false;
        }

    }



    /**
     * Converte String em Blob.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value String a converter
     *
     * @return Blob
     */
    public static Blob convertBlob( String value ) {

        if ( value == null )
            return null;

        try {
            return new SerialBlob(value.getBytes());
        } catch (SQLException e) {
            return null;
        }

    }


}
