package infra.util;

import play.Logger;

/**
 * Utilitario para facilitar logger...
 */
public class UtilLog {

    public static <T> void info(
        final Class<T> clazz,
        final String message,
        final Object... args
    ) {

        Logger.info( "[" + ( clazz != null ? clazz.getSimpleName() : "???" ) + " ] " + message, args );
    }

}
