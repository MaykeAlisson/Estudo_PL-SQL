package infra.util;

/**
 * Classe utilitária que simula as funcionalidades de um Cronometro.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 03/09/2014
 *
 */
public final class UtilCronometro {

    private long start;
    private long intervalo;
    private boolean started;
    private boolean stoped;

    public UtilCronometro() {
        this.start = 0;
    }

    public UtilCronometro start() {
        this.start =  System.currentTimeMillis();
        this.started = true;
        this.stoped = false;
        return this;
    }

    public UtilCronometro stop() {
        this.intervalo = this.started ? System.currentTimeMillis() - this.start : 0;
        this.stoped = true;
        return this;
    }

    public Long getMilisegundos() {
        return this.started ? ( this.stoped ? this.intervalo : System.currentTimeMillis() - this.start ) : 0;
    }

    public Long getSegundos() {
        long milisegundos = getMilisegundos();
        return milisegundos > 0 ? milisegundos / 1000 : 0;
    }

    public Long getMinutos() {
        long milisegundos = getMilisegundos();
        return milisegundos > 0 ? milisegundos / (1000*60) : 0;
    }


}
