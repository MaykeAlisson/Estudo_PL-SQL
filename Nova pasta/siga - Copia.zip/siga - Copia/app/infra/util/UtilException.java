package infra.util;

import com.fasterxml.jackson.databind.JsonNode;
import infra.exceptions.BusinessException;

import java.util.HashMap;
import java.util.Map;
import java.util.StringJoiner;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilSqlException.Erro;
import static infra.util.UtilSqlException.traduzErro;
import static infra.util.UtilString.contem;
import static infra.util.UtilString.converterString;
import static infra.util.UtilString.isVazia;
import static infra.util.UtilString.removerUltimosCaracteres;
import static java.lang.String.format;
import static play.libs.Json.toJson;

/**
 * Classe utilitária para tratamento de exceções.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 03/09/2014
 *
 */
public final class UtilException {

    private static final String ERROS = "erro";
    private static final String STACK = "stack";
    private static final String MESSAGE = "message";
    private static final String SQL_REGISTRO_DUPLICADO = "sqlRegistroDuplicado";
    private static final String SQL_REGISTRO_ALTERADO = "sqlRegistroAlteradoPorOutroUsuario";

    public static JsonNode getException( final String mensagem ) {

        final Map<String,String> erros = new HashMap<>(2);
        erros.put( STACK, "" );
        erros.put( MESSAGE, mensagem );

        final Map<String,Object> retorno = new HashMap<>(1);
        retorno.put( ERROS, erros );

        return toJson( retorno );
    }

    public static JsonNode getException( final Throwable ex ) {

        final Map<String,Object> erro = new HashMap<>(1);
        erro.put( ERROS, lerStack(ex) );
        return toJson( erro );
    }

    public static String getExceptionComoString( final Throwable ex ) {

        final Map<String, Object> info = lerStack(ex);

        return isVazia( converterString(info.get(STACK)) )
            ? converterString( info.get(MESSAGE) )
            : format( "%s%n%s", info.get(MESSAGE), info.get(STACK) );
    }

    private static Map<String,Object> lerStack( final Throwable ex ) {

        final Map<String,Object> info = new HashMap<>(3);

        if ( ex == null || isVazia( ex.getStackTrace() ) ) {

            info.put( MESSAGE, "ERRO NÃO IDENTIFICADO !!" );
            info.put( STACK, "ERRO NÃO IDENTIFICADO !!" );

        } else {

            final StackTraceElement root = ex.getStackTrace()[0];
            final String[] pacotesPrincipais = {"models.", "controllers.", "infra.", "service."};

            final Erro sqlErro = traduzErro( ex );

            info.put( MESSAGE, sqlErro.getMensagem() );
            info.put( STACK, formataClass(root) );
            info.put( SQL_REGISTRO_DUPLICADO, sqlErro.isRegistroDuplicado() );
            info.put( SQL_REGISTRO_ALTERADO, sqlErro.isRegistroAlterado() );

            if ( !contem( root.getClassName(), pacotesPrincipais ) ) {

                final StringJoiner detalhe = new StringJoiner("\n");

                for ( StackTraceElement stack : ex.getStackTrace() )
                    if ( contem( stack.getClassName(), pacotesPrincipais ) )
                        detalhe.add( formataClass( stack )  );

                if ( detalhe.length() > 1 ) {
                    detalhe.add( converterString(info.get(STACK)) );
                    info.put(STACK, detalhe.toString());
                }
            }

            // Não exibimos o nome do classe pois se trata de uma mensagem para usuario.
            if ( ex instanceof BusinessException )
                info.put( STACK, "" );
        }

        return info;
    }

    private static String formataClass( final StackTraceElement stack ) {

        return stack != null
            ? format( "[ %s.%s (Linha:%s) ] ",
                removerUltimosCaracteres( stack.getFileName(), 5 ),
                stack.getMethodName(),
                stack.getLineNumber()
            )
            : "";
    }

}
