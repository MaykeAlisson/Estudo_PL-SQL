package infra.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;

import static infra.util.UtilDate.isValida;
import static infra.util.UtilNumero.toLong;
import static infra.util.UtilString.apenasNumero;
import static java.lang.Long.valueOf;
import static java.time.format.DateTimeFormatter.ofPattern;

/**
 * Classe utilitária para tratamento mobile.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 04/09/2018
 *
 */
public final class UtilMobile {

    /**
     * Retorna senha de conexao.
     *
     * <p>Autor: GPortes</p>
     *
     * @param dataBase
     *
     * @return Senha de conexão.
     */
    private static Long getSenhaCnx( final LocalDate dataBase ) {

        if ( isValida( dataBase ) )
            return ( valueOf( dataBase.format( ofPattern("ddMMyyyy") ) ) ^ dataBase.getYear() ) >> 1;

        return 0L;
    }

    /**
     * Verifica se senha informada é valida.
     *
     * <p>Autor: GPortes</p>
     *
     * @param senhaInformada    Senha a ser validada.
     * @param dataBase          Data base para comparação.
     *
     * @return (true) se ok e (false) o contrário.
     */
    public static boolean isSenhaCnxValida(
        final String senhaInformada,
        final LocalDate dataBase
    ) {

        if ( !isValida(dataBase) || !apenasNumero( senhaInformada ) )
            return false;

        return toLong( senhaInformada )
                .filter( senha -> Objects.equals( senha, getSenhaCnx(dataBase) ) )
                .isPresent();
    }

    /**
     * @see UtilMobile#isSenhaCnxValida(String, LocalDate)
     */
    public static boolean isSenhaCnxValida(
        final String senhaInformada,
        final LocalDateTime dataBase
    ) {

        return isValida( dataBase ) && isSenhaCnxValida( senhaInformada, dataBase.toLocalDate() );
    }

}
