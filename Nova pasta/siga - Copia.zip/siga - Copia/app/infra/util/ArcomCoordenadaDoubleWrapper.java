package infra.util;

public class ArcomCoordenadaDoubleWrapper<T>{

	private final T object;
	private final double latitude;
	private final double longitude;
	
	public ArcomCoordenadaDoubleWrapper(T object, double latitude, double longitude) {
		super();
		this.object = object;
		this.latitude = latitude;
		this.longitude = longitude;
	}

	public T getObject() {
		return object;
	}

	public double getLatitude() {
		return latitude;
	}

	public double getLongitude() {
		return longitude;
	}
	
	public long calcularDistanciaEmMetros(double lat, double lng){
		return ArcomLocalizacaoUtils.calcularDistanciaCoordenadasEmMetros(this.latitude, this.longitude, lat, lng);
	}

	@Override
	public String toString() {
		return "ArcomCoordenadaDoubleWrapper [object=" + object + ", latitude=" + latitude + ", longitude=" + longitude + "]";
	}
}