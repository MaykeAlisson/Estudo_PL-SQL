package infra.util;

import infra.commons.constantes.FormatoData;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Scanner;
import java.util.StringJoiner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import static infra.commons.constantes.FormatoData.DATA_HORA;
import static infra.util.UtilArquivo.Ordenacao.DESC;
import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilDate.ehMenorIgual;
import static infra.util.UtilDate.getDataComoString;
import static infra.util.UtilDate.getValue;
import static infra.util.UtilRandom.getRandom;
import static infra.util.UtilSistema.OSType.WINDOWS;
import static infra.util.UtilSistema.QUEBRA_LINHA;
import static infra.util.UtilSistema.SO_CORRENTE;
import static infra.util.UtilSistema.isAmbienteUnix;
import static infra.util.UtilSistema.isAmbienteWindows;
import static infra.util.UtilString.isVazia;
import static java.lang.String.format;
import static java.nio.file.Files.exists;
import static java.nio.file.Files.isDirectory;
import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;
import static java.util.Arrays.stream;
import static java.util.Base64.getEncoder;
import static java.util.Collections.emptyList;
import static java.util.Objects.requireNonNull;
import static java.util.Optional.empty;
import static java.util.Optional.of;
import static java.util.Optional.ofNullable;
import static java.util.stream.Collectors.toList;


/**
 * Classe utilitária para manipulação de arquivos.
 *
 * <p>Autor: GPortes</p>
 *
 */
public final class UtilArquivo {

    /**
     * Tipo de Ordenação.
     */
    public enum Ordenacao { ASC, DESC };

    /**
     * Retorna a path referente a pasta temporária do sistema operacional.
     *
     * <p>Autor: GPortes</p>
     *
     * @return Caminho da pasta de temporária.
     */
    public static Path getPastaTemporaria() {

        return Paths.get( System.getProperty( "java.io.tmpdir" ) );
    }

    /**
     * Retorna o caminho completo da pasta do sistema.
     *
     * <p>Autor: GPortes</p>
     *
     * @return Path do sistema
     */
    public static String getPathDoSistema() {

        return System.getProperty( "user.dir" );
    }

    /**
     * Retorna conteudo do arquivo em base 64.
     *
     * <p>Autor: GPortes</p>
     *
     * @param arquivo Arquivo a ser lido.
     *
     * @return Conteúdo do arquivo em base61
     */
    public static Optional<String> getBase64( final String arquivo ) {

        if ( isVazia( arquivo ) )
            throw new IllegalArgumentException( "Faltou definir argumento [ arquivo ]" );

        File file = new File( arquivo );

        try ( InputStream inputStream = new FileInputStream(arquivo) ) {
            byte[] bytes = new byte[(int) file.length()];
            inputStream.read( bytes );
            return ofNullable( getEncoder().encodeToString(bytes) );
        } catch ( IOException e ) {
            return empty();
        }
    }

    /**
     * Retorna conteudo do arquivo em base 64.
     *
     * <p>Autor: GPortes</p>
     *
     * @param path Arquivo a ser lido.
     *
     * @return Conteúdo do arquivo em base61
     */
    public static Optional<String> getBase64( final Path path ) {

        requireNonNull( path, "Obrigatório informar argumento [ path ]" );

        final File file = path.toFile();

        try ( InputStream inputStream = new FileInputStream(file) ) {
            byte[] bytes = new byte[(int) file.length()];
            inputStream.read( bytes );
            return ofNullable( getEncoder().encodeToString(bytes) );
        } catch ( IOException e ) {
            return empty();
        }
    }

    /**
     * Retorno o conteúdo de um arquivo texto.
     *
     * <p>Autor: GPortes</p>
     *
     * @param   arquivo  Arquivo a ser lido
     *
     * @return  Conteúdo do arquivo.
     */
    public static Optional<String> getConteudoDoArquivo( final Path arquivo ) {

        Objects.requireNonNull( arquivo, "Faltou definir argumento [ arquivo ]" );

        try ( Scanner scanner = new Scanner( arquivo ) ) {
            final String conteudo = scanner.useDelimiter( "\\Z" ).next();
            return isVazia( conteudo ) ? empty() : of( conteudo );
        } catch ( IOException e ) {
            throw new UncheckedIOException(e);
        }
    }

    /**
     * Grava conteudo de uma string no arquivo informado.
     *
     * <p>Autor: Cleber</p>
     *
     * @param nomeArquivo   Nome do arquivo.
     * @param textoArquivo  String a ser armazenada no arquivo.
     *
     * @return (true) se ok e (false) ocorreu algum problema.
     */
    public static boolean gravarTexto(
        final String nomeArquivo,
        final String textoArquivo
    ) {

        return gravarTexto( toPath(nomeArquivo).orElse(null ), textoArquivo );
    }

    /**
     * Grava conteudo de uma string no arquivo informado.
     *
     * <p>Autor: GPortes</p>
     *
     * @param pathArquivo   Nome do arquivo.
     * @param textoArquivo  String a ser armazenada no arquivo.
     *
     * @return (true) se ok e (false) ocorreu algum problema.
     */
    public static boolean gravarTexto(
        final Path pathArquivo,
        final String textoArquivo
    ) {

        if ( pathArquivo == null )
            throw new IllegalArgumentException( "Faltou definir argumento [ pathArquivo ]" );

        if ( isVazia( textoArquivo ) )
            throw new IllegalArgumentException( "Faltou definir argumento [ textoArquivo ]" );

        try ( final FileWriter fw = new FileWriter( pathArquivo.toFile().getAbsoluteFile() );
              final BufferedWriter bw = new BufferedWriter(fw)
        ) {
            bw.write( textoArquivo );
            return true;
        } catch ( IOException e ) {
            return false;
        }
    }

    /**
     * Grava arquivo de bytes.
     *
     * <p>Autor: GPortes</p>
     *
     * @param pathArquivo   Caminho/Nome do arquivo.
     * @param dados         Dados a serem persistidos no arquivo.
     *
     * @return Qtde de bytes.
     */
    public static long gravarArquivo(
        final Path pathArquivo,
        final byte[] dados
    ) {

        requireNonNull( pathArquivo, "Obrigatório informar [pathArquivo]" );

        try {
            Files.write( pathArquivo, dados );
            return Files.size( pathArquivo );
        } catch ( IOException e ) {
            throw new UncheckedIOException( e );
        }
    }

    /**
     * Verifica se existe arquivo.
     *
     * <p>Autor: GPortes</p>
     *
     * @param arquivo Arquivo
     *
     * @return
     */
    public static boolean existeArquivo( final Path arquivo ) {

        return arquivo != null && Files.exists( arquivo );
    }

    /**
     * Move arquivo informado para pasta temporaria.
     *
     * @param arquivo
     * @return
     */
    public static Optional<Path> moverPastaTemporaria( final String arquivo ) {

        if ( isVazia(arquivo) )
            throw new IllegalArgumentException( "Faltou definir argumento [arquivo]" );

        final Path origem = Paths.get(arquivo);
        if ( !exists(origem) )
            return empty();

        final Path destino = getPastaTemporaria().resolve( arquivo );

        try {
            Files.move( origem, destino,REPLACE_EXISTING );
            return of( destino );
        } catch ( IOException e ) {
            return empty();
        }
    }

    /**
     * Converte o "path" informado para o formato do SO corrente
     *
     * <p>Autor: GPortes</p>
     *
     * <p><b>Metodo depreciado - Use: {@link #toPath(String)}</b></p>
     *
     * @param path Arquivo a ser verificado.
     *
     * @return String no formato java.
     */
    @Deprecated
    public static String toPathSOCorrente( final String path ) {

        String novoPath = path;

        if ( !isVazia( novoPath ) ) {
            if ( SO_CORRENTE == WINDOWS ) {
                if ( novoPath.startsWith("/") ) {
                    novoPath = novoPath.replace("/", "\\");
                    novoPath = novoPath.substring(1, 2) + ":" + novoPath.substring(2);
                }
            }
        }

        return novoPath;
    }

    /**
     * Retorna a data de criação do arquivo.
     *
     * <p>Autor: GPortes</p>
     *
     * @param path          Arquivo a ser verificado.
     * @param formatoData   Formato da data de retorno.
     *
     * @return Data de criação do arquivo.
     */
    public static Optional<Date> getDataCriacao(
        final Path path,
        final FormatoData formatoData
    ) {

        if ( path == null )
            return empty();

        if ( formatoData == null )
            throw new IllegalArgumentException( "Faltou definir argumento [formatoData]" );

        try {
            final BasicFileAttributes attributes = Files.readAttributes( path, BasicFileAttributes.class );
            return attributes != null ? ofNullable( getValue( attributes.creationTime().toMillis(), formatoData ) ) : empty();
        } catch ( IOException e ) {
            return empty();
        }
    }

    /**
     * Retorna o tamanho do arquivo.
     *
     * <p>Autor: GPortes</p>
     *
     * @param path Arquivo.
     *
     * @return O tamanho do arquivo.
     */
    public static Optional<Long> getTamanhoEmBytes( final Path path ) {

        if ( path == null )
            return empty();

        try {
            final BasicFileAttributes attributes = Files.readAttributes( path, BasicFileAttributes.class );
            return attributes != null ? of( attributes.size() ) : empty();
        } catch ( IOException e ) {
            return empty();
        }
    }

    /**
     * Retorna o Path a partir de uma url no formato String ( windows ou unix-like )
     *
     * <p>**Obs: Mapeamento de unidades no linux, são montadas a partir do /var/ </p>
     *
     * <p>Autor:GPortes</p>
     *
     * @param url   Url no formato String.
     *
     * @return Path
     */
    public static Optional<Path> toPath( final String url ) {

        if ( isVazia(url) )
            return empty();

        Path path = null;
        final String unidade = url.substring(0,1);

        if ( unidade.startsWith("/") ) {

            // url no formato unix

            switch ( SO_CORRENTE ) {
                case WINDOWS:
                    final Path root = Paths.get(url.substring(5,6) + ":\\" );
                    path = Stream
                            .of( url.substring(6).split("/" ) )
                            .map( Paths::get )
                            .reduce( root, Path::resolve );
                    break;
                case LINUX:
                    path = Paths.get( url );
                    break;
            }

        } else if ( url.matches( "^([A-Za-z]):.*$" ) ) /* inicia com a letra da unidade windows */ {

            // url no formato windows

            switch ( SO_CORRENTE ) {
                case WINDOWS:
                    path = Paths.get( url );
                    break;
                case LINUX:
                    final Path root = Paths.get("/var/").resolve( url.substring(0,1).toLowerCase() );
                    path = Stream
                            .of( url.substring(2).split("[\\\\/]",-1) )
                            .map( Paths::get )
                            .reduce( root, Path::resolve );

            }
        }

        return ofNullable( path );
    }

    /**
     * @see UtilArquivo#getDataCriacao(Path, FormatoData)
     */
    public static Optional<Date> getDataCriacao( final Path path ) {

        return getDataCriacao( path, DATA_HORA );
    }

    /**
     * Retorna a pasta com a data de criação mais recente.
     *
     * <p>Autor: GPortes</p>
     *
     * @param path
     *        o {@code Path} que deve ser pesquisado
     *
     * @return Retora o {@code Path} com data de criação mais recente.
     */
    public static Optional<Path> buscarPastaComDataCriacaoMaisRecente( final Path path ) {

        if ( path == null )
            return empty();

        try {
            return Files
                    .list(path)
                    .filter(Files::isDirectory)
                    .reduce(( p1, p2 ) -> ehMenorIgual(getDataCriacao(p1).orElse(null), getDataCriacao(p2).orElse(null)) ? p2 : p1);
        } catch ( IOException e ) {
            return empty();
        }
    }

    /**
     * Concatena path a várias strings.
     *
     * <p>Autor: GPortes</p>
     *
     * @param path  Path a ser concatenada.
     * @param paths Valores a serem concatenados.
     *
     * @return Path
     */
    public static Path concat(
        final Path path,
        final String... paths
    ) {

        requireNonNull(path,"Faltou definir argumento [ path ]");

        if ( isVazia(paths) )
            return path;

        Path reduce = stream(paths)
                        .map(Paths::get)
                        .reduce(Paths.get(""), (p1,p2) -> p1.resolve(p2));

        return path.resolve(reduce);
    }

    /**
     * Exclui diretorio e sub-diretorios.
     *
     * <p>Autor: GPortes</p>
     *
     * @param path Caminho a ser excluido.
     *
     * @return (true) se execucao ok e (false) falhou exclusão.
     */
    public static boolean excluirDiretorio( final Path path ) {

        if ( path == null )
            return true;

        try {
            Files.walk(path)
                .sorted(Comparator.reverseOrder())
                .map(Path::toFile)
                .forEach(File::delete);
            return true;
        } catch ( IOException e ) {
            return false;
        }
    }

    /**
     * Exclui arquivo.
     *
     * <p>Autor: GPortes</p>
     *
     * @param path  Arquivo a ser excluido.
     *
     * @return (true) se finalizou operação com sucesso e (false) o contrário.
     */
    public static boolean excluirArquivo( final Path path ) {

        if ( path == null )
            return true;

        try {
            Files.delete( path );
            return true;
        } catch ( IOException e ) {
            return false;
        }
    }

    /**
     * Retorna nome de arquivo com base na data atual + nro aleatório.
     *
     * <p>Autor: GPortes</p>
     *
     * <p>Saida no formato:   dd_MM_yyyy_HH_mm_NRO_RANDOMICO.EXTENSAO</p>
     *
     * @param extensaoDoArquivo Extensão que irá compor o nome do arquivo.
     *
     * @return Nome do arquivo.
     */
    public static String gerarNomeRandomico( final String extensaoDoArquivo ) {

        return gerarNomeRandomico() + "." + extensaoDoArquivo;
    }

    /**
     * Retorna nome de arquivo com base na data atual + nro aleatório.
     *
     * @return Nome do arquivo.
     */
    public static String gerarNomeRandomico( ) {

        return format( "%s_%s", getDataComoString(LocalDateTime.now(), "dd_MM_yyyy_HH_mm"), getRandom() );
    }

    /**
     * Listas todos os diretorios a partir de um Path.
     *
     * <p>Autor: GPortes</p>
     *
     * @param caminho  Caminho a ser listado.
     *
     * @return Lista de Paths
     */
    public static List<Path> listarDiretorios( final Path caminho ) {

        if ( caminho == null )
            return emptyList();

        try {
            return Files.list(caminho)
                        .filter(Files::isDirectory)
                        .collect(toList());
        } catch ( IOException e ) {
            return emptyList();
        }
    }

    /**
     * Listas todos os arquivos a partir de um Path.
     *
     * <p>Autor: GPortes</p>
     *
     * @param caminho Caminho a ser listado.
     *
     * @return Lista de Paths
     */
    public static List<Path> listarArquivos( final Path caminho ) {

        if ( caminho == null )
            return emptyList();

        try {
            return Files.list(caminho)
                .filter(file -> !isDirectory(file))
                .collect(toList());
        } catch ( final IOException e ) {
            return emptyList();
        }
    }

    private static String[] cmdDirWindows(
        final Path caminho,
        final String extensao,
        final Ordenacao ordenacao
    ) {

        final String[] comandos = new String[5];
        comandos[0] = "cmd.exe";
        comandos[1] = "/c";
        comandos[2] = "dir";
        comandos[3] = Objects.equals( ordenacao, DESC ) ? "/o:-d" : "/o";
        comandos[4] = format( "%s\\%s",
            requireNonNull( caminho,"Obrigatório informar [caminho]" ).toString(),
            isVazia(extensao) ? "" : extensao
        );
        return comandos;
    }

    private static String cmdLsUnix(
        final Path caminho,
        final String extensao,
        final Ordenacao ordenacao
    ) {

        final StringJoiner cmder = new StringJoiner(" " );
        cmder.add( "ls" );
        cmder.add( Objects.equals( ordenacao, DESC ) ? "-lt" : "-ltr" );
        cmder.add( format( "%s/%s",
            requireNonNull( caminho,"Obrigatório informar [caminho]" ).toString(),
            isVazia(extensao) ? "" : extensao
        ));
        cmder.add( "|" );
        cmder.add( "awk" );
        cmder.add( "'{print $9}'" );
        return cmder.toString();
    }

    /**
     * Listas todos os nome de arquivos a partir de um Path.
     *
     * <p>Autor: GPortes</p>
     *
     * @param caminho   Caminho dos arquivos a ser listados.
     * @param extensao  Extensão dos arquivos a ser filtrados.
     * @param ordenacao Tipo de ordenação por data de criação do arquivo.
     *
     * @return  Lista de nome de arquivos.
     */
    public static List<String> listarNomeArquivos(
        final Path caminho,
        final String extensao,
        final Ordenacao ordenacao
    ) {

        requireNonNull( caminho, "Obrigatório informar [ caminho ] para listar arquivos" );
        requireNonNull( ordenacao, "Obrigatório informar [ tipo de ordenação ] para listar arquivos" );

        ProcessBuilder pb;
        String regex = "";
        int nroGroup;

        if ( isAmbienteWindows() ) {
            pb = new ProcessBuilder( cmdDirWindows(caminho, extensao, ordenacao) );
            regex = "^(\\d{2}/\\d{2}/\\d{4})\\s+(\\d{2}:\\d{2})\\s+.*\\s+(.*$)";
            nroGroup = 3;
        } else if ( isAmbienteUnix() ) {
            pb = new ProcessBuilder( "bash", "-c", cmdLsUnix(caminho, extensao, ordenacao) );
            regex = ".*/(.*)$";
            nroGroup = 1;
        } else {
            throw new IllegalStateException( "Plataforma não detectada !!");
        }

        try {
            final Process prs = pb.start();

            try ( final InputStream is = prs.getInputStream() ) {

                byte[] buffer = new byte[1024];
                int size;
                final ByteArrayOutputStream stream = new ByteArrayOutputStream();
                while ( (size = is.read(buffer)) != -1 )
                    stream.write( buffer, 0, size );
                final String[] dados = new String( stream.toByteArray() ).split( QUEBRA_LINHA );

                final Pattern pattern = Pattern.compile( regex );
                final List<String> retorno = new ArrayList<>();

                for ( final String linha : dados ) {
                    final Matcher matcher = pattern.matcher( linha.toLowerCase() );
                    while ( matcher.find() )
                        retorno.add( matcher.group(nroGroup) );
                }

                return retorno;
            }

        } catch ( final IOException e ) {

            throw new IllegalStateException( "Falha ao listar arquivo(s)" );
        }
    }

    /**
     * Lista todos os arquivos e diretorios a partir de uma Path
     *
     * <p>Autor: GPortes</p>
     *
     * @param caminho Ponto de partida.
     *
     * @return Lista de Paths
     */
    public static List<Path> listarArqDir( final Path caminho ) {

        if ( caminho == null )
            return emptyList();

        try {
            return Files.list(caminho).collect(toList());
        } catch ( IOException e ) {
            return emptyList();
        }
    }

    /**
     * Cria diretorio caso o mesmo não exista.
     *
     * <p>Autor: GPortes</p>
     *
     * @param path  Diretorio
     *
     * @return (true) se OK e (false) erro.
     */
    public static boolean criarDiretorioSeNaoExiste( final Path path ) {

        requireNonNull( path, "Obrigatório informar o caminho ");

        try {
            if ( Files.isDirectory( path ) ) return false;
            Files.createDirectory( path );
            return true;
        } catch ( IOException e ) {
            throw new UncheckedIOException( e );
        }
    }

    /**
     * Retorna o tamanho do arquivo.
     *
     * <p>Autor: GPortes</p>
     *
     * @param arquivo   Nome do arquivo.
     *
     * @return Tamanho do arquivo.
     */
    public static long tamanhoDoArquivo( final Path arquivo ) {

        requireNonNull( arquivo, "Obrigatório informar o arquivo" );

        try {
            return Files.size( arquivo );
        } catch ( final IOException e ) {
            throw new UncheckedIOException( e );
        }
    }

    /**
     * Copia arquivo - Sobrepõe se existir.
     *
     * <p>Autor: GPortes</p>
     *
     * @param origem    Arquivo origem
     * @param destino   Arquivo destino.
     */
    public static void copiarArquivo(
        final Path origem,
        final Path destino
    ) {

        requireNonNull( origem, "Obrigatório informar argumento [origem]" );
        requireNonNull( destino, "Obrigatório informar argumento [destino]" );

        try {
            Files.copy( origem, destino, REPLACE_EXISTING );
        } catch ( IOException e ) {
            throw new UncheckedIOException( e );
        }
    }

    /**
     * Mover arquivo - Sobrepõe se existir.
     *
     * <p>Autor: GPortes</p>
     *
     * @param origem    Arquivo origem
     * @param destino   Arquivo destino.
     */
    public static void moverArquivo(
        final Path origem,
        final Path destino
    ) {

        requireNonNull( origem, "Obrigatório informar argumento [origem]" );
        requireNonNull( destino, "Obrigatório informar argumento [destino]" );

        try {
            Files.move( origem, destino, REPLACE_EXISTING );
        } catch ( IOException e ) {
            throw new UncheckedIOException( e );
        }
    }

    /**
     * Retorna a extensão de um arquivo.
     *
     * <p>Autor: GPortes</p>
     *
     * @param arquivo - Arquivo a ser avaliado.
     *
     * @return Extensão do arquivo.
     *
     * <pre>{@code
     *
     *      // Exemplo:
     *
     *      Path path = Paths.get("r:\\teste\\teste.sql");
     *      UtilArquivo.getExtensaoArquivo( path ) => get => .sql
     *
     *      path = Paths.get("r:\\teste\\teste");
     *      UtilArquivo.getExtensaoArquivo( path ) => empty()
     *
     *      path = null;
     *      UtilArquivo.getExtensaoArquivo( path ) => empty()
     *
     * }</pre>
     *
     */
    public static Optional<String> getExtensaoArquivo( final Path arquivo ) {

        return ofNullable( arquivo )
            .map( String::valueOf )
            .filter( f -> f.contains(".") )
            .map( f -> f.substring(f.lastIndexOf(".") + 1) );
    }


}
