package infra.util;

import infra.commons.constantes.PastaAplicacao;
import play.Logger;

import java.util.Objects;
import java.util.Optional;

import static infra.commons.constantes.PastaAplicacao.NAO_IDENTIFICADO;
import static infra.commons.constantes.PastaAplicacao.SIGA_1;
import static infra.commons.constantes.PastaAplicacao.SIGA_2;
import static infra.util.UtilArquivo.getPathDoSistema;
import static infra.util.UtilNet.getHostName;
import static infra.util.UtilSistema.OSType.LINUX;
import static infra.util.UtilSistema.OSType.MAC_OS;
import static infra.util.UtilSistema.OSType.OUTROS;
import static infra.util.UtilSistema.OSType.WINDOWS;
import static infra.util.UtilString.isVazia;
import static java.util.Optional.empty;
import static java.util.Optional.of;

/**
 * Classe com métodos utilitários ref. a informações do sistema.
 *
 * <p>Autor: GPortes</p>
 *
 */
public final class UtilSistema {

    public static final String QUEBRA_LINHA = System.getProperty( "line.separator" );
    public static final OSType SO_CORRENTE;

    static {

        String so = System.getProperty( "os.name" );

        if ( so != null ) {
            so = so.toLowerCase();
            if( so.contains( "mac" ) || so.contains( "darwin" ) )
                SO_CORRENTE = MAC_OS;
            else if ( so.contains( "win" ) )
                SO_CORRENTE = WINDOWS;
            else if ( so.contains( "nux" ) )
                SO_CORRENTE = LINUX;
            else
                SO_CORRENTE = OUTROS;
        } else {
            SO_CORRENTE = OUTROS;
        }
    }

    public enum OSType {
        WINDOWS,
        LINUX,
        MAC_OS,
        OUTROS
    }

    /**
     * Metodo utilizado para verificar em qual instância a aplicação foi carregada!
     *
     * <p>Autor: GPortes</p>
     *
     * @return Número da aplicação corrente. Caso não consiga retorna 0 (zero)
     */
    public static PastaAplicacao getPastaDaAplicacaoCorrente() {

        String pasta = getPathDoSistema();

        if ( isVazia( pasta ) )
            return NAO_IDENTIFICADO;

        pasta = pasta.toLowerCase();

        if ( pasta.contains( "siga1" ))
            return SIGA_1;

        if ( pasta.contains( "siga2" ))
            return SIGA_2;

        return NAO_IDENTIFICADO;
    }

    /**
     * Retorna o nro da pasta corrente.
     *
     * <p>Autor: GPortes</p>
     *
     * @return Nro da pasta da aplicacao corrente.
     */
    public static Optional<Short> getNroPastaDaAplicacaoCorrente() {

        switch ( getPastaDaAplicacaoCorrente() ) {
            case SIGA_1:
                return of((short)1);
            case SIGA_2:
                return of((short)2);
        }

        return empty();
    }

    /**
     * Indica que o sistema esta executando em produção.
     *
     * <p>Autor: GPortes</p>
     *
     * @return (true) se positivo e (false) o contrário.
     */
    public static boolean isSistemaEmProducao() {

        return getHostName().toLowerCase().startsWith("play");
    }

    /**
     * Loga caso esteja executando em desenvolvimento.
     *
     * <p>Autor: Tiagopti</p>
     *
     */
    public static void logaSeDesenvolvimento(
        final String origem ,
        final String texto
    ) {

        final PastaAplicacao pastaAplicacao = getPastaDaAplicacaoCorrente();
        if ( Objects.equals( pastaAplicacao, NAO_IDENTIFICADO ) ) {
            Logger.info("[" + origem + "] " + texto + " - @" + (int) Math.ceil(Math.random() * 1000));
        }
    }

    /**
     * Indica se aplicação esta executando sobre plataforma Windows.
     *
     * <p>Autor: GPortes</p>
     *
     * @return (true) se afirmativo e (false) o contrário.
     */
    public static boolean isAmbienteWindows() {

        return Objects.equals(SO_CORRENTE, WINDOWS);
    }

    /**
     * Indica se aplicação esta executando sobre plataforma Unix.
     *
     * <p>Autor: GPortes</p>
     *
     * @return (true) se afirmativo e (false) o contrário.
     */
    public static boolean isAmbienteUnix() {

        return Objects.equals(SO_CORRENTE, MAC_OS)
                || Objects.equals(SO_CORRENTE, LINUX);
    }
}
