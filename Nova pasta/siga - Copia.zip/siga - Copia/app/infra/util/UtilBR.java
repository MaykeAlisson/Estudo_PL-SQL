package infra.util;

import br.com.caelum.stella.format.CEPFormatter;
import br.com.caelum.stella.format.CNPJFormatter;
import br.com.caelum.stella.format.CPFFormatter;
import br.com.caelum.stella.validation.CPFValidator;
import br.com.caelum.stella.validation.InvalidStateException;

import static infra.util.UtilString.preencheZeroEsquerda;
import static java.lang.String.format;
import static java.lang.String.valueOf;
import static java.util.Objects.requireNonNull;

public final class UtilBR {

    /**
     * Verifica se CPF válido.
     *
     * <p>Autor: GPortes</p>
     *
     * @param cpf Nro do cpf
     *
     * @return (true) se válido e (false) o contrário.
     */
    public static boolean cpfValido( final Long cpf ) {

        requireNonNull( cpf, "Obrigatório informar argumento [cpf]" );

        try {
            new CPFValidator().assertValid( preencheZeroEsquerda( valueOf(cpf), 11 ) );
            return true;
        } catch ( final InvalidStateException  e ) {
            return false;
        }
    }

    /**
     * Formata cep.
     *
     * <p>Autor: GPortes</p>
     *
     * @param cep Nro do cep
     *
     * @return Cep formatado.
     */
    public static String formatarCep( final Long cep ) {

        requireNonNull( cep, "Obrigatório informar argumento [cep]" );

        return new CEPFormatter().format( format( "%08d", cep ) );
    }

    /**
     * Formatar CNPJ
     *
     * <p>Autor: GPortes</p>
     *
     * @param cnpj Nro do CNPJ
     *
     * @return CNPJ formatado.
     */
    public static String formatarCNPJ( final Long cnpj ) {

        requireNonNull( cnpj, "Obrigatório informar argumento [cnpj]" );

        return new CNPJFormatter().format( format( "%014d", cnpj ) );
    }

    /**
     * Formatar CNPJ
     *
     * <p>Autor: GPortes</p>
     *
     * @param cpf Nro do CNPJ
     *
     * @return CNPJ formatado.
     */
    public static String formatarCPF( final Long cpf ) {

        requireNonNull( cpf, "Obrigatório informar argumento [cep]" );

        return new CPFFormatter().format( format( "%011d", cpf ) );
    }
}
