package infra.util;

import java.util.Optional;

import static java.util.Optional.empty;
import static java.util.Optional.of;

/**
 * Classe utilitária para tratamento de retornos de valores.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 03/09/2014
 *
 */
public final class UtilResult {

    /**
     * Retorna Option de um valor.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor Valor
     *
     * @return
     */
    public static <T> Optional<T> getResult(final T valor ) {

        return valor == null ? empty() : of( valor );
    }

    /**
     * Retorna um Wrapper (valor x motivo).
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor     Valor
     * @param motivo    Motivo do valor
     *
     * @return Wrapper (valor x motivo)
     */
    public static <T> R<T> getResult( final T valor,
                                      final String motivo ) {

        return new R<T>( ) {

            @Override
            public T getValor( ) {
                return valor;
            }

            @Override
            public String getMotivo( ) {
                return motivo;
            }
        };
    }

    /**
     * Interface p/ representar um valor e o seu motivo.
     */
    public interface R <T> {

        T getValor();
        String getMotivo();
    }
}
