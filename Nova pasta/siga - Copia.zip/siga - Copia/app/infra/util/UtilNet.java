package infra.util;

import java.net.InetAddress;
import java.net.UnknownHostException;

import static play.Logger.error;

/**
 * Classe utilitaria para acesso a informações da rede.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 22/01/2014
 */
public final class UtilNet {

    private static InetAddress inetAddress;

    static {

        try {
            inetAddress = InetAddress.getLocalHost();
        } catch ( UnknownHostException e1 ) {
            error( "------------------------------------------" );
            error( "[ UtilNet ] FALHOU TENTATIVA DE LEITURA DO HOST" );
            error( "------------------------------------------" );
        }
    }

    public static String getHostName() {

        return inetAddress == null ? "" : inetAddress.getHostName();
    }

    public static String getIP() {

        return inetAddress == null ? "" : inetAddress.getHostAddress();
    }

    public static String getCanonicalHostName() {

        return inetAddress == null ? "" : inetAddress.getCanonicalHostName();
    }
}
