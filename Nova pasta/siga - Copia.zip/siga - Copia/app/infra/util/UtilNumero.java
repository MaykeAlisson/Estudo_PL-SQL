package infra.util;

import infra.binders.IntegerBinder;
import infra.binders.ShortBinder;
import infra.exceptions.InfraException;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Pattern;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilString.apenasNumero;
import static infra.util.UtilString.asListNumero;
import static infra.util.UtilString.getAPartirDe;
import static infra.util.UtilString.isVazia;
import static infra.util.UtilString.preencheZeroEsquerda;
import static infra.util.UtilString.requireNonEmpty;
import static java.lang.String.format;
import static java.math.BigDecimal.ROUND_HALF_UP;
import static java.math.BigDecimal.ZERO;
import static java.math.RoundingMode.HALF_DOWN;
import static java.math.RoundingMode.HALF_UP;
import static java.util.Collections.emptyList;
import static java.util.Optional.empty;
import static java.util.Optional.of;

/**
 * Classe utilitaria para manipulação de números.
 *
 * <p>Autor: GPortes</p>
 * @since 05/06/2014
 *
 */
public final class UtilNumero {

    private static final Locale BRASIL = new Locale("pt","BR");
    private static final Short[] ARRAY_VAZIO = {};
    private static final BigDecimal[] ARRAY_VAZIO_DE_BIGDECIMAL = {};
    public  static final BigDecimal CEM = new BigDecimal(100);

    private static final Map<Class<? extends Number>,Object> zeroes = new HashMap<>( ) ;

    static {
        zeroes.put( Short.class, (short) 0 );
        zeroes.put( Integer.class, 0 );
        zeroes.put( Long.class, (long) 0 );
        zeroes.put( Double.class, (double) 0 );
    }

    /**
     * Retorna o soma dos valores informados.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor1
     * @param valor2
     *
     * @return A soma dos valores.
     */
    public static BigDecimal somar(
        final BigDecimal valor1,
        final BigDecimal valor2
    ) {

        BigDecimal soma = ZERO;

        if ( valor1 == null && valor2 != null ) {
            soma = valor2;
        } else if ( valor1 != null && valor2 == null ) {
            soma = valor1;
        } else if ( valor1 != null ) {
            soma = valor1.add( valor2 );
        }

        return soma;
    }

    /**
     * Retorna a soma dos valores informados.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor1
     * @param valor2
     *
     * @return A soma dos valores.
     */
    public static Short somar(
        final Short valor1,
        final Short valor2
    ) {

        Integer soma = getOrElseZero( valor1, Short.class ) + getOrElseZero( valor2, Short.class );

        if ( soma > Short.MAX_VALUE )
            throw new InfraException( "Somatória de valores retornou valor acima do limite do tipo Short" );

        return soma.shortValue();
    }

    /**
     * Retorna o primeiro numero em uma string.
     *
     * <p>Autor: Cleber</p>
     *
     * @param valueString
     *
     * @return O primeiro numero contido em uma string
     */
    public static Long buscarLong( final String valueString ) {

        if( valueString== null )
            return 0L;

        char[] characters = valueString.toCharArray();
        Long value = null;
        boolean isPrevDigit = false;
        for (int i = 0; i < characters.length; i++) {
            if (!isPrevDigit) {
                if (Character.isDigit(characters[i])) {
                    isPrevDigit = true;
                    value = (long)  Character.getNumericValue(characters[i]) ;
                }
            } else {
                if (Character.isDigit(characters[i])) {
                    value = (value * 10) + Character.getNumericValue(characters[i]);
                } else {
                    break;
                }
            }
        }
        return value;
    }

    /**
     * Retorna o primeiro numero em uma string
     *
     * @param string
     *
     * @return O primeiro numero contido em uma string
     */
    public static Long buscarLongApartirDe (final String string, final String apartir) {

        final String novaString = getAPartirDe(string,apartir);

        return buscarLong(novaString);
    }

    /**
     * Retorna o soma dos valores informados.
     *
     * @param valor1
     * @param valor2
     *
     * @return A soma dos valores.
     */
    public static <T extends Number> BigDecimal somar(
        final BigDecimal valor1,
        final T valor2
    ) {

        if ( valor1 == null ) return null;
        if ( valor2 == null ) return somar( valor1, ZERO );

        if ( valor2 instanceof Integer )
            return somar( valor1, new BigDecimal( getOrElseZero( ( Integer ) valor2, Integer.class ) ) );

        if ( valor2 instanceof Long )
            return somar( valor1, new BigDecimal( getOrElseZero( ( Long ) valor2, Long.class ) ) );

        if ( valor2 instanceof Double )
            return somar( valor1, new BigDecimal( getOrElseZero( ( Double ) valor2, Double.class ) ) );

        if ( valor2 instanceof Short )
            return somar( valor1, new BigDecimal( getOrElseZero( ( Short ) valor2, Short.class ) ) );

        if ( valor2 instanceof Byte )
            return somar( valor1, new BigDecimal( getOrElseZero( ( Byte ) valor2, Byte.class ) ) );

        throw new InfraException( format( "[ UtilNumero.somar ] tipo não tratável !! - %s ", valor2.getClass() ) );
    }

    /**
     * Retorna o subtração dos valores informados.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor1 Minuendo
     * @param valor2 Subtraendo
     *
     * @return {@link BigDecimal}
     */
    public static BigDecimal subtrair(
        final BigDecimal valor1,
        final BigDecimal valor2
    ) {

        BigDecimal subtrair = ZERO;

        if ( valor1 == null && valor2 != null ) {
            subtrair = valor2;
        } else if ( valor1 != null && valor2 == null ) {
            subtrair = valor1;
        } else if ( valor1 != null ) {
            subtrair = valor1.subtract(valor2);
        }

        return subtrair;
    }

    /**
     * Retorna o subtração dos valores informados.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor1    Minuendo
     * @param valor2    Subtraendo
     *
     * @return Subtração de valores.
     */
    public static <T extends Number> BigDecimal subtrair(
        final BigDecimal valor1,
        final T valor2
    ) {

        if ( valor1 == null ) return null;
        if ( valor2 == null ) return subtrair( valor1, ZERO );

        if ( valor2 instanceof Integer )
            return subtrair( valor1, new BigDecimal( getOrElseZero( (Integer) valor2, Integer.class ) ) );

        if ( valor2 instanceof Long )
            return subtrair( valor1, new BigDecimal( getOrElseZero( (Long) valor2, Long.class ) ) );

        if ( valor2 instanceof Double )
            return subtrair( valor1, new BigDecimal( getOrElseZero( (Double) valor2, Double.class ) ) );

        if ( valor2 instanceof Short )
            return subtrair( valor1, new BigDecimal( getOrElseZero( (Short) valor2, Short.class ) ) );

        if ( valor2 instanceof Byte )
            return subtrair( valor1, new BigDecimal( getOrElseZero( (Byte) valor2, Byte.class ) ) );

        throw new InfraException( format( "[ UtilNumero.subtrair ] tipo não tratável !! - %s", valor2.getClass() ) );
    }

    /**
     * Retorna a multiplicação dos valores informados.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor1 Multiplicando
     * @param valor2 Multiplicador
     *
     * @return {@link BigDecimal}
     */
    public static BigDecimal multiplicar(
        final BigDecimal valor1,
        final BigDecimal valor2
    ) {

        BigDecimal multiplicar = ZERO;
        if ( valor1 == null && valor2 != null ) {
            multiplicar = valor2;
        } else if ( valor1 != null && valor2 == null ) {
            multiplicar = valor1;
        } else if ( valor1 != null ) {
            multiplicar = valor1.multiply(valor2);
        }

        return multiplicar;
    }

    /**
     * Aplicar percentual
     *
     * <p>Autor: Cleber</p>
     *
     * @param valor1
     * @param valor2
     * @param escala
     *
     * @return
     */
    public static BigDecimal multiplicarPercentual(
        final BigDecimal valor1,
        final BigDecimal valor2,
        int escala
    ) {

        return dividir( multiplicar(valor1,valor2),100L, escala );
    }

    /**
     * Retorna a multiplicação dos valores informados.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valorA Multiplicando
     * @param valorB Multiplicador
     *
     * @return {@link BigDecimal}
     */
    public static BigDecimal multiplicar(
        final BigDecimal valorA,
        final Long valorB
    ) {

        return multiplicar( valorA, new BigDecimal(valorB) );
    }

    /**
     * Retorna a multiplicação dos valores informados.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valorA Multiplicando
     * @param valorB Multiplicador
     *
     * @return {@link BigDecimal}
     */
    public static BigDecimal multiplicar(
        final BigDecimal valorA,
        final Double valorB
    ) {

        return multiplicar( valorA, new BigDecimal(valorB) );
    }

    /**
     * Retorna a multiplicação dos valores informados.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valorA Multiplicando
     * @param valorB Multiplicador
     *
     * @return {@link BigDecimal}
     */
    public static BigDecimal multiplicar(
        final BigDecimal valorA,
        final Integer valorB
    ) {

        return multiplicar( valorA, new BigDecimal( valorB ) );
    }

    /**
     * Retorna a multiplicação dos valores informados.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valorA Multiplicando
     * @param valorB Multiplicador
     *
     * @return {@link BigDecimal}
     */
    public static BigDecimal multiplicar(
        final BigDecimal valorA,
        final Short valorB
    ) {

        return multiplicar( valorA, new BigDecimal( valorB ) );
    }

    /**
     * Retorna a divisão dos valores informados.
     *
     * <p>Autor: GPortes</p>
     *
     * Obs: Arredondamento de 2 decimais.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor1 Dividendo
     * @param valor2 Divisor
     *
     * @return {@link BigDecimal}
     */
    public static BigDecimal dividir(
        final BigDecimal valor1,
        final BigDecimal valor2
    ) {

        BigDecimal dividir = ZERO;
        if (valor1 == null && valor2 != null) {
            dividir = valor2;
        } else if (valor1 != null && valor2 == null) {
            dividir = valor1;
        } else if (valor1 != null ) {
            dividir = valor1.divide(valor2, 2, RoundingMode.UP);
        }

        return dividir;
    }

    /**
     * Retorna a divisão dos valores informados.
     *
     * <p>Autor: GPortes</p>
     *
     * Obs: Arredondamento de 2 decimais.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor1 Dividendo
     * @param valor2 Divisor
     * @param precisao  qtd-Casas-Decimais
     *
     * @return {@link BigDecimal}
     */
    public static BigDecimal dividir(
        final BigDecimal valor1,
        final BigDecimal valor2,
        final int precisao
    ) {

        BigDecimal dividir = ZERO;
        if ( valor1 == null && valor2 != null ) {
            dividir = valor2;
        } else if ( valor1 != null && valor2 == null ) {
            dividir = valor1;
        } else if ( valor1 != null ) {
            dividir = valor1.divide(valor2, precisao, RoundingMode.UP);
        }

        return dividir;
    }

    /**
     * Retorna divisão dos valores informados.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor1    Dividendo
     * @param valor2    Divisor
     *
     * @return Valor dividido.
     */
    public static BigDecimal dividir(
        final BigDecimal valor1,
        final Long valor2
    ) {

        return dividir( valor1,new BigDecimal(valor2) );
    }

    /**
     * Retorna divisão dos valores informados.
     *
     * <p>Autor: GPortes</p>
     *
     * <pre>{@code
     *
     *      // Ex.:
     *      BigDecimal v1 = new BigDecimal( 7485 );
     *      Long v2 = (long) 10000;
     *      int casasDecimais = 6;
     *
     *      BigDecimal valor = UtilNumero.dividir( v1, v2, casasDecimais  );
     *
     *      => 0.748500
     *
     * }</pre>
     *
     * @param dividendo Dividendo
     * @param divisor   Divisor
     * @param escala    Casas decimais
     *
     * @return Valor dividido.
     */
    public static BigDecimal dividir(
        final BigDecimal dividendo,
        final Long divisor,
        int escala
    ) {

        return dividendo == null && divisor == null ?
               ZERO : dividendo != null && divisor != null ?
               dividendo.divide( new BigDecimal( divisor ), escala, ROUND_HALF_UP ) : dividendo != null ?
               dividendo : new BigDecimal( divisor );
    }

    /**
     * Divide valor em várias partes.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor     Valor a ser divido.
     * @param partes    Qtde de partes o valor deve ser dividido.
     *
     * @return Array com os valores divididos.
     */
    public static BigDecimal[] dividir(
        final BigDecimal valor,
        final int partes
    ) {

        if ( valor == null || ehIgual( valor, ZERO ) || partes <= 0 )
            return ARRAY_VAZIO_DE_BIGDECIMAL;

        final BigDecimal divisao = valor.divide( new BigDecimal( partes ), RoundingMode.DOWN );
        final BigDecimal resto = subtrair( valor, multiplicar( divisao, partes ) );

        BigDecimal[] novosValores = new BigDecimal[partes];

        for ( int i=0; i<partes; i++ )
            novosValores[i] = divisao;

        novosValores[partes-1] = somar( novosValores[partes-1], resto );

        return novosValores;
    }

    public static Short[] dividir(
        final Short valor,
        final int partes
    ) {

        if ( valor == null || valor.equals( 0 ) || partes <= 0 )
            return ARRAY_VAZIO;

        if ( partes > valor )
            throw new IllegalArgumentException( "Valor é inferior a qtde de partes" );

        final short divisao = ( short ) ( valor / partes );
        Short resto = ( short ) ( valor - ( divisao * partes ) );

        Short[] novosValores = new Short[partes];
        short tmp;

        for ( int i = 0; i < partes; i++ ) {
            tmp = (short) ( resto > 0 ? 1 : 0 );
            novosValores[i] = (short) ( divisao + tmp );
            resto --;
        }

        return novosValores;
    }

    /**
     * Calcula acrescimento ao valor.
     *
     * Obs: Arredondamento de 2 decimais.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor         Valor a sofrer acrescimo.
     * @param percentual    Percentual de acrescimo.
     *
     * @return {@link BigDecimal}
     */
    public static BigDecimal acrescimoValor(
        final BigDecimal valor,
        final int percentual
    ) {

        if ( valor == null )
            return null;

        if ( percentual == 0 )
            return valor;

        return valor.add( dividir( multiplicar(valor, new BigDecimal(percentual) ), new BigDecimal(100)) );
    }

    /**
     * Calcula acrescimento ao valor.
     *
     * Obs: Arredondamento de 2 decimais.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor         Valor a sofrer acrescimo.
     * @param percentual    Percentual de acrescimo.
     *
     * @return {@link BigDecimal}
     */
    public static BigDecimal acrescimoValor(
        final BigDecimal valor,
        final BigDecimal percentual
    ) {

        if ( valor == null )
            return null;

        if (ehZero(percentual))
            return valor;

        return valor.add( dividir( multiplicar(valor, percentual ), new BigDecimal(100)) );
    }

    /**
     *
     * @param valor1
     * @param valor2
     * @param precisao
     * @return
     */
    public static BigDecimal percentual (
        final BigDecimal valor1,
        final BigDecimal valor2,
        final int precisao
    )  {

        if ( valor1 == null || valor2 == null ) return null;
        if ( Objects.equals(valor2,ZERO) ) return ZERO;

        return valor1.divide(valor2, MathContext.DECIMAL32)
                .multiply(CEM)
                .setScale(precisao,ROUND_HALF_UP);
    }

    /**
     * Extrair raiz do CNPJ
     *
     * <p>Autor: GPortes</p>
     *
     * @param cnpj Cnpj a ser extraido
     *
     * @return {@link Long}
     */
    public static Long extrairRaizCNPJ( final Long cnpj ) {

        return cnpj == null ? null : Long.valueOf( preencheZeroEsquerda(cnpj, 14).substring(0,8) );
    }

    /**
     * Verifica se o valor informado é positivo. ( Deve ser superior a zero )
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor Valor a ser avaliado.
     *
     * @return (true) se o valor é positivo e (false) o contrário
     */
    public static boolean ehValorPositivo( final BigDecimal valor ) {

        return valor != null && valor.doubleValue() > ZERO.doubleValue();
    }

    /**
     * Verifica se o valor informado é negativo.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor Valor a ser avaliado.
     *
     * @return (true) se o valor é negativo e (false) o contrário.
     */
    public static boolean ehValorNegativo( final BigDecimal valor ) {

        return valor != null && valor.doubleValue() < ZERO.doubleValue();
    }

    /**
     * Retorna se o valor esta zerado.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor Valor a ser avaliado.
     *
     * @return (true) se o valor esta zerado e (false) o contrário.
     */
    public static boolean ehZero( final BigDecimal valor ) {

        return ehIgual(valor, ZERO);
    }

    /**
     * Retorna se o valor esta zerado.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor Valor a ser avaliado.
     *
     * @return (true) se o valor esta zerado e (false) o contrário.
     */
    public static <T extends Number> boolean ehZero( final T valor ) {

        return valor != null && "0".endsWith( valor.toString() );
    }

    /**
     * Retorna se o valor esta nulo ou zerado.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor Valor a ser avaliado.
     *
     * @return (true) se o valor esta nulo ou zerado e (false) o contrário.
     */
    public static <T extends Number> boolean ehNuloOuZero( final T valor ) {

        return valor == null || ehZero( valor );
    }

    /**
     * Retorna se valor nulo.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor Valor a ser avaliado.
     *
     * @return (true) se o valor é nulo e (false) o contrário.
     */
    public static boolean ehNulo( final ShortBinder valor ) {

        return valor == null || valor.getValue() == null;
    }

    /**
     * Retorna se valor nulo.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor Valor a ser avaliado.
     *
     * @return (true) se o valor é nulo e (false) o contrário.
     */
    public static boolean ehNulo( final IntegerBinder valor ) {

        return valor == null || valor.getValue() == null;
    }

    /**
     * Retorna se o valorA < valorB
     *
     * <p>Autor: GPortes</p>
     *
     * @param valorA Valor A
     * @param valorB Valor B
     *
     * @return boolean
     */
    public static boolean ehMenor(
        final BigDecimal valorA,
        final BigDecimal valorB
    ) {

        return compararBigDecimal(valorA, valorB) == -1;
    }

    /**
     * Retorna ser valor é menor ou igual a Zero.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor Valor a ser avaliado.
     *
     * @return (true) menor ou igual e (false) o contrário.
     */
    public static boolean ehMenorIgualZero( final BigDecimal valor) {

        return valor != null && ZERO.compareTo(valor) >= 0;
    }

    /**
     * Retorna se valor é menor do que Zero.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor Valor a ser avaliado.
     *
     * @return (true) se positivo e (false) o contrário.
     */
    public static boolean ehMenorZero( final BigDecimal valor ) {

        return ehMenor( valor, ZERO );
    }

    /**
     * Retorna se o valorA > valorB
     *
     * <p>Autor: GPortes</p>
     *
     * @param valorA Valor A
     * @param valorB Valor B
     *
     * @return boolean
     */
    public static boolean ehMaior(
        final BigDecimal valorA,
        final BigDecimal valorB
    ) {

        return compararBigDecimal(valorA, valorB) == 1;
    }

    /**
     * Retorna (true) se valor informado é superior a zero.
     *
     * @param value Valor a ser comparado.
     *
     * @return (true) se valor é maior do que zero e (false) o contrário.
     */
    public static boolean ehMaiorZero( final BigDecimal value ) {

        return ehMaior( value, ZERO );
    }

    /**
     * Verifica se os valores são identicos.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valorA
     * @param valorB
     *
     * @return boolean
     */
    public static boolean ehIgual(
        final BigDecimal valorA,
        final BigDecimal valorB
    ) {

        return compararBigDecimal( valorA, valorB ) == 0;
    }

    /**
     * Retorna se o valorA >= valorB
     *
     * <p>Autor: GPortes</p>
     *
     * @param valorA
     * @param valorB
     *
     * @return boolean
     */
    public static boolean ehMaiorIgual(
        final BigDecimal valorA,
        final BigDecimal valorB
    ) {

        return ehMaior(valorA, valorB) || ehIgual(valorA, valorB);
    }

    /**
     * Realiza a comparacao dos dois valores informados. Este metodo nada mais e
     * do que uma chamada ao metodo compareTo do {@link BigDecimal}, que trata
     * valores nulos que possam ser informados.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor1
     * @param valor2
     *
     * @return Integer
     */
    public static Integer compararBigDecimal(
        final BigDecimal valor1,
        final BigDecimal valor2
    ) {

        int retorno = 0;

        if (valor1 == null && valor2 == null) {
            retorno = 0;
        } else if (valor1 == null && valor2 != null) {
            retorno = -1;
        } else if (valor1 != null && valor2 == null) {
            retorno = 1;
        } else {
            Double doubleValor1 = valor1.doubleValue();
            Double doubleValor2 = valor2.doubleValue();
            retorno = doubleValor1.compareTo(doubleValor2);
        }

        return retorno;
    }

    /**
     * Formata valor em Real.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor
     *
     * @return {@link String}
     */
    public static String formatarMoeda( final BigDecimal valor ) {

        return valor != null
            ? DecimalFormat.getCurrencyInstance( BRASIL ).format( valor )
            : null;
    }

    /**
     * Formata valor.
     *
     * <p>Autor: Cleber</p>
     *
     * @param valor
     *
     * @return {@link String}
     */
    public static String formatarString( final BigDecimal valor ) {

        if ( valor == null ) return null;
        String valorFormat = DecimalFormat.getInstance( BRASIL ).format( valor );
        return valorFormat.contains( "," ) ? valorFormat : valorFormat.concat( ",00" );
    }

    /**
     * Enum usado no retorno de valores de metodos de comparação de valores.
     *
     * <p>Autor: GPortes</p>
     *
     * <pre>
     *     DENTRO_DO_INTERVALO
     *     A_DO_INTERVALO_A_MAIOR
     *     FORA_DO_INTERVALO_A_MENOR
     * </pre>
     *
     */
    public enum R {
        DENTRO_DO_INTERVALO, FORA_DO_INTERVALO_A_MAIOR, FORA_DO_INTERVALO_A_MENOR;
    }

    /**
     * Compara valores no intervalo de valores.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valorAComparar Valor a comparar
     * @param valorInicio Inicio do intervalo
     * @param valorFim Fim do intervalo
     *
     * @return {@link R}
     */
    public static R compararNoIntervalo(
        final BigDecimal valorAComparar,
        final BigDecimal valorInicio,
        final BigDecimal valorFim
    ) {

        String argNulo = "";

        if ( valorAComparar == null )
            argNulo = "[ valorAComparar ]";

        if ( valorInicio == null )
            argNulo += "[ valorInicio ]";

        if ( valorFim == null )
            argNulo += "[ valorFim ]";

        if ( !isVazia(argNulo) )
            throw new IllegalArgumentException("Falta definir argumento(s): " + argNulo + " em UtilNumero.compararNoIntervalo");

        if ( valorFim.compareTo(valorInicio) == -1 )
            throw new IllegalArgumentException("Argumento [valorInicio] < [valorFim ] em UtilNumero.compararNoIntervalo");

        switch ( valorAComparar.compareTo(valorInicio) ) {
            case -1:
                return R.FORA_DO_INTERVALO_A_MENOR;
            case 0:
                return R.DENTRO_DO_INTERVALO;
        }

        if ( valorAComparar.compareTo(valorFim) == 1 ) {
            return R.FORA_DO_INTERVALO_A_MAIOR;
        }

        return R.DENTRO_DO_INTERVALO;
    }

    /**
     * Converte String para Integer, caso String vazia ou null retorna null.
     *
     * @param valor
     *
     * @return {@link Integer}
     */
    public static Integer converterParaInteger( final String valor ) {

        return isVazia(valor) ? null : Integer.valueOf(valor);
    }

    /**
     * Compara se valores são iguais.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value1 Valor a comparar
     * @param value2 Valor a comparar
     *
     * @return boolean true: são iguais e false o contrário.
     */
    public static <T extends Number> boolean ehIgual(
        final T value1,
        final T value2
    ) {

        if ( ( value1 == null && value2 != null ) || ( value1 != null && value2 == null ) )
            return false;

        return Objects.equals( value1.doubleValue() , value2.doubleValue() );
    }

    /**
     * Compara se valores são iguais considerando uma margem de erro.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value1 Valor a comparar
     * @param value2 Valor a comparar
     * @param margem Margem de erro
     *
     * @return (boolean) true: são iguais e false o contrário.
     */
    public static <T extends Number> boolean ehIgual(
        final T value1,
        final T value2,
        int margem
    ) {

        if ( value1.equals(value2) )
            return true;

        if ( value1.doubleValue() < value2.doubleValue() && value2.doubleValue() <= ( value1.doubleValue() + margem ) )
            return true;

        return  ( value1.doubleValue() > value2.doubleValue() && value1.doubleValue() <= ( value2.doubleValue() + margem ) );
    }

    /**
     * Retorna (true) se valor é superior a zero.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value Valor a ser avaliado.
     *
     * @return (true) se é superior
     */
    public static <T extends Number> boolean ehMaiorZero( final T value ) {

        return ( value != null && value.doubleValue() > 0 );
    }

    /**
     * Retorna valor não nulo, caso algum dos argumentos não seja nulo.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value1 Valor a retornar se o mesmo não for nulo.
     * @param value2 Valor a retornar caso value1 for nulo
     *
     * @return Valor não nulo
     *
     */
    public static <T extends Number> T getOrElse(
        final T value1,
        final T value2
    ) {

        if ( value2 == null )
            throw new IllegalArgumentException( "Segundo argumento na chamada de UtilNumero.getOrElse não pode ser nulo" );

        return value1 == null ? value2 : value1;
    }

    /**
     * Retorna zero caso valor informado seja nulo.
     *
     * <p>Autor: GPortes</p>
     *
     * <pre>{@code
     *
     *      // Exemplo:
     *      Short v1, v2;
     *
     *      v1 = null;
     *      v2 = UtilNumero.getOrElseZero( v1 );  // v2 -> 0
     *
     *      v1 = 10;
     *      v2 = UtilNumero.getOrElseZero( v1 );   //  v2 -> 10
     *
     * }</pre>
     *
     * @param number Valor numérico a ser avaliado.
     *
     * @return Valor informado ou Zero caso seja nulo.
     */
    public static <T extends Number> T getOrElseZero(
        final T number,
        Class<T> clazz
    ) {

        if ( number == null ) {
            if ( zeroes.containsKey( clazz ) )
                return clazz.cast( zeroes.get(clazz) );

            throw new IllegalArgumentException ( "Tipo [ " + clazz.getName() + " ] não tratado para getOrElseZero !!" );
        }

        return number ;
    }

    /**
     * Retorna zero caso valor informado seja nulo.
     *
     * <p>Autor: GPortes</p>
     *
     * <pre>{@code
     *
     *      // Exemplo:
     *      BigDecimal v1, v2;
     *
     *      v1 = null;
     *      v2 = UtilNumero.getOrElseZero( v1 );  // v2 -> BigDecimal.ZERO
     *
     *      v1 = BigDecimal.TEN;
     *      v2 = UtilNumero.getOrElseZero( v1 );   //  v2 -> BigDecimal.TEN
     *
     * }</pre>
     *
     * @param value Valor numérico a ser avaliado.
     *
     * @return Valor informado ou Zero caso seja nulo.
     */
    public static BigDecimal getOrElseZero( final BigDecimal value ) {

        return value != null ? value : ZERO;
    }

    /**
     * Retorna zero caso valor informado seja nulo.
     *
     * @param value
     *
     * @return
     */
    public static Long getOrElseZero( final Long value ) {

        return getOrElseZero( value, Long.class );
    }

    public static Short getOrElseZero( final Short value ) {

        return getOrElseZero( value, Short.class );
    }

    /**
     * Retorna array de longs baseado numa String.
     *
     * <p>Autor: GPortes</p>
     *
     * <pre>{@code
     *
     *      // Exemplo:
     *
     *      Long[] values = UtilNumero.getArray( "12,31,54,98,78" , "," );
     *
     *      values[0]; // 12
     *      values[1]; // 31
     *      values[2]; // 54
     *      values[3]; // 98
     *      values[4]; // 78
     *
     *
     * }</pre>
     *
     * @param value String a ser avaliada.
     * @param split Quebra da String.
     *
     * @return Array de Strings.
     */
    public static Long[] getArray(
        final String value,
        final String split
    ) {

        requireNonEmpty( value, "Argumento [ value ] inválido !!" );
        requireNonEmpty( split, "Argumento [ split ] inválido !!" );

        final String[] stringValues = value.split( split );
        final int tamanhoInicial = stringValues.length;
        final Long[] longValues = new Long[tamanhoInicial];
        int tamanhoFinal = -1;

        for ( final String val : stringValues )
            if ( apenasNumero( val.trim() ) )
                longValues[++tamanhoFinal] = Long.valueOf( val.trim() );

        if ( tamanhoFinal != -1 ) {
            int index = -1;
            Long[] newArray = new Long[tamanhoFinal+1];
            for ( int i=0; i<=tamanhoFinal; i++ )
                if ( longValues[i] != null )
                    newArray[++index] = longValues[i];

            if ( index != -1 )
                return newArray;
        }

        return new Long[0] ;
    }

    /**
     *
     * @param elementos
     * @return
     */
    public static List<Long> asListLong( final String elementos ) {

        requireNonEmpty( elementos, "Argumento [ elementos ] inválido !!" );

        List<String> listString = asListNumero( elementos );
        List<Long> listLong = new ArrayList<>( listString.size() );

        for ( String elemento : listString ) {
            try {
                listLong.add( Long.valueOf( elemento ));
            } catch ( NumberFormatException e ) {}
        }

        if ( isVazia( listLong ) )
            return emptyList();

        return listLong;
    }

    /**
     * Extrai intervalo CNPJ.
     *
     * <p>Autor: GPortes</p>
     *
     * @param cnpj CNPJ a ser extraido.
     *
     * @return Intervalo do CNPJ
     *
     * <pre>{@code
     *
     *      // Exemplo:
     *
     *      Long[] cnpjs = extrairIntervaloCNPJ( Long.valueOf( "45543915" ) );
     *
     *      // cnpjs[0] => 45543915000000
     *      // cnpjs[1] => 45543915999999
     *
     * }</pre>
     *
     */
    public static Long[] extrairIntervaloCNPJ( final long cnpj ) {

        String cnpjTemp = String.valueOf( cnpj );

        if ( cnpjTemp.length() > 9 )
            cnpjTemp = cnpjTemp.substring( 0, 8 );

        Long[] cnpjs = new Long[2];

        cnpjs[0] = Long.valueOf( cnpjTemp + "000000" );
        cnpjs[1] = Long.valueOf( cnpjTemp + "999999" );

        return cnpjs;
    }

    /**
     * Setar precisão de um valor decimal.
     *
     * <pre>{@code
     *
     *      // Exemplo:
     *
     *      BigDecimal a = new BigDecimal( "10.12345" );
     *      BigDecimal b = UtilNumero.setarPrecisao( a, 2 ) ;  // 10.12
     *
     * }</pre>
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor     Valor a ser transformado.
     * @param precisao  Qtde de casas decimais.
     *
     * @return Novo valor
     */
    public static BigDecimal setarPrecisao(
        final BigDecimal valor,
        final int precisao
    ) {

        return valor != null ? valor.setScale( precisao, HALF_UP ) : valor;
    }

    /**
     * Converte object para long
     *
     * <p>Autor: GPortes</p>
     *
     * @param value Objeto a ser convertido.
     *
     * @return Possivel numero.
     */
    public static Long toLong( final Object value ) {

        try {
            return value != null ? ((Number) value).longValue() : null;
        } catch ( NumberFormatException | ClassCastException e ) {
            return null;
        }
    }

    /**
     * Convert String para Long.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value String a ser convertida.
     *
     * @return Possivel numero.
     */
    public static Optional<Long> toLong( final String value ) {

        try {
            return value != null ? of( Long.valueOf(value.trim()) ) : empty();
        } catch ( NumberFormatException e ) {
            return empty();
        }
    }

    /**
     * Convert String para Long.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value value String a ser convertida.
     *
     * @return Possível numero.
     */
    public static Long convLong( final String value ) {

        return toLong(value).orElse( null );
    }

    /**
     * Convert Short pava Long.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value Valor short a ser convertido.
     *
     * @return Long
     */
    public static Long toLong( final Short value ) {

        return Long.valueOf(value);
    }

    /**
     * Convert String para Integer.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value String a ser convertida.
     *
     * @return Possivel numero.
     */
    public static Optional<Integer> toInteger( final String value ) {

        try {
            return value != null ? of( Integer.valueOf(value) ) : empty();
        } catch ( NumberFormatException e ) {
            return empty();
        }
    }

    /**
     * Converte Integer para Short
     *
     * <p>Autor: GPortes</p>
     *
     * @param value Valor a ser convertido
     *
     * @return Valor convertido
     */
    public static Short toShort( final Integer value ) {

        return value != null && value <= Short.MAX_VALUE ? value.shortValue() : null;
    }

    /**
     * Converte Long para Short
     *
     * <p>Autor: GPortes</p>
     *
     * @param value Valor a ser convertido
     *
     * @return Valor convertido
     */
    public static Short toShort( final Long value ) {

        return value != null && value <= Short.MAX_VALUE ? value.shortValue() : null;
    }

    /**
     * Converte String para Short.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value String a ser convertida.
     *
     * @return Valor Short.
     */
    public static Optional<Short> toShort( final String value ) {

        try {
            return isVazia(value) ? empty() : of(Short.valueOf(value));
        } catch ( NumberFormatException e ) {
            return empty();
        }
    }

    /**
     * Converte String para Short.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value String a ser convertida.
     *
     * @return Valor Short.
     *
     * <pre>{@code
     *
     *      Short valor1 = UtilNumero.convShort("10"); // 10
     *      Short valor2 = UtilNumero.convShort("abd"); // null
     *      Short valor3 = UtilNumero.convShort(null); // null
     *
     * }</pre>
     *
     */
    public static Short convShort( final String value ) {

        return toShort( value ).orElse( null );
    }

    /**
     * Convert Object para Short.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value Valor a ser convertido para Short.
     *
     * @return Valor Short ou NULL em caso de conversão inválida.
     */
    public static Short toShort( final Object value ) {

        try {
            return ( value != null ) ? ((Number) value).shortValue() : null;
        } catch ( NumberFormatException | ClassCastException e ) {
            return null;
        }
    }

    /**
     * Converte {@code String} para {@code BigDecimal}
     *
     * <p>Autor: GPortes</p>
     *
     * @param value String a ser convertida.
     *
     * @return {@code BigDecimal}
     *
     * <pre>{@code
     *  // Exemplo:
     *  BigDecimal b = UtilNumero.toBigDecimal( "152,26" );
     * }</pre>
     *
     */
    public static Optional<BigDecimal> toBigDecimal( final String value ) {

        if ( isVazia(value) )
            return empty();

        try {
            final String noPoint = Pattern.compile("\\.").matcher( value ).replaceAll("");
            return of(
                new BigDecimal( Pattern.compile(",").matcher( noPoint ).replaceAll(".") )
            );
        } catch ( NumberFormatException e ) {
            return empty();
        }
    }

    /**
     * Retorna zero caso o value seja nulo
     *
     * <p>Autor: Jander Dutra</p>
     *
     * @param value Long a ser comparado
     *
     * @return {@code Long}
     *
     */
    public static Short isNullZero(Short value) {
        return value == null ? (short)0 : value;
    }

    /**
     * Retorna zero caso o value seja nulo
     *
     * <p>Autor: Jander Dutra</p>
     *
     * @param value Long a ser comparado
     *
     * @return {@code Long}
     *
     */
    public static Integer isNullZero(Integer value) {
        return value == null ? 0 : value;
    }

    /**
     * Retorna zero caso o value seja nulo
     *
     * <p>Autor: Jander Dutra</p>
     *
     * @param value Long a ser comparado
     *
     * @return {@code Long}
     *
     */
    public static Long isNullZero(Long value) {
        return value == null ? 0L : value;
    }

    /**
     * Retorna zero caso o value seja nulo
     *
     * <p>Autor: Jander Dutra</p>
     *
     * @param value Long a ser comparado
     *
     * @return {@code BigDecimal}
     *
     */
    public static BigDecimal isNullZero(BigDecimal value) {
        return value == null ? BigDecimal.ZERO : value;
    }

    /**
     * Calcula variação percentual entre dois valores:
     * <blockquote><pre>
     *      BigDecimal vlrMercadoria = new BigDecimal( "50" );
     *      BigDecimal vlrVenda = new BigDecimal( "30" );
     *      BigDecimal percentual = variacaoPercentual( vlrVenda, vlrMercadoria );
     *      // -40.00 => 40% desconto
     * </pre></blockquote>
     *
     * <p>Autor: GPortes</p>
     *
     * @param valorFinal    Valor Final
     * @param valorInicial  Valor Inicial.
     * @param precisao      Casa decimais.
     *
     * @return Percentual do calculo.
     *
     */
    public static BigDecimal variacaoPercentual (
        final BigDecimal valorFinal,
        final BigDecimal valorInicial,
        final int precisao
    )  {

        if ( valorFinal == null || valorInicial == null )
            return ZERO;
        if ( valorInicial.compareTo(ZERO) == 0 && ZERO.compareTo(valorFinal) < 0 )
            return CEM;
        final BigDecimal dif = valorFinal.subtract(valorInicial).setScale(precisao, HALF_DOWN);
        final BigDecimal div = dif.divide(valorInicial,precisao, HALF_DOWN);
        return div.multiply(CEM);
    }

    /**
     * Retorna o valor absoluto.
     *
     * <p>Autor: GPortes</p>
     *
     * @param value
     *
     * @return
     */
    public static BigDecimal abs( final BigDecimal value ) {

        return value != null ? value.abs() : value;
    }
}
