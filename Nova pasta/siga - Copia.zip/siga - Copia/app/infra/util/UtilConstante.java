package infra.util;

import infra.model.Constante;

import static infra.util.UtilString.isVazia;

/**
 * Classe utilitária para tratamento de constantes.
 *
 * <p>Autor: GPortes</p>
 *
 */
public final class UtilConstante {

    /**
     * Verifica se constante e valor estão presentes.
     *
     * <p>Autor: GPortes</p>
     *
     * @param constante
     *
     * @return (true) se esta presente ou false o contrário.
     */
    public static <T> boolean isPresent( Constante<T> constante ) {

        return constante != null && constante.getValor() != null;
    }

    /**
     * Retorna o valor de uma constante.
     *
     * <p>Autor: GPortes</p>
     *
     * @param constante
     *
     * @return Valor da constante.
     */
    public static <T> T getValor( Constante<T> constante ) {

        return constante != null ? constante.getValor() : null;
    }

    /**
     * Retorna a descricao de uma constante.
     *
     * <p>Autor: GPortes</p>
     *
     * @param constante
     *
     * @return Descrição da constante.
     */
    public static <T> String getDescricao( Constante<T> constante ) {

        return constante != null ? constante.getDescricao() : "";
    }

    /**
     * Retorna o valor de uma constante.
     *
     * <p>Autor: GPortes</p>
     *
     * @param constante
     *
     * @return
     */
    public static Integer getValorInteger( Constante<Short> constante ) {

        return constante != null ? constante.getValor().intValue() : null;
    }

    /**
     * Verifica se objeto não é {@code null}. Este método é projetado principalmente
     * para fazer a validação de parâmetros em métodos e construtores, como demonstrado abaixo:
     *
     * <blockquote><pre>
     * public Pessoa(TipoPessoa tipoPessoa) {
     *     this.tipoPessoa = UtilConstante.requireNonEmpty(tipoPessoa);
     * }
     * </pre></blockquote>
     *
     * @param obj       the object reference to check for nullity
     * @param message   the type of the reference
     *
     * @return {@code obj} if not {@code null}
     *
     * @see java.util.Objects#requireNonNull(Object, String)
     *
     * @throws NullPointerException if {@code obj} is {@code null}
     *
     * <p>Autor: GPortes</p>
     */
    public static <T> Constante<T> requireNonNull(
        final Constante<T> obj,
        final String message
    ) {

        if ( isPresent(obj) )
            return obj;

        if ( isVazia(message) )
            throw new NullPointerException( "Constante não pode ser nula" );

        throw new NullPointerException( message );
    }

}
