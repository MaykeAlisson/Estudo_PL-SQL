package infra.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static infra.util.UtilString.isVazia;

public final class UtilEmail {

    /**
     * Valida se email é valido.
     *
     * <p>Autor: Victor</p>
     *
     * @param email Email a ser avaliado.
     *
     * @return (true) se ok e (false) o contrário.
     */
    public static boolean validaEmail( final String email ) {

        if ( isVazia(email) )
            return false;

        Pattern pattern = Pattern.compile("^[\\w-]+(\\.[\\w-]+)*@([\\w-]+\\.)+[a-zA-Z]{2,7}$");
        Matcher matcher = pattern.matcher(email);
        return matcher.find();
    }

}
