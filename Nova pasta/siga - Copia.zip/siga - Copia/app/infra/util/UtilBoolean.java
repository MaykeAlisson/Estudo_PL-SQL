package infra.util;

/**
 * Classe utilitária para tratamento de valores boolean.
 *
 * <p>Autor: GPortes</p>
 *
 * @since 09/10/2016
 *
 */
public final class UtilBoolean {

    /**
     * Retorna false caso o valor informado esteja nulo.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor Valor a ser avaliado.
     *
     * @return (true) ou (false)
     */
    public static boolean getOrElseFalse( final Boolean valor ) {

        return valor == null ? false : valor;
    }

    /**
     * Retorna true caso o valor informado esteja nulo.
     *
     * <p>Autor: GPortes</p>
     *
     * @param valor Valor a ser avaliado.
     *
     * @return (true) ou (false)
     */
    public static boolean getOrElseTrue( final Boolean valor ) {

        return valor == null ? true : valor;
    }

}
