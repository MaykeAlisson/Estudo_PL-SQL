package infra.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

import static infra.util.UtilArquivo.getPastaTemporaria;
import static infra.util.UtilCollections.isVazia;

/**
 * Created by clebersilva on 1/29/16.
 */
public class UtilTxt {


    public static String gerarTxt ( String nomeDoArquivo,
                                        String[] cabecalhos,
                                        int[] lengths,
                                        List<Object[]> dados)  {

        if ( isVazia( dados ) )
            throw new IllegalArgumentException( "Faltou definir argumento [lista]" );

        if ( isVazia( cabecalhos ) )
            throw new IllegalArgumentException( "Faltou definir argumento [cabecalhos]" );

        if ( UtilString.isVazia( nomeDoArquivo ) )
            throw new IllegalArgumentException( "Faltou definir argumento [ nomeDoArquivo ]" );

        final Path path = getPastaTemporaria().resolve(  nomeDoArquivo + ".txt" );
        final String arquivoTxt = path.toAbsolutePath().toString();

        try {
            File file = new File(arquivoTxt);
            FileWriter fw = new FileWriter(file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(montarLinha(cabecalhos,lengths));
            for ( Object[] registro : dados ) {
                bw.write(montarLinha(registro, lengths));
            }
            bw.close();
            return arquivoTxt;
        } catch (IOException e) {
            e.printStackTrace();
            return arquivoTxt;
        }

    }

    public static String montarLinha(Object[] dados, int[] lengths) {

        int dia = 0;
        int mes = 0;
        int ano = 0;

        String linha = "";
        int    qtdColunas = dados.length;
        int i = 0;
        do {
            if (dados[i] == null)  { dados[i] = ""; }
            String value = UtilString.removerAcentosECaracteresEspeciais(dados[i].toString());
            String tipo = dados[i].getClass().getSimpleName();

            if (tipo.equals("Date")) {
                dia = Integer.valueOf(value.substring(8));
                mes = Integer.valueOf(value.substring(5,7));
                ano = Integer.valueOf(value.substring(0,4));
                if (ano == 1900 && dia == 01 && mes == 01) {
                    value = "";  }
                else {
                    value = UtilDate.getDataComoString(UtilDate.getData(dia, mes, ano));
                }
            }
            linha = linha + UtilString.preencherComEspacosADireita(value,lengths[i]);
            i++;
        } while (i < qtdColunas);
        linha = linha + " \n";
        return linha;

    }
}
