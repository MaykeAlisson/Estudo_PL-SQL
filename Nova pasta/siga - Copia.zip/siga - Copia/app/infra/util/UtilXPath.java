package infra.util;

import play.libs.XPath;

import static infra.util.UtilNumero.convLong;
import static infra.util.UtilNumero.convShort;

/**
 * Classe utilitária para leitura de dados XML
 */
public class UtilXPath extends XPath {

    public static Long getLong(
        final String path,
        final Object node
    ) {

        return convLong( selectText(path, node) );
    }    

    public static Short getShort(
        final String path,
        final Object node
    ) {

        return convShort( selectText(path, node) );
    }
}
