package infra.util;

import infra.exceptions.InfraException;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRXlsExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleXlsReportConfiguration;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Collection;

import static infra.util.UtilArquivo.excluirArquivo;
import static infra.util.UtilArquivo.gerarNomeRandomico;
import static infra.util.UtilArquivo.getPastaTemporaria;
import static infra.util.UtilCollections.requiredNonEmpty;
import static infra.util.UtilImpressora.imprimirRelatorio;
import static infra.util.UtilString.requireNonEmpty;
import static java.lang.String.format;
import static java.nio.file.Files.copy;
import static java.nio.file.Files.exists;
import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;
import static java.util.Objects.requireNonNull;

/**
 * Classe utilitária para facilitar interação com a API do JasperReport.
 */
public final class UtilJasper {

    /**
     * Gera arquivo PDF.
     *
     * <p>Autor: GPortes</p>
     *
     * @param lista         Dados a serem persistidos em arquivo PDF.
     * @param arquivoJasper Arquivo jasper
     * @param destino       Destino a ser gerado o PDF.
     *
     */
    public static <T> void saveAsPdf(
        final Collection<T> lista,
        final Path arquivoJasper,
        final Path destino
    ) {
        requiredNonEmpty( lista, "Obrigatório informar [ lista ]" );
        requireNonNull( arquivoJasper, "Obrigatório informar [ arquivoJasper ]" );
        requireNonNull( destino, "Obrigatório informar [ nomeArquivo ]" );

        final Path saida = saveAsPdf( lista, arquivoJasper );
        try {
            copy( saida, destino, REPLACE_EXISTING );
        } catch ( final IOException e ) {
            throw new InfraException( e );
        } finally {
            excluirArquivo( saida );
        }
    }

    /**
     * Gera arquivo PDF.
     *
     * @param lista         Dados a serem persistidos em arquivo PDF.
     * @param arquivoJasper Arquivo jasper.
     *
     * @return Arquivo PDF
     */
    public static <T> Path saveAsPdf(
        final Collection<T> lista,
        final Path arquivoJasper
    ) {

        requiredNonEmpty( lista, "Obrigatório informar [ lista ]" );
        requireNonNull( arquivoJasper, "Obrigatório informar [ arquivoJasper ]" );

        if ( exists( arquivoJasper ) ) {
            try {
                final Path saida = getPastaTemporaria().resolve( "jasper" + gerarNomeRandomico("pdf") );
                final JasperPrint jasperPrint = JasperFillManager.fillReport(
                        arquivoJasper.toString(),
                        null,
                        new JRBeanCollectionDataSource( lista )
                );
                JasperExportManager.exportReportToPdfFile( jasperPrint, saida.toString() );
                return saida;
            } catch ( JRException e ) {
                throw new InfraException( e );
            }
        } else {
            throw new InfraException( format( "Não localizou [%s] ", arquivoJasper ) );
        }
    }

    public static <T> Path saveAsExcel(
        final Collection<T> lista,
        final Path arquivoJasper
    ) {

        requiredNonEmpty( lista, "Obrigatório informar [ lista ]" );
        requireNonNull( arquivoJasper, "Obrigatório informar [ arquivoJasper ]" );

        if ( exists( arquivoJasper ) ) {
            try {
                final Path saida = getPastaTemporaria().resolve( "jasper" + gerarNomeRandomico("xls") );

                final JasperPrint jasperPrint = JasperFillManager.fillReport(
                        arquivoJasper.toString(),
                        null,
                        new JRBeanCollectionDataSource( lista )
                );

                JRXlsExporter xlsExporter = new JRXlsExporter();
                xlsExporter.setExporterInput(new SimpleExporterInput(jasperPrint));
                xlsExporter.setExporterOutput(new SimpleOutputStreamExporterOutput(saida.toFile()));
                SimpleXlsReportConfiguration configuration = new SimpleXlsReportConfiguration();
                configuration.setRemoveEmptySpaceBetweenRows(true);
                configuration.setDetectCellType(true);
                configuration.setWhitePageBackground(false);
                xlsExporter.setConfiguration(configuration);
                xlsExporter.exportReport();
                return saida;
            } catch ( JRException e ) {
                throw new InfraException( e );
            }
        } else {
            throw new InfraException( format( "Não localizou [%s] ", arquivoJasper ) );
        }
    }

    /**
     * Imprime relatório na impressora informada.
     *
     * <p>Autor: GPortes</p>
     *
     * @param relatorio         Dados do relatório.
     * @param arquivoJasper     Nome do arquivo Jasper.
     * @param destinoImpressora Nome da impressora
     */
    public static <T> void imprimirPdf(
        final Collection<T> relatorio,
        final Path arquivoJasper,
        final String destinoImpressora
    ) {

        requiredNonEmpty( relatorio, "Obrigatório informar [ lista ]" );
        requireNonNull( arquivoJasper, "Obrigatório informar [ nomeArquivoJasper ]" );
        requireNonEmpty( destinoImpressora, "Obrigatório informar [ destinoImpressora ]" );

        if ( exists( arquivoJasper ) ) {
            try {
                final JasperPrint jasperPrint = JasperFillManager.fillReport(
                        arquivoJasper.toString(),
                        null,
                        new JRBeanCollectionDataSource( relatorio )
                );
                imprimirRelatorio( jasperPrint, destinoImpressora );
            } catch ( final JRException e ) {
                throw new InfraException( e );
            }
        } else {
            throw new InfraException( format( "Não localizou [%s] ", arquivoJasper ) );
        }
    }

}
