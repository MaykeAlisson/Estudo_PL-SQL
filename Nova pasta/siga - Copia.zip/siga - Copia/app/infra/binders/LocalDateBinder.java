package infra.binders;

import play.mvc.PathBindable;
import play.mvc.QueryStringBindable;

import java.time.LocalDate;
import java.util.Map;
import java.util.Optional;

import static java.time.LocalDate.parse;
import static java.time.format.DateTimeFormatter.ofPattern;
import static java.util.Optional.empty;
import static java.util.Optional.of;

/**
 * Binder para rotas formadas com valores {@link java.time.LocalDate}
 *
 * <p>Autor: GPortes</p>
 */
public class LocalDateBinder implements PathBindable<LocalDateBinder>,
                                        QueryStringBindable<LocalDateBinder> {

    private static final String FORMATO = "d-MM-yyyy";

    private LocalDate value;

    public LocalDateBinder() {

    }

    public LocalDateBinder( final LocalDate value ) {

        this.value = value;
    }

    public LocalDate getValue() {

        return value;
    }

    @Override
    public LocalDateBinder bind(
        final String key,
        final String data
    ) {
        try {
            this.value = parse( data, ofPattern( FORMATO ) );
        } catch ( final Throwable e ) {
            this.value = null;
        }
        return this;
    }

    @Override
    public Optional<LocalDateBinder> bind(
        final String key,
        final Map<String, String[]> data
    ) {
        if ( data.isEmpty() )
            return empty();

        try {
            return of( new LocalDateBinder( parse( data.get( key )[0], ofPattern( FORMATO )) ) );
        } catch ( final Throwable e ) {
            return empty();
        }
    }

    @Override
    public String unbind( final String key ) {

        return null;
    }

    @Override
    public String javascriptUnbind() {

        return null;
    }

    public static LocalDate getValue( final LocalDateBinder binder ) {

        return binder != null ? binder.getValue() : null;
    }
}
