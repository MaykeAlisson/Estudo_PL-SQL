package infra.binders;

import play.mvc.PathBindable;
import play.mvc.QueryStringBindable;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static infra.util.UtilCollections.isVazia;
import static java.lang.Short.valueOf;
import static java.util.Collections.emptyList;
import static java.util.Optional.empty;
import static java.util.Optional.of;
import static java.util.stream.Collectors.toList;

/**
 * Binder para rotas formadas com tipos de dados [Short]
 *
 * <p>Autor: GPortes</p>
 *
 * <p>https://www.playframework.com/documentation/2.2.2/api/java/play/mvc/QueryStringBindable.html</p>
 *
 */
public class ShortBinder implements PathBindable<ShortBinder>, QueryStringBindable<ShortBinder> {

    private Short value;

    public ShortBinder() {
    }

    public ShortBinder( final Short value ) {

        this.value = value;
    }

    public ShortBinder( final Integer value ) {

        this.value = value == null ? null : value.shortValue();
    }

    public ShortBinder( final String value ) {

        this.value = valueOf( value );
    }

    public Short getValue() {

        return value;
    }

    @Override
    public ShortBinder bind(
        final String key,
        final String txt
    ) {

        try {
            this.value = valueOf( txt );
        } catch ( final Throwable e ) {
            this.value = null;
        }
        return this;
    }

    @Override
    public Optional<ShortBinder> bind(
        final String key,
        final Map<String, String[]> data
    ) {
        if ( isVazia(data) )
            return empty();

        try {
            return of( new ShortBinder( data.get( key )[0] ) );
        } catch ( final Throwable e ) {
            return empty();
        }
    }

    @Override
    public String unbind( final String s ) {

        return  value == null ? "" : value.toString();
    }

    @Override
    public String javascriptUnbind() {

        return null;
    }

    public static Short getValue( final ShortBinder value ) {

        return value != null ? value.getValue() : null;
    }

    public static Short getValue( final Optional<ShortBinder> possivelValue ) {

        return getValue( possivelValue.orElse( null ) );
    }

    public static List<Short> getValue( final List<ShortBinder> values ) {

        if ( isVazia( values ) )
            return emptyList();

        return values
                .stream()
                .map( shortBinder -> shortBinder.getValue() )
                .collect( toList() );
    }

}
