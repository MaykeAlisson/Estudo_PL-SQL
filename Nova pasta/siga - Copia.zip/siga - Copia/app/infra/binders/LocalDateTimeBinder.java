package infra.binders;

import infra.util.UtilCollections;
import play.mvc.PathBindable;
import play.mvc.QueryStringBindable;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.Optional;

import static infra.util.UtilCollections.isVazia;
import static java.time.LocalDateTime.parse;
import static java.time.format.DateTimeFormatter.ofPattern;
import static java.util.Optional.empty;
import static java.util.Optional.of;

/**
 * Binder para rotas formadas com valores {@link java.time.LocalDate}
 *
 * <p>Autor: GPortes</p>
 */
public class LocalDateTimeBinder implements PathBindable<LocalDateTimeBinder>,
        QueryStringBindable<LocalDateTimeBinder> {

    private static final String FORMATO_1 = "d-MM-yyyy HH:mm:ss";
    private static final String FORMATO_2 = "d-MM-yyyy HH:mm";
    private static final String FORMATO_3 = "d-MM-yyyy";

    private LocalDateTime value;

    public LocalDateTimeBinder() {

    }

    public LocalDateTimeBinder( final LocalDateTime value ) {

        this.value = value;
    }

    public LocalDateTime getValue() {

        return value;
    }

    @Override
    public LocalDateTimeBinder bind(
            final String key,
            final String data
    ) {
        try {
            this.value = parse( data, ofPattern( FORMATO_1 ) );
        } catch ( final Throwable e ) {
            this.value = null;
        }
        return this;
    }

    @Override
    public Optional<LocalDateTimeBinder> bind(
            final String key,
            final Map<String, String[]> data
    ) {
        if ( isVazia(data) )
            return empty();

        try {
            final String dataHora = data.get(key)[0];
            final int tam = dataHora.length();
            String formato = FORMATO_1;
            if ( tam == FORMATO_2.length() + 1 )
                formato = FORMATO_2;
            else if ( tam == FORMATO_3.length() + 1 )
                formato = FORMATO_3;
            return of( new LocalDateTimeBinder( parse( dataHora, ofPattern( formato )) ) );
        } catch ( final Throwable e ) {
            return empty();
        }
    }

    @Override
    public String unbind( final String key ) {

        return null;
    }

    @Override
    public String javascriptUnbind() {

        return null;
    }

    public static LocalDateTime getValue( final LocalDateTimeBinder binder ) {

        return binder != null ? binder.getValue() : null;
    }
}
