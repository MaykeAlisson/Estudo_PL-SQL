package infra.binders;

import play.mvc.PathBindable;
import play.mvc.QueryStringBindable;

import java.math.BigDecimal;
import java.util.Map;
import java.util.Optional;

import static infra.util.UtilNumero.formatarString;
import static java.util.Optional.empty;
import static java.util.Optional.of;

/**
 * Binder para rotas formadas com valores {@link java.math.BigDecimal}
 *
 * <p>Autor: GPortes</p>
 */
public class BigDecimalBinder implements PathBindable<BigDecimalBinder>,
                                         QueryStringBindable<BigDecimalBinder> {

    private BigDecimal value;

    public BigDecimalBinder( ) {
    }

    public BigDecimalBinder( final BigDecimal value ) {

        this.value = value;
    }

    public BigDecimal getValue( ) {

        return value;
    }

    @Override
    public BigDecimalBinder bind( final String key,
                                  final String data ) {
        try {
            this.value = new BigDecimal( data );
        } catch ( NumberFormatException e ) {
            this.value = null;
        }
        return this;
    }

    @Override
    public Optional<BigDecimalBinder> bind( final String key,
                                            Map<String, String[]> map ) {

        if ( map.isEmpty() )
            return empty();

        final String data = map.get( key )[0];
        final BigDecimal value = new BigDecimal( data );
        return of( new BigDecimalBinder( value ) );
    }

    @Override
    public String unbind( String txt ) {

        return formatarString( this.value );
    }

    @Override
    public String javascriptUnbind( ) {

        return null;
    }
}
