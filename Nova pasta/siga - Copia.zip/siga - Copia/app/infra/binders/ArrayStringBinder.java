package infra.binders;

import infra.util.UtilCollections;
import play.mvc.PathBindable;
import play.mvc.QueryStringBindable;

import java.util.Map;
import java.util.Optional;

import static infra.util.UtilString.isVazia;
import static java.util.Optional.empty;
import static java.util.Optional.of;

/**
 * Binder para rotas formadas no formato de array de strings
 *
 * <p>Autor: GPortes</p>
 *
 * <p>https://www.playframework.com/documentation/2.3.6/api/java/play/mvc/QueryStringBindable.html</p>
 *
 */
public class ArrayStringBinder implements PathBindable<ArrayStringBinder>, QueryStringBindable<ArrayStringBinder> {

    private String value[];

    public ArrayStringBinder() {
    }

    public ArrayStringBinder( final String[] value ) {

        this.value = value;
    }

    public String[] getValue() {

        return value;
    }

    @Override
    public ArrayStringBinder bind(
        final String key,
        final String data
    ) {

        this.value = isVazia(data) ? null : data.split(",");
        return this;
    }

    @Override
    public Optional<ArrayStringBinder> bind(
        final String key,
        final Map<String, String[]> map
    ) {

        if ( UtilCollections.isVazia( map ) )
            return empty();

        final String data = map.get( key )[0];
        final String values[] = isVazia(data) ? null : data.split(",");

        return of(new ArrayStringBinder(values));
    }

    @Override
    public String unbind( String key ) {

        return  value == null ? "" : value.toString();
    }

    @Override
    public String javascriptUnbind() {

        return null;
    }

    public static String[] getValue( final ArrayStringBinder binder ) {

        return binder != null ? binder.getValue() : null;
    }

}
