package infra.binders;

import play.mvc.PathBindable;
import play.mvc.QueryStringBindable;

import java.util.Map;
import java.util.Optional;

import static infra.util.UtilCollections.isVazia;
import static java.lang.Long.valueOf;
import static java.util.Optional.empty;
import static java.util.Optional.of;

/**
 *  Binder para rotas formadas com valores {@link java.lang.Long}
 *
 *  <p>Autor: GPortes</p>
 */
public class LongBinder implements PathBindable<LongBinder>, QueryStringBindable<LongBinder> {

    private Long value;

    public LongBinder() {
    }

    public LongBinder( final Long value ) {

        this.value = value;
    }

    public Long getValue() {

        return value;
    }

    @Override
    public LongBinder bind(
        final String key,
        final String txt
    ) {
        try {
            this.value = valueOf( txt );
        } catch ( final Throwable e ) {
            this.value = null;
        }
        return this;
    }

    @Override
    public Optional<LongBinder> bind(
        final String key,
        final Map<String, String[]> data
    ) {
        if ( isVazia(data) )
            return empty();

        try {
            return of( new LongBinder( valueOf( data.get(key)[0] ) ) );
        } catch ( final Throwable e ) {
            return empty();
        }
    }

    @Override
    public String unbind( final String s ) {

        return  value == null ? "" : value.toString();
    }

    @Override
    public String javascriptUnbind() {

        return null;
    }

    public static Long getValue( final LongBinder binder ) {

        return binder != null ? binder.getValue() : null;
    }
}
