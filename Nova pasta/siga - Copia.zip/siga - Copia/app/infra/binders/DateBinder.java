package infra.binders;

import play.mvc.PathBindable;
import play.mvc.QueryStringBindable;

import java.util.Date;
import java.util.Map;
import java.util.Optional;

import static infra.util.UtilDate.getDataComoString;
import static infra.util.UtilDate.getStringComoDate;
import static infra.util.UtilString.isVazia;
import static java.util.Optional.empty;
import static java.util.Optional.of;

/**
 * Binder para rotas formadas com valores {@link java.util.Date}
 *
 * <p>Autor: GPortes</p>
 */
public class DateBinder implements PathBindable<DateBinder>, QueryStringBindable<DateBinder> {

    // Formatos default.
    private static final String FORMATO = "dd-MM-yyyy HH:mm:ss";
    private static final String FORMATO_HORA = "dd-MM-yyyy HH:mm";
    private static final String FORMATO_SIMPLES = "dd-MM-yyyy";

    private Date value;

    public DateBinder() {
    }

    public DateBinder( final Date value ) {

        this.value = value;
    }

    public Date getValue() {

        return value;
    }

    @Override
    public DateBinder bind( final String key,
                            final String data ) {

        this.value = getStringComoDate( data, getFormato( data ) );
        return this;
    }

    @Override
    public Optional<DateBinder> bind(final String key,
                                     final Map<String, String[]> map ) {

        if ( map.isEmpty() )
            return empty();

        final String data = map.get( key )[0];
        final Date value = getStringComoDate( data, getFormato( data ) );

        return of( new DateBinder( value ) );
    }

    @Override
    public String unbind( String txt ) {

        return getDataComoString( value, FORMATO );
    }

    @Override
    public String javascriptUnbind() {

        return null;
    }

    private String getFormato( final String data ) {

        if ( isVazia( data ) )
            return "";

        int tamanho = data.length();

        if ( tamanho == FORMATO.length() )
            return FORMATO;

        if ( tamanho == FORMATO_HORA.length() )
            return FORMATO_HORA;

        if ( data.matches("\\d{4}-\\d{2}-\\d{2}") )
            return "yyyy-MM-dd";

        return FORMATO_SIMPLES;
    }

    public static Date getValue( final DateBinder binder ) {

        return binder != null ? binder.getValue() : null;
    }
}
