package infra.binders;

import play.mvc.PathBindable;
import play.mvc.QueryStringBindable;

import java.util.Map;
import java.util.Optional;

import static infra.util.UtilCollections.isVazia;
import static infra.util.UtilNumero.getArray;
import static java.util.Optional.empty;
import static java.util.Optional.of;

/**
 * Binder para rotas formadas no formato de array de long
 *
 * <p>Autor: GPortes</p>
 *
 * <p>https://www.playframework.com/documentation/2.3.6/api/java/play/mvc/QueryStringBindable.html</p>
 *
 */
public class ArrayLongBinder implements PathBindable<ArrayLongBinder>, QueryStringBindable<ArrayLongBinder> {

    private Long value[];

    public ArrayLongBinder() {

    }

    public ArrayLongBinder( final Long[] value ) {

        this.value = value;
    }

    public Long[] getValue() {

        return value;
    }

    @Override
    public ArrayLongBinder bind(
        final String key,
        final String data
    ) {

        this.value = getArray( data, "," );
        return this;
    }

    @Override
    public Optional<ArrayLongBinder> bind(
        final String key,
        final Map<String, String[]> map
    ) {

        if ( isVazia( map ) )
            return empty();

        final String data = map.get( key )[0];
        final Long values[] = getArray( data, "," );
        return of( new ArrayLongBinder( values ) );
    }

    @Override
    public String unbind( final String key ) {

        return  value == null ? "" : value.toString();
    }

    @Override
    public String javascriptUnbind() {

        return null;
    }

    public static Long[] getValue( final ArrayLongBinder binder ) {

        return binder != null ? binder.getValue() : null;
    }
}
