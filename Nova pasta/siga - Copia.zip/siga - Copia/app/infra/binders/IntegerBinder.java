package infra.binders;

import play.mvc.PathBindable;
import play.mvc.QueryStringBindable;

import java.util.Map;
import java.util.Optional;

import static infra.util.UtilCollections.isVazia;
import static java.lang.Integer.valueOf;
import static java.util.Optional.empty;
import static java.util.Optional.of;

/**
 * Binder para rotas formadas com valores {@link java.lang.Integer}
 *
 * <p>Autor: GPortes</p>
 */
public class IntegerBinder implements PathBindable<IntegerBinder>, QueryStringBindable<IntegerBinder> {

    private Integer value;

    public IntegerBinder() {
    }

    public IntegerBinder( final Integer value ) {

        this.value = value;
    }

    public Integer getValue() {

        return value;
    }

    @Override
    public IntegerBinder bind(
        final String key,
        final String txt
    ) {
        try {
            this.value = valueOf( txt );
        } catch ( final Throwable e ) {
            this.value = null;
        }
        return this;
    }

    @Override
    public Optional<IntegerBinder> bind(
        final String key,
        final Map<String, String[]> data
    ) {
        if ( isVazia(data) )
            return empty();

        try {
            return of( new IntegerBinder( valueOf( data.get(key)[0] ) ) );
        } catch ( final Throwable e ) {
            return empty();
        }
    }

    @Override
    public String unbind( final String s ) {

        return  value == null ? "" : value.toString();
    }

    @Override
    public String javascriptUnbind() {

        return null;
    }

    public static Integer getValue( final IntegerBinder binder ) {

        return binder != null ? binder.getValue() : null;
    }
}
