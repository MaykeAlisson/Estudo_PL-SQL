package infra.binders;

import play.mvc.PathBindable;
import play.mvc.QueryStringBindable;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static java.util.Optional.empty;
import static java.util.Optional.of;

public class BooleanBinder implements PathBindable<BooleanBinder>,
                                      QueryStringBindable<BooleanBinder> {

    private Boolean value;

    public BooleanBinder() {
    }

    public BooleanBinder( final Boolean value ) {

        this.value = value;
    }

    public Boolean getValue() {

        return value;
    }

    @Override
    public BooleanBinder bind(
        final String key,
        final String data
    ) {

        return Objects.equals(data,"true") || Objects.equals(data,"false") ? this : null;
    }

    @Override
    public Optional<BooleanBinder> bind(
        final String key,
        final Map<String, String[]> data
    ) {
        if ( data.isEmpty() )
            return empty();

        return of( new BooleanBinder( Objects.equals((data.get(key)[0]).toLowerCase(),"true") ) );
    }

    @Override
    public String unbind( final String key ) {

        return null;
    }

    @Override
    public String javascriptUnbind() {

        return null;
    }

    public static Boolean getValue( final BooleanBinder binder ) {

        return binder != null ? binder.getValue() : null;
    }

    public static BooleanBinder newInstance( final String value ) {

        return new BooleanBinder( Objects.equals("true",value) );
    }

}
