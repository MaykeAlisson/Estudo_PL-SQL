package infra.validators;

import infra.annotations.NaoVazio;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import static infra.util.UtilString.isVazia;

public class NaoVazioValidator implements ConstraintValidator<NaoVazio, String> {

    private String message;

    @Override
    public void initialize( final NaoVazio constraintAnnotation ) {

        this.message = constraintAnnotation.message();
    }

    @Override
    public boolean isValid(
        final String value,
        final ConstraintValidatorContext context
    ) {

        return !isVazia(value);
    }
}
